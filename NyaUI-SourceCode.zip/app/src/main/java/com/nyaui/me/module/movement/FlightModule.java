package com.nyaui.me.module.movement;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class FlightModule extends Module {
    public FlightModule() {
        super("Flight", ModuleCategory.MOVEMENT);
        setChineseName("Flight");
    }

    protected void onEnable() {
        try { SafeCall.setEnabled("Fly"); } catch (Throwable t) {}
    }

    protected void onDisable() {
        try { SafeCall.setEnabled("Fly"); } catch (Throwable t) {}
    }

    public void configureSubMenu(SubMenuPanel subMenu) {
        super.configureSubMenu(subMenu);
        new FlyModule().configureSubMenu(subMenu);
    }
}
