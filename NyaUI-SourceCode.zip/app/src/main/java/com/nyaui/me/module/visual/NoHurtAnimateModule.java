package com.nyaui.me.module.visual;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;

public class NoHurtAnimateModule extends Module {
    public NoHurtAnimateModule() { super("NoHurtAnimate", ModuleCategory.VISUAL, ""); setChineseName("No Hurt Cam"); }
    public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("NoHurtAnimate"); } catch (Throwable t) {} }
    public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("NoHurtAnimate"); } catch (Throwable t) {} }
}
