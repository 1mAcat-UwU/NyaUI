package com.nyaui.me.ui;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.nyaui.me.module.Module;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class ModuleItemView extends LinearLayout implements ThemeManager.OnThemeModeChangeListener, ThemeManager.OnRainbowColorUpdateListener {

    private final Module module;
    private final MenuView parentMenu;

    private final FrameLayout mainContainer;
    private final TextView normalText;
    private final TextView boldText;
    private final SubMenuPanel subMenuPanel;

    private ValueAnimator colorAnimator;
    private final Handler longPressHandler = new Handler(Looper.getMainLooper());
    private Runnable longPressRunnable;
    private boolean isLongPressing = false;

    private float touchStartX = 0f;
    private float touchStartY = 0f;
    private boolean hasMoved = false;
    private final int touchSlop;

    private float scaleFactor = 1.0f;

    private boolean lastKnownState = false;

    private static final long LONG_PRESS_DELAY = 500L;
    private static final int CORNER_RADIUS_DP = 8;

    public ModuleItemView(Context context, Module module, MenuView parentMenu, float scaleFactor) {
        super(context);
        this.module = module;
        this.parentMenu = parentMenu;
        this.touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
        this.lastKnownState = module.isEnabled();
        this.scaleFactor = scaleFactor;

        setOrientation(VERTICAL);
        setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        mainContainer = createMainContainer();
        addView(mainContainer);

        normalText = createNormalText();
        boldText = createBoldText();
        mainContainer.addView(normalText);
        mainContainer.addView(boldText);

        subMenuPanel = new SubMenuPanel(context, module, scaleFactor);
        addView(subMenuPanel);

        module.configureSubMenu(subMenuPanel);

        subMenuPanel.setOnStateChangedListener(() -> {
            if (parentMenu != null) {
                parentMenu.recalculateHeight();
            }
        });

        updateVisualState(module.isEnabled(), false);

        setupTouchListeners();

        ThemeManager.addModeListener(this);
        ThemeManager.addRainbowColorUpdateListener(this);
    }

    public void syncWithModuleState(boolean currentState) {
        if (lastKnownState != currentState) {
            lastKnownState = currentState;
            updateVisualState(currentState, true);
        }
    }

    public void updateScale(float scaleFactor) {
        this.scaleFactor = scaleFactor;

        LayoutParams params = (LayoutParams) mainContainer.getLayoutParams();
        params.setMargins(0, 0, 0, 0);
        mainContainer.setLayoutParams(params);

        float textSize = 11f * scaleFactor;
        int paddingV = scaled(7);
        int paddingH = scaled(12);

        normalText.setTextSize(textSize);
        normalText.setPadding(paddingH, paddingV, paddingH, paddingV);

        boldText.setTextSize(textSize);
        boldText.setPadding(paddingH, paddingV, paddingH, paddingV);

        subMenuPanel.updateScale(scaleFactor);

        requestLayout();
    }

    private int scaled(int baseDp) {
        return (int) (dpToPx(baseDp) * scaleFactor);
    }

    private FrameLayout createMainContainer() {
        FrameLayout container = new FrameLayout(getContext());

        LayoutParams params = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        params.setMargins(0, 0, 0, 0);
        container.setLayoutParams(params);

        GradientDrawable initialBackground = new GradientDrawable();
        initialBackground.setColor(Color.TRANSPARENT);
        initialBackground.setCornerRadius(0f);
        container.setBackground(initialBackground);

        return container;
    }

    private TextView createNormalText() {
        TextView textView = new TextView(getContext());
        textView.setText(module.getName());
        textView.setTextSize(11f * scaleFactor);
        textView.setTextColor(ThemeManager.getTextPrimary());
        textView.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        int paddingV = scaled(7);
        int paddingH = scaled(12);
        textView.setPadding(paddingH, paddingV, paddingH, paddingV);
        textView.setTypeface(Typeface.DEFAULT);
        textView.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
        ));
        return textView;
    }

    private TextView createBoldText() {
        TextView textView = new TextView(getContext());
        textView.setText(module.getName());
        textView.setTextSize(11f * scaleFactor);
        textView.setTextColor(ThemeManager.getTextOnTheme());
        textView.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        int paddingV = scaled(7);
        int paddingH = scaled(12);
        textView.setPadding(paddingH, paddingV, paddingH, paddingV);
        textView.setTypeface(Typeface.DEFAULT_BOLD);
        textView.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
        ));
        textView.setAlpha(0f);
        return textView;
    }

    private void setupTouchListeners() {
        mainContainer.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    v.getParent().requestDisallowInterceptTouchEvent(true);
                    touchStartX = event.getX();
                    touchStartY = event.getY();
                    hasMoved = false;
                    isLongPressing = false;

                    longPressRunnable = () -> {
                        if (!hasMoved) {
                            isLongPressing = true;
                            onLongPress();
                        }
                    };
                    longPressHandler.postDelayed(longPressRunnable, LONG_PRESS_DELAY);

                    return true;

                case MotionEvent.ACTION_MOVE:
                    float deltaX = Math.abs(event.getX() - touchStartX);
                    float deltaY = Math.abs(event.getY() - touchStartY);

                    if (!hasMoved && deltaY > deltaX && deltaY > touchSlop) {
                        hasMoved = true;
                        v.getParent().requestDisallowInterceptTouchEvent(false);
                        cancelLongPressDetection();
                    }

                    boolean isOutOfBounds = event.getX() < 0 || event.getX() > getWidth() || event.getY() < 0 || event.getY() > getHeight();

                    if (isOutOfBounds) {
                        hasMoved = true;
                        cancelLongPressDetection();
                    }
                    return true;

                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    v.getParent().requestDisallowInterceptTouchEvent(false);
                    cancelLongPressDetection();

                    if (!hasMoved && !isLongPressing) {
                        module.toggle();
                        lastKnownState = module.isEnabled();
                        updateVisualState(lastKnownState, true);
                    }

                    isLongPressing = false;
                    hasMoved = false;
                    return true;
            }
            return false;
        });
    }

    private void onLongPress() {
        performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
        subMenuPanel.toggle();
    }

    private void cancelLongPressDetection() {
        if (longPressRunnable != null) {
            longPressHandler.removeCallbacks(longPressRunnable);
        }
        longPressRunnable = null;
    }

    public void updateVisualState(boolean isEnabled, boolean animated) {
        if (animated) {
            animateToState(isEnabled);
        } else {
            setStateImmediately(isEnabled);
        }
    }

    private void setStateImmediately(boolean isEnabled) {
        GradientDrawable bg = (GradientDrawable) mainContainer.getBackground();
        bg.setColor(isEnabled ? ThemeManager.getAccentColor() : Color.TRANSPARENT);
        bg.setCornerRadius(0f);

        if (isEnabled) {
            boldText.setTextColor(ThemeManager.getTextOnTheme());
        }

        normalText.setAlpha(isEnabled ? 0f : 1f);
        boldText.setAlpha(isEnabled ? 1f : 0f);
    }

    private void animateToState(boolean isEnabled) {
        if (colorAnimator != null) {
            colorAnimator.cancel();
        }

        GradientDrawable bg = (GradientDrawable) mainContainer.getBackground();

        int fromColor = (bg.getColor() != null) ? bg.getColor().getDefaultColor() : Color.TRANSPARENT;
        int toColor = isEnabled ? ThemeManager.getAccentColor() : Color.TRANSPARENT;

        colorAnimator = ValueAnimator.ofObject(new ArgbEvaluator(), fromColor, toColor);
        colorAnimator.setDuration(150);
        colorAnimator.addUpdateListener(animator -> {
            bg.setColor((int) animator.getAnimatedValue());
            if (isEnabled) {
                boldText.setTextColor(ThemeManager.getTextOnTheme());
            }
        });
        colorAnimator.start();

        normalText.animate().alpha(isEnabled ? 0f : 1f).setDuration(150).start();
        boldText.animate().alpha(isEnabled ? 1f : 0f).setDuration(150).start();
    }

    public void updateThemeColor() {
        if (module.isEnabled()) {
            GradientDrawable bg = (GradientDrawable) mainContainer.getBackground();
            bg.setColor(ThemeManager.getAccentColor());
            boldText.setTextColor(ThemeManager.getTextOnTheme());
        }
    }

        public void onThemeModeChanged(boolean isDark) {
        normalText.setTextColor(ThemeManager.getTextPrimary());
        if (module.isEnabled()) {
            boldText.setTextColor(ThemeManager.getTextOnTheme());
        }
    }

        public void onRainbowColorUpdate(int color) {
    }

    public void closeSubMenuIfOpen() {
        if (subMenuPanel.isOpen()) {
            subMenuPanel.forceCollapse();
        }
    }

    public void cancelAllAnimations() {
        if (colorAnimator != null) colorAnimator.cancel();
        mainContainer.animate().cancel();
        normalText.animate().cancel();
        boldText.animate().cancel();
        cancelLongPressDetection();
    }

        protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        cancelAllAnimations();
        longPressHandler.removeCallbacksAndMessages(null);
        ThemeManager.removeModeListener(this);
        ThemeManager.removeRainbowColorUpdateListener(this);
    }

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density);
    }
}
