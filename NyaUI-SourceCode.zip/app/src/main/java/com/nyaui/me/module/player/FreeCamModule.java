package com.nyaui.me.module.player;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;

public class FreeCamModule extends Module {
    public FreeCamModule() { super("FreeCam", ModuleCategory.PLAYER, ""); setChineseName("Free Camera"); }
    public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("FreeCam"); } catch (Throwable t) {} }
    public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("FreeCam"); } catch (Throwable t) {} }
}
