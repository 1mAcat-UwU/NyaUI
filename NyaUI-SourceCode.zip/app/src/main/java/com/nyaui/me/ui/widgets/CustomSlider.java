package com.nyaui.me.ui.widgets;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewParent;
import android.view.animation.AnimationUtils;

import com.nyaui.me.ui.ThemeManager;

public class CustomSlider extends View {
    private final Paint bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint thumbPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();

    private float min = 0f;
    private float max = 100f;
    private float value = 0f;
    private float step = 1f;
    private float prog = 0f;
    private float visualProg = 0f;
    private float thumbScale = 1f;
    private float targetScale = 1f;
    private long lastFrame = 0L;
    private int trackH;
    private float scaleFactor = 1f;
    private boolean classicStyle = false;
    private boolean dragging = false;
    private OnValueChangeListener listener;
    private OnValueChangeListener endListener;

    public interface OnValueChangeListener {
        void onValueChanged(float value);
    }

    public void setClassicStyle(boolean classic) {
        classicStyle = classic;
        invalidate();
    }

    public CustomSlider(Context ctx) {
        super(ctx);
        init(ctx);
    }

    public CustomSlider(Context ctx, String name, String label, int min, int max, int defaultValue, OnValueChangeListener l) {
        super(ctx);
        init(ctx);
        this.min = min;
        this.max = max;
        this.step = 1f;
        this.value = defaultValue - min;
        this.listener = l;
        recompute();
        visualProg = prog;
    }

    private void init(Context ctx) {
        float d = ctx.getResources().getDisplayMetrics().density;
        trackH = Math.max(2, (int) (d * 4));
        setClickable(true);
        setFocusable(true);
        setFocusableInTouchMode(true);
        setLongClickable(false);
        setWillNotDraw(false);
    }

    public void setRange(float min, float max) {
        this.min = min;
        this.max = max;
        recompute();
    }

    public void setStep(float step) {
        this.step = Math.max(0.0001f, step);
    }

    public void setValue(float v) {
        float clamped = Math.max(min, Math.min(max, v));
        this.value = snap(clamped) - min;
        recompute();
        postInvalidateOnAnimation();
    }

    public float getValue() {
        return value + min;
    }

    public void setOnValueChangeListener(OnValueChangeListener l) {
        this.listener = l;
    }

    public void setOnValueChangeFinishedListener(OnValueChangeListener l) {
        this.endListener = l;
    }

    public void setScaleFactor(float s) {
        this.scaleFactor = s;
        requestLayout();
    }

    public void updateScale(float s) {
        setScaleFactor(s);
    }

    private void recompute() {
        prog = (max > min) ? Math.max(0f, Math.min(1f, value / (max - min))) : 0f;
    }

    private float snap(float absolute) {
        if (step <= 0f) return absolute;
        float steps = Math.round((absolute - min) / step);
        float snapped = min + steps * step;
        return Math.max(min, Math.min(max, snapped));
    }

    private void disallowParents(boolean disallow) {
        ViewParent p = getParent();
        while (p != null) {
            p.requestDisallowInterceptTouchEvent(disallow);
            if (p instanceof View) {
                p = ((View) p).getParent();
            } else {
                break;
            }
        }
    }

    protected void onMeasure(int wSpec, int hSpec) {
        float d = getResources().getDisplayMetrics().density * scaleFactor;
        int h = Math.max((int) (36 * d), (int) (36 * getResources().getDisplayMetrics().density));
        setMeasuredDimension(MeasureSpec.getSize(wSpec), h);
    }

    protected void onDraw(Canvas canvas) {
        long now = AnimationUtils.currentAnimationTimeMillis();
        float dt = lastFrame == 0 ? 16 : Math.max(1, Math.min(64, now - lastFrame));
        lastFrame = now;

        float lerp = 1f - (float) Math.exp(-dt / 80f);
        visualProg += (prog - visualProg) * lerp;
        thumbScale += (targetScale - thumbScale) * (1f - (float) Math.exp(-dt / 120f));

        float w = getWidth();
        float h = getHeight();
        float cy = h / 2f;
        float pad = Math.max(trackH * 2f, h * 0.2f);
        float left = pad;
        float right = Math.max(left + 1f, w - pad);
        float trackW = right - left;
        float tt = cy - trackH / 2f;
        float tb = cy + trackH / 2f;
        float rd = classicStyle ? Math.max(1f, trackH * 0.25f) : trackH / 2f;

        bgPaint.setColor(ThemeManager.getStateDisabled());
        rect.set(left, tt, right, tb);
        canvas.drawRoundRect(rect, rd, rd, bgPaint);

        float fw = left + trackW * visualProg;
        fillPaint.setColor(ThemeManager.getThemeColor());
        rect.set(left, tt, fw, tb);
        canvas.drawRoundRect(rect, rd, rd, fillPaint);

        float tr = trackH * 1.8f * thumbScale;
        float tx = left + trackW * visualProg;
        tx = Math.max(left, Math.min(right, tx));
        thumbPaint.setColor(Color.WHITE);
        thumbPaint.clearShadowLayer();
        canvas.drawCircle(tx, cy, tr, thumbPaint);

        if (Math.abs(visualProg - prog) > 0.001f || Math.abs(thumbScale - targetScale) > 0.005f) {
            postInvalidateOnAnimation();
        }
    }

    public boolean onTouchEvent(MotionEvent e) {
        if (!isEnabled()) return false;
        int action = e.getActionMasked();
        switch (action) {
            case MotionEvent.ACTION_DOWN:
                dragging = true;
                targetScale = 1.2f;
                disallowParents(true);
                applyTouchX(e.getX());
                postInvalidateOnAnimation();
                return true;
            case MotionEvent.ACTION_MOVE:
                if (!dragging) return true;
                disallowParents(true);
                applyTouchX(e.getX());
                postInvalidateOnAnimation();
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (dragging) {
                    applyTouchX(e.getX());
                    if (endListener != null) {
                        endListener.onValueChanged(getValue());
                    }
                }
                dragging = false;
                targetScale = 1f;
                disallowParents(false);
                postInvalidateOnAnimation();
                return true;
            default:
                return super.onTouchEvent(e);
        }
    }

    private void applyTouchX(float x) {
        float w = getWidth();
        if (w <= 1f) return;
        float pad = Math.max(trackH * 2f, getHeight() * 0.2f);
        float left = pad;
        float right = Math.max(left + 1f, w - pad);
        float t = (x - left) / (right - left);
        t = Math.max(0f, Math.min(1f, t));
        float absolute = min + t * (max - min);
        absolute = snap(absolute);
        value = absolute - min;
        recompute();
        if (listener != null) {
            listener.onValueChanged(absolute);
        }
    }
}
