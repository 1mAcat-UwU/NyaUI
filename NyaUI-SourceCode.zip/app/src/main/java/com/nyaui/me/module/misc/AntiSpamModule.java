package com.nyaui.me.module.misc;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class AntiSpamModule extends Module {
    public AntiSpamModule() {
        super("AntiSpam", ModuleCategory.MISC);
    }
}
