package com.nyaui.me.module.movement;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class SafeWalkModule extends Module {
    public SafeWalkModule() {
        super("SafeWalk", ModuleCategory.MOVEMENT);
    }
}
