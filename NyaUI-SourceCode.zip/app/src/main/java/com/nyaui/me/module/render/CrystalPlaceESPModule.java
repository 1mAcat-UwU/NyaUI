package com.nyaui.me.module.render;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class CrystalPlaceESPModule extends Module {
    public CrystalPlaceESPModule() {
        super("CrystalPlaceESP", ModuleCategory.RENDER);
    }
}
