package com.nyaui.me.module.misc;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class AutoPearlModule extends Module {
    public AutoPearlModule() {
        super("AutoPearl", ModuleCategory.MISC);
    }
}
