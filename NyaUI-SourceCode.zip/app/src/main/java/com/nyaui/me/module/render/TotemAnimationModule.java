package com.nyaui.me.module.render;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class TotemAnimationModule extends Module {
    public TotemAnimationModule() {
        super("TotemAnimation", ModuleCategory.RENDER);
    }
}
