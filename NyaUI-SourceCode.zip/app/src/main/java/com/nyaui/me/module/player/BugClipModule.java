package com.nyaui.me.module.player;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class BugClipModule extends Module {
    public BugClipModule() {
        super("BugClip", ModuleCategory.PLAYER);
    }
}
