package com.nyaui.me.module.combat;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class AutoCityModule extends Module {
    public AutoCityModule() {
        super("AutoCity", ModuleCategory.COMBAT);
    }
}
