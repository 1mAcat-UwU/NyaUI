package com.nyaui.me.module.render;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;

public class XrayModule extends Module {
    public XrayModule() { super("Xray", ModuleCategory.RENDER, ""); setChineseName("ESP"); }
    public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("Xray"); } catch (Throwable t) {} }
    public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("Xray"); } catch (Throwable t) {} }
}
