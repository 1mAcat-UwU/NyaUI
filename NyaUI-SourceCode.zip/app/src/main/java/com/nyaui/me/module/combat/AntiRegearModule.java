package com.nyaui.me.module.combat;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class AntiRegearModule extends Module {
    public AntiRegearModule() {
        super("AntiRegear", ModuleCategory.COMBAT);
    }
}
