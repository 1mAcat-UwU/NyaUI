package com.nyaui.me.module.client;

import com.nyaui.me.config.ConfigManager;
import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.ui.HUDManager;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public final class ModuleListModule extends Module {
    public ModuleListModule() {
        super("ModuleList", ModuleCategory.CLIENT, "");
        setChineseName("Module List");
    }

    public boolean shouldShowInArraylist() { return false; }
    public boolean supportsShortcut() { return false; }

    protected void onEnable() {
        HUDManager.setArraylistEnabled(true);
    }

    protected void onDisable() {
        HUDManager.setArraylistEnabled(false);
    }

    public void configureSubMenu(SubMenuPanel subMenu) {
        super.configureSubMenu(subMenu);
        subMenu.addSlider("X", 0, 100, Math.round(ConfigManager.getFloat("HUD", "arraylist_x", 100f)), "%d%%", v -> HUDManager.setArraylistPosition(v / 100f, null));
        subMenu.addSlider("Y", 0, 100, Math.round(ConfigManager.getFloat("HUD", "arraylist_y", 4f)), "%d%%", v -> HUDManager.setArraylistPosition(null, v / 100f));
        subMenu.addGradientColorSetting("HUD", "arraylist_color", 0xFFFFFFFF, HUDManager::setArraylistColor);
    }
}
