package com.nyaui.me.module.combat;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class BurrowAssistModule extends Module {
    public BurrowAssistModule() {
        super("BurrowAssist", ModuleCategory.COMBAT);
    }
}
