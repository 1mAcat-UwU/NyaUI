package com.nyaui.me.module.movement;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class BlockStrafeModule extends Module {
    public BlockStrafeModule() {
        super("BlockStrafe", ModuleCategory.MOVEMENT);
    }
}
