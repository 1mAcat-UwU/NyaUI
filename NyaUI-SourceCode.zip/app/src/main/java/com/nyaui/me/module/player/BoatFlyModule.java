package com.nyaui.me.module.player;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class BoatFlyModule extends Module {
    public BoatFlyModule() { super("BoatFly", ModuleCategory.PLAYER, ""); setChineseName("Spaceship"); }
    public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("BoatFly"); } catch (Throwable t) {} }
    public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("BoatFly"); } catch (Throwable t) {} }
    public void configureSubMenu(SubMenuPanel s) {
        super.configureSubMenu(s);
        s.addSlider("Speed", 1, 20, (int)(SafeCall.getFloat(getName(), 0) * 10), "%.1f", v -> SafeCall.setFloat(getName(), 0, v / 10f));
    }
}
