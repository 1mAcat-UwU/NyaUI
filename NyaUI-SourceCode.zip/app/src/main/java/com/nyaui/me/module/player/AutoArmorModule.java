package com.nyaui.me.module.player;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class AutoArmorModule extends Module {
    public AutoArmorModule() {
        super("AutoArmor", ModuleCategory.PLAYER);
    }
}
