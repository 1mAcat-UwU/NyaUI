package com.nyaui.me.module.misc;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class BaseFinderModule extends Module {
    public BaseFinderModule() {
        super("BaseFinder", ModuleCategory.MISC);
    }
}
