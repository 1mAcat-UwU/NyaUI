package com.nyaui.me.module;

public interface ModuleToggleListener {
    void onModuleToggled(Module module);
}

