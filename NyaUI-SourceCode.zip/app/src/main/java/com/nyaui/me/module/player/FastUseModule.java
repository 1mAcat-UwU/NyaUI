package com.nyaui.me.module.player;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class FastUseModule extends Module {
    public FastUseModule() {
        super("FastUse", ModuleCategory.PLAYER);
    }
}
