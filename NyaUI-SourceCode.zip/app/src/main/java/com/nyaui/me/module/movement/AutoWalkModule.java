package com.nyaui.me.module.movement;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class AutoWalkModule extends Module {
    public AutoWalkModule() {
        super("AutoWalk", ModuleCategory.MOVEMENT);
    }
}
