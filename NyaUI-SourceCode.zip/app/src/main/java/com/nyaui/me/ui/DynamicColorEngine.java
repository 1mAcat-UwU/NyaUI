package com.nyaui.me.ui;

import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Shader;
import android.view.Choreographer;

import java.util.ArrayList;
import java.util.List;

public final class DynamicColorEngine {
    public static final int DIR_LEFT_RIGHT = 0;
    public static final int DIR_RIGHT_LEFT = 1;
    public static final int DIR_TOP_BOTTOM = 2;
    public static final int DIR_BOTTOM_TOP = 3;

    private static float baseCycleSeconds = 4.5f;
    private static float speedMultiplier = 1f;
    private static int direction = DIR_LEFT_RIGHT;
    private static float phase;
    private static long lastNs;
    private static boolean running;
    private static final List<Runnable> listeners = new ArrayList<>();
    private static final Choreographer.FrameCallback FRAME = new Choreographer.FrameCallback() {
        public void doFrame(long frameTimeNs) {
            if (!running) return;
            if (lastNs == 0L) lastNs = frameTimeNs;
            float dt = (frameTimeNs - lastNs) / 1_000_000_000f;
            lastNs = frameTimeNs;
            if (dt < 0f) dt = 0f;
            if (dt > 0.05f) dt = 0.05f;
            if (speedMultiplier <= 0f) {
                running = false;
                lastNs = 0L;
                return;
            }
            float cycle = Math.max(0.4f, baseCycleSeconds / speedMultiplier);
            phase += dt / cycle;
            if (phase >= 1f) phase -= (float) Math.floor(phase);
            for (Runnable r : new ArrayList<>(listeners)) {
                try { r.run(); } catch (Throwable ignored) {}
            }
            if (running && !listeners.isEmpty() && speedMultiplier > 0f) {
                Choreographer.getInstance().postFrameCallback(this);
            } else {
                running = false;
                lastNs = 0L;
            }
        }
    };

    private DynamicColorEngine() {}

    public static float getPhase() {
        return phase;
    }

    public static void setSpeedMultiplier(float multiplier) {
        speedMultiplier = Math.max(0f, Math.min(5f, multiplier));
        if (speedMultiplier <= 0f) {
            running = false;
            lastNs = 0L;
        } else if (!listeners.isEmpty()) {
            ensureRunning();
        }
    }

    public static float getSpeedMultiplier() {
        return speedMultiplier;
    }

    public static void setDirection(int dir) {
        if (dir < DIR_LEFT_RIGHT || dir > DIR_BOTTOM_TOP) dir = DIR_LEFT_RIGHT;
        direction = dir;
    }

    public static int getDirection() {
        return direction;
    }

    public static void addListener(Runnable r) {
        if (r == null) return;
        if (!listeners.contains(r)) listeners.add(r);
        ensureRunning();
    }

    public static void removeListener(Runnable r) {
        listeners.remove(r);
        if (listeners.isEmpty()) {
            running = false;
            lastNs = 0L;
        }
    }

    private static void ensureRunning() {
        if (running) return;
        if (listeners.isEmpty()) return;
        running = true;
        lastNs = 0L;
        Choreographer.getInstance().postFrameCallback(FRAME);
    }

    public static int lerpColor(int a, int b, float t) {
        if (t <= 0f) return a;
        if (t >= 1f) return b;
        int aa = Color.alpha(a);
        int ar = Color.red(a);
        int ag = Color.green(a);
        int ab = Color.blue(a);
        int ba = Color.alpha(b);
        int br = Color.red(b);
        int bg = Color.green(b);
        int bb = Color.blue(b);
        return Color.argb(
                Math.round(aa + (ba - aa) * t),
                Math.round(ar + (br - ar) * t),
                Math.round(ag + (bg - ag) * t),
                Math.round(ab + (bb - ab) * t)
        );
    }

    public static int sampleFlow(int c0, int c1, float localOffset) {
        float t = phase + localOffset;
        t = t - (float) Math.floor(t);
        float wave = 0.5f - 0.5f * (float) Math.cos(t * Math.PI * 2.0);
        return lerpColor(c0, c1, wave);
    }

    public static int applyAlpha(int color, int alphaByte) {
        int a = Math.max(0, Math.min(255, alphaByte));
        return (color & 0x00FFFFFF) | (a << 24);
    }

    public static Shader createFlowShader(float width, float height, int c0, int c1) {
        return createFlowShader(width, height, c0, c1, direction);
    }

    public static Shader createFlowShader(float width, float height, int c0, int c1, int dir) {
        float w = Math.max(1f, width);
        float h = Math.max(1f, height);
        float shift = phase;
        int mid = lerpColor(c0, c1, 0.5f);
        int[] colors = new int[]{c0, mid, c1, mid, c0};
        float[] stops = new float[]{0f, 0.25f, 0.5f, 0.75f, 1f};
        boolean horizontal = dir == DIR_LEFT_RIGHT || dir == DIR_RIGHT_LEFT;
        boolean reverse = dir == DIR_RIGHT_LEFT || dir == DIR_BOTTOM_TOP;
        LinearGradient lg;
        if (horizontal) {
            lg = new LinearGradient(0f, 0f, w * 2f, 0f, colors, stops, Shader.TileMode.MIRROR);
        } else {
            lg = new LinearGradient(0f, 0f, 0f, h * 2f, colors, stops, Shader.TileMode.MIRROR);
        }
        Matrix m = new Matrix();
        float travel = horizontal ? w * 2f : h * 2f;
        float offset = (reverse ? shift : -shift) * travel;
        if (horizontal) {
            m.setTranslate(offset, 0f);
        } else {
            m.setTranslate(0f, offset);
        }
        lg.setLocalMatrix(m);
        return lg;
    }

    public static boolean isGradientMode(String mode) {
        return mode != null && mode.equalsIgnoreCase("gradient");
    }
}
