package com.nyaui.me.module.combat;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class AnchorAuraModule extends Module {
    public AnchorAuraModule() {
        super("AnchorAura", ModuleCategory.COMBAT);
    }
}
