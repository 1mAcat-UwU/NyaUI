package com.nyaui.me.module.player;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class AutoRespawnModule extends Module {
    public AutoRespawnModule() {
        super("AutoRespawn", ModuleCategory.PLAYER);
    }
}
