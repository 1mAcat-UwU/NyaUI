package com.nyaui.me.module.misc;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class SpammerModule extends Module {
    public SpammerModule() { super("Spammer", ModuleCategory.MISC, ""); setChineseName("Spammer"); }
    public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("Spammer"); } catch (Throwable t) {} }
    public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("Spammer"); } catch (Throwable t) {} }
    public void configureSubMenu(SubMenuPanel s) {
        super.configureSubMenu(s);
        s.addSlider("Delay (ms)", 500, 10000, SafeCall.getInt(getName(), 0) * 1000, "%d", v -> SafeCall.setInt(getName(), 0, (int)(v / 1000)));
    }
}
