package com.nyaui.me.module.misc;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class NoServerRPModule extends Module {
    public NoServerRPModule() {
        super("NoServerRP", ModuleCategory.MISC);
    }
}
