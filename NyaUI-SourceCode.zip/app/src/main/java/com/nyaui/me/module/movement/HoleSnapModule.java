package com.nyaui.me.module.movement;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class HoleSnapModule extends Module {
    public HoleSnapModule() {
        super("HoleSnap", ModuleCategory.MOVEMENT);
    }
}
