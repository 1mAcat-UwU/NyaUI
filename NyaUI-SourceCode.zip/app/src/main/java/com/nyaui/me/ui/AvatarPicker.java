package com.nyaui.me.ui;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;

public final class AvatarPicker {
    public static final int REQUEST_CODE = 0x4E5941;

    private AvatarPicker() {}

    public static void pick(Activity activity) {
        if (activity == null) return;
        try {
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("image/*");
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            activity.startActivityForResult(Intent.createChooser(intent, "Select Avatar"), REQUEST_CODE);
        } catch (Throwable ignored) {}
    }

    public static void handleResult(Activity activity, int requestCode, int resultCode, Intent data) {
        if (requestCode != REQUEST_CODE) return;
        if (resultCode != Activity.RESULT_OK || data == null) return;
        Uri uri = data.getData();
        if (uri == null) return;
        try {
            UserProfile.setAvatarFromUri(activity, uri);
        } catch (Throwable ignored) {}
    }
}
