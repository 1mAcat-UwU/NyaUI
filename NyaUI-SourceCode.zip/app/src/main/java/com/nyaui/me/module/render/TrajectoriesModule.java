package com.nyaui.me.module.render;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class TrajectoriesModule extends Module {
    public TrajectoriesModule() {
        super("Trajectories", ModuleCategory.RENDER);
    }
}
