package com.nyaui.me.module.render;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class HoleESPModule extends Module {
    public HoleESPModule() {
        super("HoleESP", ModuleCategory.RENDER);
    }
}
