package com.nyaui.me.module.combat;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class AutoCrystalModule extends Module {
    public AutoCrystalModule() {
        super("AutoCrystal", ModuleCategory.COMBAT);
    }
}
