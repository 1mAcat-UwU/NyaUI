package com.nyaui.me.module.visual;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;

public class TracerModule extends Module {
    public TracerModule() { super("Tracer", ModuleCategory.VISUAL, ""); setChineseName("Tracers"); }
    public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("Tracer"); } catch (Throwable t) {} }
    public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("Tracer"); } catch (Throwable t) {} }
}
