package com.nyaui.me.module.render;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class LogoutSpotsModule extends Module {
    public LogoutSpotsModule() {
        super("LogoutSpots", ModuleCategory.RENDER);
    }
}
