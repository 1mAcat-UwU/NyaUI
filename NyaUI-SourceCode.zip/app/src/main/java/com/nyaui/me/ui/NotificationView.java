package com.nyaui.me.ui;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.view.animation.DecelerateInterpolator;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.content.ContextWrapper;

import com.nyaui.me.module.Module;
public class NotificationView extends LinearLayout implements ThemeManager.OnThemeColorChangeListener,
        ThemeManager.OnThemeModeChangeListener {
    private final Module module;
    private final TextView textView;
    private PopupWindow popupWindow;
    private int positionIndex = 0;
    private int currentY = 0; 
    private ValueAnimator currentPositionAnimator = null; 
    private int currentX = 0; 
    private ValueAnimator progressAnimator;
    private ProgressBarDrawable progressBarDrawable;
    private GradientDrawable progressDrawable;

    private static final int NOTIFICATION_WIDTH_DP = 120;
    private static final int NOTIFICATION_HEIGHT_DP = 24;
    private static final int MARGIN_DP = 8;
    private static final int SPACING_DP = 4;
    private static final int ANIMATION_DURATION = 300;
    private static final int POSITION_UPDATE_DURATION = 250; 
    private static final int DISPLAY_DURATION = 2000;
    private static final int GLOW_BLUR_RADIUS_DP = 6;

    public NotificationView(Context context, Module module, boolean isEnabled) {
        super(context);
        this.module = module;

        setOrientation(HORIZONTAL);
        setGravity(Gravity.CENTER_VERTICAL);
        setPadding(dpToPx(8), dpToPx(4), dpToPx(8), dpToPx(4));
        setMinimumWidth(dpToPx(150));

        
        progressBarDrawable = new ProgressBarDrawable();
        progressBarDrawable.setColor(Color.parseColor("#F01A1A1A"));
        progressBarDrawable.setCornerRadius(dpToPx(8));

        
        progressDrawable = new GradientDrawable();
        progressDrawable.setCornerRadius(dpToPx(8));
        updateProgressDrawableColors(); 
        progressBarDrawable.setProgressDrawable(progressDrawable);
        setBackground(progressBarDrawable);

        
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);

        textView = new TextView(context);
        boolean isChinese = com.nyaui.me.config.ConfigManager.isChinese();
        String statusText = isEnabled ? (isChinese ? "Enabled" : "Enabled") : (isChinese ? "Disabled" : "Disabled");
        textView.setText(module.getDisplayName() + " " + statusText);
        textView.setTextColor(Color.WHITE);
        textView.setTextSize(11f);
        textView.setSingleLine(true);
        textView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        textView.setLayoutParams(new LinearLayout.LayoutParams(
                LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT
        ));

        addView(textView);

        ThemeManager.addListener(this);
        ThemeManager.addModeListener(this);
    }

    public void show(WindowManager windowManager, int index) {
        this.positionIndex = index;

        int screenWidth = getDisplayWidth();
        int screenHeight = getDisplayHeight();
        
        int widthMeasureSpec = MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED);
        int heightMeasureSpec = MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED);
        measure(widthMeasureSpec, heightMeasureSpec);

        int width = getMeasuredWidth();
        int height = getMeasuredHeight();

        
        setTranslationX(width);
        setAlpha(0f);

        popupWindow = new PopupWindow(this, width, height, false);
        popupWindow.setTouchable(false);
        popupWindow.setFocusable(false);
        popupWindow.setOutsideTouchable(false);
        popupWindow.setClippingEnabled(false); 
        popupWindow.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));

        View decorView = findDecorView();
        if (decorView == null) return;

        
        int x = screenWidth - width - dpToPx(MARGIN_DP);
        int y = screenHeight - dpToPx(MARGIN_DP) - height - (height + dpToPx(SPACING_DP)) * index;
        this.currentY = y; 
        this.currentX = x; 

        popupWindow.showAtLocation(decorView, Gravity.NO_GRAVITY, x, y);

        
        post(() -> {
            slideIn();
            postDelayed(this::slideOut, DISPLAY_DURATION);
        });
    }

    private void slideIn() {
        
        ObjectAnimator slideIn = ObjectAnimator.ofFloat(this, "translationX", getTranslationX(), 0);
        ObjectAnimator fadeIn = ObjectAnimator.ofFloat(this, "alpha", 0, 1);

        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.playTogether(slideIn, fadeIn);
        animatorSet.setDuration(ANIMATION_DURATION);
        animatorSet.setInterpolator(new DecelerateInterpolator());
        animatorSet.start();

        progressAnimator = ValueAnimator.ofFloat(1f, 0f); 
        progressAnimator.setDuration(DISPLAY_DURATION);
        progressAnimator.setInterpolator(new DecelerateInterpolator());
        progressAnimator.addUpdateListener(animation -> {
            float progress = (float) animation.getAnimatedValue();
            progressBarDrawable.setProgress(progress);
        });
        progressAnimator.start();
    }

    private void slideOut() {
        if (popupWindow == null || !popupWindow.isShowing()) return;

        if (progressAnimator != null && progressAnimator.isRunning()) {
            progressAnimator.cancel();
        }

        
        if (currentPositionAnimator != null && currentPositionAnimator.isRunning()) {
            currentPositionAnimator.cancel();
            currentPositionAnimator = null;
            
            if (popupWindow != null && popupWindow.isShowing()) {
                popupWindow.update(currentX, currentY, -1, -1);
            }
        }

        
        ObjectAnimator slideOut = ObjectAnimator.ofFloat(this, "translationX", 0, getWidth());
        ObjectAnimator fadeOut = ObjectAnimator.ofFloat(this, "alpha", 1, 0);

        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.playTogether(slideOut, fadeOut);
        animatorSet.setDuration(ANIMATION_DURATION);
        animatorSet.setInterpolator(new DecelerateInterpolator());
        animatorSet.addListener(new AnimatorListenerAdapter() {
                        public void onAnimationEnd(Animator animation) {
                dismiss();
                NotificationManager.onNotificationDismissed(NotificationView.this);
            }
        });
        animatorSet.start();
    }

    public void updatePosition(int newIndex) {
        if (this.positionIndex == newIndex || popupWindow == null || !popupWindow.isShowing()) {
            return;
        }

        
        if (currentPositionAnimator != null && currentPositionAnimator.isRunning()) {
            currentPositionAnimator.cancel();
            currentPositionAnimator = null;
        }

        int screenHeight = getDisplayHeight();
        int height = getMeasuredHeight();
        int oldY = currentY;
        int newY = screenHeight - dpToPx(MARGIN_DP) - height - (height + dpToPx(SPACING_DP)) * newIndex;
        
        
        if (oldY == newY) {
            this.positionIndex = newIndex;
            return;
        }

        
        int deltaY = newY - oldY;
        
        
        if (deltaY > 0) {
            
            currentPositionAnimator = ValueAnimator.ofInt(oldY, newY);
            currentPositionAnimator.setDuration(POSITION_UPDATE_DURATION);
            currentPositionAnimator.addUpdateListener(animation -> {
                if (popupWindow != null && popupWindow.isShowing()) {
                    int animatedY = (Integer) animation.getAnimatedValue();
                    
                    popupWindow.update(currentX, animatedY, -1, -1);
                    currentY = animatedY; 
                }
            });
            currentPositionAnimator.addListener(new AnimatorListenerAdapter() {
                                public void onAnimationEnd(Animator animation) {
                    
                    if (popupWindow != null && popupWindow.isShowing()) {
                        popupWindow.update(currentX, newY, -1, -1);
                        currentY = newY;
                        positionIndex = newIndex;
                    }
                    currentPositionAnimator = null;
                }
                
                                public void onAnimationCancel(Animator animation) {
                    
                    if (popupWindow != null && popupWindow.isShowing()) {
                        popupWindow.update(currentX, currentY, -1, -1);
                    }
                    currentPositionAnimator = null;
                }
            });
            currentPositionAnimator.start();
        } else {
            
            
            int screenWidth = getDisplayWidth();
            int newX = screenWidth - getWidth() - dpToPx(MARGIN_DP);
            
            if (popupWindow.isShowing()) {
                popupWindow.update(newX, newY, -1, -1);
                currentX = newX;
                currentY = newY;
                this.positionIndex = newIndex;
            }
        }
    }

    public void dismiss() {
        if (progressAnimator != null && progressAnimator.isRunning()) {
            progressAnimator.cancel();
        }
        
        if (currentPositionAnimator != null && currentPositionAnimator.isRunning()) {
            currentPositionAnimator.cancel();
            currentPositionAnimator = null;
        }
        
        if (popupWindow != null) {
            if (popupWindow.isShowing()) {
                popupWindow.dismiss();
            }
            popupWindow = null;
        }
        ThemeManager.removeListener(this);
        ThemeManager.removeModeListener(this);
    }

    private View findDecorView() {
        Context context = getContext();
        while (context instanceof ContextWrapper) {
            if (context instanceof android.app.Activity) {
                return ((android.app.Activity) context).getWindow().getDecorView();
            }
            context = ((ContextWrapper) context).getBaseContext();
        }
        return getRootView();
    }

    private int getDisplayWidth() {
        DisplayMetrics metrics = new DisplayMetrics();
        ((WindowManager) getContext().getSystemService(Context.WINDOW_SERVICE))
                .getDefaultDisplay().getRealMetrics(metrics);
        return metrics.widthPixels;
    }

    private int getDisplayHeight() {
        DisplayMetrics metrics = new DisplayMetrics();
        ((WindowManager) getContext().getSystemService(Context.WINDOW_SERVICE))
                .getDefaultDisplay().getRealMetrics(metrics);
        return metrics.heightPixels;
    }

        public void onThemeColorChanged(int newColor) {
        updateColors();
        updateProgressDrawableColors();
        
    }

        public void onThemeModeChanged(boolean isDark) {
        updateColors();
    }

    private void updateColors() {
        if (progressBarDrawable != null) {
            progressBarDrawable.setColor(Color.parseColor("#F01A1A1A"));
        }
        textView.setTextColor(Color.WHITE);
        invalidate();
    }

    private void updateProgressDrawableColors() {
        int themeColor = ThemeManager.getThemeColor();
        float[] hsv = new float[3];
        Color.colorToHSV(themeColor, hsv);
        hsv[2] *= 1.2f; 
        int lighterColor = Color.HSVToColor(hsv);

        if (progressDrawable != null) {
            progressDrawable.setColors(new int[]{themeColor, lighterColor});
            progressDrawable.setOrientation(GradientDrawable.Orientation.LEFT_RIGHT);
        }
        if (progressBarDrawable != null) {
            progressBarDrawable.setGlowColor(themeColor, dpToPx(GLOW_BLUR_RADIUS_DP));
        }
    }

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density + 0.5f);
    }

    public Module getModule() {
        return module;
    }
}

