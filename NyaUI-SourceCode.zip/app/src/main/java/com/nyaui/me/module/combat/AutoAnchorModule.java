package com.nyaui.me.module.combat;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class AutoAnchorModule extends Module {
    public AutoAnchorModule() {
        super("AutoAnchor", ModuleCategory.COMBAT);
    }
}
