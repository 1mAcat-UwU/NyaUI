package com.nyaui.me.module.world;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;

public class BoxAuraModule extends Module {
    public BoxAuraModule() { super("BoxAura", ModuleCategory.WORLD, ""); setChineseName("Chest Aura"); }
    public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("BoxAura"); } catch (Throwable t) {} }
    public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("BoxAura"); } catch (Throwable t) {} }
}
