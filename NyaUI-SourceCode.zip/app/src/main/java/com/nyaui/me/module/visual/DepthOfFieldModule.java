package com.nyaui.me.module.visual;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class DepthOfFieldModule extends Module {
    public DepthOfFieldModule() { super("DepthOfField", ModuleCategory.VISUAL, ""); setChineseName("Depth of Field"); }
    public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("DepthOfField"); } catch (Throwable t) {} }
    public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("DepthOfField"); } catch (Throwable t) {} }
    public void configureSubMenu(SubMenuPanel s) {
        super.configureSubMenu(s);
        String n = getName();
        s.addSlider("Blur", 1, 50, (int)(SafeCall.getFloat(n, 0) * 10), "%.1f", v -> SafeCall.setFloat(n, 0, v));
        s.addSlider("Far Blur", 1, 150, (int)(SafeCall.getFloat(n, 1) * 10), "%.1f", v -> SafeCall.setFloat(n, 1, v));
        s.addSlider("Focus Distance", 1, 100, (int)SafeCall.getFloat(n, 2), "%d", v -> SafeCall.setFloat(n, 2, v));
        s.addSlider("Near Blur", 1, 150, (int)(SafeCall.getFloat(n, 3) * 10), "%.1f", v -> SafeCall.setFloat(n, 3, v));
        s.addSwitch("Focus Center", SafeCall.getBool(n, 0), e -> SafeCall.setBool(n, 0, e));
    }
}
