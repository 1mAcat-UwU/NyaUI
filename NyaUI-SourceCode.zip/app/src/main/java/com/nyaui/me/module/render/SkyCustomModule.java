package com.nyaui.me.module.render;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class SkyCustomModule extends Module {
    public SkyCustomModule() { super("SkyCustom", ModuleCategory.RENDER, ""); setChineseName("Custom Sky"); }
    public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("SkyCustom"); } catch (Throwable t) {} }
    public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("SkyCustom"); } catch (Throwable t) {} }
    public void configureSubMenu(SubMenuPanel s) {
        super.configureSubMenu(s);
        String n = getName();
        s.addSlider("Red", 0, 100, (int)(SafeCall.getFloat(n, 0) * 100), "%d", v -> SafeCall.setFloat(n, 0, v / 100f));
        s.addSlider("Green", 0, 100, (int)(SafeCall.getFloat(n, 1) * 100), "%d", v -> SafeCall.setFloat(n, 1, v / 100f));
        s.addSlider("Blue", 0, 100, (int)(SafeCall.getFloat(n, 2) * 100), "%d", v -> SafeCall.setFloat(n, 2, v / 100f));
        s.addSlider("Opacity", 0, 100, (int)(SafeCall.getFloat(n, 3) * 100), "%d", v -> SafeCall.setFloat(n, 3, v / 100f));
    }
}
