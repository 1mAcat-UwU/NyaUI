package com.nyaui.me.module.render;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class HotbarRefillModule extends Module {
    public HotbarRefillModule() {
        super("HotbarRefill", ModuleCategory.RENDER);
    }
}
