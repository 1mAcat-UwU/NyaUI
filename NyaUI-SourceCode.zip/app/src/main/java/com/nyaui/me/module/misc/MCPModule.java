package com.nyaui.me.module.misc;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class MCPModule extends Module {
    public MCPModule() {
        super("MCP", ModuleCategory.MISC);
    }
}
