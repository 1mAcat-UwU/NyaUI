package com.nyaui.me.module.combat;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class AutoClickModule extends Module {
    public AutoClickModule() { super("AutoClick", ModuleCategory.COMBAT, ""); setChineseName("Auto Click"); }
    public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("AutoClick"); } catch (Throwable t) {} }
    public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("AutoClick"); } catch (Throwable t) {} }
    public void configureSubMenu(SubMenuPanel s) {
        super.configureSubMenu(s);
        String n = getName();
        s.addSlider("CPS", 1, 20, (int)SafeCall.getFloat(n, 0), "%d", v -> SafeCall.setFloat(n, 0, v));
    }
}
