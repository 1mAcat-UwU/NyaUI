package com.nyaui.me.module.render;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class FullBrightModule extends Module {
    public FullBrightModule() { super("FullBright", ModuleCategory.RENDER, ""); setChineseName("World Brightness"); }
    public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("FullBright"); } catch (Throwable t) {} }
    public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("FullBright"); } catch (Throwable t) {} }
    public void configureSubMenu(SubMenuPanel s) {
        super.configureSubMenu(s);
        s.addSlider("Intensity", 0, 50, (int)SafeCall.getFloat(getName(), 0), "%d", v -> SafeCall.setFloat(getName(), 0, v));
    }
}
