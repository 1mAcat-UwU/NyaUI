package com.nyaui.me.ui;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.SoundPool;
import android.media.ToneGenerator;
import com.nyaui.me.R;
import com.nyaui.me.config.ConfigManager;

public final class SoundPlayer {
    private static SoundPool soundPool;
    private static int clickSoundId;
    private static boolean initialized;
    private static boolean clickLoaded;
    private static long lastPlayMs;
    private static long lastTogglePlayMs;
    private static ToneGenerator toneGenerator;

    public static synchronized void init(Context context) {
        if (initialized) return;
        Context app = context.getApplicationContext();
        try {
            AudioAttributes attributes = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            soundPool = new SoundPool.Builder().setMaxStreams(4).setAudioAttributes(attributes).build();
            soundPool.setOnLoadCompleteListener((sp, id, status) -> {
                if (status == 0 && id == clickSoundId) clickLoaded = true;
            });
            clickSoundId = soundPool.load(app, R.raw.ui_click, 1);
            try { toneGenerator = new ToneGenerator(AudioManager.STREAM_MUSIC, 45); } catch (Throwable ignored) {}
            initialized = true;
        } catch (Throwable ignored) {
            initialized = false;
            try { toneGenerator = new ToneGenerator(AudioManager.STREAM_MUSIC, 45); } catch (Throwable ignored2) {}
        }
    }

    public static void playClick() { play(0.55f, 1.05f); }
    public static void playOnSound() { playToggle(0.72f, 1.14f); }
    public static void playOffSound() { playToggle(0.58f, 0.88f); }

    private static void play(float volume, float rate) {
        playInternal(volume, rate, false);
    }

    private static void playToggle(float volume, float rate) {
        playInternal(volume, rate, true);
    }

    private static void playInternal(float volume, float rate, boolean toggle) {
        if (!ConfigManager.isSoundEnabled()) return;
        long now = System.currentTimeMillis();
        if (toggle) {
            if (now - lastTogglePlayMs < 70) return;
            lastTogglePlayMs = now;
        } else {
            if (now - lastPlayMs < 45) return;
            lastPlayMs = now;
        }
        boolean played = false;
        if (initialized && soundPool != null && clickLoaded && clickSoundId != 0) {
            try { played = soundPool.play(clickSoundId, volume, volume, 1, 0, rate) != 0; } catch (Throwable ignored) {}
        }
        if (!played && toneGenerator != null) {
            try { toneGenerator.startTone(ToneGenerator.TONE_PROP_BEEP2, 28); } catch (Throwable ignored) {}
        }
    }

    public static synchronized void release() {
        if (soundPool != null) { try { soundPool.release(); } catch (Throwable ignored) {} }
        if (toneGenerator != null) { try { toneGenerator.release(); } catch (Throwable ignored) {} }
        soundPool = null; toneGenerator = null; clickSoundId = 0; clickLoaded = false; initialized = false;
    }

    private SoundPlayer() {}
}
