package com.nyaui.me.module.player;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class PacketEatModule extends Module {
    public PacketEatModule() {
        super("PacketEat", ModuleCategory.PLAYER);
    }
}
