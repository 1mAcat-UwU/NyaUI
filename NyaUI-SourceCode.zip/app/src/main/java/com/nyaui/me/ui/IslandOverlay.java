package com.nyaui.me.ui;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.view.Choreographer;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.PopupWindow;

import com.nyaui.me.config.ConfigManager;
import com.nyaui.me.media.LyricFetcher;
import com.nyaui.me.media.MediaReader;

public class IslandOverlay {

    public static final String CFG = "Island";
    public static final String K_ISLAND = "hud_island";
    public static final String K_MUSIC = "island_music";
    public static final String K_TIME = "island_time";

    

    private static final float WIN_W0 = 140f;   
    private static final float WIN_H0 = 50f;
    private static final float WIN_PAD = 12f;   

     
    private static final int MAX_HINTS = 6;

    private static IslandOverlay instance;

    private final Activity act;
    private final float density;
    private PopupWindow popup;
    private IslandView view;

    private IslandOverlay(Activity act) {
        this.act = act;
        this.density = act.getResources().getDisplayMetrics().density;
    }

    public static void attach(Activity act) {
        try {
            if (act == null) return;
            if (instance != null && instance.popup != null && instance.popup.isShowing()) return;
            instance = new IslandOverlay(act);
            instance.show();
            FrameRate.requestHighRefresh(act);
        } catch (Throwable ignored) {}
    }

     
    public static void notifyToggle(String name, boolean on) {
        if (instance != null && instance.view != null) instance.view.pushHint(name, on);
    }

    public static void detach() {
        try { if (instance != null && instance.popup != null) instance.popup.dismiss(); }
        catch (Throwable ignored) {}
        instance = null;
    }

    private void show() {
        view = new IslandView(act);
        popup = new PopupWindow(view, Math.round(WIN_W0 * density), Math.round(WIN_H0 * density));
        popup.setFocusable(false);
        popup.setTouchable(true);
        popup.setOutsideTouchable(false);
        popup.setClippingEnabled(false);
        popup.setBackgroundDrawable(null);
        View decor = act.getWindow().getDecorView();
        decor.post(() -> {
            try {
                popup.showAtLocation(decor, Gravity.TOP | Gravity.CENTER_HORIZONTAL, 0,
                        Math.round(8 * density));
                FrameRate.requestHighRefresh(view);
            } catch (Throwable ignored) {}
        });
    }

    

    private static class Spring {
        float value, target, vel;
        final float stiffness, damping;
        Spring(float stiffness, float damping) { this.stiffness = stiffness; this.damping = damping; }
        void snap(float v) { value = v; target = v; vel = 0f; }
        void to(float t) { target = t; }
        void update(float dt) {
            if (dt > 0.05f) dt = 0.05f;
            float f = -stiffness * (value - target) - damping * vel;
            vel += f * dt;
            value += vel * dt;
        }
        boolean settled() {
            return Math.abs(value - target) < 0.4f && Math.abs(vel) < 0.4f;
        }
    }

    private class IslandView extends View {
        private final Paint blob = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint art = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint title = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint sub = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint accentP = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint wave = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint discP = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();
        private final RectF artRect = new RectF();
        private final RectF curHit = new RectF();
        private final RectF tmp = new RectF();
        private final Matrix artMtx = new Matrix();
        private final Path clipPath = new Path();
        private final Path g2Path = new Path();
        private final Path artPath = new Path();

        

        private void drawG2(Canvas canvas, RectF r, float corner, Paint paint) {
            buildG2(g2Path, g2Key, r, corner);
            if (g2Path.isEmpty()) return;
            canvas.drawPath(g2Path, paint);
        }

        
        
        private final float[] g2Key = new float[5];
        private final float[] g2KeyArt = new float[5];

        private void buildG2(Path out, float[] key, RectF r, float corner) {
            if (key[0] == r.left && key[1] == r.top && key[2] == r.right
                    && key[3] == r.bottom && key[4] == corner && !out.isEmpty()) {
                return;
            }
            key[0] = r.left; key[1] = r.top; key[2] = r.right; key[3] = r.bottom; key[4] = corner;
            SquircleDrawable.buildSquirclePath(out, r.left, r.top, r.right, r.bottom, corner, 0.72f);
        }

        private final Spring sw = new Spring(260f, 33f);
        private final Spring sh = new Spring(260f, 33f);
        private final Spring scorner = new Spring(260f, 33f);

        private float wavePhase = 0f;
        private float discAngle = 0f;
        private boolean expanded = false;

        private final java.util.ArrayList<HintItem> hints = new java.util.ArrayList<>();
        private float lyricFill = 0f;
        private String lyricKey = "";

        private class HintItem {
            String name; boolean on; float timer; float in; float onMix;
            float life;   
            HintItem(String n, boolean o) {
                name = n; on = o; timer = 2.0f; in = 0f; life = 4.0f;
                onMix = o ? 0f : 1f;   
            }
        }

        private Bitmap artBmp;
        private BitmapShader artShader;
        private String lastTrackKey = "";
        private long lastFrame = 0L;
        private int lastShownFps = -1;
        private final MediaReader.NowPlaying[] npHolder = new MediaReader.NowPlaying[1];

        
        private boolean cfgIslandOn = true;
        private boolean cfgMusicOn = true;
        private boolean cfgTimeOn = false;
        private long cfgAt = 0L;
        private Context appCtx;

        private final Choreographer.FrameCallback cb = new Choreographer.FrameCallback() {
            public void doFrame(long t) {
                
                
                
                
                try {
                    FrameRate.onFrame(t);
                    if (lastFrame == 0L) lastFrame = t;
                    float dt = (t - lastFrame) / 1_000_000_000f;
                    if (dt > 0.1f) dt = 0.1f;
                    lastFrame = t;
                    step(dt);
                    if (needsRedraw()) invalidate();
                } catch (Throwable ignored) {
                    
                } finally {
                    if (alive) Choreographer.getInstance().postFrameCallback(this);
                }
            }
        };

        private boolean alive = false;

        IslandView(Context c) {
            super(c);
            
            
            
            title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            sub.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
            sw.snap(dp(138)); sh.snap(dp(30)); scorner.snap(dp(15));
        }

        void pushHint(String name, boolean on) {
            for (HintItem h : hints) {
                if (h.name.equals(name)) {
                    h.on = on;
                    h.timer = 2.0f;
                    
                    h.life = Math.min(4.0f, h.life + 1.0f);
                    return;
                }
            }
            hints.add(new HintItem(name, on));
        }

        protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            lastFrame = 0L;
            alive = true;
            Choreographer.getInstance().postFrameCallback(cb);
        }

        protected void onDetachedFromWindow() {
            super.onDetachedFromWindow();
            alive = false;
            Choreographer.getInstance().removeFrameCallback(cb);
        }

        private void refreshCfg() {
            long now = SystemClock.uptimeMillis();
            if (now - cfgAt < 500L) return;
            cfgAt = now;
            cfgIslandOn = ConfigManager.getBoolean(CFG, K_ISLAND, true);
            cfgMusicOn = ConfigManager.getBoolean(CFG, K_MUSIC, true);
            cfgTimeOn = ConfigManager.getBoolean(CFG, K_TIME, false);
        }

         
        private boolean needsRedraw() {
            if (!hints.isEmpty()) return true;
            MediaReader.NowPlaying np = npHolder[0];
            if (np != null && np.active && np.playing) return true;
            if (cfgTimeOn) return true;
            if (!sw.settled() || !sh.settled() || !scorner.settled()) return true;
            int f = FrameRate.getFpsInt();
            if (f != lastShownFps) { lastShownFps = f; return true; }
            return false;
        }

        private void step(float dt) {
            for (int i = hints.size() - 1; i >= 0; i--) {
                HintItem h = hints.get(i);
                h.timer -= dt;
                h.life -= dt;
                h.in = Math.min(1f, h.in + dt * 6f);
                h.onMix += ((h.on ? 1f : 0f) - h.onMix) * Math.min(1f, dt * 9f);
                if (h.timer <= 0f || h.life <= 0f) hints.remove(i);
            }
            wavePhase += dt * 6f;

            refreshCfg();
            if (appCtx == null) {
                try { appCtx = getContext().getApplicationContext(); } catch (Throwable ignored) {}
            }
            MediaReader.NowPlaying np = cfgMusicOn ? MediaReader.poll(appCtx) : null;
            npHolder[0] = np;
            if (np != null && np.playing) discAngle += dt * 40f;
            updateArt(np);

            if (cfgTimeOn) {
                long now = System.currentTimeMillis();
                if (now / 1000L != cfgAt / 1000L) invalidate();
            }

            if (np != null && np.active && np.title != null) {
                String key = np.title + "|" + (np.artist == null ? "" : np.artist);
                if (!key.equals(lastTrackKey)) {
                    lastTrackKey = key;
                    LyricFetcher.request(np.title, np.artist, np.duration);
                }
            }

            int state = stateOf(np, cfgIslandOn);
            float tw, th, tc;
            if (state == 3) {
                int rows = Math.min(MAX_HINTS, Math.max(1, hints.size()));
                tw = dp(238); th = dp(10) + rows * dp(28); tc = dp(20);
            } else if (state == 2) {
                tw = dp(260); th = dp(76); tc = dp(20);
            } else if (state == 1) {
                tw = dp(150); th = dp(34); tc = dp(17);
            } else {
                tw = measureIdleWidth();
                th = dp(30);
                tc = dp(15);
            }
            if (!cfgIslandOn) { tw = 0f; th = 0f; }

            sw.to(tw); sh.to(th); scorner.to(tc);
            sw.update(dt); sh.update(dt); scorner.update(dt);

            syncWindow();

            
            
            
            updateHit();
        }

        private int winW = -1, winH = -1;
        private boolean touchDown = false;

        

        private void syncWindow() {
            if (popup == null || !popup.isShowing()) return;
            if (touchDown) return;

            int needW, needH;
            boolean still = sw.settled() && sh.settled();
            if (still) {
                needW = Math.round(sw.target) + dp(WIN_PAD);
                needH = Math.round(sh.target) + dp(WIN_PAD) + dp(4);
            } else {
                
                needW = Math.max(winW, Math.round(Math.max(sw.value, sw.target)) + dp(WIN_PAD));
                needH = Math.max(winH, Math.round(Math.max(sh.value, sh.target)) + dp(WIN_PAD) + dp(4));
            }
            needW = Math.max(needW, dp(40));
            needH = Math.max(needH, dp(24));

            if (Math.abs(needW - winW) >= dp(3) || Math.abs(needH - winH) >= dp(3)) {
                winW = needW; winH = needH;
                
                try { popup.update(needW, needH); } catch (Throwable ignored) {}
            }
        }

         
        private void updateHit() {
            float bw = sw.value, bh = sh.value;
            if (bw < dp(2) || bh < dp(2) || !cfgIslandOn) { curHit.setEmpty(); return; }
            float cx = getWidth() / 2f;
            if (cx <= 0f) cx = winW > 0 ? winW / 2f : WIN_W0 * density / 2f;   
            float left = cx - bw / 2f;
            curHit.set(left, dp(4), left + bw, dp(4) + bh);
        }

        private int stateOf(MediaReader.NowPlaying np, boolean islandOn) {
            if (!islandOn) return 0;
            if (!hints.isEmpty()) return 3;
            boolean active = np != null && np.active;
            if (active && expanded) return 2;
            if (active) return 1;
            return 0;
        }

        protected void onDraw(Canvas canvas) {
            float bw = sw.value, bh = sh.value;
            if (bw < dp(2) || bh < dp(2)) return;

            float cx = getWidth() / 2f, top = dp(4);
            float left = cx - bw / 2f;
            rect.set(left, top, left + bw, top + bh);
            float corner = scorner.value;

            
            blob.setColor(0xFF000000);
            drawG2(canvas, rect, corner, blob);

            MediaReader.NowPlaying np = npHolder[0];
            int state = stateOf(np, cfgIslandOn);
            int accent = ThemeManager.getThemeColor();

            
            clipPath.set(g2Path);
            canvas.save();
            canvas.clipPath(clipPath);

            if (state == 3) drawHint(canvas, rect, accent);
            else if (state == 2) drawExpanded(canvas, rect, np, accent);
            else if (state == 1) drawCollapsedMusic(canvas, rect, np);
            else drawIdle(canvas, rect, accent);

            canvas.restore();
        }

         
        private String formatSystemTime() {
            return new java.text.SimpleDateFormat("hh:mm:ss a", java.util.Locale.US)
                    .format(new java.util.Date(System.currentTimeMillis()));
        }

        private float measureIdleWidth() {
            title.setTextSize(dp(11.5f));
            sub.setTextSize(dp(11.5f));
            float gap = dp(6);
            float side = dp(10);
            float time = cfgTimeOn ? title.measureText(formatSystemTime()) : 0f;
            float brand = title.measureText("NyaUI");
            float fps = sub.measureText("FPS: " + FrameRate.getFpsInt());
            float content = cfgTimeOn ? time + gap + brand + gap + fps : brand + dp(7) + fps;
            return Math.max(dp(138), content + side * 2);
        }

        private void drawIdle(Canvas canvas, RectF r, int accent) {
            title.setColor(Color.WHITE);
            title.setAlpha(255);
            title.setTextSize(dp(11.5f));
            title.setTextAlign(Paint.Align.LEFT);

            sub.setColor(accent);
            sub.setAlpha(255);
            sub.setTextSize(dp(11.5f));
            sub.setTextAlign(Paint.Align.LEFT);

            String brand = "NyaUI";
            String fps = "FPS: " + FrameRate.getFpsInt();
            float gap = dp(6);
            float x = r.left + dp(10);
            float by = r.centerY() - (title.ascent() + title.descent()) / 2f;

            if (cfgTimeOn) {
                String time = formatSystemTime();
                canvas.drawText(time, x, by, title);
                x += title.measureText(time) + gap;
            }

            canvas.drawText(brand, x, by, title);
            x += title.measureText(brand) + gap;
            canvas.drawText(fps, x, by, sub);
        }

        private void drawCollapsedMusic(Canvas canvas, RectF r, MediaReader.NowPlaying np) {
            float cy = r.centerY();
            float artSize = r.height() - dp(8);
            float ax = r.left + dp(4);
            artRect.set(ax, cy - artSize / 2f, ax + artSize, cy + artSize / 2f);
            drawArt(canvas, artRect, dp(6));
            drawWaveform(canvas, r.right - dp(28), cy, np != null && np.playing);

            sub.setColor(Color.WHITE);
            sub.setAlpha(235);
            sub.setTextSize(dp(11.5f));
            sub.setTextAlign(Paint.Align.LEFT);
            float tx = artRect.right + dp(8);
            float maxW = (r.right - dp(34)) - tx;
            String t = np != null && np.title != null ? np.title : "";
            canvas.drawText(ellipsize(t, sub, maxW), tx, cy - (sub.ascent() + sub.descent()) / 2f, sub);
        }

         
        private void drawExpanded(Canvas canvas, RectF r, MediaReader.NowPlaying np, int accent) {
            float pad = dp(10);
            float artSize = r.height() - pad * 2f;
            artRect.set(r.left + pad, r.top + pad, r.left + pad + artSize, r.top + pad + artSize);
            drawArt(canvas, artRect, dp(9));

            float tx = artRect.right + dp(10);
            float right = r.right - pad;
            float maxW = right - tx;

            title.setColor(Color.WHITE);
            title.setAlpha(255);
            title.setTextSize(dp(12.5f));
            title.setTextAlign(Paint.Align.LEFT);
            canvas.drawText(ellipsize(safe(np != null ? np.title : ""), title, maxW),
                    tx, r.top + pad + dp(11), title);

            sub.setColor(0xFFB0B0B8);
            sub.setAlpha(255);
            sub.setTextAlign(Paint.Align.LEFT);
            sub.setTextSize(dp(10f));
            canvas.drawText(ellipsize(safe(np != null ? np.artist : ""), sub, maxW),
                    tx, r.top + pad + dp(24), sub);

            
            float ly = r.top + pad + dp(39);
            LyricFetcher.Cur cur = (np != null) ? LyricFetcher.current(np.title, np.artist, np.position) : null;
            String lyric;
            float targetFill;
            if (cur != null) {
                lyric = cur.text;
                long span = Math.max(1, cur.end - cur.start);
                targetFill = clamp01((np.position - cur.start) / (float) span);
                if (!np.playing) targetFill = lyricFill;
            } else {
                lyric = (np != null && np.lyric != null && !np.lyric.trim().isEmpty())
                        ? np.lyric : (np != null ? "\u266A  " + safe(np.title) : "");
                targetFill = 0f;
            }
            String key = lyric == null ? "" : lyric;
            if (!key.equals(lyricKey)) { lyricKey = key; lyricFill = targetFill; }
            lyricFill += (targetFill - lyricFill) * 0.5f;
            if (Math.abs(targetFill - lyricFill) < 0.004f) lyricFill = targetFill;
            float fill = clamp01(lyricFill);

            sub.setTextSize(dp(8.5f));
            String shown = ellipsize(lyric == null ? "" : lyric, sub, maxW);
            float lyW = sub.measureText(shown);
            sub.setColor(0xFFB8BCC4);
            sub.setAlpha(255);
            canvas.drawText(shown, tx, ly, sub);
            if (fill > 0.001f) {
                canvas.save();
                canvas.clipRect(tx, ly - dp(11), tx + lyW * fill, ly + dp(4));
                sub.setColor(accent);
                sub.setAlpha(255);
                canvas.drawText(shown, tx, ly, sub);
                canvas.restore();
            }

            float prog = (np != null && np.duration > 0) ? clamp01((float) np.position / np.duration) : 0f;
            float ph = dp(2.5f);
            float py = r.bottom - pad - ph;
            accentP.setColor(0x33FFFFFF);
            tmp.set(tx, py, right, py + ph);
            canvas.drawRoundRect(tmp, ph / 2f, ph / 2f, accentP);
            accentP.setColor(accent);
            accentP.setAlpha(255);
            tmp.set(tx, py, tx + (right - tx) * prog, py + ph);
            canvas.drawRoundRect(tmp, ph / 2f, ph / 2f, accentP);

            sub.setColor(0xFF8A8A90);
            sub.setAlpha(255);
            sub.setTextSize(dp(7.5f));
            canvas.drawText(fmt(np != null ? np.position : 0), tx, py - dp(3), sub);
            sub.setTextAlign(Paint.Align.RIGHT);
            canvas.drawText(fmt(np != null ? np.duration : 0), right, py - dp(3), sub);
            sub.setTextAlign(Paint.Align.LEFT);
        }

         
        private void drawHint(Canvas canvas, RectF r, int accent) {
            float rowH = dp(28);
            float pad = dp(5);
            int n = Math.min(MAX_HINTS, hints.size());
            for (int i = 0; i < n; i++) {
                HintItem h = hints.get(i);
                float ein = h.in * h.in * (3f - 2f * h.in);
                float top = r.top + pad + i * rowH - (1f - ein) * dp(8);
                float cy = top + rowH / 2f;
                float ra = clamp01(h.timer / 0.4f) * ein;
                float sm = h.onMix * h.onMix * (3f - 2f * h.onMix);

                float tx = r.left + dp(14);
                title.setColor(Color.WHITE);
                title.setAlpha((int) (ra * 255));
                title.setTextSize(dp(12f));
                title.setTextAlign(Paint.Align.LEFT);
                float trackW = dp(30), trackH = dp(16);
                float trackRight = r.right - dp(10);
                float trackLeft = trackRight - trackW;
                canvas.drawText(ellipsize(h.name, title, trackLeft - tx - dp(8)), tx,
                        cy - (title.ascent() + title.descent()) / 2f, title);

                float tTop = cy - trackH / 2f;
                tmp.set(trackLeft, tTop, trackRight, tTop + trackH);
                accentP.setColor(blend(0xFF3A3A40, accent, sm));
                accentP.setAlpha((int) (ra * 255));
                canvas.drawRoundRect(tmp, trackH / 2f, trackH / 2f, accentP);

                float kpad = dp(2.5f);
                float knobR = trackH / 2f - kpad;
                float kxMin = trackLeft + kpad + knobR;
                float kxMax = trackRight - kpad - knobR;
                discP.setColor(0xFFFFFFFF);
                discP.setAlpha((int) (ra * 255));
                canvas.drawCircle(kxMin + (kxMax - kxMin) * sm, cy, knobR, discP);
            }
        }

         
        private void drawArt(Canvas canvas, RectF rr, float corner) {
            if (artShader != null && artBmp != null) {
                float scale = rr.width() / Math.max(1, artBmp.getWidth());
                artMtx.setScale(scale, scale);
                artMtx.postTranslate(rr.left, rr.top);
                artShader.setLocalMatrix(artMtx);
                art.setShader(artShader);
                art.setAlpha(255);
                buildG2(artPath, g2KeyArt, rr, corner);
                if (!artPath.isEmpty()) canvas.drawPath(artPath, art);
                art.setShader(null);
            } else {
                int accent = ThemeManager.getThemeColor();
                canvas.save();
                canvas.rotate(discAngle, rr.centerX(), rr.centerY());
                discP.setColor(blend(accent, 0xFF000000, 0.35f));
                discP.setAlpha(255);
                buildG2(artPath, g2KeyArt, rr, corner);
                if (!artPath.isEmpty()) canvas.drawPath(artPath, discP);
                canvas.restore();
                discP.setColor(accent);
                canvas.drawCircle(rr.centerX(), rr.centerY(), rr.width() * 0.08f, discP);
            }
        }

         
        private void drawWaveform(Canvas canvas, float cx, float cy, boolean playing) {
            wave.setColor(ThemeManager.getThemeColor());
            wave.setAlpha(255);
            float bw = dp(2.4f), gap = dp(2.2f);
            for (int i = 0; i < 4; i++) {
                float amp = playing ? dp(5.5f) : dp(1.2f);
                float hgt = dp(3.5f) + amp * (0.5f + 0.5f * (float) Math.sin(wavePhase + i * 1.1f));
                float x = cx + i * (bw + gap);
                tmp.set(x, cy - hgt, x + bw, cy + hgt);
                canvas.drawRoundRect(tmp, bw / 2f, bw / 2f, wave);
            }
        }

        private void updateArt(MediaReader.NowPlaying np) {
            if (np != null && np.art != null && np.art != artBmp) {
                artBmp = np.art;
                artShader = new BitmapShader(artBmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
            } else if (np == null || np.art == null) {
                artBmp = null; artShader = null;
            }
        }

        public boolean onTouchEvent(MotionEvent e) {
            if (!cfgIslandOn) return false;
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    
                    
                    
                    touchDown = true;
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    touchDown = false;
                    return true;
                case MotionEvent.ACTION_UP:
                    touchDown = false;
                    if (!hints.isEmpty()) {
                        
                        
                        hints.clear();
                        invalidate();
                        return true;
                    }
                    MediaReader.NowPlaying np = npHolder[0];
                    
                    
                    if (expanded || (np != null && np.active)) {
                        expanded = !expanded;
                        invalidate();
                    }
                    return true;
            }
            return false;
        }

        private String fmt(long ms) {
            if (ms <= 0) return "0:00";
            long s = ms / 1000; long m = s / 60; s = s % 60;
            return m + ":" + (s < 10 ? "0" + s : String.valueOf(s));
        }
        private String safe(String s) { return s == null ? "" : s; }
        private String ellipsize(String s, Paint p, float maxW) {
            if (s == null) return "";
            if (p.measureText(s) <= maxW) return s;
            int len = s.length();
            while (len > 0 && p.measureText(s.substring(0, len) + "\u2026") > maxW) len--;
            return s.substring(0, Math.max(0, len)) + "\u2026";
        }
        private int blend(int c1, int c2, float t) {
            int a1 = (c1 >>> 24), r1 = (c1 >> 16) & 0xff, g1 = (c1 >> 8) & 0xff, b1 = c1 & 0xff;
            int a2 = (c2 >>> 24), r2 = (c2 >> 16) & 0xff, g2 = (c2 >> 8) & 0xff, b2 = c2 & 0xff;
            return ((int) (a1 + (a2 - a1) * t) << 24) | ((int) (r1 + (r2 - r1) * t) << 16)
                    | ((int) (g1 + (g2 - g1) * t) << 8) | (int) (b1 + (b2 - b1) * t);
        }
        private float clamp01(float v) { return v < 0f ? 0f : (v > 1f ? 1f : v); }
    }

    private int dp(float v) { return Math.round(v * density); }
}
