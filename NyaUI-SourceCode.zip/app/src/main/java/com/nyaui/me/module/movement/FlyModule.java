package com.nyaui.me.module.movement;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class FlyModule extends Module {
    public FlyModule() { super("Fly", ModuleCategory.MOVEMENT, ""); setChineseName("Fly"); }
    public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("Fly"); } catch (Throwable t) {} }
    public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("Fly"); } catch (Throwable t) {} }
    public void configureSubMenu(SubMenuPanel s) {
        super.configureSubMenu(s);
        String n = getName();
        s.addSlider("Speed", 10, 100, (int)(SafeCall.getFloat(n, 0) * 100), "%.2f", v -> SafeCall.setFloat(n, 0, v / 100f));
        int cnt = SafeCall.getModeSize(n, 0); java.util.List<String> modes = new java.util.ArrayList<>(); for (int i = 0; i < cnt; i++) modes.add(SafeCall.getModeString(n, 0, i));
        s.addMode("Mode", modes, SafeCall.getModeValue(n, 0), (index, name) -> SafeCall.setModeValue(n, 0, index));
    }
}
