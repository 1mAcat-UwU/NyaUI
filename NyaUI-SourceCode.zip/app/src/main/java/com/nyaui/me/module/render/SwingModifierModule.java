package com.nyaui.me.module.render;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class SwingModifierModule extends Module {
    public SwingModifierModule() {
        super("SwingModifier", ModuleCategory.RENDER);
    }
}
