package com.nyaui.me.module.misc;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class AutoReconnectModule extends Module {
    public AutoReconnectModule() {
        super("AutoReconnect", ModuleCategory.MISC);
    }
}
