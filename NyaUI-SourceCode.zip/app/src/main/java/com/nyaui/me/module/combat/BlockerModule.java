package com.nyaui.me.module.combat;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class BlockerModule extends Module {
    public BlockerModule() {
        super("Blocker", ModuleCategory.COMBAT);
    }
}
