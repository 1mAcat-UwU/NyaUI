package com.nyaui.me.ui;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;

import com.nyaui.me.config.ConfigManager;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public final class UserProfile {
    public static final String DEFAULT_USERNAME = "NyaUI User";
    public static final String DEFAULT_BIO = "にゃ ~ ん";
    private static final String GROUP = "UserProfile";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_BIO = "bio";
    private static final String AVATAR_FILE = "user_avatar.jpg";

    public interface Listener {
        void onUserProfileChanged();
    }

    private static final List<Listener> listeners = new ArrayList<>();

    private UserProfile() {}

    public static void addListener(Listener l) {
        if (l != null && !listeners.contains(l)) listeners.add(l);
    }

    public static void removeListener(Listener l) {
        listeners.remove(l);
    }

    private static void notifyChanged() {
        for (Listener l : new ArrayList<>(listeners)) {
            try { l.onUserProfileChanged(); } catch (Throwable ignored) {}
        }
    }

    public static String getUsername() {
        String v = ConfigManager.getString(GROUP, KEY_USERNAME, DEFAULT_USERNAME);
        if (v == null || v.trim().isEmpty()) return DEFAULT_USERNAME;
        return v;
    }

    public static void setUsername(String username) {
        String v = username == null ? "" : username.trim();
        if (v.isEmpty()) v = DEFAULT_USERNAME;
        ConfigManager.saveString(GROUP, KEY_USERNAME, v);
        notifyChanged();
    }

    public static String getBio() {
        String v = ConfigManager.getString(GROUP, KEY_BIO, DEFAULT_BIO);
        if (v == null || v.trim().isEmpty()) return DEFAULT_BIO;
        return v;
    }

    public static void setBio(String bio) {
        String v = bio == null ? "" : bio.trim();
        if (v.isEmpty()) v = DEFAULT_BIO;
        ConfigManager.saveString(GROUP, KEY_BIO, v);
        notifyChanged();
    }

    public static File getAvatarFile(Context ctx) {
        return new File(ctx.getFilesDir(), AVATAR_FILE);
    }

    public static boolean hasCustomAvatar(Context ctx) {
        File f = getAvatarFile(ctx);
        return f.exists() && f.length() > 0;
    }

    public static Bitmap loadAvatarBitmap(Context ctx) {
        try {
            File f = getAvatarFile(ctx);
            if (!f.exists()) return null;
            return BitmapFactory.decodeFile(f.getAbsolutePath());
        } catch (Throwable t) {
            return null;
        }
    }

    public static boolean setAvatarFromUri(Context ctx, Uri uri) {
        if (ctx == null || uri == null) return false;
        try (InputStream in = ctx.getContentResolver().openInputStream(uri);
             FileOutputStream out = new FileOutputStream(getAvatarFile(ctx))) {
            if (in == null) return false;
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            out.flush();
            notifyChanged();
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    public static void clearAvatar(Context ctx) {
        try {
            File f = getAvatarFile(ctx);
            if (f.exists()) f.delete();
        } catch (Throwable ignored) {}
        notifyChanged();
    }
}
