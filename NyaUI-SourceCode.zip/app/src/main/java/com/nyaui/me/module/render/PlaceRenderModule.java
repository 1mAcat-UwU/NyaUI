package com.nyaui.me.module.render;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class PlaceRenderModule extends Module {
    public PlaceRenderModule() {
        super("PlaceRender", ModuleCategory.RENDER);
    }
}
