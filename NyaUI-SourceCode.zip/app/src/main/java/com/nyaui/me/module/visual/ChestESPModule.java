package com.nyaui.me.module.visual;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;

public class ChestESPModule extends Module {
    public ChestESPModule() { super("ChestESP", ModuleCategory.VISUAL, ""); setChineseName("Chest ESP"); }
    public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("ChestESP"); } catch (Throwable t) {} }
    public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("ChestESP"); } catch (Throwable t) {} }
}
