package com.nyaui.me.module.render;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class TwoDESPModule extends Module {
    public TwoDESPModule() {
        super("2DESP", ModuleCategory.RENDER);
    }
}
