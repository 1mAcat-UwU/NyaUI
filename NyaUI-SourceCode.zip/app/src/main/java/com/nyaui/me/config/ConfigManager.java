package com.nyaui.me.config;

import android.content.Context;
import android.content.SharedPreferences;

public class ConfigManager {

    private static final String PREF_NAME = "phoenix_gui_config";
    private static SharedPreferences sharedPreferences;

    private static final String KEY_DYNAMIC_ISLAND_ENABLED = "dynamic_island_enabled";
    private static final String KEY_UI_SCALE = "ClickGUI_ui_scale_factor";
    private static final String KEY_DYNAMIC_ISLAND_SCALE = "dynamic_island_scale";
    private static final String KEY_DYNAMIC_ISLAND_USERNAME = "dynamic_island_username";
    private static final String KEY_HUD_POSITION_FORMAT = "hud_position_format";

    public static void init(Context context) {
        if (sharedPreferences == null) {
            sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
            normalizeHudPositionConfig();
        }
    }

    public static void normalizeHudPositionConfig() {
        if (sharedPreferences == null) return;
        if (sharedPreferences.getInt(KEY_HUD_POSITION_FORMAT, 0) >= 1) return;
        SharedPreferences.Editor editor = sharedPreferences.edit();
        normalizeHudValue(editor, "HUD_watermark_x", 4f);
        normalizeHudValue(editor, "HUD_watermark_y", 4f);
        normalizeHudValue(editor, "HUD_notifications_x", 100f);
        normalizeHudValue(editor, "HUD_notifications_y", 100f);
        normalizeHudValue(editor, "HUD_arraylist_x", 100f);
        normalizeHudValue(editor, "HUD_arraylist_y", 4f);
        editor.putInt(KEY_HUD_POSITION_FORMAT, 1).apply();
    }

    private static void normalizeHudValue(SharedPreferences.Editor editor, String key, float fallback) {
        if (!sharedPreferences.contains(key)) {
            editor.putFloat(key, fallback);
            return;
        }
        float value;
        try {
            value = sharedPreferences.getFloat(key, fallback);
        } catch (ClassCastException e) {
            value = sharedPreferences.getInt(key, Math.round(fallback));
        }
        if (value >= 0f && value <= 1f) value *= 100f;
        editor.putFloat(key, Math.max(0f, Math.min(100f, value)));
    }

    private static String getKey(String moduleName, String configKey) {
        return moduleName + "_" + configKey;
    }
        private static SharedPreferences getPrefs() {
        if (sharedPreferences == null) {
            throw new IllegalStateException("ConfigManager not initialized. Call init() first.");
        }
        return sharedPreferences;
    }
    public static float getFloat(String moduleName, String key, float defaultValue) {
        try {
            return getPrefs().getFloat(moduleName + "_" + key, defaultValue);
        } catch (ClassCastException e) {

            try {
                return (float) getPrefs().getInt(moduleName + "_" + key, (int) defaultValue);
            } catch (Exception e2) {
                return defaultValue;
            }
        }
    }

    public static void saveInt(String moduleName, String configKey, int value) {
        if (sharedPreferences == null) return;
        sharedPreferences.edit().putInt(getKey(moduleName, configKey), value).apply();
    }

    public static int getInt(String moduleName, String configKey, int defaultValue) {
        if (sharedPreferences == null) return defaultValue;
        return sharedPreferences.getInt(getKey(moduleName, configKey), defaultValue);
    }
    public static void saveBoolean(String moduleName, String configKey, boolean value) {
        if (sharedPreferences == null) return;
        sharedPreferences.edit().putBoolean(getKey(moduleName, configKey), value).apply();
    }

    public static boolean getBoolean(String moduleName, String configKey, boolean defaultValue) {
        if (sharedPreferences == null) return defaultValue;
        return sharedPreferences.getBoolean(getKey(moduleName, configKey), defaultValue);
    }

    public static void saveModuleConfig(String moduleName, String configKey, int value) {
        saveInt(moduleName, configKey, value);
    }

    public static void saveModuleConfig(String moduleName, String configKey, boolean value) {
        saveBoolean(moduleName, configKey, value);
    }

    public static boolean getDynamicIslandEnabled() {
        return getPrefs().getBoolean(KEY_DYNAMIC_ISLAND_ENABLED, true);
    }

    public static void setDynamicIslandEnabled(boolean enabled) {
        getPrefs().edit()
            .putBoolean(KEY_DYNAMIC_ISLAND_ENABLED, enabled)
            .apply();
    }

    public static float getDynamicIslandScale() {
        return getPrefs().getFloat(KEY_DYNAMIC_ISLAND_SCALE, 0.7f);
    }

    public static void setDynamicIslandScale(float scale) {
        getPrefs().edit().putFloat(KEY_DYNAMIC_ISLAND_SCALE, scale).apply();
    }

    public static float getTargetHUDX() {
        return getPrefs().getFloat("targetHudX", 0.5f);
    }

    public static void setTargetHUDX(float x) {
        getPrefs().edit().putFloat("targetHudX", x).apply();
    }

    public static float getTargetHUDY() {
        return getPrefs().getFloat("targetHudY", 0.5f);
    }

    public static void setTargetHUDY(float y) {
        getPrefs().edit().putFloat("targetHudY", y).apply();
    }

    public static float getTargetHUDScale() {
        return getPrefs().getFloat("targetHudScale", 1.0f);
    }

    public static void setTargetHUDScale(float scale) {
        getPrefs().edit().putFloat("targetHudScale", scale).apply();
    }

    public static boolean isRainbowModeEnabled() {
        return getPrefs().getBoolean("rainbowModeEnabled", false);
    }

    public static void setRainbowModeEnabled(boolean enabled) {
        getPrefs().edit().putBoolean("rainbowModeEnabled", enabled).apply();
    }

    public static String getDynamicIslandUsername() {
        return getPrefs().getString(KEY_DYNAMIC_ISLAND_USERNAME, "User");
    }

    public static void setDynamicIslandUsername(String username) {
        getPrefs().edit()
            .putString(KEY_DYNAMIC_ISLAND_USERNAME, username)
            .apply();
    }

    public static void clearAll() {
        getPrefs().edit().clear().apply();
    }

    public static boolean isSoundEnabled() {
        return getPrefs().getBoolean("soundEnabled", true);
    }

    public static void setSoundEnabled(boolean enabled) {
        getPrefs().edit().putBoolean("soundEnabled", enabled).apply();
    }

    public static boolean isBlurEnabled() {
        return getPrefs().getBoolean("blurEnabled", true);
    }

    public static void setBlurEnabled(boolean enabled) {
        getPrefs().edit().putBoolean("blurEnabled", enabled).apply();
    }

    public static int getThemeColor() {
        return getPrefs().getInt("themeColor", 0xFF96CCFF);
    }

    public static void setThemeColor(int color) {
        getPrefs().edit().putInt("themeColor", color).apply();
    }

    public static String getConfigFileName() {
        String name = getPrefs().getString("config_file_name", "cfg.txt");
        if (name == null || name.trim().isEmpty()) return "cfg.txt";
        return sanitizeConfigFileName(name.trim());
    }

    public static void setConfigFileName(String name) {
        String safe = sanitizeConfigFileName(name);
        getPrefs().edit().putString("config_file_name", safe).apply();
    }

    private static String sanitizeConfigFileName(String name) {
        if (name == null) return "cfg.txt";
        String safe = name.trim().replace('\\', '_').replace('/', '_');
        if (safe.isEmpty()) safe = "cfg.txt";
        if (safe.equals(".") || safe.equals("..")) safe = "cfg.txt";
        if (!safe.contains(".")) safe = safe + ".txt";
        return safe;
    }

    public static boolean isWatermarkEnabled() {
        return getPrefs().getBoolean("watermarkEnabled", true);
    }

    public static void setWatermarkEnabled(boolean enabled) {
        getPrefs().edit().putBoolean("watermarkEnabled", enabled).apply();
    }

    public static boolean isChinese() {
        return getPrefs().getBoolean("is_chinese", false);
    }

    public static void setChinese(boolean isChinese) {
        getPrefs().edit().putBoolean("is_chinese", isChinese).apply();
    }

    public static float getBlurRadius() {
        return getPrefs().getFloat("blurRadius", 10.0f);
    }

    public static void setBlurRadius(float radius) {
        getPrefs().edit().putFloat("blurRadius", radius).apply();
    }

    private ConfigManager() {

    }

    public static final String UI_STYLE_DEFAULT = "default";
    public static final String UI_STYLE_CLASSIC = "classic";

    public static String getUiStyle() {
        return getPrefs().getString("ui_style", UI_STYLE_DEFAULT);
    }

    public static void setUiStyle(String style) {
        getPrefs().edit().putString("ui_style", style == null ? UI_STYLE_DEFAULT : style).apply();
    }

    public static boolean isClassicUi() {
        return UI_STYLE_CLASSIC.equalsIgnoreCase(getUiStyle());
    }

    public static float getUiScale() {
        return Math.max(0.5f, Math.min(1.2f, getPrefs().getFloat(KEY_UI_SCALE, 0.95f)));
    }

    public static void setUiScale(float scale) {
        getPrefs().edit().putFloat(KEY_UI_SCALE, Math.max(0.5f, Math.min(1.2f, scale))).apply();
    }

    public static void saveFloat(String moduleName, String key, float value) {
        getPrefs().edit().putFloat(moduleName + "_" + key, value).apply();
    }

    private static final String MODULE_STATE = "ModuleState";

    public static void saveModuleEnabled(String moduleName, boolean enabled) {
        try {
            getPrefs().edit().putBoolean(MODULE_STATE + "_" + moduleName, enabled).apply();
        } catch (Throwable ignored) {}
    }

    public static boolean hasModuleEnabled(String moduleName) {
        try {
            return getPrefs().contains(MODULE_STATE + "_" + moduleName);
        } catch (Throwable t) {
            return false;
        }
    }

    public static boolean getModuleEnabled(String moduleName, boolean defaultValue) {
        try {
            return getPrefs().getBoolean(MODULE_STATE + "_" + moduleName, defaultValue);
        } catch (Throwable t) {
            return defaultValue;
        }
    }

    public static void saveColorMode(String group, String key, String mode) {
        saveString(group, key + "_mode", mode == null ? "solid" : mode);
    }

    public static String getColorMode(String group, String key) {
        return getString(group, key + "_mode", "solid");
    }

    public static void saveGradientColors(String group, String key, int start, int end) {
        saveInt(group, key + "_g0", start);
        saveInt(group, key + "_g1", end);
    }

    public static int getGradientStart(String group, String key, int fallback) {
        return getInt(group, key + "_g0", fallback);
    }

    public static int getGradientEnd(String group, String key, int fallback) {
        return getInt(group, key + "_g1", fallback);
    }

    public static void saveString(String moduleName, String configKey, String value) {
        getPrefs().edit().putString(getKey(moduleName, configKey), value == null ? "" : value).apply();
    }

    public static String getString(String moduleName, String configKey, String defaultValue) {
        return getPrefs().getString(getKey(moduleName, configKey), defaultValue);
    }

    public static void clearKeysWithPrefix(String prefix) {
        try {
            android.content.SharedPreferences prefs = getPrefs();
            android.content.SharedPreferences.Editor editor = prefs.edit();
            for (String k : prefs.getAll().keySet()) {
                if (k != null && k.startsWith(prefix)) editor.remove(k);
            }
            editor.apply();
        } catch (Throwable ignored) {}
    }

    public static void clearModuleConfig(String moduleName) {
        if (moduleName == null || moduleName.isEmpty()) return;
        clearKeysWithPrefix(moduleName + "_");
    }

}
