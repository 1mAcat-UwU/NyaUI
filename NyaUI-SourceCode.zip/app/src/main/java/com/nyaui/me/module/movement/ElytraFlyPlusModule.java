package com.nyaui.me.module.movement;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class ElytraFlyPlusModule extends Module {
    public ElytraFlyPlusModule() {
        super("ElytraFlyPlus", ModuleCategory.MOVEMENT);
    }
}
