package com.nyaui.me.module.player;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class CrashModule extends Module {
    public CrashModule() { super("Crash", ModuleCategory.PLAYER, ""); setChineseName("Crash Server"); }
    public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("Crash"); } catch (Throwable t) {} }
    public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("Crash"); } catch (Throwable t) {} }
    public void configureSubMenu(SubMenuPanel s) {
        super.configureSubMenu(s);
        String n = getName();
        int cnt = SafeCall.getModeSize(n, 0); java.util.List<String> modes = new java.util.ArrayList<>(); for (int i = 0; i < cnt; i++) modes.add(SafeCall.getModeString(n, 0, i));
        s.addMode("Mode", modes, SafeCall.getModeValue(n, 0), (index, name) -> SafeCall.setModeValue(n, 0, index));
    }
}
