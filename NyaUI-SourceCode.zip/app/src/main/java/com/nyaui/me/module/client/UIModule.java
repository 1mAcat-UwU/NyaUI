package com.nyaui.me.module.client;

import com.nyaui.me.config.ConfigManager;
import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.ui.PhoenixPopup;
import com.nyaui.me.ui.SoundPlayer;
import com.nyaui.me.ui.ThemeManager;
import com.nyaui.me.ui.UiBackground;
import com.nyaui.me.ui.widgets.ColorPickerView;
import com.nyaui.me.ui.widgets.SubMenuPanel;


public class UIModule extends Module {
    public UIModule() {
        super("UI", ModuleCategory.CLIENT, "");
        setChineseName("UI");
    }

    public boolean shouldShowInArraylist() { return false; }
    public boolean supportsShortcut() { return false; }

    protected void onEnable() {
        PhoenixPopup.showClickGui();
    }

    protected void onDisable() {
        PhoenixPopup.hideMenus();
    }

    protected void onResetSettings() {
        ThemeManager.resetToFactoryDefaults();
        ThemeManager.syncActiveStyleColor();
        ConfigManager.saveColorMode("UI", "background", "solid");
        ConfigManager.saveInt("UI", "background", UiBackground.DEFAULT_COLOR);
        ConfigManager.saveGradientColors("UI", "background", UiBackground.DEFAULT_COLOR, UiBackground.DEFAULT_COLOR);
        ConfigManager.saveInt("UI", "background_alpha", android.graphics.Color.alpha(UiBackground.DEFAULT_COLOR));
        ConfigManager.saveFloat("UI", "background_speed", 1f);
        ConfigManager.saveInt("UI", "background_dir", 0);
        ConfigManager.saveFloat("UI", "ui_scale_factor", 0.95f);
        ConfigManager.setUiScale(0.95f);
        ConfigManager.setSoundEnabled(true);
        ConfigManager.setRainbowModeEnabled(false);
        try { PhoenixPopup.refreshUiBackground(); } catch (Throwable ignored) {}
    }

    public void configureSubMenu(SubMenuPanel subMenu) {
        super.configureSubMenu(subMenu);
        subMenu.addSectionTitle("Theme");
        subMenu.addThemeModeSwitch();
        subMenu.addSwitch("Rainbow", ThemeManager.isRainbowModeEnabled(), ThemeManager::setRainbowModeEnabled);
        subMenu.addThemeButtons();
        subMenu.addSectionTitle("Custom Color");
        subMenu.addCustomView(new ColorPickerView(subMenu.getContext()));

        subMenu.addDivider();
        subMenu.addSectionTitle("Interface");
        float scale = ConfigManager.getFloat("UI", "ui_scale_factor", ConfigManager.getFloat("ClickGUI", "ui_scale_factor", 0.95f));
        int scalePct = Math.round(scale * 100f);
        subMenu.addSlider("UI Size", 50, 120, scalePct, "%d%%", v -> {
            float s = Math.max(0.5f, Math.min(1.2f, v / 100f));
            ConfigManager.saveFloat("UI", "ui_scale_factor", s);
            ConfigManager.setUiScale(s);
        });
        if (subMenu.getLastSlider() != null) {
            subMenu.getLastSlider().setOnValueChangeFinishedListener(v -> {
                final float s = Math.max(0.5f, Math.min(1.2f, v / 100f));
                ConfigManager.saveFloat("UI", "ui_scale_factor", s);
                ConfigManager.setUiScale(s);
                subMenu.post(() -> PhoenixPopup.applyUiScale(s));
            });
        }
        subMenu.addSwitch("UI Sound", ConfigManager.isSoundEnabled(), enabled -> {
            ConfigManager.setSoundEnabled(enabled);
            if (enabled) SoundPlayer.playClick();
        });

        subMenu.addDivider();
        SubMenuPanel.ExpandableSection colorSection = subMenu.addExpandableSection("Color", false);
        subMenu.addGradientColorSettingTo(colorSection.getContent(), "UI", "background", 0xCC211F26, color -> {
            try { PhoenixPopup.refreshUiBackground(); } catch (Throwable ignored) {}
        });
    }
}
