package com.nyaui.me.module.client;

import com.nyaui.me.config.ConfigManager;
import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.ui.PhoenixPopup;
import com.nyaui.me.ui.SoundPlayer;
import com.nyaui.me.ui.ThemeManager;
import com.nyaui.me.ui.widgets.ColorPickerView;
import com.nyaui.me.ui.widgets.SubMenuPanel;

import java.util.ArrayList;
import java.util.List;

public class UIModule extends Module {
    public UIModule() {
        super("UI", ModuleCategory.CLIENT, "");
        setChineseName("UI");
    }

    public boolean shouldShowInArraylist() { return false; }
    public boolean supportsShortcut() { return false; }

    protected void onEnable() {
        PhoenixPopup.showClickGui();
    }

    protected void onDisable() {
        PhoenixPopup.hideMenus();
    }

    public void configureSubMenu(SubMenuPanel subMenu) {
        super.configureSubMenu(subMenu);
        subMenu.addSectionTitle("UI Style");
        List<String> styles = new ArrayList<>();
        styles.add("Default");
        styles.add("Classic");
        int cur = ConfigManager.isClassicUi() ? 1 : 0;
        subMenu.addMode("Style", styles, cur, (index, mode) -> {
            ConfigManager.setUiStyle(index == 1 ? ConfigManager.UI_STYLE_CLASSIC : ConfigManager.UI_STYLE_DEFAULT);
            ThemeManager.syncActiveStyleColor();
            PhoenixPopup.hideMenus();
        });

        subMenu.addDivider();
        subMenu.addSectionTitle("Theme");
        subMenu.addThemeModeSwitch();
        subMenu.addSwitch("Rainbow", ThemeManager.isRainbowModeEnabled(), ThemeManager::setRainbowModeEnabled);
        subMenu.addThemeButtons();
        subMenu.addSectionTitle("Custom Color");
        subMenu.addCustomView(new ColorPickerView(subMenu.getContext()));

        subMenu.addDivider();
        subMenu.addSectionTitle("Interface");
        float scale = ConfigManager.getFloat("UI", "ui_scale_factor", ConfigManager.getFloat("ClickGUI", "ui_scale_factor", 0.95f));
        int scalePct = Math.round(scale * 100f);
        subMenu.addSlider("UI Size", 50, 120, scalePct, "%d%%", v -> {
            float s = Math.max(0.5f, Math.min(1.2f, v / 100f));
            ConfigManager.saveFloat("UI", "ui_scale_factor", s);
            PhoenixPopup.applyUiScale(s);
        });
        subMenu.addSwitch("UI Sound", ConfigManager.isSoundEnabled(), enabled -> {
            ConfigManager.setSoundEnabled(enabled);
            if (enabled) SoundPlayer.playClick();
        });

        subMenu.addDivider();
        subMenu.addSectionTitle("UI Background");
        subMenu.addGradientColorSetting("UI", "background", 0xCC211F26, color -> {
            try { com.nyaui.me.ui.PhoenixPopup.refreshUiBackground(); } catch (Throwable ignored) {}
        });
    }
}
