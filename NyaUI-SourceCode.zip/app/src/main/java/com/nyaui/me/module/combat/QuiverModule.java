package com.nyaui.me.module.combat;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class QuiverModule extends Module {
    public QuiverModule() {
        super("Quiver", ModuleCategory.COMBAT);
    }
}
