package com.nyaui.me.module.misc;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class SilentDisconnectModule extends Module {
    public SilentDisconnectModule() {
        super("SilentDisconnect", ModuleCategory.MISC);
    }
}
