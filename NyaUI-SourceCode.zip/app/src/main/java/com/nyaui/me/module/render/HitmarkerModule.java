package com.nyaui.me.module.render;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class HitmarkerModule extends Module {
    public HitmarkerModule() {
        super("Hitmarker", ModuleCategory.RENDER);
    }
}
