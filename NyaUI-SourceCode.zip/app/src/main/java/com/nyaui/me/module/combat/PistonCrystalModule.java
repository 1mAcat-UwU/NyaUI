package com.nyaui.me.module.combat;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class PistonCrystalModule extends Module {
    public PistonCrystalModule() {
        super("PistonCrystal", ModuleCategory.COMBAT);
    }
}
