package com.nyaui.me.ui;

import android.app.Activity;
import android.os.Build;
import android.view.Choreographer;
import android.view.Display;
import android.view.Window;
import android.view.WindowManager;

public final class FrameRate {

    private FrameRate() {}

     
     
    private static Display displayOf(Activity act) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Display d = act.getDisplay();
                if (d != null) return d;
            }
        } catch (Throwable ignored) {}
        try { return act.getWindowManager().getDefaultDisplay(); }
        catch (Throwable ignored) { return null; }
    }

    private static Display displayOf(android.content.Context ctx) {
        try {
            WindowManager wm = (WindowManager) ctx.getSystemService(android.content.Context.WINDOW_SERVICE);
            return wm.getDefaultDisplay();
        } catch (Throwable ignored) { return null; }
    }

    

    public static void requestHighRefresh(Activity act) {
        if (act == null) return;
        try {
            Window w = act.getWindow();
            if (w == null) return;
            Display d = displayOf(act);
            if (d == null) return;
            WindowManager.LayoutParams lp = w.getAttributes();
            applyBestMode(d, lp);
            w.setAttributes(lp);
        } catch (Throwable ignored) {}
    }

     
    public static void requestHighRefresh(android.view.View anyViewInWindow) {
        if (anyViewInWindow == null) return;
        try {
            android.view.View root = anyViewInWindow.getRootView();
            if (root == null) return;
            android.view.ViewGroup.LayoutParams glp = root.getLayoutParams();
            if (!(glp instanceof WindowManager.LayoutParams)) return;
            WindowManager.LayoutParams lp = (WindowManager.LayoutParams) glp;
            Display d = displayOf(anyViewInWindow.getContext());
            if (d == null) return;
            applyBestMode(d, lp);
            WindowManager wm = (WindowManager) anyViewInWindow.getContext()
                    .getSystemService(android.content.Context.WINDOW_SERVICE);
            wm.updateViewLayout(root, lp);
        } catch (Throwable ignored) {}
    }

    private static void applyBestMode(Display d, WindowManager.LayoutParams lp) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return;
        Display.Mode cur = d.getMode();
        Display.Mode[] modes = d.getSupportedModes();
        if (cur == null || modes == null || modes.length == 0) return;

        int cw = cur.getPhysicalWidth(), ch = cur.getPhysicalHeight();
        float bestSameRes = cur.getRefreshRate();
        int bestSameId = cur.getModeId();
        float bestAny = cur.getRefreshRate();
        int bestAnyId = cur.getModeId();

        for (Display.Mode m : modes) {
            float r = m.getRefreshRate();
            if (r > bestAny + 0.1f) { bestAny = r; bestAnyId = m.getModeId(); }
            if (m.getPhysicalWidth() == cw && m.getPhysicalHeight() == ch
                    && r > bestSameRes + 0.1f) {
                bestSameRes = r; bestSameId = m.getModeId();
            }
        }

        
        if (bestSameRes > cur.getRefreshRate() + 0.1f) {
            lp.preferredDisplayModeId = bestSameId;
            lp.preferredRefreshRate = bestSameRes;
            return;
        }
        
        if (bestAny > cur.getRefreshRate() + 0.1f) {
            lp.preferredDisplayModeId = bestAnyId;
            lp.preferredRefreshRate = bestAny;
            return;
        }
        
        lp.preferredRefreshRate = cur.getRefreshRate();
    }

     
    public static String describeModes(Activity act) {
        try {
            Display d = displayOf(act);
            if (d == null) return "Cannot get Display";
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return "System too old, no mode info";
            Display.Mode cur = d.getMode();
            StringBuilder sb = new StringBuilder();
            sb.append("Current: ").append(cur.getPhysicalWidth()).append("x")
              .append(cur.getPhysicalHeight()).append(" @")
              .append(Math.round(cur.getRefreshRate())).append("Hz\nSupported: ");
            Display.Mode[] modes = d.getSupportedModes();
            if (modes != null) {
                java.util.ArrayList<String> seen = new java.util.ArrayList<>();
                for (Display.Mode m : modes) {
                    String one = m.getPhysicalWidth() + "x" + m.getPhysicalHeight()
                            + "@" + Math.round(m.getRefreshRate());
                    if (!seen.contains(one)) seen.add(one);
                }
                for (int i = 0; i < seen.size(); i++) {
                    if (i > 0) sb.append(", ");
                    sb.append(seen.get(i));
                }
            }
            return sb.toString();
        } catch (Throwable t) {
            return "Read failed: " + t.getClass().getSimpleName();
        }
    }

    

    private static volatile float fps = 0f;
    private static long lastNanos = 0L;
    private static int frames = 0;
    private static long windowStart = 0L;
    private static boolean running = false;

    

    public static void onFrame(long frameTimeNanos) {
        if (windowStart == 0L) { windowStart = frameTimeNanos; frames = 0; return; }
        frames++;
        long span = frameTimeNanos - windowStart;
        if (span >= 400_000_000L) {          
            float v = frames * 1_000_000_000f / span;
            fps = fps <= 0.1f ? v : (fps * 0.6f + v * 0.4f);
            frames = 0;
            windowStart = frameTimeNanos;
        }
    }

     
    private static final Choreographer.FrameCallback TICK = new Choreographer.FrameCallback() {
        public void doFrame(long frameTimeNanos) {
            if (!running) return;
            onFrame(frameTimeNanos);
            Choreographer.getInstance().postFrameCallback(this);
        }
    };

    public static void start() {
        if (running) return;
        running = true;
        frames = 0;
        windowStart = 0L;
        try { Choreographer.getInstance().postFrameCallback(TICK); } catch (Throwable ignored) {}
    }

    public static void stop() {
        running = false;
        try { Choreographer.getInstance().removeFrameCallback(TICK); } catch (Throwable ignored) {}
    }

    private static volatile boolean fakeFpsEnabled = false;
    private static volatile int fakeFpsValue = 60;

    public static void setFakeFps(boolean enabled, int value) {
        fakeFpsEnabled = enabled;
        fakeFpsValue = Math.max(1, Math.min(999, value));
    }

    public static boolean isFakeFpsEnabled() { return fakeFpsEnabled; }

    public static int getFakeFpsValue() { return fakeFpsValue; }

    public static float getFps() { return fakeFpsEnabled ? (float) fakeFpsValue : fps; }

    public static int getFpsInt() { return fakeFpsEnabled ? fakeFpsValue : Math.round(fps); }
}
