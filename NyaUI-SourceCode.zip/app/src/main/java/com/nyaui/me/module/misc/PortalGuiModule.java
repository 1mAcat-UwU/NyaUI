package com.nyaui.me.module.misc;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class PortalGuiModule extends Module {
    public PortalGuiModule() {
        super("PortalGui", ModuleCategory.MISC);
    }
}
