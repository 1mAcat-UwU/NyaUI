package com.nyaui.me.module;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleManager;

public class ModuleBridge {

    public static boolean getEnabledByName(String name) {
        Module module = ModuleManager.getModuleByName(name);
        return module != null && module.isEnabled();
    }

    public static void toggleModuleByName(String name) {
        Module module = ModuleManager.getModuleByName(name);
        if (module != null) {
            module.toggle();
        }
    }

    public static void enableModuleByName(String name) {
        Module module = ModuleManager.getModuleByName(name);
        if (module != null && !module.isEnabled()) {
            module.enable();
        }
    }

    public static void disableModuleByName(String name) {
        Module module = ModuleManager.getModuleByName(name);
        if (module != null && module.isEnabled()) {
            module.disable();
        }
    }

    public static String getChineseByName(String name) {
        Module module = ModuleManager.getModuleByName(name);
        if (module != null) {
            return module.getChineseName();
        }
        return name;
    }

    public static int getModuleCountByCategory(String category) {
        return ModuleManager.getModulesByCategory(
            getCategoryFromString(category)
        ).size();
    }

    public static String getModuleNameByCategoryAndCount(String category, int index) {
        try {
            return ModuleManager.getModulesByCategory(
                getCategoryFromString(category)
            ).get(index).getName();
        } catch (Exception e) {
            return "";
        }
    }

    public static String getModuleChineseByCategoryAndCount(String category, int index) {
        try {
            return ModuleManager.getModulesByCategory(
                getCategoryFromString(category)
            ).get(index).getChineseName();
        } catch (Exception e) {
            return "";
        }
    }

    private static ModuleCategory getCategoryFromString(String category) {
        if (category == null) return ModuleCategory.RENDER;
        switch (category.trim().toUpperCase()) {
            case "COMBAT": return ModuleCategory.COMBAT;
            case "MISC": return ModuleCategory.MISC;
            case "RENDER":
            case "VISUAL": return ModuleCategory.RENDER;
            case "MOVEMENT": return ModuleCategory.MOVEMENT;
            case "PLAYER": return ModuleCategory.PLAYER;
            case "EXPLOIT": return ModuleCategory.EXPLOIT;
            case "CLIENT":
            case "SETTINGS": return ModuleCategory.CLIENT;
            case "WORLD": return ModuleCategory.MISC;
            default: return ModuleCategory.RENDER;
        }
    }

}

