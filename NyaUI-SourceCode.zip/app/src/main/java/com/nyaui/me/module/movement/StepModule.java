package com.nyaui.me.module.movement;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class StepModule extends Module {
    public StepModule() {
        super("Step", ModuleCategory.MOVEMENT);
    }
}
