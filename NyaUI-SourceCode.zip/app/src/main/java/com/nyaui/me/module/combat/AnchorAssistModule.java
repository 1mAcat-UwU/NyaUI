package com.nyaui.me.module.combat;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class AnchorAssistModule extends Module {
    public AnchorAssistModule() {
        super("AnchorAssist", ModuleCategory.COMBAT);
    }
}
