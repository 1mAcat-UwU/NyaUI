

package com.nyaui.me.ui.widgets;

import android.content.Context;
import android.view.KeyEvent;
import android.text.TextUtils;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import androidx.appcompat.widget.AppCompatTextView;

import com.nyaui.me.module.Module;
import com.nyaui.me.ui.KeybindManager;
import android.graphics.Typeface;
import com.nyaui.me.ui.ThemeManager;

public class KeybindButton extends AppCompatTextView {

    public static KeybindButton listeningButton = null;

    private final Module module;
    private boolean isListening = false;
    private float scaleFactor;
    private boolean classicStyle = false;
    public void setClassicStyle(boolean classic) { classicStyle = classic; updateAppearance(); }

    public KeybindButton(Context context, Module module, float initialScale) {
        super(context);
        this.module = module;
        this.scaleFactor = initialScale;
        
        setSingleLine(true);
        setMaxLines(1);
        setEllipsize(TextUtils.TruncateAt.END);
        setIncludeFontPadding(false);
        setGravity(Gravity.CENTER);
        setTypeface(Typeface.DEFAULT_BOLD);

        applyScale();

        setOnClickListener(v -> {
            if (isListening) {
                stopListening();
            } else {
                startListening();
            }
        });
    }

    public void updateScale(float newScale) {
        this.scaleFactor = newScale;
        applyScale();
    }

    private void applyScale() {
        setTextSize(11f * scaleFactor);
        int paddingH = (int) (6 * getResources().getDisplayMetrics().density * scaleFactor);
        int paddingV = (int) (2 * getResources().getDisplayMetrics().density * scaleFactor);
        setPadding(paddingH, paddingV, paddingH, paddingV);
        updateAppearance();
    }

    private void startListening() {
        if (listeningButton != null) {
            listeningButton.stopListening();
        }
        isListening = true;
        listeningButton = this;
        setFocusable(true);
        setFocusableInTouchMode(true);
        requestFocus();
        updateAppearance();
    }

    public void stopListening() {
        isListening = false;
        if (listeningButton == this) {
            listeningButton = null;
        }
        clearFocus();
        updateAppearance();
    }

        public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (isListening) {
            onKeyBound(keyCode);
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    public void onKeyBound(int keyCode) {
        if (keyCode == KeyEvent.KEYCODE_ESCAPE || keyCode == KeyEvent.KEYCODE_DEL) {
            KeybindManager.getInstance().unbindKey(module.getName());
        } else {
            KeybindManager.getInstance().bindKey(module.getName(), keyCode);
        }
        stopListening();
    }

    private void updateText() {
        int currentKey = KeybindManager.getInstance().getKeyForModule(module.getName());
        setText(KeybindManager.getKeyName(currentKey));
    }

    private void updateAppearance() {
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius((classicStyle ? 2 : 6) * getResources().getDisplayMetrics().density * scaleFactor);
        bg.setStroke(Math.max(1, (int)(getResources().getDisplayMetrics().density * scaleFactor)), ThemeManager.getStateDisabled());

        setTextColor(ThemeManager.getTextPrimary());
        bg.setColor(ThemeManager.getBgDisabled());
        setBackground(bg);

        if (isListening) {
            setText("...");
        } else {
            updateText();
        }
    }
}