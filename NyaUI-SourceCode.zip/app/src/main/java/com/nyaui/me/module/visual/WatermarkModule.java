package com.nyaui.me.module.visual;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.ui.WatermarkManager;

public class WatermarkModule extends Module {
    private static WatermarkModule instance;
    public WatermarkModule() { super("Watermark", ModuleCategory.VISUAL, ""); setChineseName("Watermark"); instance = this; }
    public static WatermarkModule getInstance() { return instance; }
    public boolean shouldShowInArraylist() { return false; }
    protected void onEnable() { super.onEnable(); WatermarkManager.show(); }
    protected void onDisable() { super.onDisable(); WatermarkManager.hide(); }
}
