package com.nyaui.me.module.render;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class CameraClipModule extends Module {
    private final Module delegate;

    public CameraClipModule() {
        super("CameraClip", ModuleCategory.RENDER);
        delegate = new CameraModModule();
        setChineseName(delegate.getChineseName());
    }

    public boolean supportsShortcut() { return delegate.supportsShortcut(); }
    public boolean shouldShowInArraylist() { return delegate.shouldShowInArraylist(); }

    protected void onEnable() {
        if (!delegate.isEnabled()) delegate.enable();
    }

    protected void onDisable() {
        if (delegate.isEnabled()) delegate.disable();
    }

    public void configureSubMenu(SubMenuPanel subMenu) {
        delegate.configureSubMenu(subMenu);
    }
}
