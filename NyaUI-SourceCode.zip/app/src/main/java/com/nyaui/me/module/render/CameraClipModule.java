package com.nyaui.me.module.render;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class CameraClipModule extends Module {
    public CameraClipModule() {
        super("CameraClip", ModuleCategory.RENDER);
        setChineseName("CameraClip");
    }

    protected void onEnable() {
        try { SafeCall.setEnabled("CameraMod"); } catch (Throwable t) {}
    }

    protected void onDisable() {
        try { SafeCall.setEnabled("CameraMod"); } catch (Throwable t) {}
    }

    public void configureSubMenu(SubMenuPanel subMenu) {
        super.configureSubMenu(subMenu);
        new CameraModModule().configureSubMenu(subMenu);
    }
}
