package com.nyaui.me.module.render;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class ZoomModule extends Module {
    public ZoomModule() {
        super("Zoom", ModuleCategory.RENDER);
        setChineseName("Zoom");
    }

    protected void onEnable() {
        try { SafeCall.setEnabled("Magnifier"); } catch (Throwable t) {}
    }

    protected void onDisable() {
        try { SafeCall.setEnabled("Magnifier"); } catch (Throwable t) {}
    }

    public void configureSubMenu(SubMenuPanel subMenu) {
        super.configureSubMenu(subMenu);
        new MagnifierModule().configureSubMenu(subMenu);
    }
}
