package com.nyaui.me.module.player;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class AutoMineModule extends Module {
    public AutoMineModule() { super("AutoMine", ModuleCategory.PLAYER, ""); setChineseName("Auto Mine"); }
    public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("AutoMine"); } catch (Throwable t) {} }
    public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("AutoMine"); } catch (Throwable t) {} }
    public void configureSubMenu(SubMenuPanel s) {
        super.configureSubMenu(s);
        s.addSlider("Range", 30, 100, 50, "%.1f", v -> {});
        java.util.List<String> modes = new java.util.ArrayList<>(); modes.add("Ores"); modes.add("Wood"); modes.add("All");
        s.addMode("Mine Type", modes, 0, (index, name) -> {});
        s.addSwitch("Auto Switch", true, enabled -> {});
    }
}
