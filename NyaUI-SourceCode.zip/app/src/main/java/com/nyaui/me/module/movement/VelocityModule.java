package com.nyaui.me.module.movement;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;
import java.util.ArrayList;
import java.util.List;

public class VelocityModule extends Module {
    public VelocityModule() { super("Velocity", ModuleCategory.MOVEMENT, ""); setChineseName("Velocity"); }
    public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("Velocity"); } catch (Throwable t) {} }
    public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("Velocity"); } catch (Throwable t) {} }
    public void configureSubMenu(SubMenuPanel s) {
        super.configureSubMenu(s);
        String n = getName();
        int cnt = SafeCall.getModeSize(n, 0);
        List<String> modes = new ArrayList<>();
        for (int i = 0; i < cnt; i++) modes.add(SafeCall.getModeString(n, 0, i));
        s.addMode("Mode", modes, SafeCall.getModeValue(n, 0), (index, name) -> SafeCall.setModeValue(n, 0, index));
        s.addSlider("Intensity", 0, 100, (int)(SafeCall.getFloat(n, 0) * 100), "%d%%", v -> SafeCall.setFloat(n, 0, v / 100f));
    }
}
