package com.nyaui.me.module.combat;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class SurroundModule extends Module {
    public SurroundModule() { super("Surround", ModuleCategory.COMBAT, ""); setChineseName("Surround"); }
    public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("Surround"); } catch (Throwable t) {} }
    public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("Surround"); } catch (Throwable t) {} }
    public void configureSubMenu(SubMenuPanel s) {
        super.configureSubMenu(s);
        String n = getName();
        s.addSlider("Orbit Radius", 10, 100, (int)(SafeCall.getFloat(n, 0) * 10), "%.1f", v -> SafeCall.setFloat(n, 0, v));
        s.addSlider("Lock Distance", 5, 50, (int)SafeCall.getFloat(n, 1), "%.1f", v -> SafeCall.setFloat(n, 1, v));
        s.addSlider("Spin Speed", 1, 50, (int)SafeCall.getFloat(n, 2), "%d", v -> SafeCall.setFloat(n, 2, v));
        s.addSwitch("Smooth Movement", SafeCall.getBool(n, 0), e -> SafeCall.setBool(n, 0, e));
    }
}
