package com.nyaui.me.module.movement;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class EntityControlModule extends Module {
    public EntityControlModule() {
        super("EntityControl", ModuleCategory.MOVEMENT);
    }
}
