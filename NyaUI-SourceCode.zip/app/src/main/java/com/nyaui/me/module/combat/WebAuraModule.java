package com.nyaui.me.module.combat;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class WebAuraModule extends Module {
    public WebAuraModule() {
        super("WebAura", ModuleCategory.COMBAT);
    }
}
