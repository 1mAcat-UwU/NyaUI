package com.nyaui.me.module.combat;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class VAnchorAuraModule extends Module {
    public VAnchorAuraModule() {
        super("VAnchorAura", ModuleCategory.COMBAT);
    }
}
