package com.nyaui.me.module.movement;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;

public class AntiWebModule extends Module {
    public AntiWebModule() { super("AntiWeb", ModuleCategory.MOVEMENT, ""); setChineseName("Anti-Web"); }
    public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("AntiWeb"); } catch (Throwable t) {} }
    public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("AntiWeb"); } catch (Throwable t) {} }
}
