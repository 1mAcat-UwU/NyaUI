package com.nyaui.me.module.misc;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class PopCounterModule extends Module {
    public PopCounterModule() {
        super("PopCounter", ModuleCategory.MISC);
    }
}
