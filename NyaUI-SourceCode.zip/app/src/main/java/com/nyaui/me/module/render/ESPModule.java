package com.nyaui.me.module.render;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;
import java.util.ArrayList;
import java.util.List;

public class ESPModule extends Module {
    public ESPModule() { super("ESP", ModuleCategory.RENDER, ""); setChineseName("Player ESP"); }
    public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("ESP"); } catch (Throwable t) {} }
    public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("ESP"); } catch (Throwable t) {} }
    public void configureSubMenu(SubMenuPanel s) {
        super.configureSubMenu(s);
        String n = getName();
        int cnt = SafeCall.getModeSize(n, 0); List<String> modes = new ArrayList<>(); for (int i = 0; i < cnt; i++) modes.add(SafeCall.getModeString(n, 0, i));
        s.addMode("Mode", modes, SafeCall.getModeValue(n, 0), (index, name) -> SafeCall.setModeValue(n, 0, index));
    }
}
