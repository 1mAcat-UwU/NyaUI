package com.nyaui.me.module.misc;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;

public class BlinkModule extends Module {
    public BlinkModule() { super("Blink", ModuleCategory.MISC, ""); setChineseName("Blink"); }
    public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("Blink"); } catch (Throwable t) {} }
    public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("Blink"); } catch (Throwable t) {} }
}
