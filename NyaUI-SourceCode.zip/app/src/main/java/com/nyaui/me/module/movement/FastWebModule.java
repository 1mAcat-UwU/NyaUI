package com.nyaui.me.module.movement;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class FastWebModule extends Module {
    public FastWebModule() {
        super("FastWeb", ModuleCategory.MOVEMENT);
        setChineseName("FastWeb");
    }

    protected void onEnable() {
        try { SafeCall.setEnabled("AntiWeb"); } catch (Throwable t) {}
    }

    protected void onDisable() {
        try { SafeCall.setEnabled("AntiWeb"); } catch (Throwable t) {}
    }

    public void configureSubMenu(SubMenuPanel subMenu) {
        super.configureSubMenu(subMenu);
        new AntiWebModule().configureSubMenu(subMenu);
    }
}
