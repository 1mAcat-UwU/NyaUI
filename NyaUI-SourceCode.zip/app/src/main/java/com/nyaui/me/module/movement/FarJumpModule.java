package com.nyaui.me.module.movement;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class FarJumpModule extends Module {
    public FarJumpModule() { super("FarJump", ModuleCategory.MOVEMENT, ""); setChineseName("Long Jump"); }
    public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("FarJump"); } catch (Throwable t) {} }
    public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("FarJump"); } catch (Throwable t) {} }
    public void configureSubMenu(SubMenuPanel s) {
        super.configureSubMenu(s);
        s.addSlider("Speed", 1, 20, (int)(SafeCall.getFloat(getName(), 0) * 10), "%.1f", v -> SafeCall.setFloat(getName(), 0, v));
    }
}
