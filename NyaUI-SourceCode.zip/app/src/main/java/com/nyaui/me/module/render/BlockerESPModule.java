package com.nyaui.me.module.render;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class BlockerESPModule extends Module {
    public BlockerESPModule() {
        super("BlockerESP", ModuleCategory.RENDER);
    }
}
