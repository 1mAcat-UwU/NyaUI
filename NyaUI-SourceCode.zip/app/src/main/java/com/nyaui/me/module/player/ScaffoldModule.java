package com.nyaui.me.module.player;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class ScaffoldModule extends Module {
    public ScaffoldModule() { super("Scaffold", ModuleCategory.PLAYER, ""); setChineseName("Scaffold"); }
    public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("Scaffold"); } catch (Throwable t) {} }
    public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("Scaffold"); } catch (Throwable t) {} }
    public void configureSubMenu(SubMenuPanel s) {
        super.configureSubMenu(s);
        String n = getName();
        int cnt0 = SafeCall.getModeSize(n, 0); java.util.List<String> m0 = new java.util.ArrayList<>(); for (int i = 0; i < cnt0; i++) m0.add(SafeCall.getModeString(n, 0, i)); s.addMode("Mode", m0, SafeCall.getModeValue(n, 0), (index, name) -> SafeCall.setModeValue(n, 0, index));
        int cnt1 = SafeCall.getModeSize(n, 1); java.util.List<String> m1 = new java.util.ArrayList<>(); for (int i = 0; i < cnt1; i++) m1.add(SafeCall.getModeString(n, 1, i)); s.addMode("Auto Switch Block", m1, SafeCall.getModeValue(n, 1), (index, name) -> SafeCall.setModeValue(n, 1, index));
        int cnt2 = SafeCall.getModeSize(n, 2); java.util.List<String> m2 = new java.util.ArrayList<>(); for (int i = 0; i < cnt2; i++) m2.add(SafeCall.getModeString(n, 2, i)); s.addMode("Rotation", m2, SafeCall.getModeValue(n, 2), (index, name) -> SafeCall.setModeValue(n, 2, index));
        s.addSlider("Extend Length", 1, 10, (int)SafeCall.getFloat(n, 0), "%.1f", v -> SafeCall.setFloat(n, 0, v));
        s.addSwitch("Lock Y", SafeCall.getBool(n, 0), e -> SafeCall.setBool(n, 0, e));
    }
}
