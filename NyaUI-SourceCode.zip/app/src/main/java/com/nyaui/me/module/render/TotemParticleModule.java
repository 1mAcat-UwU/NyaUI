package com.nyaui.me.module.render;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class TotemParticleModule extends Module {
    public TotemParticleModule() {
        super("TotemParticle", ModuleCategory.RENDER);
    }
}
