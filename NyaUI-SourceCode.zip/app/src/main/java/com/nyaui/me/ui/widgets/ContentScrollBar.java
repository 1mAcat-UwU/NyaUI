package com.nyaui.me.ui.widgets;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.ScrollView;

import com.nyaui.me.ui.ThemeManager;

public class ContentScrollBar extends View {
    private ScrollView scrollView;
    private final Paint trackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint thumbPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF thumbRect = new RectF();
    private float thumbY;
    private float thumbH;
    private boolean dragging;
    private float dragOffsetY;
    private final ViewTreeObserver.OnScrollChangedListener scrollListener = this::syncFromScroll;
    private final ViewTreeObserver.OnGlobalLayoutListener layoutListener = this::syncFromScroll;

    public ContentScrollBar(Context context) {
        super(context);
        setClickable(true);
        setFocusable(true);
        setWillNotDraw(false);
        trackPaint.setColor(0x33FFFFFF);
        thumbPaint.setColor(ThemeManager.getThemeColor());
    }

    public void attachTo(ScrollView sv) {
        if (scrollView != null) {
            try {
                scrollView.getViewTreeObserver().removeOnScrollChangedListener(scrollListener);
                scrollView.getViewTreeObserver().removeOnGlobalLayoutListener(layoutListener);
            } catch (Throwable ignored) {}
        }
        scrollView = sv;
        if (scrollView != null) {
            scrollView.getViewTreeObserver().addOnScrollChangedListener(scrollListener);
            scrollView.getViewTreeObserver().addOnGlobalLayoutListener(layoutListener);
            scrollView.setVerticalScrollBarEnabled(false);
            scrollView.setHorizontalScrollBarEnabled(false);
            post(this::syncFromScroll);
        }
    }

    public void detach() {
        if (scrollView != null) {
            try {
                scrollView.getViewTreeObserver().removeOnScrollChangedListener(scrollListener);
                scrollView.getViewTreeObserver().removeOnGlobalLayoutListener(layoutListener);
            } catch (Throwable ignored) {}
            scrollView = null;
        }
    }

    public void refreshTheme() {
        thumbPaint.setColor(ThemeManager.getThemeColor());
        invalidate();
    }

    private void syncFromScroll() {
        if (scrollView == null) return;
        View child = scrollView.getChildCount() > 0 ? scrollView.getChildAt(0) : null;
        if (child == null) {
            setVisibility(GONE);
            return;
        }
        int viewport = scrollView.getHeight();
        int content = child.getHeight();
        int range = content - viewport;
        if (viewport <= 0 || range <= 0) {
            setVisibility(GONE);
            return;
        }
        setVisibility(VISIBLE);
        float trackH = getHeight();
        if (trackH <= 0) trackH = viewport;
        thumbH = Math.max(dp(28), trackH * (viewport / (float) content));
        float maxThumbTravel = Math.max(1f, trackH - thumbH);
        float progress = scrollView.getScrollY() / (float) range;
        thumbY = progress * maxThumbTravel;
        invalidate();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    protected void onDraw(Canvas canvas) {
        if (getVisibility() != VISIBLE) return;
        float w = getWidth();
        float h = getHeight();
        if (w <= 0 || h <= 0) return;
        float cx = w / 2f;
        float tw = Math.max(2f, w * 0.35f);
        canvas.drawRoundRect(cx - tw / 2f, 0, cx + tw / 2f, h, tw, tw, trackPaint);
        thumbPaint.setColor(ThemeManager.getThemeColor());
        float left = Math.max(1f, w * 0.15f);
        float right = w - left;
        thumbRect.set(left, thumbY, right, thumbY + thumbH);
        canvas.drawRoundRect(thumbRect, (right - left) / 2f, (right - left) / 2f, thumbPaint);
    }

    public boolean onTouchEvent(MotionEvent e) {
        if (scrollView == null || getVisibility() != VISIBLE) return false;
        View child = scrollView.getChildCount() > 0 ? scrollView.getChildAt(0) : null;
        if (child == null) return false;
        int viewport = scrollView.getHeight();
        int content = child.getHeight();
        int range = content - viewport;
        if (range <= 0) return false;
        float trackH = getHeight();
        float maxThumbTravel = Math.max(1f, trackH - thumbH);
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                float y = e.getY();
                if (y >= thumbY && y <= thumbY + thumbH) {
                    dragging = true;
                    dragOffsetY = y - thumbY;
                } else {
                    dragging = true;
                    dragOffsetY = thumbH / 2f;
                    float target = y - dragOffsetY;
                    target = Math.max(0f, Math.min(maxThumbTravel, target));
                    thumbY = target;
                    int sy = Math.round((thumbY / maxThumbTravel) * range);
                    scrollView.scrollTo(0, sy);
                }
                if (getParent() != null) {
                    getParent().requestDisallowInterceptTouchEvent(true);
                }
                invalidate();
                return true;
            }
            case MotionEvent.ACTION_MOVE: {
                if (!dragging) return true;
                float target = e.getY() - dragOffsetY;
                target = Math.max(0f, Math.min(maxThumbTravel, target));
                thumbY = target;
                int sy = Math.round((thumbY / maxThumbTravel) * range);
                scrollView.scrollTo(0, sy);
                invalidate();
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                dragging = false;
                if (getParent() != null) {
                    getParent().requestDisallowInterceptTouchEvent(false);
                }
                invalidate();
                return true;
        }
        return super.onTouchEvent(e);
    }

    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        detach();
    }
}
