package com.nyaui.me.module.render;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class AmbienceModule extends Module {
    public AmbienceModule() {
        super("Ambience", ModuleCategory.RENDER);
    }
}
