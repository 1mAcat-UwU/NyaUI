package com.nyaui.me.config;

import com.nyaui.me.ui.PhoenixPopup;

import com.nyaui.me.ui.NotificationManager;

import com.nyaui.me.ui.IslandOverlay;

import com.nyaui.me.ui.FrameRate;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleManager;
import com.nyaui.me.ui.HUDManager;
import com.nyaui.me.ui.KeybindManager;
import com.nyaui.me.ui.ThemeManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class ConfigExporter {
    public static final int REQ_EXPORT = 8001;
    public static final int REQ_IMPORT = 8002;

    private static final String DIR = "nya_configs";
    private static final int FORMAT_VERSION = 4;
    private static final String[] PREF_NAMES = new String[]{
            "phoenix_gui_config",
            "Remedy_Keybinds",
            "shortcut_button_positions",
            "CardMenuPrefs",
            "NyaUIClassicFrames",
            "menu_view_client",
            "menu_view_settings",
            "DL_Prefs"
    };

    private static Runnable pendingOk;
    private static Runnable pendingFail;

    private ConfigExporter() {}

    public static String exportConfig(Context ctx) {
        try {
            JSONObject root = new JSONObject();
            root.put("app", "NyaUI");
            root.put("format", FORMAT_VERSION);
            root.put("config_file", ConfigManager.getConfigFileName());
            root.put("exported_at", System.currentTimeMillis());

            JSONArray modules = new JSONArray();
            for (Module module : ModuleManager.getAllModules()) {
                JSONObject item = new JSONObject();
                item.put("name", module.getName());
                item.put("enabled", module.isEnabled());
                item.put("shortcut", module.isShortcutEnabled());
                modules.put(item);
            }
            root.put("modules", modules);

            JSONObject preferences = new JSONObject();
            for (String name : PREF_NAMES) {
                SharedPreferences prefs = ctx.getSharedPreferences(name, Context.MODE_PRIVATE);
                preferences.put(name, encodePreferences(prefs.getAll()));
            }
            root.put("preferences", preferences);

            JSONObject runtime = new JSONObject();
            runtime.put("theme_color", ThemeManager.getThemeColor());
            runtime.put("dark_mode", ThemeManager.isDarkMode());
            runtime.put("rainbow", ThemeManager.isRainbowModeEnabled());
            runtime.put("hud_enabled", ModuleManager.getModuleByName("HUD") != null && ModuleManager.getModuleByName("HUD").isEnabled());
            root.put("runtime", runtime);

            return root.toString(2);
        } catch (Throwable t) {
            return "{}";
        }
    }

    public static String exportJson(Context ctx) {
        return exportConfig(ctx);
    }

    private static JSONObject encodePreferences(Map<String, ?> values) throws Exception {
        JSONObject result = new JSONObject();
        for (Map.Entry<String, ?> entry : values.entrySet()) {
            Object value = entry.getValue();
            JSONObject item = new JSONObject();
            if (value instanceof Boolean) {
                item.put("type", "boolean");
                item.put("value", value);
            } else if (value instanceof Integer) {
                item.put("type", "int");
                item.put("value", value);
            } else if (value instanceof Long) {
                item.put("type", "long");
                item.put("value", value);
            } else if (value instanceof Float) {
                item.put("type", "float");
                item.put("value", value);
            } else if (value instanceof String) {
                item.put("type", "string");
                item.put("value", value);
            } else if (value instanceof Set) {
                JSONArray array = new JSONArray();
                for (Object entryValue : (Set<?>) value) array.put(String.valueOf(entryValue));
                item.put("type", "string_set");
                item.put("value", array);
            } else {
                continue;
            }
            result.put(entry.getKey(), item);
        }
        return result;
    }

    public static boolean importConfig(String text, Context ctx) {
        if (text == null || ctx == null) return false;
        try {
            String clean = text.trim();
            while (!clean.isEmpty() && (clean.charAt(0) == '\uFEFF' || clean.charAt(0) == '\uFFFE')) {
                clean = clean.substring(1).trim();
            }
            JSONObject root = new JSONObject(clean);
            if (!"NyaUI".equalsIgnoreCase(root.optString("app", ""))) return false;

            JSONObject preferences = root.optJSONObject("preferences");
            if (preferences != null) {
                Iterator<String> names = preferences.keys();
                while (names.hasNext()) {
                    String name = names.next();
                    if (!isAllowedPreference(name)) continue;
                    JSONObject encoded = preferences.optJSONObject(name);
                    if (encoded == null) continue;
                    restorePreferences(ctx.getSharedPreferences(name, Context.MODE_PRIVATE), encoded);
                }
            } else {
                importLegacyConfig(root, ctx);
            }

            JSONArray modules = root.optJSONArray("modules");
            if (modules != null) {
                for (int i = 0; i < modules.length(); i++) {
                    JSONObject item = modules.optJSONObject(i);
                    if (item == null) continue;
                    Module module = ModuleManager.getModuleByName(item.optString("name", ""));
                    if (module == null) continue;
                    boolean enabled = item.optBoolean("enabled", false);
                    if (enabled && !module.isEnabled()) module.enable();
                    if (!enabled && module.isEnabled()) module.disable();
                    boolean shortcut = item.optBoolean("shortcut", false);
                    if (shortcut != module.isShortcutEnabled()) module.toggleShortcut(shortcut);
                }
            }

            if (root.has("config_file")) {
                ConfigManager.setConfigFileName(root.optString("config_file", "cfg.txt"));
            }

            ConfigManager.normalizeHudPositionConfig();
            refreshRuntime(ctx);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    public static void importJson(String json, Context ctx) {
        importConfig(json, ctx);
    }

    private static boolean isAllowedPreference(String name) {
        for (String allowed : PREF_NAMES) {
            if (allowed.equals(name)) return true;
        }
        return false;
    }

    private static void restorePreferences(SharedPreferences prefs, JSONObject encoded) throws Exception {
        SharedPreferences.Editor editor = prefs.edit().clear();
        Iterator<String> keys = encoded.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            JSONObject item = encoded.optJSONObject(key);
            if (item == null) continue;
            String type = item.optString("type", "");
            switch (type) {
                case "boolean":
                    editor.putBoolean(key, item.optBoolean("value", false));
                    break;
                case "int":
                    editor.putInt(key, item.optInt("value", 0));
                    break;
                case "long":
                    editor.putLong(key, item.optLong("value", 0L));
                    break;
                case "float":
                    editor.putFloat(key, (float) item.optDouble("value", 0.0));
                    break;
                case "string":
                    editor.putString(key, item.optString("value", ""));
                    break;
                case "string_set":
                    JSONArray array = item.optJSONArray("value");
                    Set<String> values = new HashSet<>();
                    if (array != null) {
                        for (int i = 0; i < array.length(); i++) values.add(array.optString(i));
                    }
                    editor.putStringSet(key, values);
                    break;
                default:
                    break;
            }
        }
        editor.apply();
    }

    private static void importLegacyConfig(JSONObject root, Context ctx) throws Exception {
        JSONArray modules = root.optJSONArray("modules");
        JSONObject keybinds = root.optJSONObject("keybinds");
        if (keybinds != null) {
            SharedPreferences.Editor editor = ctx.getSharedPreferences("Remedy_Keybinds", Context.MODE_PRIVATE).edit().clear();
            Iterator<String> keys = keybinds.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                editor.putInt(key, keybinds.optInt(key, 0));
            }
            editor.apply();
        }
        JSONObject ui = root.optJSONObject("ui");
        if (ui != null) {
            if (ui.has("themeColor")) ThemeManager.setThemeColor(ui.optInt("themeColor"));
            if (ui.has("darkMode")) ThemeManager.setDarkMode(ui.optBoolean("darkMode"));
            if (ui.has("rainbow")) ThemeManager.setRainbowModeEnabled(ui.optBoolean("rainbow"));
            if (ui.has("watermarkColor")) ConfigManager.saveInt("HUD", "watermark_color", ui.optInt("watermarkColor"));
            if (ui.has("notificationsColor")) ConfigManager.saveInt("HUD", "notifications_color", ui.optInt("notificationsColor"));
            if (ui.has("arraylistColor")) ConfigManager.saveInt("HUD", "arraylist_color", ui.optInt("arraylistColor"));
        }
        if (modules != null) {
            for (int i = 0; i < modules.length(); i++) {
                JSONObject item = modules.optJSONObject(i);
                if (item == null) continue;
                Module module = ModuleManager.getModuleByName(item.optString("name", ""));
                if (module == null) continue;
                if (item.optBoolean("enabled", false)) module.enable(); else module.disable();
                module.toggleShortcut(item.optBoolean("shortcut", false));
            }
        }
    }

    private static void refreshRuntime(Context ctx) {
        try {
            Module hud = ModuleManager.getModuleByName("HUD");
            if (hud != null) {
                if (hud.isEnabled()) HUDManager.setEnabled(true); else HUDManager.setEnabled(false);
            }
            Module list = ModuleManager.getModuleByName("ModuleList");
            if (list != null) {
                HUDManager.setArraylistEnabled(list.isEnabled());
            }
            Module notify = ModuleManager.getModuleByName("Notify");
            if (notify != null) {
                NotificationManager.setEnabled(notify.isEnabled());
                if (!notify.isEnabled()) NotificationManager.clearAll();
            }
            Module di = ModuleManager.getModuleByName("DynamicIsland");
            if (di != null) {
                if (di.isEnabled()) {
                    Activity act = PhoenixPopup.getCurrentActivity();
                    if (act != null) IslandOverlay.attach(act);
                } else {
                    IslandOverlay.detach();
                }
            }
            boolean fakeOn = ConfigManager.getBoolean("FakeFps", "enabled", false);
            int fakeVal = ConfigManager.getInt("FakeFps", "value", 120);
            FrameRate.setFakeFps(fakeOn, fakeVal);
            HUDManager.setWatermarkEnabled(ConfigManager.getBoolean("HUD", "watermark", true));
            HUDManager.setWatermarkPosition(
                    ConfigManager.getFloat("HUD", "watermark_x", 4f) / 100f,
                    ConfigManager.getFloat("HUD", "watermark_y", 4f) / 100f);
            HUDManager.setWatermarkColor(ConfigManager.getInt("HUD", "watermark_color", 0x80FFFFFF));
            HUDManager.setNotificationDuration(ConfigManager.getInt("HUD", "notification_duration", 2000));
            HUDManager.setNotificationPosition(
                    ConfigManager.getFloat("HUD", "notifications_x", 100f) / 100f,
                    ConfigManager.getFloat("HUD", "notifications_y", 100f) / 100f);
            HUDManager.setNotificationColor(ConfigManager.getInt("HUD", "notifications_color", 0xFFFFFFFF));
            HUDManager.setArraylistPosition(
                    ConfigManager.getFloat("HUD", "arraylist_x", 100f) / 100f,
                    ConfigManager.getFloat("HUD", "arraylist_y", 4f) / 100f);
            HUDManager.setArraylistColor(ConfigManager.getInt("HUD", "arraylist_color", 0xFFFFFFFF));
        } catch (Throwable ignored) {}
    }

    public static void doExport(Activity act, Runnable ok, Runnable fail) {
        pendingOk = ok;
        pendingFail = fail;
        try {
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_TITLE, ConfigManager.getConfigFileName());
            act.startActivityForResult(intent, REQ_EXPORT);
        } catch (Throwable t) {
            clearCallbacks();
            if (fail != null) fail.run();
        }
    }

    public static void doImport(Activity act, Runnable ok, Runnable fail) {
        pendingOk = ok;
        pendingFail = fail;
        try {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"text/plain", "application/json", "application/octet-stream"});
            act.startActivityForResult(Intent.createChooser(intent, "Select NyaUI config"), REQ_IMPORT);
        } catch (Throwable t) {
            clearCallbacks();
            if (fail != null) fail.run();
        }
    }

    public static boolean handleResult(Activity act, int req, int res, Intent data) {
        if (req != REQ_EXPORT && req != REQ_IMPORT) return false;
        if (res != Activity.RESULT_OK || data == null || data.getData() == null) {
            Runnable fail = pendingFail;
            clearCallbacks();
            if (fail != null) fail.run();
            return true;
        }
        try {
            if (req == REQ_EXPORT) {
                try (OutputStream os = act.getContentResolver().openOutputStream(data.getData(), "wt")) {
                    if (os == null) throw new IllegalStateException("Cannot open output stream");
                    os.write(exportConfig(act).getBytes(StandardCharsets.UTF_8));
                    os.flush();
                }
            } else {
                String text;
                try (InputStream is = act.getContentResolver().openInputStream(data.getData());
                     ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
                    if (is == null) throw new IllegalStateException("Cannot open input stream");
                    byte[] bytes = new byte[8192];
                    int read;
                    while ((read = is.read(bytes)) != -1) buffer.write(bytes, 0, read);
                    text = buffer.toString(StandardCharsets.UTF_8.name());
                }
                if (!importConfig(text, act)) throw new IllegalArgumentException("Invalid NyaUI config");
            }
            Runnable ok = pendingOk;
            clearCallbacks();
            if (ok != null) ok.run();
        } catch (Throwable t) {
            Runnable fail = pendingFail;
            clearCallbacks();
            if (fail != null) fail.run();
        }
        return true;
    }

    private static void clearCallbacks() {
        pendingOk = null;
        pendingFail = null;
    }

    public static void saveConfig(Context ctx, String name) {
        if (name == null || name.trim().isEmpty()) name = "cfg";
        String fileName = ConfigManager.getConfigFileName();
        if (!name.contains(".")) fileName = name + ".txt";
        else fileName = name;
        File dir = new File(ctx.getFilesDir(), DIR);
        if (!dir.exists()) dir.mkdirs();
        try (FileOutputStream out = new FileOutputStream(new File(dir, fileName))) {
            out.write(exportConfig(ctx).getBytes(StandardCharsets.UTF_8));
            out.flush();
        } catch (Throwable ignored) {}
    }

    public static List<String> listConfigs(Context ctx) {
        List<String> result = new ArrayList<>();
        File dir = new File(ctx.getFilesDir(), DIR);
        if (!dir.isDirectory()) return result;
        File[] files = dir.listFiles((d, name) -> name.endsWith(".txt") || name.endsWith(".json"));
        if (files != null) {
            Arrays.sort(files, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));
            for (File file : files) result.add(file.getName());
        }
        return result;
    }

    public static void loadConfig(Context ctx, String name) {
        File file = new File(new File(ctx.getFilesDir(), DIR), name);
        if (!file.exists() && !name.endsWith(".txt")) file = new File(new File(ctx.getFilesDir(), DIR), name + ".txt");
        try (FileInputStream in = new FileInputStream(file); ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
            byte[] bytes = new byte[8192];
            int read;
            while ((read = in.read(bytes)) != -1) buffer.write(bytes, 0, read);
            importConfig(buffer.toString(StandardCharsets.UTF_8.name()), ctx);
        } catch (Throwable ignored) {}
    }

    public static void deleteConfig(Context ctx, String name) {
        new File(new File(ctx.getFilesDir(), DIR), name).delete();
    }
}
