package com.nyaui.me.module.combat;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;
import java.util.ArrayList;
import java.util.List;

public class KillAuraModule extends Module {
    public KillAuraModule() {
        super("KillAura", ModuleCategory.COMBAT, "");
        setChineseName("KillAura");
    }

        public void onEnable() {
        super.onEnable();
        try { SafeCall.setEnabled("KillAura"); } catch (Throwable t) {}
    }

        public void onDisable() {
        super.onDisable();
        try { SafeCall.setEnabled("KillAura"); } catch (Throwable t) {}
    }

        public void configureSubMenu(SubMenuPanel s) {
        super.configureSubMenu(s);
        String n = getName();
        s.addSwitch("Auto Weapon", SafeCall.getBool(n, 0), e -> SafeCall.setBool(n, 0, e));
        s.addSlider("CPS", 1, 20, SafeCall.getInt(n, 0), "%d", v -> SafeCall.setInt(n, 0, (int)v));
        s.addSlider("APS", 1, 20, SafeCall.getInt(n, 1), "%d", v -> SafeCall.setInt(n, 1, (int)v));
        s.addSlider("Range", 30, 150, (int)(SafeCall.getFloat(n, 0) * 10), "%.1f", v -> SafeCall.setFloat(n, 0, v));
        addMode(s, n, 0, "Attack Mode");
        addMode(s, n, 1, "Aim Mode");
        s.addSlider("Turn Speed", 5, 20, (int)SafeCall.getFloat(n, 1), "%d", v -> SafeCall.setFloat(n, 1, v));
        addMode(s, n, 2, "Attack Style");
        addMode(s, n, 3, "Swing Style");
    }

    private static void addMode(SubMenuPanel s, String n, int idx, String label) {
        int cnt = SafeCall.getModeSize(n, idx);
        List<String> modes = new ArrayList<>();
        for (int i = 0; i < cnt; i++) modes.add(SafeCall.getModeString(n, idx, i));
        int cur = SafeCall.getModeValue(n, idx);
        s.addMode(label, modes, cur, (index, name) -> SafeCall.setModeValue(n, idx, index));
    }
}
