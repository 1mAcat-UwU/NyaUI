package com.nyaui.me.module.combat;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class AuraModule extends Module {
    public AuraModule() {
        super("Aura", ModuleCategory.COMBAT);
        setChineseName("Aura");
    }

    protected void onEnable() {
        try { SafeCall.setEnabled("KillAura"); } catch (Throwable t) {}
    }

    protected void onDisable() {
        try { SafeCall.setEnabled("KillAura"); } catch (Throwable t) {}
    }

    public void configureSubMenu(SubMenuPanel subMenu) {
        super.configureSubMenu(subMenu);
        new KillAuraModule().configureSubMenu(subMenu);
    }
}
