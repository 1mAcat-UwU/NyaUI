package com.nyaui.me.module.settings;

import com.nyaui.me.config.ConfigManager;
import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.ui.HUDManager;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class HUDModule extends Module {
    public HUDModule() {
        super("HUD", ModuleCategory.SETTINGS, "");
        setChineseName("HUD");
    }

    public boolean shouldShowInArraylist() { return false; }
    public boolean supportsShortcut() { return false; }

    protected void onEnable() {
        HUDManager.setEnabled(true);
    }

    protected void onDisable() {
        HUDManager.setEnabled(false);
    }

    public static void ensureDefaultEnabled() {
        Module module = com.nyaui.me.module.ModuleManager.getModuleByName("HUD");
        if (module instanceof HUDModule && !module.isEnabled()) module.enable();
    }

    public void configureSubMenu(SubMenuPanel subMenu) {
        super.configureSubMenu(subMenu);
        subMenu.addSectionTitle("HUD");

        subMenu.addSwitch("Enable HUD", isEnabled(), enabled -> {
            if (enabled) enable(); else disable();
        });

        subMenu.addDivider();
        subMenu.addSectionTitle("Watermark");
        subMenu.addSwitch("Watermark", ConfigManager.getBoolean("HUD", "watermark", true), enabled -> {
            ConfigManager.saveBoolean("HUD", "watermark", enabled);
            HUDManager.setWatermarkEnabled(enabled);
        });
        subMenu.addSlider("Watermark X", 0, 100, Math.round(ConfigManager.getFloat("HUD", "watermark_x", 4f)), "%d%%", v -> HUDManager.setWatermarkPosition(v / 100f, null));
        subMenu.addSlider("Watermark Y", 0, 100, Math.round(ConfigManager.getFloat("HUD", "watermark_y", 4f)), "%d%%", v -> HUDManager.setWatermarkPosition(null, v / 100f));
        subMenu.addColorPicker("Watermark Color", ConfigManager.getInt("HUD", "watermark_color", 0x80FFFFFF), color -> HUDManager.setWatermarkColor(color));

        subMenu.addDivider();
        subMenu.addSectionTitle("Notifications");
        subMenu.addSwitch("Notifications", ConfigManager.getBoolean("HUD", "notifications", true), enabled -> {
            ConfigManager.saveBoolean("HUD", "notifications", enabled);
            HUDManager.setNotificationsEnabled(enabled);
        });
        subMenu.addSlider("Notification Duration", 500, 10000, ConfigManager.getInt("HUD", "notification_duration", 2000), "%dms", v -> HUDManager.setNotificationDuration(Math.round(v)));
        subMenu.addSlider("Notifications X", 0, 100, Math.round(ConfigManager.getFloat("HUD", "notifications_x", 100f)), "%d%%", v -> HUDManager.setNotificationPosition(v / 100f, null));
        subMenu.addSlider("Notifications Y", 0, 100, Math.round(ConfigManager.getFloat("HUD", "notifications_y", 100f)), "%d%%", v -> HUDManager.setNotificationPosition(null, v / 100f));
        subMenu.addColorPicker("Notifications Color", ConfigManager.getInt("HUD", "notifications_color", 0xFFFFFFFF), color -> HUDManager.setNotificationColor(color));

        subMenu.addDivider();
        subMenu.addSectionTitle("ArrayList");
        subMenu.addSwitch("ArrayList", ConfigManager.getBoolean("HUD", "arraylist", true), enabled -> {
            ConfigManager.saveBoolean("HUD", "arraylist", enabled);
            HUDManager.setArraylistEnabled(enabled);
        });
        subMenu.addSlider("ArrayList X", 0, 100, Math.round(ConfigManager.getFloat("HUD", "arraylist_x", 100f)), "%d%%", v -> HUDManager.setArraylistPosition(v / 100f, null));
        subMenu.addSlider("ArrayList Y", 0, 100, Math.round(ConfigManager.getFloat("HUD", "arraylist_y", 4f)), "%d%%", v -> HUDManager.setArraylistPosition(null, v / 100f));
        subMenu.addColorPicker("ArrayList Color", ConfigManager.getInt("HUD", "arraylist_color", 0xFFFFFFFF), color -> HUDManager.setArraylistColor(color));
    }
}
