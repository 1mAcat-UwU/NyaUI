package com.nyaui.me.module.movement;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class StrafeModule extends Module {
    public StrafeModule() {
        super("Strafe", ModuleCategory.MOVEMENT);
    }
}
