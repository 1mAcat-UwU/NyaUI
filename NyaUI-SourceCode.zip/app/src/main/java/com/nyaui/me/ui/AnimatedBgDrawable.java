package com.nyaui.me.ui;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;

public class AnimatedBgDrawable extends Drawable {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private float corner;
    private ColorStyle style;
    private final Runnable tick = this::invalidateSelf;
    private boolean attached;

    public AnimatedBgDrawable(ColorStyle style, float cornerPx) {
        this.style = style;
        this.corner = cornerPx;
        paint.setStyle(Paint.Style.FILL);
    }

    public void setStyle(ColorStyle style) {
        this.style = style;
        invalidateSelf();
    }

    public void setCorner(float cornerPx) {
        this.corner = cornerPx;
        invalidateSelf();
    }

    public void attach() {
        if (attached) return;
        attached = true;
        DynamicColorEngine.addListener(tick);
    }

    public void detach() {
        if (!attached) return;
        attached = false;
        DynamicColorEngine.removeListener(tick);
    }

    public void draw(Canvas canvas) {
        Rect b = getBounds();
        if (b.isEmpty() || style == null) return;
        rect.set(b);
        if (style.isGradient()) {
            paint.setShader(DynamicColorEngine.createFlowShader(b.width(), b.height(), style.start(), style.end(), true));
            paint.setColor(0xFFFFFFFF);
        } else {
            paint.setShader(null);
            paint.setColor(style.solid());
        }
        canvas.drawRoundRect(rect, corner, corner, paint);
    }

    public void setAlpha(int alpha) {
        paint.setAlpha(alpha);
    }

    public void setColorFilter(ColorFilter colorFilter) {
        paint.setColorFilter(colorFilter);
    }

    public int getOpacity() {
        return PixelFormat.TRANSLUCENT;
    }
}
