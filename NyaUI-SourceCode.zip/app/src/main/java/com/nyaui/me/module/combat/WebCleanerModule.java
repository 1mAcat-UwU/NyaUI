package com.nyaui.me.module.combat;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class WebCleanerModule extends Module {
    public WebCleanerModule() {
        super("WebCleaner", ModuleCategory.COMBAT);
    }
}
