package com.nyaui.me.module.render;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class AspectRatioModule extends Module {
    public AspectRatioModule() {
        super("AspectRatio", ModuleCategory.RENDER);
    }
}
