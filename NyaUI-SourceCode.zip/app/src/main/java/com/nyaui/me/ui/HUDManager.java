package com.nyaui.me.ui;

import android.app.Activity;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;

import com.nyaui.me.config.ConfigManager;

public final class HUDManager {
    private static Activity activity;
    private static FrameLayout container;
    private static ArraylistView arraylistView;
    private static boolean enabled = true;

    private HUDManager() {}

    public static void init(Activity act, FrameLayout root) {
        activity = act;
        container = root;
        enabled = true;
        ensureArraylist();
        applyAll();
    }

    public static void setEnabled(boolean value) {
        enabled = value;
        if (activity == null) return;
        activity.runOnUiThread(() -> {
            if (value) {
                ensureArraylist();
                applyAll();
            } else {
                if (arraylistView != null) arraylistView.setVisibility(View.GONE);
                WatermarkManager.hide();
                NotificationManager.setEnabled(false);
                NotificationManager.clearAll();
            }
        });
    }

    public static void setWatermarkEnabled(boolean value) {
        ConfigManager.saveBoolean("HUD", "watermark", value);
        if (!enabled) return;
        if (value) WatermarkManager.show(); else WatermarkManager.hide();
    }

    public static void setWatermarkPosition(Float x, Float y) {
        if (x != null) ConfigManager.saveFloat("HUD", "watermark_x", clampUnit(x) * 100f);
        if (y != null) ConfigManager.saveFloat("HUD", "watermark_y", clampUnit(y) * 100f);
        WatermarkManager.updatePosition();
    }

    public static void setWatermarkColor(int color) {
        ConfigManager.saveInt("HUD", "watermark_color", color);
        WatermarkManager.setColor(color);
    }

    public static void setNotificationsEnabled(boolean value) {
        ConfigManager.saveBoolean("HUD", "notifications", value);
        NotificationManager.setEnabled(value && enabled);
        if (!value) NotificationManager.clearAll();
    }

    public static void setNotificationDuration(int ms) {
        ConfigManager.saveInt("HUD", "notification_duration", Math.max(500, Math.min(10000, ms)));
    }

    public static void setNotificationPosition(Float x, Float y) {
        if (x != null) ConfigManager.saveFloat("HUD", "notifications_x", clampUnit(x) * 100f);
        if (y != null) ConfigManager.saveFloat("HUD", "notifications_y", clampUnit(y) * 100f);
        NotificationManager.updateAllPositions();
    }

    public static void setNotificationColor(int color) {
        ConfigManager.saveInt("HUD", "notifications_color", color);
        NotificationManager.updateColors();
    }

    public static void setArraylistEnabled(boolean value) {
        ConfigManager.saveBoolean("HUD", "arraylist", value);
        if (arraylistView == null) return;
        arraylistView.setVisibility(value && enabled ? View.VISIBLE : View.GONE);
    }

    public static void setArraylistPosition(Float x, Float y) {
        if (x != null) ConfigManager.saveFloat("HUD", "arraylist_x", clampUnit(x) * 100f);
        if (y != null) ConfigManager.saveFloat("HUD", "arraylist_y", clampUnit(y) * 100f);
        updateArraylistPosition();
    }

    public static void setArraylistColor(int color) {
        ConfigManager.saveInt("HUD", "arraylist_color", color);
        if (arraylistView != null) arraylistView.setHudTextColor(color);
    }

    public static ArraylistView getArraylistView() { return arraylistView; }

    public static boolean isHudEnabled() { return enabled; }

    private static float clampUnit(float value) {
        if (Float.isNaN(value) || Float.isInfinite(value)) return 0f;
        return Math.max(0f, Math.min(1f, value));
    }

    private static void ensureArraylist() {
        if (activity == null || container == null) return;
        if (arraylistView == null) {
            arraylistView = new ArraylistView(activity);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    Gravity.NO_GRAVITY);
            container.addView(arraylistView, lp);
            for (com.nyaui.me.module.Module module : com.nyaui.me.module.ModuleManager.getAllModules()) {
                if (module.isEnabled() && module.shouldShowInArraylist()) {
                    arraylistView.addModule(module.getDisplayName());
                }
            }
        }
    }

    private static void applyAll() {
        if (!enabled) return;
        ensureArraylist();
        if (arraylistView != null) {
            arraylistView.setHudTextColor(ConfigManager.getInt("HUD", "arraylist_color", 0xFFFFFFFF));
            arraylistView.setVisibility(ConfigManager.getBoolean("HUD", "arraylist", true) ? View.VISIBLE : View.GONE);
            updateArraylistPosition();
        }
        NotificationManager.setEnabled(ConfigManager.getBoolean("HUD", "notifications", true));
        if (ConfigManager.getBoolean("HUD", "watermark", true)) WatermarkManager.show();
        else WatermarkManager.hide();
    }

    private static void updateArraylistPosition() {
        if (arraylistView == null || activity == null) return;
        arraylistView.post(() -> {
            int sw = activity.getWindowManager().getDefaultDisplay().getWidth();
            int sh = activity.getWindowManager().getDefaultDisplay().getHeight();
            float x = ConfigManager.getFloat("HUD", "arraylist_x", 100f) / 100f;
            float y = ConfigManager.getFloat("HUD", "arraylist_y", 4f) / 100f;
            float maxX = Math.max(0, sw - arraylistView.getMeasuredWidth());
            float maxY = Math.max(0, sh - arraylistView.getMeasuredHeight());
            arraylistView.setX(maxX * Math.max(0f, Math.min(1f, x)));
            arraylistView.setY(maxY * Math.max(0f, Math.min(1f, y)));
        });
    }

    public static void onModuleToggled(com.nyaui.me.module.Module module) {
        if (arraylistView == null || !enabled || !ConfigManager.getBoolean("HUD", "arraylist", true)) return;
        if (!module.shouldShowInArraylist()) return;
        if (module.isEnabled()) arraylistView.addModule(module.getDisplayName());
        else arraylistView.removeModule(module.getDisplayName());
        arraylistView.setHudTextColor(ConfigManager.getInt("HUD", "arraylist_color", 0xFFFFFFFF));
        updateArraylistPosition();
    }

    public static void cleanup() {
        if (arraylistView != null) {
            arraylistView.clearModules();
            if (arraylistView.getParent() instanceof FrameLayout) ((FrameLayout) arraylistView.getParent()).removeView(arraylistView);
        }
        arraylistView = null;
        container = null;
        activity = null;
    }
}
