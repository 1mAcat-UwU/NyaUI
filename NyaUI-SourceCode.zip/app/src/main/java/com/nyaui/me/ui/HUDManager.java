package com.nyaui.me.ui;

import android.app.Activity;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;

import com.nyaui.me.config.ConfigManager;
import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleManager;

public final class HUDManager {
    private static Activity activity;
    private static FrameLayout container;
    private static ArraylistView arraylistView;
    private static boolean enabled = false;

    private HUDManager() {}

    public static void init(Activity act, FrameLayout root) {
        activity = act;
        container = root;
        Module hud = ModuleManager.getModuleByName("HUD");
        enabled = hud != null && hud.isEnabled();
        ensureArraylist();
        applyAll();
    }

    public static void setEnabled(boolean value) {
        enabled = value;
        if (activity == null) return;
        activity.runOnUiThread(() -> {
            if (value) {
                ensureArraylist();
                applyAll();
            } else {
                if (arraylistView != null) arraylistView.setVisibility(View.GONE);
                WatermarkManager.hide();
            }
        });
    }

    public static void setWatermarkEnabled(boolean value) {
        ConfigManager.saveBoolean("HUD", "watermark", value);
        if (!enabled) return;
        if (value) WatermarkManager.show(); else WatermarkManager.hide();
    }

    public static void setWatermarkPosition(Float x, Float y) {
        if (x != null) ConfigManager.saveFloat("HUD", "watermark_x", clampUnit(x) * 100f);
        if (y != null) ConfigManager.saveFloat("HUD", "watermark_y", clampUnit(y) * 100f);
        WatermarkManager.updatePosition();
    }

    public static void setWatermarkColor(int color) {
        ConfigManager.saveInt("HUD", "watermark_color", color);
        WatermarkManager.setColor(color);
    }

    public static void setNotificationDuration(int ms) {
        ConfigManager.saveInt("HUD", "notification_duration", Math.max(500, Math.min(10000, ms)));
    }

    public static void setNotificationPosition(Float x, Float y) {
        if (x != null) ConfigManager.saveFloat("HUD", "notifications_x", clampUnit(x) * 100f);
        if (y != null) ConfigManager.saveFloat("HUD", "notifications_y", clampUnit(y) * 100f);
        NotificationManager.updateAllPositions();
    }

    public static void setNotificationColor(int color) {
        ConfigManager.saveInt("HUD", "notifications_color", color);
        NotificationManager.updateColors();
    }

    public static void setArraylistEnabled(boolean value) {
        ConfigManager.saveBoolean("HUD", "arraylist", value);
        if (arraylistView == null) return;
        arraylistView.setVisibility(value && enabled && isModuleListOn() ? View.VISIBLE : View.GONE);
    }

    public static void setArraylistPosition(Float x, Float y) {
        if (x != null) ConfigManager.saveFloat("HUD", "arraylist_x", clampUnit(x) * 100f);
        if (y != null) ConfigManager.saveFloat("HUD", "arraylist_y", clampUnit(y) * 100f);
        updateArraylistPosition();
    }

    public static void setArraylistColor(int color) {
        ConfigManager.saveInt("HUD", "arraylist_color", color);
        if (arraylistView != null) arraylistView.setHudTextColor(color);
    }

    public static ArraylistView getArraylistView() { return arraylistView; }

    private static boolean isModuleListOn() {
        try {
            Module m = ModuleManager.getModuleByName("ModuleList");
            return m != null && m.isEnabled();
        } catch (Throwable t) {
            return false;
        }
    }

    private static void ensureArraylist() {
        if (activity == null || container == null) return;
        if (arraylistView == null) {
            arraylistView = new ArraylistView(activity);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    Gravity.TOP | Gravity.END
            );
            container.addView(arraylistView, lp);
        }
        rebuildArraylistContent();
    }

    private static void rebuildArraylistContent() {
        if (arraylistView == null) return;
        arraylistView.clearModules();
        if (!enabled || !isModuleListOn()) {
            arraylistView.setVisibility(View.GONE);
            return;
        }
        for (Module module : ModuleManager.getAllModules()) {
            if (module.isEnabled() && module.shouldShowInArraylist()) {
                arraylistView.addModule(module.getDisplayName());
            }
        }
        arraylistView.setHudTextColor(ConfigManager.getInt("HUD", "arraylist_color", 0xFFFFFFFF));
        arraylistView.setVisibility(View.VISIBLE);
        updateArraylistPosition();
    }

    private static void applyAll() {
        if (!enabled) {
            if (arraylistView != null) arraylistView.setVisibility(View.GONE);
            WatermarkManager.hide();
            return;
        }
        ensureArraylist();
        if (arraylistView != null) {
            arraylistView.setHudTextColor(ConfigManager.getInt("HUD", "arraylist_color", 0xFFFFFFFF));
            arraylistView.setVisibility(isModuleListOn() ? View.VISIBLE : View.GONE);
            if (isModuleListOn()) rebuildArraylistContent();
        }
        if (ConfigManager.getBoolean("HUD", "watermark", true)) WatermarkManager.show();
        else WatermarkManager.hide();
    }

    private static void updateArraylistPosition() {
        if (arraylistView == null || activity == null) return;
        arraylistView.post(() -> {
            int sw = activity.getWindowManager().getDefaultDisplay().getWidth();
            int sh = activity.getWindowManager().getDefaultDisplay().getHeight();
            float x = ConfigManager.getFloat("HUD", "arraylist_x", 100f) / 100f;
            float y = ConfigManager.getFloat("HUD", "arraylist_y", 4f) / 100f;
            float maxX = Math.max(0, sw - arraylistView.getMeasuredWidth());
            float maxY = Math.max(0, sh - arraylistView.getMeasuredHeight());
            arraylistView.setX(maxX * Math.max(0f, Math.min(1f, x)));
            arraylistView.setY(maxY * Math.max(0f, Math.min(1f, y)));
        });
    }

    public static void onModuleToggled(Module module) {
        if (arraylistView == null || !enabled || !isModuleListOn()) return;
        if (!module.shouldShowInArraylist()) return;
        if (module.isEnabled()) arraylistView.addModule(module.getDisplayName());
        else arraylistView.removeModule(module.getDisplayName());
        arraylistView.setHudTextColor(ConfigManager.getInt("HUD", "arraylist_color", 0xFFFFFFFF));
        updateArraylistPosition();
    }

    public static void cleanup() {
        if (arraylistView != null) {
            arraylistView.clearModules();
            if (arraylistView.getParent() instanceof FrameLayout) {
                ((FrameLayout) arraylistView.getParent()).removeView(arraylistView);
            }
        }
        arraylistView = null;
        container = null;
        activity = null;
        enabled = false;
    }

    private static float clampUnit(float v) {
        return Math.max(0f, Math.min(1f, v));
    }
}
