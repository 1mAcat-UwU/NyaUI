package com.nyaui.me.ui;

import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;

public class ProgressBarDrawable extends GradientDrawable {

    private float progress;
    private GradientDrawable progressDrawable;
    private final Paint glowPaint;
    private final RectF glowRect;
    private float glowRadius = 0;
    private float cornerRadius = 0;

    public ProgressBarDrawable() {
        super();
        glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        glowPaint.setStyle(Paint.Style.FILL);
        glowRect = new RectF();
    }

    public void setProgress(float progress) {
        this.progress = progress;
        invalidateSelf();
    }

    public void setProgressDrawable(GradientDrawable drawable) {
        this.progressDrawable = drawable;
    }

    public void setGlowColor(int color, float radius) {
        glowPaint.setColor(color);
        if (radius > 0) {
            this.glowRadius = radius;
            glowPaint.setMaskFilter(new BlurMaskFilter(radius, BlurMaskFilter.Blur.NORMAL));
        } else {
            this.glowRadius = 0;
            glowPaint.setMaskFilter(null);
        }
        invalidateSelf();
    }

        public void setCornerRadius(float radius) {
        super.setCornerRadius(radius);
        this.cornerRadius = radius;
    }

        public void draw(Canvas canvas) {
        if (progressDrawable == null) {
            super.draw(canvas);
            return;
        }

        Rect bounds = getBounds();
        int progressWidth = (int) (bounds.width() * progress);

        
        if (progressWidth > 0) {
            canvas.save();
            canvas.clipRect(bounds.left, bounds.top, bounds.left + progressWidth, bounds.bottom);

            
            if (glowPaint.getMaskFilter() != null) {
                glowRect.set(bounds);
                
                glowRect.inset(glowRadius / 2, glowRadius / 2);
                canvas.drawRoundRect(glowRect, cornerRadius, cornerRadius, glowPaint);
            }

            
            progressDrawable.setBounds(bounds);
            progressDrawable.draw(canvas);
            canvas.restore();
        }

        
        if (progressWidth < bounds.width()) {
            canvas.save();
            canvas.clipRect(bounds.left + progressWidth, bounds.top, bounds.right, bounds.bottom);
            super.draw(canvas);
            canvas.restore();
        }
    }
}

