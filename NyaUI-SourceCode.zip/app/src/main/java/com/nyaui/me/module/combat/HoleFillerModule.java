package com.nyaui.me.module.combat;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class HoleFillerModule extends Module {
    public HoleFillerModule() {
        super("HoleFiller", ModuleCategory.COMBAT);
    }
}
