package com.nyaui.me.module;

public interface ShortcutToggleListener {
    void onShortcutToggled(Module module, boolean enabled);
}

