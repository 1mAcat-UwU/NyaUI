package com.nyaui.me.module.client;

import android.app.Activity;
import android.content.Context;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.nyaui.me.config.ConfigManager;
import com.nyaui.me.media.MediaReader;
import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.ui.FrameRate;
import com.nyaui.me.ui.IslandOverlay;
import com.nyaui.me.ui.PhoenixPopup;
import com.nyaui.me.ui.ThemeManager;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class DynamicIslandModule extends Module {

    public DynamicIslandModule() {
        super("DynamicIsland", ModuleCategory.CLIENT, "");
        setChineseName("Dynamic Island");
    }

    public boolean shouldShowInArraylist() { return false; }
    public boolean supportsShortcut() { return false; }

    protected void onEnable() {
        ConfigManager.setDynamicIslandEnabled(true);
        ConfigManager.saveBoolean(IslandOverlay.CFG, IslandOverlay.K_ISLAND, true);
        Activity act = PhoenixPopup.getCurrentActivity();
        if (act != null) {
            try { IslandOverlay.attach(act); } catch (Throwable ignored) {}
        }
    }

    protected void onDisable() {
        ConfigManager.setDynamicIslandEnabled(false);
        ConfigManager.saveBoolean(IslandOverlay.CFG, IslandOverlay.K_ISLAND, false);
        try { IslandOverlay.detach(); } catch (Throwable ignored) {}
    }

    public void configureSubMenu(SubMenuPanel subMenu) {
        super.configureSubMenu(subMenu);
        final Context ctx = subMenu.getContext();
        final float d = ctx.getResources().getDisplayMetrics().density;

        subMenu.addSectionTitle("Music");
        subMenu.addSwitch("Read & Show Music",
                ConfigManager.getBoolean(IslandOverlay.CFG, IslandOverlay.K_MUSIC, true),
                on -> ConfigManager.saveBoolean(IslandOverlay.CFG, IslandOverlay.K_MUSIC, on));

        subMenu.addSectionTitle("Time");
        subMenu.addSwitch("Time",
                ConfigManager.getBoolean(IslandOverlay.CFG, IslandOverlay.K_TIME, false),
                on -> ConfigManager.saveBoolean(IslandOverlay.CFG, IslandOverlay.K_TIME, on));
        subMenu.addText("Shows the system time in 12-hour format as hh:mm:ss AM/PM");

        subMenu.addDivider();
        subMenu.addSectionTitle("Music Access Permission");
        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView btn = new TextView(ctx);
        btn.setText("Open Access");
        btn.setTextSize(11f);
        btn.setTypeface(Typeface.DEFAULT_BOLD);
        btn.setTextColor(ThemeManager.getTextOnTheme());
        btn.setPadding((int) (12 * d), (int) (8 * d), (int) (12 * d), (int) (8 * d));
        btn.setBackgroundColor(ThemeManager.getThemeColor());
        btn.setOnClickListener(v -> {
            MediaReader.openAccessSettings(ctx);
            Toast.makeText(ctx, "Find NyaUI in the list and enable it", Toast.LENGTH_LONG).show();
        });
        row.addView(btn);
        subMenu.addCustomView(row);
        subMenu.addText("After granting access, play any music to show cover, title and lyrics on the Dynamic Island");

        subMenu.addDivider();
        subMenu.addSectionTitle("Refresh Rate Info");
        final TextView modeInfo = new TextView(ctx);
        modeInfo.setTextSize(10f);
        modeInfo.setTextColor(ThemeManager.getTextSecondary());
        modeInfo.setPadding((int) (4 * d), 0, 0, (int) (6 * d));
        try {
            if (ctx instanceof android.app.Activity) {
                modeInfo.setText(FrameRate.describeModes((android.app.Activity) ctx));
            } else {
                modeInfo.setText("Unavailable");
            }
        } catch (Throwable t) {
            modeInfo.setText("Unavailable");
        }
        subMenu.addCustomView(modeInfo);
    }
}
