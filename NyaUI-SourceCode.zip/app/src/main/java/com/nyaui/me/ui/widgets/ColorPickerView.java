package com.nyaui.me.ui.widgets;

import android.content.Context;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Shader;
import android.graphics.drawable.GradientDrawable;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.SeekBar;

import com.nyaui.me.ui.ColorUtils;
import com.nyaui.me.ui.ThemeManager;

public class ColorPickerView extends LinearLayout implements ThemeManager.OnThemeColorChangeListener {
    private final ColorPaletteView paletteView;
    private final SeekBar hueSlider;
    private final SeekBar alphaSlider;
    private float currentHue;
    private float currentSat;
    private float currentVal;
    private int currentAlpha;
    private boolean classicStyle = false;
    private boolean internalUpdate = false;
    private final boolean followsTheme;
    private final OnColorChangedListener colorListener;

    public interface OnColorChangedListener {
        void onColorChanged(int color);
    }

    public void setClassicStyle(boolean classic) {
        classicStyle = classic;
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.TRANSPARENT);
        bg.setCornerRadius(0);
        paletteView.setBackground(bg);
        hueSlider.setBackgroundColor(Color.TRANSPARENT);
        alphaSlider.setBackgroundColor(Color.TRANSPARENT);
        updateSliderDrawables();
        invalidate();
    }

    public ColorPickerView(Context context) {
        this(context, ThemeManager.getThemeColor(), null);
    }

    public ColorPickerView(Context context, int initialColor, OnColorChangedListener listener) {
        super(context);
        colorListener = listener;
        followsTheme = listener == null;
        setOrientation(VERTICAL);
        setPadding(0, dpToPx(5), 0, 0);

        float[] initialHsv = ColorUtils.toHsv(initialColor);
        currentHue = initialHsv[0];
        currentSat = initialHsv[1];
        currentVal = initialHsv[2];
        currentAlpha = Color.alpha(initialColor);

        paletteView = new ColorPaletteView(context);
        addView(paletteView, new LayoutParams(LayoutParams.MATCH_PARENT, dpToPx(100)));

        hueSlider = createSlider();
        hueSlider.setMax(360);
        hueSlider.setProgress(Math.round(currentHue));
        LayoutParams hueParams = new LayoutParams(LayoutParams.MATCH_PARENT, dpToPx(10));
        hueParams.setMargins(0, dpToPx(10), 0, 0);
        addView(hueSlider, hueParams);

        alphaSlider = createSlider();
        alphaSlider.setMax(255);
        alphaSlider.setProgress(currentAlpha);
        alphaSlider.setVisibility(followsTheme ? GONE : VISIBLE);
        LayoutParams alphaParams = new LayoutParams(LayoutParams.MATCH_PARENT, dpToPx(10));
        alphaParams.setMargins(0, dpToPx(6), 0, 0);
        addView(alphaSlider, alphaParams);

        hueSlider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && !internalUpdate) {
                    currentHue = ColorUtils.clampHue(progress);
                    paletteView.setHue(currentHue);
                    updateSliderDrawables();
                    updateColor();
                }
            }
            public void onStartTrackingTouch(SeekBar seekBar) {}
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        alphaSlider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && !internalUpdate) {
                    currentAlpha = ColorUtils.clampAlpha(progress);
                    updateSliderDrawables();
                    updateColor();
                }
            }
            public void onStartTrackingTouch(SeekBar seekBar) {}
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        updateSliderDrawables();
        paletteView.setHue(currentHue);
        if (followsTheme) ThemeManager.addListener(this);
    }

    private SeekBar createSlider() {
        SeekBar slider = new SeekBar(getContext());
        slider.setBackgroundColor(Color.TRANSPARENT);
        slider.getThumb().setColorFilter(new PorterDuffColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN));
        return slider;
    }

    private void updateSliderDrawables() {
        if (getWidth() <= 0) return;
        int[] hueColors = new int[361];
        for (int i = 0; i < hueColors.length; i++) {
            hueColors[i] = Color.HSVToColor(new float[]{i, 1f, 1f});
        }
        hueSlider.setProgressDrawable(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, hueColors));

        int baseColor = ColorUtils.hsvToColor(currentHue, currentSat, currentVal, 255);
        alphaSlider.setProgressDrawable(new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{ColorUtils.withAlpha(baseColor, 0), baseColor}));
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        updateSliderDrawables();
    }

    @Override
    protected void onDetachedFromWindow() {
        if (followsTheme) ThemeManager.removeListener(this);
        super.onDetachedFromWindow();
    }

    @Override
    public void onThemeColorChanged(int newColor) {
        if (!followsTheme || internalUpdate) return;
        float[] hsv = ColorUtils.toHsv(newColor);
        int alpha = Color.alpha(newColor);
        if (Math.abs(hsv[0] - currentHue) > 0.5f
                || Math.abs(hsv[1] - currentSat) > 0.005f
                || Math.abs(hsv[2] - currentVal) > 0.005f
                || alpha != currentAlpha) {
            internalUpdate = true;
            currentHue = hsv[0];
            currentSat = hsv[1];
            currentVal = hsv[2];
            currentAlpha = alpha;
            hueSlider.setProgress(Math.round(currentHue));
            alphaSlider.setProgress(currentAlpha);
            paletteView.setHue(currentHue);
            paletteView.updateIndicator(currentSat, currentVal);
            updateSliderDrawables();
            internalUpdate = false;
        }
    }

    private void updateColor() {
        int color = ColorUtils.hsvToColor(currentHue, currentSat, currentVal, currentAlpha);
        if (colorListener != null) {
            colorListener.onColorChanged(color);
        } else {
            ThemeManager.setThemeColor(ColorUtils.opaque(color));
        }
    }

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density + 0.5f);
    }

    private class ColorPaletteView extends View {
        private final Paint saturationPaint;
        private final Paint valuePaint;
        private final Paint indicatorPaint;
        private final Paint indicatorShadowPaint;
        private Shader valueShader;
        private Shader saturationShader;
        private float hue;
        private float indicatorX;
        private float indicatorY;

        public ColorPaletteView(Context context) {
            super(context);
            saturationPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            valuePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            indicatorPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            indicatorPaint.setStyle(Paint.Style.STROKE);
            indicatorPaint.setStrokeWidth(dpToPx(2));
            indicatorPaint.setColor(Color.WHITE);
            indicatorShadowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            indicatorShadowPaint.setStyle(Paint.Style.STROKE);
            indicatorShadowPaint.setStrokeWidth(dpToPx(2));
            indicatorShadowPaint.setColor(Color.BLACK);
            setHue(currentHue);
        }

        public void updateIndicator(float sat, float val) {
            if (getWidth() > 0 && getHeight() > 0) {
                indicatorX = getWidth() * ColorUtils.clampUnit(sat);
                indicatorY = getHeight() * (1f - ColorUtils.clampUnit(val));
                invalidate();
            }
        }

        public void setHue(float hue) {
            this.hue = ColorUtils.clampHue(hue);
            if (getWidth() > 0) {
                int hueColor = Color.HSVToColor(new float[]{this.hue, 1f, 1f});
                saturationShader = new LinearGradient(0, 0, getWidth(), 0,
                        Color.WHITE, hueColor, Shader.TileMode.CLAMP);
                saturationPaint.setShader(saturationShader);
            }
            invalidate();
        }

        @Override
        protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            super.onSizeChanged(w, h, oldw, oldh);
            valueShader = new LinearGradient(0, 0, 0, h,
                    Color.TRANSPARENT, Color.BLACK, Shader.TileMode.CLAMP);
            valuePaint.setShader(valueShader);
            setHue(hue);
            updateIndicator(currentSat, currentVal);
        }

        @Override
        protected void onDraw(android.graphics.Canvas canvas) {
            canvas.drawRect(0, 0, getWidth(), getHeight(), saturationPaint);
            canvas.drawRect(0, 0, getWidth(), getHeight(), valuePaint);
            canvas.drawCircle(indicatorX, indicatorY, dpToPx(7), indicatorShadowPaint);
            canvas.drawCircle(indicatorX, indicatorY, dpToPx(5), indicatorPaint);
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            int action = event.getActionMasked();
            if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_MOVE || action == MotionEvent.ACTION_UP) {
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                if (getWidth() > 0 && getHeight() > 0) {
                    indicatorX = Math.max(0f, Math.min(getWidth(), event.getX()));
                    indicatorY = Math.max(0f, Math.min(getHeight(), event.getY()));
                    currentSat = ColorUtils.clampUnit(indicatorX / getWidth());
                    currentVal = ColorUtils.clampUnit(1f - indicatorY / getHeight());
                    updateColor();
                    invalidate();
                }
                if (action == MotionEvent.ACTION_UP) {
                    if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(false);
                }
                return true;
            }
            if (action == MotionEvent.ACTION_CANCEL) {
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(false);
                return true;
            }
            return true;
        }
    }
}
