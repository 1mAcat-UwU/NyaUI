package com.nyaui.me.ui;

import android.content.Context;
import android.graphics.Outline;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.PopupWindow;

import com.nyaui.me.R;

public class FloatBallView extends FrameLayout {

    private final ImageView iconView;
    private final PopupWindow popupWindow;

    public FloatBallView(Context context, PopupWindow popupWindow) {
        super(context);
        this.popupWindow = popupWindow;

        int size = (int) (getScreenHeight(context) * 0.065f);
        if (size < 56) size = 56;
        int corner = (int) (size * 0.22f);

        iconView = new ImageView(context);
        LayoutParams lp = new LayoutParams(size, size);
        lp.gravity = Gravity.CENTER;
        iconView.setLayoutParams(lp);
        iconView.setImageResource(R.mipmap.ic_launcher);
        iconView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        iconView.setClickable(true);
        iconView.setElevation(6f);
        iconView.setClipToOutline(true);
        final int r = corner;
        iconView.setOutlineProvider(new ViewOutlineProvider() {
                        public void getOutline(View view, Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), r);
            }
        });

        addView(iconView);
        setupTouchListeners();
    }

    private void setupTouchListeners() {
        final float[] downRaw = new float[2];
        final int[] initialPos = new int[2];
        final boolean[] hasMoved = {false};
        final long[] downTime = {0};

        iconView.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    downRaw[0] = event.getRawX();
                    downRaw[1] = event.getRawY();
                    try {
                        WindowManager.LayoutParams params = (WindowManager.LayoutParams) getRootView().getLayoutParams();
                        initialPos[0] = params.x;
                        initialPos[1] = params.y;
                    } catch (Exception e) {
                        initialPos[0] = 0;
                        initialPos[1] = 0;
                    }
                    hasMoved[0] = false;
                    downTime[0] = System.currentTimeMillis();
                    v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(80).start();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float deltaX = event.getRawX() - downRaw[0];
                    float deltaY = event.getRawY() - downRaw[1];
                    if (!hasMoved[0] && (Math.abs(deltaX) > 10 || Math.abs(deltaY) > 10)) {
                        hasMoved[0] = true;
                    }
                    if (hasMoved[0] && popupWindow != null) {
                        int newX = initialPos[0] + (int) deltaX;
                        int newY = initialPos[1] + (int) deltaY;
                        popupWindow.update(newX, newY, -1, -1);
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    v.animate().scaleX(1f).scaleY(1f).setDuration(180).start();
                    if (!hasMoved[0] && System.currentTimeMillis() - downTime[0] < 300) {
                        try { SoundPlayer.playClick(); } catch (Throwable ignored) {}
                        PhoenixPopup.showMenus();
                    }
                    return true;
            }
            return false;
        });
    }

    public void hide() {
        PhoenixPopup.hideMenus();
        animate().alpha(0f).scaleX(0.8f).scaleY(0.8f).setDuration(200)
            .withEndAction(() -> setVisibility(GONE)).start();
    }

    public void destroy() {}

    private int getScreenHeight(Context context) {
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics metrics = new DisplayMetrics();
        if (wm != null) {
            wm.getDefaultDisplay().getRealMetrics(metrics);
        }
        return metrics.heightPixels > 0 ? metrics.heightPixels : 800;
    }
}
