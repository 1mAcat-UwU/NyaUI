package com.nyaui.me;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import com.nyaui.me.ui.PhoenixPopup;

public class ViewLoader {

    private static final long INJECT_DELAY_MS = 5000L;

    public static void Loading(final Activity activity) {
        try {
            activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        } catch (Throwable ignored) {}
        try {
            applyImmersive(activity);
        } catch (Throwable ignored) {}

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            try { zombie_activity.addActivity(activity); } catch (Throwable ignored) {}

            hideWelcome(activity);

            try {
                PhoenixPopup.init(activity);
            } catch (Throwable ignored) {}

            try {
                new HiroUI(activity).show();
            } catch (Throwable ignored) {}
        }, INJECT_DELAY_MS);
    }

    private static void hideWelcome(Activity activity) {
        if (activity == null) return;
        try {
            View welcome = activity.findViewById(R.id.welcomeContainer);
            if (welcome != null) {
                welcome.animate().cancel();
                welcome.setAlpha(0f);
                welcome.setVisibility(View.GONE);
            }
            View loading = activity.findViewById(R.id.loadingText);
            if (loading != null) {
                loading.setVisibility(View.GONE);
            }
            View welcomeText = activity.findViewById(R.id.welcomeText);
            if (welcomeText != null) {
                welcomeText.setVisibility(View.GONE);
            }
        } catch (Throwable ignored) {}
    }

    private static void applyImmersive(Activity activity) {
        if (activity == null) return;
        Window window = activity.getWindow();
        if (window == null) return;
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        window.addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.setStatusBarColor(Color.TRANSPARENT);
            window.setNavigationBarColor(Color.TRANSPARENT);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            WindowManager.LayoutParams lp = window.getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            window.setAttributes(lp);
        }
        View decor = window.getDecorView();
        int flags = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
        decor.setSystemUiVisibility(flags);
    }
}
