package com.nyaui.me.media;

import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

public class MediaNotificationListener extends NotificationListenerService {
    public void onNotificationPosted(StatusBarNotification sbn) {}
    public void onNotificationRemoved(StatusBarNotification sbn) {}
}
