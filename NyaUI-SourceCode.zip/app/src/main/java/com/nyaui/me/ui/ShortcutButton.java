package com.nyaui.me.ui;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.nyaui.me.module.Module;

public class ShortcutButton extends LinearLayout implements ThemeManager.OnThemeColorChangeListener,
        ThemeManager.OnThemeModeChangeListener, ThemeManager.OnRainbowColorUpdateListener {

    private static final String PREF_NAME = "shortcut_button_positions";
    private final Module module;
    private final SharedPreferences preferences;
    private final TextView textView;
    private final GradientDrawable background;
    private final PopupWindow popupWindow;
    private final WindowManager windowManager;

    private int currentBackgroundColor;
    private ValueAnimator currentColorAnimator;

    public ShortcutButton(Context context, Module module, PopupWindow popupWindow) {
        super(context);
        this.module = module;
        this.popupWindow = popupWindow;
        this.preferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        this.windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);

        setOrientation(HORIZONTAL);
        setGravity(Gravity.CENTER);

        background = new GradientDrawable();
        updateBackgroundColor();
        background.setCornerRadius(dpToPx(20));
        setBackground(background);

        int paddingH = dpToPx(12);
        int paddingV = dpToPx(8);
        setPadding(paddingH, paddingV, paddingH, paddingV);

        textView = new TextView(context);
        textView.setText(module.getDisplayName());
        textView.setTextSize(11f);
        updateTextColor();
        textView.setGravity(Gravity.CENTER);
        addView(textView);

        setupTouchListeners();
        ThemeManager.addListener(this);
        ThemeManager.addModeListener(this);
        ThemeManager.addRainbowColorUpdateListener(this);
    }

    private void updateBackgroundColor() {
        currentBackgroundColor = module.isEnabled() ? ThemeManager.getThemeColor() : ThemeManager.getBgDisabled();
        background.setColor(currentBackgroundColor);
    }

    private void updateTextColor() {
        int textColor = module.isEnabled() ? ThemeManager.getTextOnTheme() : ThemeManager.getTextPrimary();
        textView.setTextColor(textColor);
        textView.setTypeface(module.isEnabled() ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
    }

    public void updateText() {
        if (textView != null && module != null) {
            textView.setText(module.getDisplayName());
        }
    }

    public int[] loadPosition() {
        String keyX = "button_x_" + module.getName();
        String keyY = "button_y_" + module.getName();
        int x = preferences.getInt(keyX, -1);
        int y = preferences.getInt(keyY, -1);

        if (x == -1 || y == -1) {
            return new int[]{dpToPx(20), dpToPx(60)};
        }

        return new int[]{x, y};
    }

    private void savePosition(int x, int y) {
        String keyX = "button_x_" + module.getName();
        String keyY = "button_y_" + module.getName();
        preferences.edit().putInt(keyX, x).putInt(keyY, y).apply();
    }

    private void setupTouchListeners() {
        final float[] downRaw = new float[2];
        final int[] initialPos = new int[2];
        final boolean[] hasMoved = {false};
        final long[] downTime = {0};

        setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    downRaw[0] = event.getRawX();
                    downRaw[1] = event.getRawY();
                    WindowManager.LayoutParams params = (WindowManager.LayoutParams) getRootView().getLayoutParams();
                    initialPos[0] = params.x;
                    initialPos[1] = params.y;
                    hasMoved[0] = false;
                    downTime[0] = System.currentTimeMillis();
                    return true;

                case MotionEvent.ACTION_MOVE:
                    float deltaX = event.getRawX() - downRaw[0];
                    float deltaY = event.getRawY() - downRaw[1];
                    if (!hasMoved[0] && (Math.abs(deltaX) > 10 || Math.abs(deltaY) > 10)) {
                        hasMoved[0] = true;
                    }
                    if (hasMoved[0]) {
                        int newX = initialPos[0] + (int) deltaX;
                        int newY = initialPos[1] + (int) deltaY;
                        popupWindow.update(newX, newY, -1, -1);
                    }
                    return true;

                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (hasMoved[0]) {
                        WindowManager.LayoutParams endParams = (WindowManager.LayoutParams) getRootView().getLayoutParams();
                        savePosition(endParams.x, endParams.y);
                    } else if (System.currentTimeMillis() - downTime[0] < 300) {
                        module.toggle();
                        updateStyle();
                    }
                    return true;
            }
            return false;
        });
    }

    public void updateStyle() {
        updateStyle(true);
    }

    public void updateStyle(boolean animate) {
        boolean isEnabled = module.isEnabled();
        int targetColor = isEnabled ? ThemeManager.getThemeColor() : ThemeManager.getBgDisabled();
        updateTextColor();

        if (currentColorAnimator != null && currentColorAnimator.isRunning()) {
            currentColorAnimator.cancel();
        }

        if (animate && currentBackgroundColor != targetColor) {
            currentColorAnimator = ValueAnimator.ofArgb(currentBackgroundColor, targetColor);
            currentColorAnimator.setDuration(150);
            currentColorAnimator.addUpdateListener(animator -> {
                int color = (int) animator.getAnimatedValue();
                background.setColor(color);
                currentBackgroundColor = color;
                invalidate();
            });
            currentColorAnimator.start();
        } else {
            currentBackgroundColor = targetColor;
            background.setColor(targetColor);
            invalidate();
        }
    }

    private void updateAllColors() {
        post(() -> {
            if (getContext() == null) return;

            boolean isEnabled = module.isEnabled();
            int targetColor = isEnabled ? ThemeManager.getThemeColor() : ThemeManager.getBgDisabled();

            if (currentColorAnimator != null && currentColorAnimator.isRunning()) {
                currentColorAnimator.cancel();
            }

            currentBackgroundColor = targetColor;
            background.setColor(targetColor);

            updateTextColor();

            invalidate();
        });
    }

        public void onThemeColorChanged(int newColor) {
        updateAllColors();
    }

        public void onThemeModeChanged(boolean isDark) {
        updateAllColors();
    }

        public void onRainbowColorUpdate(int color) {
        post(() -> {
            if (getContext() == null) return;

            boolean isEnabled = module.isEnabled();

            if (isEnabled) {
                currentBackgroundColor = ThemeManager.getThemeColor();
                background.setColor(currentBackgroundColor);
            }

            updateTextColor();
            invalidate();
        });
    }

    public void destroy() {
        ThemeManager.removeListener(this);
        ThemeManager.removeModeListener(this);
        ThemeManager.removeRainbowColorUpdateListener(this);

        if (currentColorAnimator != null && currentColorAnimator.isRunning()) {
            currentColorAnimator.cancel();
        }
    }

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density);
    }
}
