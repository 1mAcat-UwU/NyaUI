package com.nyaui.me.module.misc;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class AutoEZModule extends Module {
    public AutoEZModule() {
        super("AutoEZ", ModuleCategory.MISC);
    }
}
