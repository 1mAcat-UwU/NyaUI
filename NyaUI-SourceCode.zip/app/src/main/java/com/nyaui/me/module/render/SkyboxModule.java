package com.nyaui.me.module.render;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class SkyboxModule extends Module {
    public SkyboxModule() {
        super("Skybox", ModuleCategory.RENDER);
        setChineseName("Skybox");
    }

    protected void onEnable() {
        try { SafeCall.setEnabled("SkyCustom"); } catch (Throwable t) {}
    }

    protected void onDisable() {
        try { SafeCall.setEnabled("SkyCustom"); } catch (Throwable t) {}
    }

    public void configureSubMenu(SubMenuPanel subMenu) {
        super.configureSubMenu(subMenu);
        new SkyCustomModule().configureSubMenu(subMenu);
    }
}
