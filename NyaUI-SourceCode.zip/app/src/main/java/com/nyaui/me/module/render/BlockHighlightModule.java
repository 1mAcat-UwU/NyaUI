package com.nyaui.me.module.render;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class BlockHighlightModule extends Module {
    public BlockHighlightModule() {
        super("BlockHighlight", ModuleCategory.RENDER);
    }
}
