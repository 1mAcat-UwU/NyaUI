package com.nyaui.me.module.client;

import com.nyaui.me.config.ConfigManager;
import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.ui.FrameRate;
import com.nyaui.me.ui.HUDManager;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class HUDModule extends Module {
    public HUDModule() {
        super("HUD", ModuleCategory.CLIENT, "");
        setChineseName("HUD");
    }

    public boolean shouldShowInArraylist() { return false; }
    public boolean supportsShortcut() { return false; }

    protected void onEnable() {
        HUDManager.setEnabled(true);
    }

    protected void onDisable() {
        HUDManager.setEnabled(false);
    }

    public void configureSubMenu(SubMenuPanel subMenu) {
        super.configureSubMenu(subMenu);
        subMenu.addSectionTitle("Watermark");
        subMenu.addSwitch("Watermark", ConfigManager.getBoolean("HUD", "watermark", true), enabled -> {
            ConfigManager.saveBoolean("HUD", "watermark", enabled);
            HUDManager.setWatermarkEnabled(enabled);
        });
        subMenu.addSwitch("Version", ConfigManager.getBoolean("HUD", "watermark_version", false), enabled -> {
            ConfigManager.saveBoolean("HUD", "watermark_version", enabled);
            com.nyaui.me.ui.WatermarkManager.refreshText();
        });
        subMenu.addSlider("Watermark X", 0, 100, Math.round(ConfigManager.getFloat("HUD", "watermark_x", 4f)), "%d%%", v -> HUDManager.setWatermarkPosition(v / 100f, null));
        subMenu.addSlider("Watermark Y", 0, 100, Math.round(ConfigManager.getFloat("HUD", "watermark_y", 4f)), "%d%%", v -> HUDManager.setWatermarkPosition(null, v / 100f));
        subMenu.addGradientColorSetting("HUD", "watermark_color", 0x80FFFFFF, color -> HUDManager.setWatermarkColor(color));

        subMenu.addDivider();
        subMenu.addSectionTitle("Fake FPS");
        boolean fakeOn = ConfigManager.getBoolean("FakeFps", "enabled", false);
        int fakeVal = ConfigManager.getInt("FakeFps", "value", 120);
        boolean fakeDyn = ConfigManager.getBoolean("FakeFps", "dynamic", false);
        int fakeMin = ConfigManager.getInt("FakeFps", "min", 80);
        int fakeMax = ConfigManager.getInt("FakeFps", "max", 180);
        int fakeSpeedPct = ConfigManager.getInt("FakeFps", "speed", 100);
        FrameRate.setFakeFps(fakeOn, fakeVal);
        FrameRate.setFakeFpsDynamic(fakeDyn, fakeMin, fakeMax, fakeSpeedPct / 100f);
        subMenu.addSwitch("Fake FPS", fakeOn, enabled -> {
            ConfigManager.saveBoolean("FakeFps", "enabled", enabled);
            FrameRate.setFakeFps(enabled, ConfigManager.getInt("FakeFps", "value", 120));
            FrameRate.setFakeFpsDynamic(
                    ConfigManager.getBoolean("FakeFps", "dynamic", false),
                    ConfigManager.getInt("FakeFps", "min", 80),
                    ConfigManager.getInt("FakeFps", "max", 180),
                    ConfigManager.getInt("FakeFps", "speed", 100) / 100f);
        });
        java.util.List<String> modes = new java.util.ArrayList<>();
        modes.add("Static");
        modes.add("Dynamic");
        subMenu.addMode("Mode", modes, fakeDyn ? 1 : 0, (index, name) -> {
            boolean dyn = index == 1;
            ConfigManager.saveBoolean("FakeFps", "dynamic", dyn);
            FrameRate.setFakeFpsDynamic(dyn,
                    ConfigManager.getInt("FakeFps", "min", 80),
                    ConfigManager.getInt("FakeFps", "max", 180),
                    ConfigManager.getInt("FakeFps", "speed", 100) / 100f);
        });
        subMenu.addSlider("FPS Value", 1, 999, fakeVal, "%d", v -> {
            int iv = Math.round(v);
            ConfigManager.saveInt("FakeFps", "value", iv);
            FrameRate.setFakeFps(ConfigManager.getBoolean("FakeFps", "enabled", false), iv);
        });
        subMenu.addSlider("Minimum", 1, 999, fakeMin, "%d", v -> {
            int iv = Math.round(v);
            int max = ConfigManager.getInt("FakeFps", "max", 180);
            if (iv > max) max = iv;
            ConfigManager.saveInt("FakeFps", "min", iv);
            ConfigManager.saveInt("FakeFps", "max", max);
            FrameRate.setFakeFpsDynamic(ConfigManager.getBoolean("FakeFps", "dynamic", false), iv, max,
                    ConfigManager.getInt("FakeFps", "speed", 100) / 100f);
        });
        subMenu.addSlider("Maximum", 1, 999, fakeMax, "%d", v -> {
            int iv = Math.round(v);
            int min = ConfigManager.getInt("FakeFps", "min", 80);
            if (iv < min) min = iv;
            ConfigManager.saveInt("FakeFps", "max", iv);
            ConfigManager.saveInt("FakeFps", "min", min);
            FrameRate.setFakeFpsDynamic(ConfigManager.getBoolean("FakeFps", "dynamic", false), min, iv,
                    ConfigManager.getInt("FakeFps", "speed", 100) / 100f);
        });
        subMenu.addSlider("Dynamic Speed", 10, 500, fakeSpeedPct, "%d%%", v -> {
            int iv = Math.round(v);
            ConfigManager.saveInt("FakeFps", "speed", iv);
            FrameRate.setFakeFpsDynamic(ConfigManager.getBoolean("FakeFps", "dynamic", false),
                    ConfigManager.getInt("FakeFps", "min", 80),
                    ConfigManager.getInt("FakeFps", "max", 180),
                    iv / 100f);
        });
    }
}
