package com.nyaui.me.module.client;

import com.nyaui.me.config.ConfigManager;
import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.ui.FrameRate;
import com.nyaui.me.ui.HUDManager;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class HUDModule extends Module {
    public HUDModule() {
        super("HUD", ModuleCategory.CLIENT, "");
        setChineseName("HUD");
    }

    public boolean shouldShowInArraylist() { return false; }
    public boolean supportsShortcut() { return false; }

    protected void onEnable() {
        HUDManager.setEnabled(true);
    }

    protected void onDisable() {
        HUDManager.setEnabled(false);
    }

    public void configureSubMenu(SubMenuPanel subMenu) {
        super.configureSubMenu(subMenu);
        subMenu.addSectionTitle("Watermark");
        subMenu.addSwitch("Watermark", ConfigManager.getBoolean("HUD", "watermark", true), enabled -> {
            ConfigManager.saveBoolean("HUD", "watermark", enabled);
            HUDManager.setWatermarkEnabled(enabled);
        });
        subMenu.addSwitch("Version", ConfigManager.getBoolean("HUD", "watermark_version", false), enabled -> {
            ConfigManager.saveBoolean("HUD", "watermark_version", enabled);
            com.nyaui.me.ui.WatermarkManager.refreshText();
        });
        subMenu.addSlider("Watermark X", 0, 100, Math.round(ConfigManager.getFloat("HUD", "watermark_x", 4f)), "%d%%", v -> HUDManager.setWatermarkPosition(v / 100f, null));
        subMenu.addSlider("Watermark Y", 0, 100, Math.round(ConfigManager.getFloat("HUD", "watermark_y", 4f)), "%d%%", v -> HUDManager.setWatermarkPosition(null, v / 100f));
        subMenu.addGradientColorSetting("HUD", "watermark_color", 0x80FFFFFF, color -> HUDManager.setWatermarkColor(color));

        subMenu.addDivider();
        subMenu.addSectionTitle("Fake FPS");
        boolean fakeOn = ConfigManager.getBoolean("FakeFps", "enabled", false);
        int fakeVal = ConfigManager.getInt("FakeFps", "value", 120);
        FrameRate.setFakeFps(fakeOn, fakeVal);
        subMenu.addSwitch("Fake FPS", fakeOn, enabled -> {
            ConfigManager.saveBoolean("FakeFps", "enabled", enabled);
            FrameRate.setFakeFps(enabled, ConfigManager.getInt("FakeFps", "value", 120));
        });
        subMenu.addSlider("FPS Value", 1, 999, fakeVal, "%d", v -> {
            int iv = Math.round(v);
            ConfigManager.saveInt("FakeFps", "value", iv);
            FrameRate.setFakeFps(ConfigManager.getBoolean("FakeFps", "enabled", false), iv);
        });
    }
}
