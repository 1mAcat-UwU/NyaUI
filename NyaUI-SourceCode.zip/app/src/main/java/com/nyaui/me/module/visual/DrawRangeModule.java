package com.nyaui.me.module.visual;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;

public class DrawRangeModule extends Module {
    public DrawRangeModule() { super("DrawRange", ModuleCategory.VISUAL, ""); setChineseName("Draw Range"); }
    public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("DrawRange"); } catch (Throwable t) {} }
    public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("DrawRange"); } catch (Throwable t) {} }
}
