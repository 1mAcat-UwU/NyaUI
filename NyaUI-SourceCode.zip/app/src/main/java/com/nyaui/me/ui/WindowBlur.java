package com.nyaui.me.ui;

import android.app.Activity;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.view.View;
import android.view.WindowManager;
import com.nyaui.me.config.ConfigManager;

public class WindowBlur {
    private static boolean isBlurApplied = false;

    private static java.lang.reflect.Method mBlurBehind;
    private static boolean blurBehindResolved = false;

    private static java.lang.reflect.Method blurBehindMethod() {
        if (!blurBehindResolved) {
            blurBehindResolved = true;
            try {
                mBlurBehind = WindowManager.LayoutParams.class.getMethod("setBlurBehindRadius", int.class);
            } catch (Throwable ignored) { mBlurBehind = null; }
        }
        return mBlurBehind;
    }

     
    public static boolean isSystemBlurAvailable(android.content.Context ctx) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return false;
        try {
            WindowManager wm = (WindowManager) ctx.getSystemService(android.content.Context.WINDOW_SERVICE);
            java.lang.reflect.Method m = WindowManager.class.getMethod("isCrossWindowBlurEnabled");
            Object r = m.invoke(wm);
            return r instanceof Boolean && (Boolean) r;
        } catch (Throwable ignored) {}
        return false;
    }

    

    public static void applyDialogBlur(android.app.Dialog dialog, int radius) {
        if (dialog == null || dialog.getWindow() == null) return;
        android.view.Window w = dialog.getWindow();
        WindowManager.LayoutParams lp = w.getAttributes();
        boolean applied = false;
        if (radius > 0
                && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                && isSystemBlurAvailable(w.getContext())) {
            java.lang.reflect.Method m = blurBehindMethod();
            if (m != null) {
                try {
                    m.invoke(lp, Math.max(1, Math.min(150, radius)));
                    lp.flags |= WindowManager.LayoutParams.FLAG_BLUR_BEHIND;
                    applied = true;
                } catch (Throwable ignored) {}
            }
        }
        if (!applied) {
            java.lang.reflect.Method m = blurBehindMethod();
            if (m != null) { try { m.invoke(lp, 0); } catch (Throwable ignored) {} }
            lp.flags &= ~WindowManager.LayoutParams.FLAG_BLUR_BEHIND;
        }
        lp.flags &= ~WindowManager.LayoutParams.FLAG_DIM_BEHIND;
        lp.dimAmount = 0f;
        try { w.setAttributes(lp); } catch (Throwable ignored) {}
    }

    

    public static boolean applyPopupBlur(View popupContent, int radius) {
        if (popupContent == null) return false;
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return false;
        if (!isSystemBlurAvailable(popupContent.getContext())) return false;
        try {
            View root = popupContent.getRootView();
            if (root == null) return false;
            android.view.ViewGroup.LayoutParams glp = root.getLayoutParams();
            if (!(glp instanceof WindowManager.LayoutParams)) return false;
            WindowManager.LayoutParams lp = (WindowManager.LayoutParams) glp;
            java.lang.reflect.Method m = blurBehindMethod();
            if (m == null) return false;
            m.invoke(lp, Math.max(1, Math.min(150, radius)));
            lp.flags |= WindowManager.LayoutParams.FLAG_BLUR_BEHIND;
            lp.flags &= ~WindowManager.LayoutParams.FLAG_DIM_BEHIND;
            lp.dimAmount = 0f;
            WindowManager wm = (WindowManager) popupContent.getContext()
                    .getSystemService(android.content.Context.WINDOW_SERVICE);
            wm.updateViewLayout(root, lp);
            return true;
        } catch (Throwable ignored) {}
        return false;
    }

    

    private static android.animation.ValueAnimator popupBlurAnim;
    private static int lastPopupRadius = -1;

     
    public static void animatePopupBlur(final View popupContent, int from, int to,
                                        long duration, final Runnable onEnd) {
        if (popupContent == null) { if (onEnd != null) onEnd.run(); return; }
        if (popupBlurAnim != null) { popupBlurAnim.cancel(); popupBlurAnim = null; }

        
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S
                || !isSystemBlurAvailable(popupContent.getContext())) {
            if (onEnd != null) onEnd.run();
            return;
        }

        lastPopupRadius = -1;
        popupBlurAnim = android.animation.ValueAnimator.ofFloat(from, to);
        popupBlurAnim.setDuration(duration);
        popupBlurAnim.setInterpolator(new android.view.animation.PathInterpolator(0.22f, 1f, 0.32f, 1f));
        popupBlurAnim.addUpdateListener(a -> {
            int r = Math.round((Float) a.getAnimatedValue());
            
            
            if (r == lastPopupRadius) return;
            lastPopupRadius = r;
            setPopupBlurRadius(popupContent, r);
        });
        popupBlurAnim.addListener(new android.animation.AnimatorListenerAdapter() {
            public void onAnimationEnd(android.animation.Animator animation) {
                setPopupBlurRadius(popupContent, to);
                popupBlurAnim = null;
                if (onEnd != null) onEnd.run();
            }
        });
        popupBlurAnim.start();
    }

     
    public static boolean setPopupBlurRadius(View popupContent, int radius) {
        if (popupContent == null) return false;
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return false;
        try {
            View root = popupContent.getRootView();
            if (root == null) return false;
            android.view.ViewGroup.LayoutParams glp = root.getLayoutParams();
            if (!(glp instanceof WindowManager.LayoutParams)) return false;
            WindowManager.LayoutParams lp = (WindowManager.LayoutParams) glp;
            java.lang.reflect.Method m = blurBehindMethod();
            if (m == null) return false;
            if (radius > 0) {
                m.invoke(lp, Math.max(1, Math.min(150, radius)));
                lp.flags |= WindowManager.LayoutParams.FLAG_BLUR_BEHIND;
            } else {
                m.invoke(lp, 0);
                lp.flags &= ~WindowManager.LayoutParams.FLAG_BLUR_BEHIND;
            }
            lp.flags &= ~WindowManager.LayoutParams.FLAG_DIM_BEHIND;
            lp.dimAmount = 0f;
            WindowManager wm = (WindowManager) popupContent.getContext()
                    .getSystemService(android.content.Context.WINDOW_SERVICE);
            wm.updateViewLayout(root, lp);
            return true;
        } catch (Throwable ignored) {}
        return false;
    }

    public static void cancelPopupBlurAnim() {
        if (popupBlurAnim != null) { popupBlurAnim.cancel(); popupBlurAnim = null; }
    }

    public static void applyBlur(Activity activity) {
        if (!ConfigManager.isBlurEnabled() || isBlurApplied) {
            return;
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                
                activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND);
                WindowManager.LayoutParams params = activity.getWindow().getAttributes();
                params.flags |= WindowManager.LayoutParams.FLAG_BLUR_BEHIND;
                activity.getWindow().setAttributes(params);
            } else {
                
                activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
                WindowManager.LayoutParams params = activity.getWindow().getAttributes();
                params.dimAmount = 0.7f;
                activity.getWindow().setAttributes(params);
                
                
                View decorView = activity.getWindow().getDecorView();
                decorView.setBackground(new ColorDrawable(0x80000000));
            }
            
            activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED);
            isBlurApplied = true;
        } catch (Exception e) {
            
            fallbackBlur(activity);
        }
    }

    public static void removeBlur(Activity activity) {
        if (!isBlurApplied) {
            return;
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND);
            } else {
                activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
                View decorView = activity.getWindow().getDecorView();
                decorView.setBackground(null);
            }
            isBlurApplied = false;
        } catch (Exception e) {
            
        }
    }

    private static void fallbackBlur(Activity activity) {
        try {
            activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            activity.getWindow().getAttributes().dimAmount = 0.5f;
            isBlurApplied = true;
        } catch (Exception e) {
            
        }
    }

    public static boolean isBlurSupported() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.S || Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP;
    }
}

