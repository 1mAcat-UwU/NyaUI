package com.nyaui.me.module.misc;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class FakePlayerModule extends Module {
    public FakePlayerModule() {
        super("FakePlayer", ModuleCategory.MISC);
    }
}
