package com.nyaui.me.module.misc;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class HCFModule extends Module {
    public HCFModule() {
        super("HCF", ModuleCategory.MISC);
    }
}
