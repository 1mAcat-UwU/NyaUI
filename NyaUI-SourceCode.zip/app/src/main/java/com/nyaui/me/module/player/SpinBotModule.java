package com.nyaui.me.module.player;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class SpinBotModule extends Module {
    public SpinBotModule() {
        super("SpinBot", ModuleCategory.PLAYER);
    }
}
