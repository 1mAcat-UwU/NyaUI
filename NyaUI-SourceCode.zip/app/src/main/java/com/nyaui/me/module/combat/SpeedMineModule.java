package com.nyaui.me.module.combat;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.module.player.AutoMineModule;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class SpeedMineModule extends Module {
    public SpeedMineModule() {
        super("SpeedMine", ModuleCategory.COMBAT);
        setChineseName("SpeedMine");
    }

    protected void onEnable() {
        try { SafeCall.setEnabled("AutoMine"); } catch (Throwable t) {}
    }

    protected void onDisable() {
        try { SafeCall.setEnabled("AutoMine"); } catch (Throwable t) {}
    }

    public void configureSubMenu(SubMenuPanel subMenu) {
        super.configureSubMenu(subMenu);
        new AutoMineModule().configureSubMenu(subMenu);
    }
}
