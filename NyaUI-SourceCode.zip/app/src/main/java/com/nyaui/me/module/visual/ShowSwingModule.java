package com.nyaui.me.module.visual;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class ShowSwingModule extends Module {
    public ShowSwingModule() { super("ShowSwing", ModuleCategory.VISUAL, ""); setChineseName("Slow Swing"); }
    public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("ShowSwing"); } catch (Throwable t) {} }
    public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("ShowSwing"); } catch (Throwable t) {} }
    public void configureSubMenu(SubMenuPanel s) {
        super.configureSubMenu(s);
        s.addSlider("Speed (ms)", 50, 500, SafeCall.getInt(getName(), 0), "%d", v -> SafeCall.setInt(getName(), 0, (int)v));
    }
}
