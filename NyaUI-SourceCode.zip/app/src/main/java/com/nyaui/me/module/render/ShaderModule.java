package com.nyaui.me.module.render;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class ShaderModule extends Module {
    public ShaderModule() {
        super("Shader", ModuleCategory.RENDER);
    }
}
