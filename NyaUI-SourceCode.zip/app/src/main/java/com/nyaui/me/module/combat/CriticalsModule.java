package com.nyaui.me.module.combat;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;

public class CriticalsModule extends Module {
    public CriticalsModule() { super("Criticals", ModuleCategory.COMBAT, ""); setChineseName("Criticals"); }
    public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("Criticals"); } catch (Throwable t) {} }
    public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("Criticals"); } catch (Throwable t) {} }
}
