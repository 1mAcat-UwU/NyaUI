package com.nyaui.me.module.player;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class ChestStealerModule extends Module {
    public ChestStealerModule() { super("ChestStealer", ModuleCategory.PLAYER, ""); setChineseName("Chest Stealer"); }
    public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("ChestStealer"); } catch (Throwable t) {} }
    public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("ChestStealer"); } catch (Throwable t) {} }
    public void configureSubMenu(SubMenuPanel s) {
        super.configureSubMenu(s);
        String n = getName();
        int cnt = SafeCall.getModeSize(n, 0); java.util.List<String> modes = new java.util.ArrayList<>(); for (int i = 0; i < cnt; i++) modes.add(SafeCall.getModeString(n, 0, i));
        s.addMode("Mode", modes, SafeCall.getModeValue(n, 0), (index, name) -> SafeCall.setModeValue(n, 0, index));
        s.addSlider("Delay (ms)", 10, 100, SafeCall.getInt(n, 0), "%d", v -> SafeCall.setInt(n, 0, (int)v));
    }
}
