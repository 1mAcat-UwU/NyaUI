package com.nyaui.me.module.player;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class ReplenishModule extends Module {
    public ReplenishModule() {
        super("Replenish", ModuleCategory.PLAYER);
    }
}
