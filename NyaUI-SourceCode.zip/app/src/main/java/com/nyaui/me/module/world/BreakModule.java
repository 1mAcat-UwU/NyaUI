package com.nyaui.me.module.world;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class BreakModule extends Module {
    public BreakModule() { super("Break", ModuleCategory.WORLD, ""); setChineseName("Break"); }
    public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("Break"); } catch (Throwable t) {} }
    public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("Break"); } catch (Throwable t) {} }
    public void configureSubMenu(SubMenuPanel s) {
        super.configureSubMenu(s);
        String n = getName();
        s.addSlider("Range", 1, 5, SafeCall.getInt(n, 0), "%d", v -> SafeCall.setInt(n, 0, (int)v));
        int cnt = SafeCall.getModeSize(n, 0); java.util.List<String> modes = new java.util.ArrayList<>(); for (int i = 0; i < cnt; i++) modes.add(SafeCall.getModeString(n, 0, i)); s.addMode("Mode", modes, SafeCall.getModeValue(n, 0), (index, name) -> SafeCall.setModeValue(n, 0, index));
    }
}
