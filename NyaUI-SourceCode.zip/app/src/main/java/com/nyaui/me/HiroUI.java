package com.nyaui.me;

import android.app.Activity;
import com.nyaui.me.ui.PhoenixPopup;

public class HiroUI {
    private Activity activity;

    public HiroUI(Activity activity) {
        this.activity = activity;
    }

    public void show() {
        if (activity == null) {
            return;
        }

        PhoenixPopup.init(activity);
        PhoenixPopup.show(activity);
    }

    public void hide() {
        PhoenixPopup.hide();
    }

    public void cleanup() {
        PhoenixPopup.cleanup();
    }
}

