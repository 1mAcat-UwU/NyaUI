package com.nyaui.me.module.misc;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class ChatSuffixModule extends Module {
    public ChatSuffixModule() {
        super("ChatSuffix", ModuleCategory.MISC);
    }
}
