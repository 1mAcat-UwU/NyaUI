package com.nyaui.me.module.render;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class NameTagsModule extends Module {
    public NameTagsModule() {
        super("NameTags", ModuleCategory.RENDER);
    }
}
