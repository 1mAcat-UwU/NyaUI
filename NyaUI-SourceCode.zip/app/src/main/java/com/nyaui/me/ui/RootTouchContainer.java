

package com.nyaui.me.ui;

import android.content.Context;
import android.view.MotionEvent;
import android.widget.FrameLayout;

public class RootTouchContainer extends FrameLayout {

    public RootTouchContainer(Context context) {
        super(context);
    }

        public boolean onTouchEvent(MotionEvent event) {

        return false;
    }
}
