package com.nyaui.me.module.combat;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class AntiPistonModule extends Module {
    public AntiPistonModule() {
        super("AntiPiston", ModuleCategory.COMBAT);
    }
}
