

package com.nyaui.me.ui;

import android.content.Context;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;

public class TransparentTouchContainer extends FrameLayout {

    public TransparentTouchContainer(Context context) {
        super(context);
    }

        public boolean onTouchEvent(MotionEvent event) {

        for (int i = 0; i < getChildCount(); i++) {
            View child = getChildAt(i);
            if (child.getVisibility() == VISIBLE && isPointInsideView(event.getX(), event.getY(), child)) {

                return true;
            }
        }

        return false;
    }

    private boolean isPointInsideView(float x, float y, View view) {
        float viewLeft = view.getLeft() + view.getTranslationX();
        float viewTop = view.getTop() + view.getTranslationY();
        float viewRight = view.getRight() + view.getTranslationX();
        float viewBottom = view.getBottom() + view.getTranslationY();
        return x >= viewLeft && x < viewRight && y >= viewTop && y < viewBottom;
    }
}
