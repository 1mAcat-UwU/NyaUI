package com.nyaui.me.module.render;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class BreakESPModule extends Module {
    public BreakESPModule() {
        super("BreakESP", ModuleCategory.RENDER);
    }
}
