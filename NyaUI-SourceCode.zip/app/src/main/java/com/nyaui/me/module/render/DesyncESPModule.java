package com.nyaui.me.module.render;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class DesyncESPModule extends Module {
    public DesyncESPModule() {
        super("DesyncESP", ModuleCategory.RENDER);
    }
}
