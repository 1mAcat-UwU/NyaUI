package com.nyaui.me.module.combat;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class TFAuraModule extends Module {
    public TFAuraModule() {
        super("TFAura", ModuleCategory.COMBAT);
    }
}
