package com.nyaui.me.ui.widgets;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.PathInterpolator;

import com.nyaui.me.ui.ThemeManager;
import com.nyaui.me.ui.SoundPlayer;

public class CustomSwitch extends View {
    private boolean isChecked;
    private float thumbPos;
    private float pressT = 0f;
    private ValueAnimator posAnim;
    private ValueAnimator pressAnim;
    private final Paint trackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint thumbPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shadowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF tmpRect = new RectF();
    private static final PathInterpolator EASE = new PathInterpolator(0.3f, 0f, 0.2f, 1f);
    private OnCheckedChangeListener listener;
    private float scaleFactor = 1f;
    private boolean classicStyle = false;
    public void setClassicStyle(boolean classic) { classicStyle = classic; invalidate(); }

    public interface OnCheckedChangeListener {
        void onCheckedChanged(boolean checked);
    }

    public CustomSwitch(Context ctx, String key, String label, boolean checked, OnCheckedChangeListener l) {
        super(ctx);
        this.isChecked = checked;
        this.thumbPos = checked ? 1f : 0f;
        this.listener = l;
        thumbPaint.setColor(Color.WHITE);
        shadowPaint.setColor(Color.argb(0, 0, 0, 0));
        setClickable(true);
    }

    public void updateScale(float scale) {
        this.scaleFactor = scale;
        requestLayout();
    }

        public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                animatePress(true);
                return true;
            case MotionEvent.ACTION_UP:
                animatePress(false);
                isChecked = !isChecked;
                animateThumb();
                try { SoundPlayer.playClick(); } catch (Throwable ignored) {}
                if (listener != null) listener.onCheckedChanged(isChecked);
                performClick();
                return true;
            case MotionEvent.ACTION_CANCEL:
                animatePress(false);
                return true;
        }
        return true;
    }

    private void animatePress(boolean down) {
        if (pressAnim != null && pressAnim.isRunning()) pressAnim.cancel();
        pressAnim = ValueAnimator.ofFloat(pressT, down ? 1f : 0f);
        pressAnim.setDuration(down ? 90 : 170);
        pressAnim.setInterpolator(EASE);
        pressAnim.addUpdateListener(a -> { pressT = (float) a.getAnimatedValue(); invalidate(); });
        pressAnim.start();
    }

    private void animateThumb() {
        if (posAnim != null && posAnim.isRunning()) posAnim.cancel();
        posAnim = ValueAnimator.ofFloat(thumbPos, isChecked ? 1f : 0f);
        posAnim.setDuration(220);
        posAnim.setInterpolator(EASE);
        posAnim.addUpdateListener(a -> { thumbPos = (float) a.getAnimatedValue(); invalidate(); });
        posAnim.start();
    }

    public void setChecked(boolean checked, boolean animate) {
        if (isChecked == checked) return;
        isChecked = checked;
        if (animate) animateThumb();
        else { thumbPos = checked ? 1f : 0f; invalidate(); }
    }

    public boolean isChecked() { return isChecked; }

        protected void onMeasure(int wSpec, int hSpec) {
        float d = getResources().getDisplayMetrics().density * scaleFactor;
        setMeasuredDimension((int) (40 * d), (int) (24 * d));
    }

        protected void onDraw(Canvas canvas) {
        int w = getWidth(), h = getHeight();
        if (w == 0 || h == 0) return;
        if (classicStyle) {
            trackPaint.setStyle(Paint.Style.FILL);
            trackPaint.setColor(Color.TRANSPARENT);
            canvas.drawRect(0, 0, w, h, trackPaint);
            trackPaint.setTypeface(Typeface.DEFAULT_BOLD);
            trackPaint.setTextSize(Math.max(10f, h * 0.52f));
            trackPaint.setTextAlign(Paint.Align.RIGHT);
            trackPaint.setColor(isChecked ? ThemeManager.getThemeColor() : ThemeManager.getTextTertiary());
            canvas.drawText(isChecked ? "ON" : "OFF", w, h * 0.67f, trackPaint);
            return;
        }
        float r = h / 2f;
        float pad = h * 0.11f;
        float thumbR = r - pad;

        int colorOn = ThemeManager.getThemeColor();
        int colorOff = ThemeManager.getStateDisabled();
        int tc = blendColor(colorOff, colorOn, thumbPos);
        trackPaint.setColor(tc);
        tmpRect.set(0, 0, w, h);
        canvas.drawRoundRect(tmpRect, r, r, trackPaint);

        float minX = pad + thumbR;
        float maxX = w - pad - thumbR;
        float cx = minX + (maxX - minX) * thumbPos;
        float cy = h / 2f;

        float tr = thumbR * (1f + 0.14f * pressT);
        float tcx = Math.max(pad + tr, Math.min(w - pad - tr, cx));

        tmpRect.set(tcx - tr, cy - tr + h * 0.06f, tcx + tr, cy + tr + h * 0.06f);
        canvas.drawOval(tmpRect, shadowPaint);

        thumbPaint.setColor(Color.WHITE);
        canvas.drawCircle(tcx, cy, tr, thumbPaint);
    }

    private int blendColor(int from, int to, float ratio) {
        float inv = 1f - ratio;
        return Color.argb(
            (int) (Color.alpha(from) * inv + Color.alpha(to) * ratio),
            (int) (Color.red(from) * inv + Color.red(to) * ratio),
            (int) (Color.green(from) * inv + Color.green(to) * ratio),
            (int) (Color.blue(from) * inv + Color.blue(to) * ratio));
    }

        protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (posAnim != null) posAnim.cancel();
        if (pressAnim != null) pressAnim.cancel();
    }
}
