package com.nyaui.me.ui.widgets;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.nyaui.me.module.Module;
import com.nyaui.me.ui.ThemeManager;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class SubMenuPanel extends LinearLayout implements ThemeManager.OnThemeColorChangeListener, ThemeManager.OnThemeModeChangeListener {
    private final Module module;
    private boolean isOpen = false;
    private ValueAnimator heightAnimator;
    private Runnable onStateChangedListener;

    private float scaleFactor = 1.0f;
    private final boolean classicStyle;

    private final List<ScalableWidget> scalableWidgets = new ArrayList<>();
    private final List<TextView> themeButtons = new ArrayList<>();
    private KeybindButton keybindButton;
    private CustomSlider lastSlider;
    private final List<Runnable> resetActions = new ArrayList<>();
    private static final Map<String, Object> FACTORY_DEFAULTS = new ConcurrentHashMap<>();
    private static volatile boolean isResetting = false;

    public static boolean isResetting() {
        return isResetting;
    }

    private final int[] themeColors = {
        0xFF96CCFF,
        0xFF4CAF50,
        0xFFBB86FC,
        0xFFFF9800,
        0xFFE91E63
    };

    public SubMenuPanel(Context context, Module module, float scaleFactor) {
        this(context, module, scaleFactor, false);
    }

    public SubMenuPanel(Context context, Module module, float scaleFactor, boolean classicStyle) {
        super(context);
        this.module = module;
        this.scaleFactor = scaleFactor;
        this.classicStyle = classicStyle;

        setOrientation(VERTICAL);
        applyPanelStyle();
        updatePadding();
        setVisibility(View.GONE);
        setAlpha(0f);

        LayoutParams params = new LayoutParams(LayoutParams.MATCH_PARENT, 0);
        params.setMargins(scaled(6), scaled(2), scaled(6), 0);
        setLayoutParams(params);
    }

    private void applyPanelStyle() {
        if (!classicStyle) {
            setBackgroundColor(Color.TRANSPARENT);
            return;
        }
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(ThemeManager.getBgSecondary());
        bg.setCornerRadius(scaled(2));
        setBackground(bg);
    }

    private void styleClassicRows() {
        if (!classicStyle) return;
        for (int i = 0; i < getChildCount(); i++) {
            View child = getChildAt(i);
            if (child instanceof LinearLayout) {
                GradientDrawable bg = new GradientDrawable();
                bg.setColor(ThemeManager.getBgPrimary());
                bg.setCornerRadius(scaled(2));
                child.setBackground(bg);
                child.setPadding(scaled(4), 0, scaled(4), 0);
            }
        }
    }

    public void addThemeModeSwitch() {
        addSwitch("Dark Mode", ThemeManager.isDarkMode(), enabled -> {
            ThemeManager.setDarkMode(enabled);
        });
    }

    public SubMenuPanel(Context context, Module module) {
        this(context, module, 1.0f);
    }

    public void updateScale(float scaleFactor) {
        this.scaleFactor = scaleFactor;
        updatePadding();
        LayoutParams params = (LayoutParams) getLayoutParams();
        params.setMargins(scaled(6), scaled(2), scaled(6), 0);
        setLayoutParams(params);
        for (int i = 0; i < getChildCount(); i++) {
            View child = getChildAt(i);
            updateChildScale(child);
        }
        for (ScalableWidget widget : scalableWidgets) {
            widget.updateScale(scaleFactor);
        }

        if (keybindButton != null) {
            keybindButton.updateScale(scaleFactor);
        }

        requestLayout();
    }

    private void updatePadding() {
        int padding = scaled(4);
        setPadding(padding, 0, padding, scaled(4));
    }

    private void updateChildScale(View view) {
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            ViewGroup.LayoutParams lp = group.getLayoutParams();
            if (lp instanceof MarginLayoutParams) {
                MarginLayoutParams mlp = (MarginLayoutParams) lp;
                mlp.topMargin = scaled(2);
                mlp.bottomMargin = scaled(2);
            }
            for (int i = 0; i < group.getChildCount(); i++) {
                updateChildScale(group.getChildAt(i));
            }
        } else if (view instanceof TextView) {
            TextView tv = (TextView) view;
            float baseSize = 11f;
            if (tv.getCurrentTextColor() == ThemeManager.getTextTertiary()) {
                baseSize = 10f;
            }
            tv.setTextSize(baseSize * scaleFactor);
        }
    }

    private int scaled(int baseDp) {
        return (int) (dpToPx(baseDp) * scaleFactor);
    }

    private String factoryKey(String label) {
        String n = module != null ? module.getName() : "?";
        return n + "\0" + label;
    }

    private int rememberIntDefault(String label, int value) {
        Object prev = FACTORY_DEFAULTS.putIfAbsent(factoryKey(label), value);
        return prev instanceof Integer ? (Integer) prev : value;
    }

    private boolean rememberBoolDefault(String label, boolean value) {
        Object prev = FACTORY_DEFAULTS.putIfAbsent(factoryKey(label), value);
        return prev instanceof Boolean ? (Boolean) prev : value;
    }

    private void registerReset(Runnable action) {
        if (action != null) resetActions.add(action);
    }

    public void addSlider(String label, int min, int max, int defaultValue, String format,
                         CustomSlider.OnValueChangeListener onValueChanged) {
        LinearLayout container = new LinearLayout(getContext());
        container.setOrientation(VERTICAL);
        LayoutParams containerParams = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        containerParams.setMargins(0, scaled(2), 0, scaled(2));
        container.setLayoutParams(containerParams);

        LinearLayout labelRow = new LinearLayout(getContext());
        labelRow.setOrientation(HORIZONTAL);

        TextView labelText = new TextView(getContext());
        labelText.setText(label);
        labelText.setTextSize(11f * scaleFactor);
        labelText.setTextColor(ThemeManager.getTextSecondary());
        LayoutParams labelParams = new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f);
        labelText.setLayoutParams(labelParams);
        labelRow.addView(labelText);

        TextView valueText = new TextView(getContext());
        valueText.setTextSize(11f * scaleFactor);
        valueText.setTextColor(ThemeManager.getTextSecondary());
        labelRow.addView(valueText);

        container.addView(labelRow);

        final int factoryValue = rememberIntDefault(label, defaultValue);
        CustomSlider slider = new CustomSlider(getContext(), module.getName(), label.toLowerCase(),
                min, max, defaultValue, value -> {
            if ("%.2f".equals(format)) {
                valueText.setText(String.format("%.2f", value / 100.0));
            } else {
                valueText.setText(String.valueOf(Math.round(value)));
            }
            onValueChanged.onValueChanged(value);
        });
        registerReset(() -> {
            if ("%.2f".equals(format)) {
                valueText.setText(String.format("%.2f", factoryValue / 100.0));
            } else {
                valueText.setText(String.valueOf(factoryValue));
            }
            onValueChanged.onValueChanged(factoryValue);
            slider.setValue(factoryValue);
        });

        slider.updateScale(scaleFactor);
        slider.setClassicStyle(classicStyle);
        lastSlider = slider;
        LayoutParams sliderParams = new LayoutParams(LayoutParams.MATCH_PARENT, scaled(36));
        sliderParams.setMargins(0, scaled(2), 0, 0);
        container.setClickable(false);
        container.setFocusable(false);
        container.addView(slider, sliderParams);
        scalableWidgets.add(new ScalableWidget(slider, labelText, valueText, sliderParams, 36));
        if ("%.2f".equals(format)) {
            valueText.setText(String.format("%.2f", defaultValue / 100.0));
        } else {
            valueText.setText(String.valueOf(Math.round(defaultValue)));
        }
        addView(container);
    }

    public void addShortcutSwitch(boolean defaultValue) {
        LinearLayout container = new LinearLayout(getContext());
        container.setOrientation(HORIZONTAL);
        container.setGravity(Gravity.CENTER_VERTICAL);
        LayoutParams containerParams = new LayoutParams(LayoutParams.MATCH_PARENT, scaled(28));
        containerParams.setMargins(0, scaled(2), 0, scaled(2));
        container.setLayoutParams(containerParams);

        TextView labelText = new TextView(getContext());
        labelText.setText("Shortcut");
        labelText.setTextSize(11f * scaleFactor);
        labelText.setTextColor(ThemeManager.getTextSecondary());
        LayoutParams labelParams = new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f);
        labelText.setLayoutParams(labelParams);
        container.addView(labelText);

        CustomSwitch switchView = new CustomSwitch(getContext(), module.getName(), "shortcut",
                defaultValue, enabled -> {
            module.toggleShortcut(enabled);
        });

        switchView.updateScale(scaleFactor);
        LayoutParams switchParams = new LayoutParams(scaled(32), scaled(18));
        container.addView(switchView, switchParams);
        scalableWidgets.add(new ScalableWidget(switchView, labelText, containerParams, switchParams, 28, 32, 18));
        registerReset(() -> {
            try { switchView.setChecked(false, false); } catch (Throwable ignored) {}
            try { module.toggleShortcut(false); } catch (Throwable ignored) {}
        });
        addView(container);
    }

    public void addKeybindSetting() {

        LinearLayout container = new LinearLayout(getContext());
        container.setOrientation(HORIZONTAL);
        container.setGravity(Gravity.CENTER_VERTICAL);
        LayoutParams containerParams = new LayoutParams(LayoutParams.MATCH_PARENT, scaled(32));
        containerParams.setMargins(0, scaled(2), 0, scaled(2));
        container.setLayoutParams(containerParams);

        LinearLayout labelArea = new LinearLayout(getContext());
        labelArea.setOrientation(VERTICAL);
        LayoutParams labelAreaParams = new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f);
        labelArea.setLayoutParams(labelAreaParams);
        labelArea.setGravity(Gravity.CENTER_VERTICAL);

        TextView labelText = new TextView(getContext());
        boolean isChinese = com.nyaui.me.config.ConfigManager.isChinese();
        labelText.setText(isChinese ? "Keybind" : "Keybind");
        labelText.setTextSize(11f * scaleFactor);
        labelText.setTextColor(ThemeManager.getTextSecondary());
        labelArea.addView(labelText);

        TextView hintText = new TextView(getContext());
        hintText.setText(isChinese ? "Tap to set key" : "Tap to set key");
        hintText.setTextSize(9f * scaleFactor);
        hintText.setTextColor(ThemeManager.getTextTertiary());
        LayoutParams hintParams = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        hintParams.setMargins(0, scaled(1), 0, 0);
        hintText.setLayoutParams(hintParams);
        labelArea.addView(hintText);

        container.addView(labelArea);

        keybindButton = new KeybindButton(getContext(), module, scaleFactor);
        LayoutParams keybindParams = new LayoutParams(LayoutParams.WRAP_CONTENT, scaled(26));
        keybindParams.setMargins(scaled(4), 0, 0, 0);
        keybindButton.setLayoutParams(keybindParams);
        container.addView(keybindButton);

        scalableWidgets.add(new ScalableWidget(keybindButton, labelText, hintText, containerParams, keybindParams));

        addView(container);
    }

    public void addKeybindSetting(String label, String hint) {
        LinearLayout container = new LinearLayout(getContext());
        container.setOrientation(HORIZONTAL);
        container.setGravity(Gravity.CENTER_VERTICAL);
        LayoutParams containerParams = new LayoutParams(LayoutParams.MATCH_PARENT, scaled(32));
        containerParams.setMargins(0, scaled(2), 0, scaled(2));
        container.setLayoutParams(containerParams);

        LinearLayout labelArea = new LinearLayout(getContext());
        labelArea.setOrientation(VERTICAL);
        LayoutParams labelAreaParams = new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f);
        labelArea.setLayoutParams(labelAreaParams);
        labelArea.setGravity(Gravity.CENTER_VERTICAL);

        TextView labelText = new TextView(getContext());
        labelText.setText(label);
        labelText.setTextSize(11f * scaleFactor);
        labelText.setTextColor(ThemeManager.getTextSecondary());
        labelArea.addView(labelText);

        if (hint != null && !hint.isEmpty()) {
            TextView hintText = new TextView(getContext());
            hintText.setText(hint);
            hintText.setTextSize(9f * scaleFactor);
            hintText.setTextColor(ThemeManager.getTextTertiary());
            LayoutParams hintParams = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
            hintParams.setMargins(0, scaled(1), 0, 0);
            hintText.setLayoutParams(hintParams);
            labelArea.addView(hintText);
        }

        container.addView(labelArea);

        keybindButton = new KeybindButton(getContext(), module, scaleFactor);
        LayoutParams keybindParams = new LayoutParams(LayoutParams.WRAP_CONTENT, scaled(26));
        keybindParams.setMargins(scaled(4), 0, 0, 0);
        keybindButton.setLayoutParams(keybindParams);
        container.addView(keybindButton);
        registerReset(() -> {
            try {
                com.nyaui.me.ui.KeybindManager.getInstance().unbindKey(module.getName());
            } catch (Throwable ignored) {}
            try {
                if (keybindButton != null) keybindButton.updateScale(scaleFactor);
            } catch (Throwable ignored) {}
        });

        addView(container);
    }

    public void addSwitch(String label, boolean defaultValue, CustomSwitch.OnCheckedChangeListener onStateChanged) {
        LinearLayout container = new LinearLayout(getContext());
        container.setOrientation(HORIZONTAL);
        container.setGravity(Gravity.CENTER_VERTICAL);
        LayoutParams containerParams = new LayoutParams(LayoutParams.MATCH_PARENT, scaled(28));
        containerParams.setMargins(0, scaled(2), 0, scaled(2));
        container.setLayoutParams(containerParams);

        TextView labelText = new TextView(getContext());
        labelText.setText(label);
        labelText.setTextSize(11f * scaleFactor);
        labelText.setTextColor(ThemeManager.getTextSecondary());
        LayoutParams labelParams = new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f);
        labelText.setLayoutParams(labelParams);
        container.addView(labelText);

        CustomSwitch switchView = new CustomSwitch(getContext(), module.getName(), label.toLowerCase(),
                defaultValue, onStateChanged);

        switchView.updateScale(scaleFactor);
        LayoutParams switchParams = new LayoutParams(scaled(32), scaled(18));
        container.addView(switchView, switchParams);
        scalableWidgets.add(new ScalableWidget(switchView, labelText, containerParams, switchParams, 28, 32, 18));
        final boolean factoryBool = rememberBoolDefault(label, defaultValue);
        registerReset(() -> {
            try { switchView.setChecked(factoryBool, false); } catch (Throwable ignored) {}
            try { onStateChanged.onCheckedChanged(factoryBool); } catch (Throwable ignored) {}
        });
        addView(container);
    }

    public void addMode(String label, List<String> modes, int defaultMode, ModeChips.OnModeChangedListener onModeChanged) {
        LinearLayout container = new LinearLayout(getContext());
        container.setOrientation(VERTICAL);
        LayoutParams containerParams = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        containerParams.setMargins(0, scaled(2), 0, scaled(2));
        container.setLayoutParams(containerParams);

        TextView labelText = new TextView(getContext());
        labelText.setText(label);
        labelText.setTextSize(11f * scaleFactor);
        labelText.setTextColor(ThemeManager.getTextSecondary());
        LayoutParams labelParams = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        labelParams.setMargins(0, 0, 0, scaled(2));
        labelText.setLayoutParams(labelParams);
        container.addView(labelText);

        final int factoryMode = rememberIntDefault(label, defaultMode);
        ModeChips chips = new ModeChips(getContext(), module.getName(), label.toLowerCase(),
                modes, defaultMode, onModeChanged);
        chips.setClassicStyle(classicStyle);
        chips.updateScale(scaleFactor);
        registerReset(() -> {
            try {
                String name = (modes != null && factoryMode >= 0 && factoryMode < modes.size()) ? modes.get(factoryMode) : "";
                onModeChanged.onModeChanged(factoryMode, name);
            } catch (Throwable ignored) {}
        });
        if (classicStyle) {
            container.addView(chips, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        } else {
            HorizontalScrollView scrollView = new HorizontalScrollView(getContext());
            scrollView.setHorizontalScrollBarEnabled(false);
            scrollView.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
            scrollView.setOverScrollMode(View.OVER_SCROLL_NEVER);
            scrollView.addView(chips);
            container.addView(scrollView);
        }
        scalableWidgets.add(new ScalableWidget(chips, labelText, null, null, 0));
        addView(container);
    }

    public void addText(String text) {
        TextView textView = new TextView(getContext());
        textView.setText(text);
        textView.setTextSize(10f * scaleFactor);
        textView.setTextColor(ThemeManager.getTextTertiary());
        LayoutParams params = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        params.setMargins(0, scaled(2), 0, scaled(2));
        textView.setLayoutParams(params);
        addView(textView);
    }

    public void addDivider() {
        View divider = new View(getContext());
        divider.setBackgroundColor(ThemeManager.getStateDisabled());
        LayoutParams params = new LayoutParams(LayoutParams.MATCH_PARENT, scaled(1));
        params.setMargins(0, scaled(6), 0, scaled(6));
        divider.setLayoutParams(params);
        addView(divider);
    }

    public void addSectionTitle(String title) {
        TextView titleView = new TextView(getContext());
        titleView.setText(title);
        titleView.setTextSize(10f * scaleFactor);
        titleView.setTextColor(ThemeManager.getThemeColor());
        titleView.setAllCaps(true);
        LayoutParams params = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        params.setMargins(0, scaled(8), 0, scaled(4));
        titleView.setLayoutParams(params);
        addView(titleView);
    }

    public void addColorPicker(String label, int initialColor, ColorPickerView.OnColorChangedListener listener) {
        TextView labelView = new TextView(getContext());
        labelView.setText(label);
        labelView.setTextSize(11f * scaleFactor);
        labelView.setTextColor(ThemeManager.getTextSecondary());
        LayoutParams labelParams = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        labelParams.setMargins(0, scaled(3), 0, scaled(2));
        addView(labelView, labelParams);

        ColorPickerView picker = new ColorPickerView(getContext(), initialColor, listener);
        picker.setClassicStyle(classicStyle);
        addView(picker, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
    }

    

    private void addModeTo(LinearLayout target, String label, List<String> modes, int defaultMode, ModeChips.OnModeChangedListener onModeChanged) {
        LinearLayout container = new LinearLayout(getContext());
        container.setOrientation(VERTICAL);
        LayoutParams containerParams = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        containerParams.setMargins(0, scaled(2), 0, scaled(2));
        container.setLayoutParams(containerParams);

        TextView labelText = new TextView(getContext());
        labelText.setText(label);
        labelText.setTextSize(11f * scaleFactor);
        labelText.setTextColor(ThemeManager.getTextSecondary());
        LayoutParams labelParams = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        labelParams.setMargins(0, 0, 0, scaled(2));
        labelText.setLayoutParams(labelParams);
        container.addView(labelText);

        final int factoryMode = rememberIntDefault(label, defaultMode);
        ModeChips chips = new ModeChips(getContext(), module.getName(), label.toLowerCase(),
                modes, defaultMode, onModeChanged);
        chips.setClassicStyle(classicStyle);
        chips.updateScale(scaleFactor);
        registerReset(() -> {
            try {
                String name = (modes != null && factoryMode >= 0 && factoryMode < modes.size()) ? modes.get(factoryMode) : "";
                onModeChanged.onModeChanged(factoryMode, name);
            } catch (Throwable ignored) {}
        });
        if (classicStyle) {
            container.addView(chips, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        } else {
            HorizontalScrollView scrollView = new HorizontalScrollView(getContext());
            scrollView.setHorizontalScrollBarEnabled(false);
            scrollView.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
            scrollView.addView(chips);
            container.addView(scrollView);
        }
        scalableWidgets.add(new ScalableWidget(chips, labelText, null, null, 0));
        target.addView(container);
    }

    private void addColorPickerTo(LinearLayout target, String label, int initialColor, ColorPickerView.OnColorChangedListener listener) {
        TextView labelView = new TextView(getContext());
        labelView.setText(label);
        labelView.setTextSize(11f * scaleFactor);
        labelView.setTextColor(ThemeManager.getTextSecondary());
        LayoutParams labelParams = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        labelParams.setMargins(0, scaled(3), 0, scaled(2));
        target.addView(labelView, labelParams);

        ColorPickerView picker = new ColorPickerView(getContext(), initialColor, listener);
        picker.setClassicStyle(classicStyle);
        target.addView(picker, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
    }

    private void addSliderTo(LinearLayout target, String label, int min, int max, int defaultValue, String format,
                             CustomSlider.OnValueChangeListener onValueChanged) {
        LinearLayout container = new LinearLayout(getContext());
        container.setOrientation(VERTICAL);
        LayoutParams containerParams = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        containerParams.setMargins(0, scaled(2), 0, scaled(2));
        container.setLayoutParams(containerParams);

        LinearLayout labelRow = new LinearLayout(getContext());
        labelRow.setOrientation(HORIZONTAL);

        TextView labelText = new TextView(getContext());
        labelText.setText(label);
        labelText.setTextSize(11f * scaleFactor);
        labelText.setTextColor(ThemeManager.getTextSecondary());
        LayoutParams labelParams = new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f);
        labelText.setLayoutParams(labelParams);
        labelRow.addView(labelText);

        TextView valueText = new TextView(getContext());
        valueText.setTextSize(11f * scaleFactor);
        valueText.setTextColor(ThemeManager.getTextSecondary());
        labelRow.addView(valueText);
        container.addView(labelRow);

        CustomSlider slider = new CustomSlider(getContext(), module.getName(), label.toLowerCase(),
                min, max, defaultValue, value -> {
            valueText.setText(String.valueOf(value));
            onValueChanged.onValueChanged(value);
        });
        slider.updateScale(scaleFactor);
        slider.setClassicStyle(classicStyle);
        lastSlider = slider;
        LayoutParams sliderParams = new LayoutParams(LayoutParams.MATCH_PARENT, scaled(32));
        sliderParams.setMargins(0, scaled(2), 0, 0);
        container.addView(slider, sliderParams);
        scalableWidgets.add(new ScalableWidget(slider, labelText, valueText, sliderParams, 32));
        valueText.setText(String.valueOf(defaultValue));
        target.addView(container);
    }

    public interface ExpandableSection {
        void setExpanded(boolean expanded);
        boolean isExpanded();
        LinearLayout getContent();
    }

    public ExpandableSection addExpandableSection(String title, boolean defaultExpanded) {
        LinearLayout section = new LinearLayout(getContext());
        section.setOrientation(LinearLayout.VERTICAL);
        LayoutParams sectionLp = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        sectionLp.topMargin = scaled(2);
        sectionLp.bottomMargin = scaled(2);
        addView(section, sectionLp);

        LinearLayout header = new LinearLayout(getContext());
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(android.view.Gravity.CENTER_VERTICAL);
        header.setPadding(0, scaled(2), 0, scaled(2));
        header.setClickable(true);
        header.setFocusable(true);
        header.setMinimumHeight(scaled(28));

        TextView titleView = new TextView(getContext());
        titleView.setText(title);
        titleView.setTextColor(ThemeManager.getTextSecondary());
        titleView.setTextSize(11f * scaleFactor);
        titleView.setTypeface(android.graphics.Typeface.DEFAULT);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f);
        header.addView(titleView, titleLp);
        section.addView(header, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        LinearLayout content = new LinearLayout(getContext());
        content.setOrientation(LinearLayout.VERTICAL);
        content.setVisibility(defaultExpanded ? VISIBLE : GONE);
        LayoutParams contentLp = new LayoutParams(LayoutParams.MATCH_PARENT, defaultExpanded ? LayoutParams.WRAP_CONTENT : 0);
        section.addView(content, contentLp);

        final boolean[] expanded = new boolean[]{defaultExpanded};
        final android.animation.ValueAnimator[] anim = new android.animation.ValueAnimator[1];
        header.setOnClickListener(v -> {
            try { com.nyaui.me.ui.SoundPlayer.playClick(); } catch (Throwable ignored) {}
            expanded[0] = !expanded[0];
            if (anim[0] != null) anim[0].cancel();
            content.measure(
                MeasureSpec.makeMeasureSpec(section.getWidth() > 0 ? section.getWidth() : getWidth(), MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED)
            );
            int target = content.getMeasuredHeight();
            LayoutParams lp = (LayoutParams) content.getLayoutParams();
            if (expanded[0]) {
                content.setVisibility(VISIBLE);
                content.setAlpha(0f);
                int from = Math.max(0, lp.height <= 0 ? 0 : lp.height);
                anim[0] = android.animation.ValueAnimator.ofInt(from, Math.max(target, 1));
                anim[0].setDuration(220);
                anim[0].setInterpolator(new android.view.animation.PathInterpolator(0.22f, 1f, 0.32f, 1f));
                anim[0].addUpdateListener(a -> {
                    lp.height = (int) a.getAnimatedValue();
                    content.setLayoutParams(lp);
                    content.setAlpha(a.getAnimatedFraction());
                });
                anim[0].addListener(new android.animation.AnimatorListenerAdapter() {
                    public void onAnimationEnd(android.animation.Animator animation) {
                        lp.height = LayoutParams.WRAP_CONTENT;
                        content.setLayoutParams(lp);
                        content.setAlpha(1f);
                    }
                });
                anim[0].start();
            } else {
                int from = content.getHeight() > 0 ? content.getHeight() : target;
                anim[0] = android.animation.ValueAnimator.ofInt(from, 0);
                anim[0].setDuration(200);
                anim[0].setInterpolator(new android.view.animation.PathInterpolator(0.22f, 1f, 0.32f, 1f));
                anim[0].addUpdateListener(a -> {
                    lp.height = (int) a.getAnimatedValue();
                    content.setLayoutParams(lp);
                    content.setAlpha(1f - a.getAnimatedFraction());
                });
                anim[0].addListener(new android.animation.AnimatorListenerAdapter() {
                    public void onAnimationEnd(android.animation.Animator animation) {
                        content.setVisibility(GONE);
                        lp.height = 0;
                        content.setLayoutParams(lp);
                        content.setAlpha(1f);
                    }
                });
                anim[0].start();
            }
        });

        return new ExpandableSection() {
            public void setExpanded(boolean e) {
                expanded[0] = e;
                content.setVisibility(e ? VISIBLE : GONE);
                LayoutParams lp = (LayoutParams) content.getLayoutParams();
                lp.height = e ? LayoutParams.WRAP_CONTENT : 0;
                content.setLayoutParams(lp);
                content.setAlpha(1f);
            }
            public boolean isExpanded() { return expanded[0]; }
            public LinearLayout getContent() { return content; }
        };
    }

    public void addGradientColorSettingTo(LinearLayout target, String group, String key, int solidDefault, ColorPickerView.OnColorChangedListener solidListener) {
        if (target == null) {
            addGradientColorSetting(group, key, solidDefault, solidListener);
            return;
        }
        java.util.List<String> modes = new java.util.ArrayList<>();
        modes.add("Solid");
        modes.add("Gradient");
        String cur = com.nyaui.me.config.ConfigManager.getColorMode(group, key);
        int idxMode = "gradient".equalsIgnoreCase(cur) ? 1 : 0;
        addModeTo(target, "Color Mode", modes, idxMode, (index, name) -> {
            com.nyaui.me.config.ConfigManager.saveColorMode(group, key, index == 1 ? "gradient" : "solid");
            if (solidListener != null) {
                int c = com.nyaui.me.config.ConfigManager.getInt(group, key, solidDefault);
                solidListener.onColorChanged(c);
            }
        });
        int solid = com.nyaui.me.config.ConfigManager.getInt(group, key, solidDefault);
        addColorPickerTo(target, "Color", solid, color -> {
            com.nyaui.me.config.ConfigManager.saveInt(group, key, color);
            if (solidListener != null) solidListener.onColorChanged(color);
        });
        int g0 = com.nyaui.me.config.ConfigManager.getGradientStart(group, key, solidDefault);
        int g1 = com.nyaui.me.config.ConfigManager.getGradientEnd(group, key, solidDefault);
        addColorPickerTo(target, "Start Color", g0, color -> {
            int end = com.nyaui.me.config.ConfigManager.getGradientEnd(group, key, solidDefault);
            com.nyaui.me.config.ConfigManager.saveGradientColors(group, key, color, end);
            if (solidListener != null) solidListener.onColorChanged(color);
        });
        addColorPickerTo(target, "End Color", g1, color -> {
            int start = com.nyaui.me.config.ConfigManager.getGradientStart(group, key, solidDefault);
            com.nyaui.me.config.ConfigManager.saveGradientColors(group, key, start, color);
            if (solidListener != null) solidListener.onColorChanged(color);
        });
        int alpha = Math.max(0, Math.min(255, com.nyaui.me.config.ConfigManager.getInt(group, key + "_alpha", android.graphics.Color.alpha(solidDefault))));
        addSliderTo(target, "Transparency", 0, 255, alpha, "%d", v -> {
            int a = Math.round(v);
            com.nyaui.me.config.ConfigManager.saveInt(group, key + "_alpha", a);
            if (solidListener != null) solidListener.onColorChanged(com.nyaui.me.config.ConfigManager.getInt(group, key, solidDefault));
        });
        float speed = com.nyaui.me.config.ConfigManager.getFloat(group, key + "_speed", 1f);
        int speedPct = Math.round(speed * 100f);
        addSliderTo(target, "Gradient Speed", 0, 500, speedPct, "%d%%", v -> {
            float s = Math.max(0f, Math.min(5f, v / 100f));
            com.nyaui.me.config.ConfigManager.saveFloat(group, key + "_speed", s);
            com.nyaui.me.ui.DynamicColorEngine.setSpeedMultiplier(s);
            if (solidListener != null) solidListener.onColorChanged(com.nyaui.me.config.ConfigManager.getInt(group, key, solidDefault));
        });
        java.util.List<String> dirs = new java.util.ArrayList<>();
        dirs.add("Left → Right");
        dirs.add("Right → Left");
        dirs.add("Top → Bottom");
        dirs.add("Bottom → Top");
        int dir = com.nyaui.me.config.ConfigManager.getInt(group, key + "_dir", 0);
        addModeTo(target, "Gradient Direction", dirs, dir, (index, name) -> {
            com.nyaui.me.config.ConfigManager.saveInt(group, key + "_dir", index);
            com.nyaui.me.ui.DynamicColorEngine.setDirection(index);
            if (solidListener != null) solidListener.onColorChanged(com.nyaui.me.config.ConfigManager.getInt(group, key, solidDefault));
        });
        final int factorySolid = solidDefault;
        registerReset(() -> {
            try {
                com.nyaui.me.config.ConfigManager.saveColorMode(group, key, "solid");
                com.nyaui.me.config.ConfigManager.saveInt(group, key, factorySolid);
                com.nyaui.me.config.ConfigManager.saveGradientColors(group, key, factorySolid, factorySolid);
                com.nyaui.me.config.ConfigManager.saveInt(group, key + "_alpha", android.graphics.Color.alpha(factorySolid));
                com.nyaui.me.config.ConfigManager.saveFloat(group, key + "_speed", 1f);
                com.nyaui.me.config.ConfigManager.saveInt(group, key + "_dir", 0);
                com.nyaui.me.ui.DynamicColorEngine.setSpeedMultiplier(1f);
                com.nyaui.me.ui.DynamicColorEngine.setDirection(0);
                if (solidListener != null) solidListener.onColorChanged(factorySolid);
            } catch (Throwable ignored) {}
        });
    }

    public void addGradientColorSetting(String group, String key, int solidDefault, ColorPickerView.OnColorChangedListener solidListener) {
        java.util.List<String> modes = new java.util.ArrayList<>();
        modes.add("Solid");
        modes.add("Gradient");
        String cur = com.nyaui.me.config.ConfigManager.getColorMode(group, key);
        int idxMode = "gradient".equalsIgnoreCase(cur) ? 1 : 0;
        addMode("Color Mode", modes, idxMode, (index, name) -> {
            com.nyaui.me.config.ConfigManager.saveColorMode(group, key, index == 1 ? "gradient" : "solid");
            if (solidListener != null) {
                int c = com.nyaui.me.config.ConfigManager.getInt(group, key, solidDefault);
                solidListener.onColorChanged(c);
            }
        });
        int solid = com.nyaui.me.config.ConfigManager.getInt(group, key, solidDefault);
        addColorPicker("Color", solid, color -> {
            com.nyaui.me.config.ConfigManager.saveInt(group, key, color);
            if (solidListener != null) solidListener.onColorChanged(color);
        });
        int g0 = com.nyaui.me.config.ConfigManager.getGradientStart(group, key, solidDefault);
        int g1 = com.nyaui.me.config.ConfigManager.getGradientEnd(group, key, solidDefault);
        addColorPicker("Start Color", g0, color -> {
            int end = com.nyaui.me.config.ConfigManager.getGradientEnd(group, key, solidDefault);
            com.nyaui.me.config.ConfigManager.saveGradientColors(group, key, color, end);
            if (solidListener != null) solidListener.onColorChanged(color);
        });
        addColorPicker("End Color", g1, color -> {
            int start = com.nyaui.me.config.ConfigManager.getGradientStart(group, key, solidDefault);
            com.nyaui.me.config.ConfigManager.saveGradientColors(group, key, start, color);
            if (solidListener != null) solidListener.onColorChanged(color);
        });
        int alpha = Math.max(0, Math.min(255, com.nyaui.me.config.ConfigManager.getInt(group, key + "_alpha", android.graphics.Color.alpha(solidDefault))));
        addSlider("Transparency", 0, 255, alpha, "%d", v -> {
            int a = Math.round(v);
            com.nyaui.me.config.ConfigManager.saveInt(group, key + "_alpha", a);
            if (solidListener != null) solidListener.onColorChanged(com.nyaui.me.config.ConfigManager.getInt(group, key, solidDefault));
        });
        float speed = com.nyaui.me.config.ConfigManager.getFloat(group, key + "_speed", 1f);
        int speedPct = Math.round(speed * 100f);
        addSlider("Gradient Speed", 0, 500, speedPct, "%d%%", v -> {
            float s = Math.max(0f, Math.min(5f, v / 100f));
            com.nyaui.me.config.ConfigManager.saveFloat(group, key + "_speed", s);
            com.nyaui.me.ui.DynamicColorEngine.setSpeedMultiplier(s);
            if (solidListener != null) solidListener.onColorChanged(com.nyaui.me.config.ConfigManager.getInt(group, key, solidDefault));
        });
        java.util.List<String> dirs = new java.util.ArrayList<>();
        dirs.add("Left → Right");
        dirs.add("Right → Left");
        dirs.add("Top → Bottom");
        dirs.add("Bottom → Top");
        int dir = com.nyaui.me.config.ConfigManager.getInt(group, key + "_dir", 0);
        addMode("Gradient Direction", dirs, dir, (index, name) -> {
            com.nyaui.me.config.ConfigManager.saveInt(group, key + "_dir", index);
            com.nyaui.me.ui.DynamicColorEngine.setDirection(index);
            if (solidListener != null) solidListener.onColorChanged(com.nyaui.me.config.ConfigManager.getInt(group, key, solidDefault));
        });
    }

    
    
        public void appendModuleReset(final com.nyaui.me.module.Module targetModule) {
        final com.nyaui.me.module.Module mod = targetModule != null ? targetModule : module;
        if (mod == null) return;
        addDivider();
        addResetButton(() -> {
            final com.nyaui.me.module.Module target = mod;
            final List<Runnable> actions = new ArrayList<>(resetActions);
            post(() -> {
                isResetting = true;
                try {
                    for (Runnable action : actions) {
                        try { action.run(); } catch (Throwable ignored) {}
                    }
                    try {
                        com.nyaui.me.config.ConfigManager.clearModuleConfig(target.getName());
                    } catch (Throwable ignored) {}
                    for (Runnable action : actions) {
                        try { action.run(); } catch (Throwable ignored) {}
                    }
                    try { target.resetSettings(); } catch (Throwable ignored) {}
                    removeAllViews();
                    resetActions.clear();
                    scalableWidgets.clear();
                    themeButtons.clear();
                    keybindButton = null;
                    lastSlider = null;
                    if (target.supportsShortcut()) {
                        addShortcutSwitch(target.isShortcutEnabled());
                    }
                    addKeybindSetting();
                    target.configureSubMenu(SubMenuPanel.this);
                    appendModuleReset(target);
                    updateThemeColors();
                    if (isOpen) {
                        getLayoutParams().height = LayoutParams.WRAP_CONTENT;
                        setVisibility(VISIBLE);
                        setAlpha(1f);
                    }
                    requestLayout();
                    invalidate();
                    if (getParent() instanceof View) {
                        ((View) getParent()).requestLayout();
                        ((View) getParent()).invalidate();
                    }
                    final boolean uiModule = target.getName() != null && target.getName().equals("UI");
                    if (uiModule) {
                        post(() -> {
                            try {
                                com.nyaui.me.ui.PhoenixPopup.refreshUiBackground();
                            } catch (Throwable ignored) {}
                            try {
                                com.nyaui.me.ui.PhoenixPopup.reloadClickGui();
                            } catch (Throwable ignored) {}
                        });
                    }
                } finally {
                    isResetting = false;
                }
            });
        });
    }

    public CustomSlider getLastSlider() { return lastSlider; }

    public void addResetButton(Runnable onReset) {
        LinearLayout row = new LinearLayout(getContext());
        row.setOrientation(HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        LayoutParams rowLp = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        rowLp.setMargins(0, scaled(2), 0, scaled(2));
        row.setLayoutParams(rowLp);
        row.setMinimumHeight(scaled(36));
        row.setPadding(scaled(4), scaled(8), scaled(4), scaled(8));
        row.setClickable(true);
        row.setFocusable(true);
        row.setEnabled(true);
        row.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);

        TextView btn = new TextView(getContext());
        btn.setText("Reset");
        btn.setTextSize(11f * scaleFactor);
        btn.setTextColor(ThemeManager.getTextSecondary());
        btn.setGravity(android.view.Gravity.CENTER_VERTICAL);
        btn.setClickable(false);
        btn.setFocusable(false);
        btn.setDuplicateParentStateEnabled(true);
        LayoutParams btnLp = new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f);
        row.addView(btn, btnLp);

        row.setOnClickListener(v -> {
            try { com.nyaui.me.ui.SoundPlayer.playClick(); } catch (Throwable ignored) {}
            if (onReset != null) onReset.run();
        });
        addView(row);
        if (classicStyle) styleClassicRows();
    }

    public void addCustomView(View view) {
        if (view.getLayoutParams() == null) {
            LayoutParams params = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
            params.setMargins(0, scaled(4), 0, scaled(4));
            view.setLayoutParams(params);
        }
        addView(view);
    }

    public void addThemeButtons() {
        themeButtons.clear();
        LinearLayout container = new LinearLayout(getContext());
        container.setOrientation(HORIZONTAL);

        String[] themeNames = {"Default", "Green", "Purple", "Orange", "Pink"};
        Runnable[] themeActions = {
            ThemeManager::applyDefaultTheme,
            ThemeManager::applyGreenTheme,
            ThemeManager::applyPurpleTheme,
            ThemeManager::applyOrangeTheme,
            ThemeManager::applyPinkTheme
        };

        for(int i = 0; i < themeNames.length; i++) {
            TextView button = new TextView(getContext());
            button.setText(themeNames[i]);
            button.setTextSize(10f * scaleFactor);
            button.setGravity(Gravity.CENTER);
            int paddingH = scaled(8);
            int paddingV = scaled(5);
            button.setPadding(paddingH, paddingV, paddingH, paddingV);

            button.setBackground(new GradientDrawable());

            final Runnable action = themeActions[i];
            button.setOnClickListener(v -> action.run());

            LayoutParams params = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
            if (i > 0) {
                params.leftMargin = scaled(4);
            }
            container.addView(button, params);
            themeButtons.add(button);
        }

        HorizontalScrollView scrollView = new HorizontalScrollView(getContext());
        scrollView.setHorizontalScrollBarEnabled(false);
        scrollView.addView(container);
        addCustomView(scrollView);

        updateThemeButtonStyles();
    }

    private void updateThemeButtonStyles() {
        int currentThemeColor = ThemeManager.getThemeColor();
        for (int i = 0; i < themeButtons.size(); i++) {
            TextView button = themeButtons.get(i);
            if (button.getBackground() instanceof GradientDrawable) {
                GradientDrawable bg = (GradientDrawable) button.getBackground();

                boolean isSelected = currentThemeColor == themeColors[i];

                if (classicStyle) {
                    bg.setColor(Color.TRANSPARENT);
                    bg.setCornerRadius(0);
                    button.setTextColor(isSelected ? ThemeManager.getThemeColor() : ThemeManager.getTextSecondary());
                    button.setTypeface(isSelected ? android.graphics.Typeface.DEFAULT_BOLD : android.graphics.Typeface.DEFAULT);
                } else if (isSelected) {
                    bg.setColor(ThemeManager.getThemeColor());
                    button.setTextColor(ThemeManager.getTextOnTheme());
                    bg.setCornerRadius(scaled(6));
                } else {
                    bg.setColor(ThemeManager.getBgDisabled());
                    button.setTextColor(ThemeManager.getTextPrimary());
                    bg.setCornerRadius(scaled(6));
                }
            }
        }
    }

    public void updateThemeColors() {
        applyPanelStyle();
        updateThemeButtonStyles();
        styleClassicRows();
        updateAllChildTextColors(this);

        for (ScalableWidget widget : scalableWidgets) {
            if (widget.widget != null) {
                widget.widget.invalidate();
            }
            if (widget.label != null) {
                widget.label.setTextColor(ThemeManager.getTextSecondary());
            }
            if (widget.valueText != null) {
                widget.valueText.setTextColor(ThemeManager.getTextSecondary());
            }
            if (widget.hintText != null) {
                widget.hintText.setTextColor(ThemeManager.getTextTertiary());
            }
        }

        if (keybindButton != null) {
            keybindButton.invalidate();
        }

        invalidate();
    }

        public void onViewAdded(View child) {
        super.onViewAdded(child);
        applyClassicStyleRecursive(child);
    }

    private void applyClassicStyleRecursive(View view) {
        if (classicStyle && view instanceof LinearLayout && view != this) {
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(ThemeManager.getBgPrimary());
            bg.setCornerRadius(scaled(2));
            view.setBackground(bg);
            view.setPadding(scaled(4), 0, scaled(4), 0);
        }
        if (view instanceof CustomSwitch) ((CustomSwitch) view).setClassicStyle(classicStyle);
        if (view instanceof CustomSlider) ((CustomSlider) view).setClassicStyle(classicStyle);
        if (view instanceof ModeChips) ((ModeChips) view).setClassicStyle(classicStyle);
        if (view instanceof KeybindButton) ((KeybindButton) view).setClassicStyle(classicStyle);
        if (view instanceof ColorPickerView) ((ColorPickerView) view).setClassicStyle(classicStyle);
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) applyClassicStyleRecursive(group.getChildAt(i));
        }
    }

    public void toggle() {
        toggle(null);
    }

    public void toggle(Runnable onComplete) {
        if (isOpen) {
            collapse(onComplete);
        } else {
            expand(onComplete);
        }
    }

    private void expand(Runnable onComplete) {
        isOpen = true;
        setVisibility(View.VISIBLE);
        measure(
            MeasureSpec.makeMeasureSpec(((ViewGroup)getParent()).getWidth(), MeasureSpec.EXACTLY),
            MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED)
        );
        int targetHeight = getMeasuredHeight();
        if (heightAnimator != null) heightAnimator.cancel();
        final ViewGroup.LayoutParams params = getLayoutParams();
        params.height = 0;
        heightAnimator = ValueAnimator.ofInt(0, targetHeight);
        heightAnimator.setDuration(220);
        heightAnimator.setInterpolator(new android.view.animation.PathInterpolator(0.22f, 1f, 0.32f, 1f));
        heightAnimator.addUpdateListener(animation -> {

            params.height = (int) animation.getAnimatedValue();
            requestLayout();
        });
        heightAnimator.addListener(new AnimatorListenerAdapter() {
                        public void onAnimationEnd(Animator animation) {
                params.height = LayoutParams.WRAP_CONTENT;
                requestLayout();
                setLayerType(LAYER_TYPE_NONE, null);
                if (onComplete != null) onComplete.run();
                if (onStateChangedListener != null) onStateChangedListener.run();
            }
        });
        setAlpha(0f);

        setLayerType(LAYER_TYPE_HARDWARE, null);
        heightAnimator.start();
        animate().alpha(1f).setDuration(220).start();
    }

    public void collapse(Runnable onComplete) {
        if (!isOpen) {
            if (onComplete != null) onComplete.run();
            return;
        }
        isOpen = false;
        int currentHeight = getHeight();
        final ViewGroup.LayoutParams params = getLayoutParams();
        params.height = currentHeight;
        if (heightAnimator != null) heightAnimator.cancel();

        setLayerType(LAYER_TYPE_HARDWARE, null);
        animate().alpha(0f).setDuration(280).start();
        heightAnimator = ValueAnimator.ofInt(currentHeight, 0);
        heightAnimator.setDuration(220);
        heightAnimator.setInterpolator(new android.view.animation.PathInterpolator(0.22f, 1f, 0.32f, 1f));
        heightAnimator.addUpdateListener(animation -> {
            params.height = (int) animation.getAnimatedValue();
            requestLayout();
        });
        heightAnimator.addListener(new AnimatorListenerAdapter() {
                        public void onAnimationEnd(Animator animation) {
                setLayerType(LAYER_TYPE_NONE, null);
                setVisibility(View.GONE);
                if (onComplete != null) onComplete.run();
                if (onStateChangedListener != null) onStateChangedListener.run();
            }
        });
        heightAnimator.start();
    }

    public void forceCollapse() {
        if (heightAnimator != null) heightAnimator.cancel();
        isOpen = false;
        setVisibility(View.GONE);
        setAlpha(0f);
        getLayoutParams().height = 0;
    }

    public boolean isOpen() {
        return isOpen;
    }

    public void setOnStateChangedListener(Runnable listener) {
        onStateChangedListener = listener;
    }

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density);
    }

        public void onThemeColorChanged(int newColor) {
        updateThemeColors();
    }

    private void updateAllChildTextColors(ViewGroup viewGroup) {
        for (int i = 0; i < viewGroup.getChildCount(); i++) {
            View child = viewGroup.getChildAt(i);
            if (child instanceof TextView) {
                TextView tv = (TextView) child;
                if (tv.getParent() instanceof ModeChips) continue;

                if (themeButtons.contains(tv)) {
                    continue;
                }

                float textSize = tv.getTextSize() / getResources().getDisplayMetrics().scaledDensity;
                float baseSize = textSize / scaleFactor;

                if (baseSize <= 10f) {
                    tv.setTextColor(ThemeManager.getTextTertiary());
                } else {
                    tv.setTextColor(ThemeManager.getTextSecondary());
                }
            } else if (child instanceof ViewGroup) {
                updateAllChildTextColors((ViewGroup) child);
            }
        }
    }

        protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        ThemeManager.addListener(this);
        ThemeManager.addModeListener(this);
    }

        protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        ThemeManager.removeListener(this);
        ThemeManager.removeModeListener(this);
    }

        public void onThemeModeChanged(boolean isDark) {
        updateThemeColors();
    }

    private class ScalableWidget {
        View widget;
        TextView label;
        TextView valueText;
        TextView hintText;
        LayoutParams sliderParams;
        LayoutParams containerParams;
        LayoutParams switchParams;
        LayoutParams keybindParams;
        int baseSliderHeight;
        int baseContainerHeight;
        int baseSwitchWidth;
        int baseSwitchHeight;

        ScalableWidget(View widget, TextView label, TextView valueText, LayoutParams sliderParams, int baseSliderHeight) {
            this.widget = widget;
            this.label = label;
            this.valueText = valueText;
            this.sliderParams = sliderParams;
            this.baseSliderHeight = baseSliderHeight;
        }

        ScalableWidget(View widget, TextView label, LayoutParams containerParams, LayoutParams switchParams,
                      int baseContainerHeight, int baseSwitchWidth, int baseSwitchHeight) {
            this.widget = widget;
            this.label = label;
            this.containerParams = containerParams;
            this.switchParams = switchParams;
            this.baseContainerHeight = baseContainerHeight;
            this.baseSwitchWidth = baseSwitchWidth;
            this.baseSwitchHeight = baseSwitchHeight;
        }

        ScalableWidget(View widget, TextView label, TextView hintText, LayoutParams containerParams, LayoutParams keybindParams) {
            this.widget = widget;
            this.label = label;
            this.hintText = hintText;
            this.containerParams = containerParams;
            this.keybindParams = keybindParams;
            this.baseContainerHeight = 32;
        }

        void updateScale(float scale) {
            if (label != null) {
                label.setTextSize(11f * scale);
            }
            if (valueText != null) {
                valueText.setTextSize(11f * scale);
            }
            if (hintText != null) {
                hintText.setTextSize(9f * scale);
            }
            if (sliderParams != null) {
                sliderParams.height = scaled(baseSliderHeight);
                sliderParams.setMargins(0, scaled(2), 0, 0);
            }
            if (containerParams != null) {
                containerParams.height = scaled(baseContainerHeight);
                containerParams.setMargins(0, scaled(2), 0, scaled(2));
            }
            if (switchParams != null) {
                switchParams.width = scaled(baseSwitchWidth);
                switchParams.height = scaled(baseSwitchHeight);
            }
            if (keybindParams != null) {
                keybindParams.width = scaled(56);
                keybindParams.height = scaled(26);
            }
            if (widget instanceof CustomSlider) {
                ((CustomSlider) widget).updateScale(scale);
            } else if (widget instanceof CustomSwitch) {
                ((CustomSwitch) widget).updateScale(scale);
            } else if (widget instanceof ModeChips) {
                ((ModeChips) widget).updateScale(scale);
            } else if (widget instanceof KeybindButton) {
                ((KeybindButton) widget).updateScale(scale);
            }
        }
    }
}
