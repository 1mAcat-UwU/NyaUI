package com.nyaui.me.ui.widgets;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.nyaui.me.module.Module;
import com.nyaui.me.ui.ThemeManager;

import java.util.ArrayList;
import java.util.List;

public class SubMenuPanel extends LinearLayout implements ThemeManager.OnThemeColorChangeListener, ThemeManager.OnThemeModeChangeListener {
    private final Module module;
    private boolean isOpen = false;
    private ValueAnimator heightAnimator;
    private Runnable onStateChangedListener;

    private float scaleFactor = 1.0f;
    private final boolean classicStyle;

    private final List<ScalableWidget> scalableWidgets = new ArrayList<>();
    private final List<TextView> themeButtons = new ArrayList<>();
    private KeybindButton keybindButton;
    
    private final int[] themeColors = {
        0xFF96CCFF, 
        0xFF4CAF50, 
        0xFFBB86FC, 
        0xFFFF9800, 
        0xFFE91E63  
    };

    public SubMenuPanel(Context context, Module module, float scaleFactor) {
        this(context, module, scaleFactor, false);
    }

    public SubMenuPanel(Context context, Module module, float scaleFactor, boolean classicStyle) {
        super(context);
        this.module = module;
        this.scaleFactor = scaleFactor;
        this.classicStyle = classicStyle;

        setOrientation(VERTICAL);
        applyPanelStyle();
        updatePadding();
        setVisibility(View.GONE);
        setAlpha(0f);

        LayoutParams params = new LayoutParams(LayoutParams.MATCH_PARENT, 0);
        params.setMargins(scaled(6), scaled(2), scaled(6), 0);
        setLayoutParams(params);
    }

    private void applyPanelStyle() {
        if (!classicStyle) {
            setBackgroundColor(Color.TRANSPARENT);
            return;
        }
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(ThemeManager.getBgSecondary());
        bg.setStroke(scaled(1), ThemeManager.getStateDisabled());
        bg.setCornerRadius(scaled(2));
        setBackground(bg);
    }

    private void styleClassicRows() {
        if (!classicStyle) return;
        for (int i = 0; i < getChildCount(); i++) {
            View child = getChildAt(i);
            if (child instanceof LinearLayout) {
                GradientDrawable bg = new GradientDrawable();
                bg.setColor(ThemeManager.getBgPrimary());
                bg.setStroke(Math.max(1, scaled(1)), ThemeManager.getStateDisabled());
                bg.setCornerRadius(scaled(2));
                child.setBackground(bg);
                child.setPadding(scaled(4), 0, scaled(4), 0);
            }
        }
    }

    public void addThemeModeSwitch() {
        addSwitch("Dark Mode", ThemeManager.isDarkMode(), enabled -> {
            ThemeManager.setDarkMode(enabled);
        });
    }

    public SubMenuPanel(Context context, Module module) {
        this(context, module, 1.0f);
    }

    public void updateScale(float scaleFactor) {
        this.scaleFactor = scaleFactor;
        updatePadding();
        LayoutParams params = (LayoutParams) getLayoutParams();
        params.setMargins(scaled(6), scaled(2), scaled(6), 0);
        setLayoutParams(params);
        for (int i = 0; i < getChildCount(); i++) {
            View child = getChildAt(i);
            updateChildScale(child);
        }
        for (ScalableWidget widget : scalableWidgets) {
            widget.updateScale(scaleFactor);
        }
        
        
        if (keybindButton != null) {
            keybindButton.updateScale(scaleFactor);
        }
        
        requestLayout();
    }

    private void updatePadding() {
        int padding = scaled(4);
        setPadding(padding, 0, padding, scaled(4));
    }

    private void updateChildScale(View view) {
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            ViewGroup.LayoutParams lp = group.getLayoutParams();
            if (lp instanceof MarginLayoutParams) {
                MarginLayoutParams mlp = (MarginLayoutParams) lp;
                mlp.topMargin = scaled(2);
                mlp.bottomMargin = scaled(2);
            }
            for (int i = 0; i < group.getChildCount(); i++) {
                updateChildScale(group.getChildAt(i));
            }
        } else if (view instanceof TextView) {
            TextView tv = (TextView) view;
            float baseSize = 11f;
            if (tv.getCurrentTextColor() == ThemeManager.getTextTertiary()) {
                baseSize = 10f;
            }
            tv.setTextSize(baseSize * scaleFactor);
        }
    }

    private int scaled(int baseDp) {
        return (int) (dpToPx(baseDp) * scaleFactor);
    }

    public void addSlider(String label, int min, int max, int defaultValue, String format,
                         CustomSlider.OnValueChangeListener onValueChanged) {
        LinearLayout container = new LinearLayout(getContext());
        container.setOrientation(VERTICAL);
        LayoutParams containerParams = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        containerParams.setMargins(0, scaled(2), 0, scaled(2));
        container.setLayoutParams(containerParams);

        LinearLayout labelRow = new LinearLayout(getContext());
        labelRow.setOrientation(HORIZONTAL);

        TextView labelText = new TextView(getContext());
        labelText.setText(label);
        labelText.setTextSize(11f * scaleFactor);
        labelText.setTextColor(ThemeManager.getTextSecondary());
        LayoutParams labelParams = new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f);
        labelText.setLayoutParams(labelParams);
        labelRow.addView(labelText);

        TextView valueText = new TextView(getContext());
        valueText.setTextSize(11f * scaleFactor);
        valueText.setTextColor(ThemeManager.getTextSecondary());
        labelRow.addView(valueText);

        container.addView(labelRow);

        CustomSlider slider = new CustomSlider(getContext(), module.getName(), label.toLowerCase(),
                min, max, defaultValue, value -> {
            if ("%.2f".equals(format)) {
                valueText.setText(String.format("%.2f", value / 100.0));
            } else {
                valueText.setText(String.valueOf(value));
            }
            onValueChanged.onValueChanged(value);
        });

        slider.updateScale(scaleFactor);
        LayoutParams sliderParams = new LayoutParams(LayoutParams.MATCH_PARENT, scaled(20));
        sliderParams.setMargins(0, scaled(2), 0, 0);
        container.addView(slider, sliderParams);
        scalableWidgets.add(new ScalableWidget(slider, labelText, valueText, sliderParams, 20));
        if ("%.2f".equals(format)) {
            valueText.setText(String.format("%.2f", defaultValue / 100.0));
        } else {
            valueText.setText(String.valueOf(defaultValue));
        }
        addView(container);
    }

    public void addShortcutSwitch(boolean defaultValue) {
        LinearLayout container = new LinearLayout(getContext());
        container.setOrientation(HORIZONTAL);
        container.setGravity(Gravity.CENTER_VERTICAL);
        LayoutParams containerParams = new LayoutParams(LayoutParams.MATCH_PARENT, scaled(28));
        containerParams.setMargins(0, scaled(2), 0, scaled(2));
        container.setLayoutParams(containerParams);

        TextView labelText = new TextView(getContext());
        labelText.setText("Shortcut");
        labelText.setTextSize(11f * scaleFactor);
        labelText.setTextColor(ThemeManager.getTextSecondary());
        LayoutParams labelParams = new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f);
        labelText.setLayoutParams(labelParams);
        container.addView(labelText);

        CustomSwitch switchView = new CustomSwitch(getContext(), module.getName(), "shortcut",
                defaultValue, enabled -> {
            module.toggleShortcut(enabled);
        });

        switchView.updateScale(scaleFactor);
        LayoutParams switchParams = new LayoutParams(scaled(32), scaled(18));
        container.addView(switchView, switchParams);
        scalableWidgets.add(new ScalableWidget(switchView, labelText, containerParams, switchParams, 28, 32, 18));
        addView(container);
    }

    

    public void addKeybindSetting() {
        
        LinearLayout container = new LinearLayout(getContext());
        container.setOrientation(HORIZONTAL);
        container.setGravity(Gravity.CENTER_VERTICAL);
        LayoutParams containerParams = new LayoutParams(LayoutParams.MATCH_PARENT, scaled(32));
        containerParams.setMargins(0, scaled(2), 0, scaled(2));
        container.setLayoutParams(containerParams);

        
        LinearLayout labelArea = new LinearLayout(getContext());
        labelArea.setOrientation(VERTICAL);
        LayoutParams labelAreaParams = new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f);
        labelArea.setLayoutParams(labelAreaParams);
        labelArea.setGravity(Gravity.CENTER_VERTICAL);

        
        TextView labelText = new TextView(getContext());
        boolean isChinese = com.nyaui.me.config.ConfigManager.isChinese();
        labelText.setText(isChinese ? "Keybind" : "Keybind");
        labelText.setTextSize(11f * scaleFactor);
        labelText.setTextColor(ThemeManager.getTextSecondary());
        labelArea.addView(labelText);

        
        TextView hintText = new TextView(getContext());
        hintText.setText(isChinese ? "Tap to set key" : "Tap to set key");
        hintText.setTextSize(9f * scaleFactor);
        hintText.setTextColor(ThemeManager.getTextTertiary());
        LayoutParams hintParams = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        hintParams.setMargins(0, scaled(1), 0, 0);
        hintText.setLayoutParams(hintParams);
        labelArea.addView(hintText);

        container.addView(labelArea);

        
        keybindButton = new KeybindButton(getContext(), module, scaleFactor);
        LayoutParams keybindParams = new LayoutParams(LayoutParams.WRAP_CONTENT, scaled(26));
        keybindParams.setMargins(scaled(4), 0, 0, 0);
        keybindButton.setLayoutParams(keybindParams);
        container.addView(keybindButton);

        
        scalableWidgets.add(new ScalableWidget(keybindButton, labelText, hintText, containerParams, keybindParams));

        addView(container);
    }

    

    public void addKeybindSetting(String label, String hint) {
        LinearLayout container = new LinearLayout(getContext());
        container.setOrientation(HORIZONTAL);
        container.setGravity(Gravity.CENTER_VERTICAL);
        LayoutParams containerParams = new LayoutParams(LayoutParams.MATCH_PARENT, scaled(32));
        containerParams.setMargins(0, scaled(2), 0, scaled(2));
        container.setLayoutParams(containerParams);

        
        LinearLayout labelArea = new LinearLayout(getContext());
        labelArea.setOrientation(VERTICAL);
        LayoutParams labelAreaParams = new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f);
        labelArea.setLayoutParams(labelAreaParams);
        labelArea.setGravity(Gravity.CENTER_VERTICAL);

        
        TextView labelText = new TextView(getContext());
        labelText.setText(label);
        labelText.setTextSize(11f * scaleFactor);
        labelText.setTextColor(ThemeManager.getTextSecondary());
        labelArea.addView(labelText);

        
        if (hint != null && !hint.isEmpty()) {
            TextView hintText = new TextView(getContext());
            hintText.setText(hint);
            hintText.setTextSize(9f * scaleFactor);
            hintText.setTextColor(ThemeManager.getTextTertiary());
            LayoutParams hintParams = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
            hintParams.setMargins(0, scaled(1), 0, 0);
            hintText.setLayoutParams(hintParams);
            labelArea.addView(hintText);
        }

        container.addView(labelArea);

        
        keybindButton = new KeybindButton(getContext(), module, scaleFactor);
        LayoutParams keybindParams = new LayoutParams(LayoutParams.WRAP_CONTENT, scaled(26));
        keybindParams.setMargins(scaled(4), 0, 0, 0);
        keybindButton.setLayoutParams(keybindParams);
        container.addView(keybindButton);

        addView(container);
    }

    public void addSwitch(String label, boolean defaultValue, CustomSwitch.OnCheckedChangeListener onStateChanged) {
        LinearLayout container = new LinearLayout(getContext());
        container.setOrientation(HORIZONTAL);
        container.setGravity(Gravity.CENTER_VERTICAL);
        LayoutParams containerParams = new LayoutParams(LayoutParams.MATCH_PARENT, scaled(28));
        containerParams.setMargins(0, scaled(2), 0, scaled(2));
        container.setLayoutParams(containerParams);

        TextView labelText = new TextView(getContext());
        labelText.setText(label);
        labelText.setTextSize(11f * scaleFactor);
        labelText.setTextColor(ThemeManager.getTextSecondary());
        LayoutParams labelParams = new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f);
        labelText.setLayoutParams(labelParams);
        container.addView(labelText);

        CustomSwitch switchView = new CustomSwitch(getContext(), module.getName(), label.toLowerCase(),
                defaultValue, onStateChanged);

        switchView.updateScale(scaleFactor);
        LayoutParams switchParams = new LayoutParams(scaled(32), scaled(18));
        container.addView(switchView, switchParams);
        scalableWidgets.add(new ScalableWidget(switchView, labelText, containerParams, switchParams, 28, 32, 18));
        addView(container);
    }

    public void addMode(String label, List<String> modes, int defaultMode, ModeChips.OnModeChangedListener onModeChanged) {
        LinearLayout container = new LinearLayout(getContext());
        container.setOrientation(VERTICAL);
        LayoutParams containerParams = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        containerParams.setMargins(0, scaled(2), 0, scaled(2));
        container.setLayoutParams(containerParams);

        TextView labelText = new TextView(getContext());
        labelText.setText(label);
        labelText.setTextSize(11f * scaleFactor);
        labelText.setTextColor(ThemeManager.getTextSecondary());
        LayoutParams labelParams = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        labelParams.setMargins(0, 0, 0, scaled(2));
        labelText.setLayoutParams(labelParams);
        container.addView(labelText);

        HorizontalScrollView scrollView = new HorizontalScrollView(getContext());
        scrollView.setHorizontalScrollBarEnabled(false);
        scrollView.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        scrollView.setOverScrollMode(View.OVER_SCROLL_NEVER);

        ModeChips chips = new ModeChips(getContext(), module.getName(), label.toLowerCase(),
                modes, defaultMode, onModeChanged);

        chips.updateScale(scaleFactor);
        scrollView.addView(chips);
        container.addView(scrollView);
        scalableWidgets.add(new ScalableWidget(chips, labelText, null, null, 0));
        addView(container);
    }

    public void addText(String text) {
        TextView textView = new TextView(getContext());
        textView.setText(text);
        textView.setTextSize(10f * scaleFactor);
        textView.setTextColor(ThemeManager.getTextTertiary());
        LayoutParams params = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        params.setMargins(0, scaled(2), 0, scaled(2));
        textView.setLayoutParams(params);
        addView(textView);
    }

    

    public void addDivider() {
        View divider = new View(getContext());
        divider.setBackgroundColor(ThemeManager.getStateDisabled());
        LayoutParams params = new LayoutParams(LayoutParams.MATCH_PARENT, scaled(1));
        params.setMargins(0, scaled(6), 0, scaled(6));
        divider.setLayoutParams(params);
        addView(divider);
    }

    

    public void addSectionTitle(String title) {
        TextView titleView = new TextView(getContext());
        titleView.setText(title);
        titleView.setTextSize(10f * scaleFactor);
        titleView.setTextColor(ThemeManager.getThemeColor());
        titleView.setAllCaps(true);
        LayoutParams params = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        params.setMargins(0, scaled(8), 0, scaled(4));
        titleView.setLayoutParams(params);
        addView(titleView);
    }

    public void addCustomView(View view) {
        if (view.getLayoutParams() == null) {
            LayoutParams params = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
            params.setMargins(0, scaled(4), 0, scaled(4));
            view.setLayoutParams(params);
        }
        addView(view);
    }

    public void addThemeButtons() {
        themeButtons.clear(); 
        LinearLayout container = new LinearLayout(getContext());
        container.setOrientation(HORIZONTAL);

        String[] themeNames = {"Default", "Green", "Purple", "Orange", "Pink"};
        Runnable[] themeActions = {
            ThemeManager::applyDefaultTheme,
            ThemeManager::applyGreenTheme,
            ThemeManager::applyPurpleTheme,
            ThemeManager::applyOrangeTheme,
            ThemeManager::applyPinkTheme
        };

        for(int i = 0; i < themeNames.length; i++) {
            TextView button = new TextView(getContext());
            button.setText(themeNames[i]);
            button.setTextSize(10f * scaleFactor);
            button.setGravity(Gravity.CENTER);
            int paddingH = scaled(8);
            int paddingV = scaled(5);
            button.setPadding(paddingH, paddingV, paddingH, paddingV);

            button.setBackground(new GradientDrawable());

            final Runnable action = themeActions[i];
            button.setOnClickListener(v -> action.run());

            LayoutParams params = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
            if (i > 0) {
                params.leftMargin = scaled(4);
            }
            container.addView(button, params);
            themeButtons.add(button);
        }

        HorizontalScrollView scrollView = new HorizontalScrollView(getContext());
        scrollView.setHorizontalScrollBarEnabled(false);
        scrollView.addView(container);
        addCustomView(scrollView);

        updateThemeButtonStyles();
    }

    private void updateThemeButtonStyles() {
        int currentThemeColor = ThemeManager.getThemeColor();
        for (int i = 0; i < themeButtons.size(); i++) {
            TextView button = themeButtons.get(i);
            if (button.getBackground() instanceof GradientDrawable) {
                GradientDrawable bg = (GradientDrawable) button.getBackground();

                boolean isSelected = currentThemeColor == themeColors[i];

                if (isSelected) {
                    bg.setColor(ThemeManager.getThemeColor());
                    button.setTextColor(ThemeManager.getTextOnTheme());
                } else {
                    bg.setColor(ThemeManager.getBgDisabled());
                    button.setTextColor(ThemeManager.getTextPrimary());
                }
                bg.setCornerRadius(scaled(6));
            }
        }
    }

    

    public void updateThemeColors() {
        applyPanelStyle();
        updateThemeButtonStyles();
        styleClassicRows();
        updateAllChildTextColors(this);
        
        for (ScalableWidget widget : scalableWidgets) {
            if (widget.widget != null) {
                widget.widget.invalidate();
            }
            if (widget.label != null) {
                widget.label.setTextColor(ThemeManager.getTextSecondary());
            }
            if (widget.valueText != null) {
                widget.valueText.setTextColor(ThemeManager.getTextSecondary());
            }
            if (widget.hintText != null) {
                widget.hintText.setTextColor(ThemeManager.getTextTertiary());
            }
        }
        
        if (keybindButton != null) {
            keybindButton.invalidate();
        }
        
        invalidate();
    }

        public void onViewAdded(View child) {
        super.onViewAdded(child);
        applyClassicStyleRecursive(child);
    }

    private void applyClassicStyleRecursive(View view) {
        if (classicStyle && view instanceof LinearLayout && view != this) {
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(ThemeManager.getBgPrimary());
            bg.setStroke(Math.max(1, scaled(1)), ThemeManager.getStateDisabled());
            bg.setCornerRadius(scaled(2));
            view.setBackground(bg);
            view.setPadding(scaled(4), 0, scaled(4), 0);
        }
        if (view instanceof CustomSwitch) ((CustomSwitch) view).setClassicStyle(classicStyle);
        if (view instanceof CustomSlider) ((CustomSlider) view).setClassicStyle(classicStyle);
        if (view instanceof ModeChips) ((ModeChips) view).setClassicStyle(classicStyle);
        if (view instanceof KeybindButton) ((KeybindButton) view).setClassicStyle(classicStyle);
        if (view instanceof ColorPickerView) ((ColorPickerView) view).setClassicStyle(classicStyle);
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) applyClassicStyleRecursive(group.getChildAt(i));
        }
    }

    public void toggle() {
        toggle(null);
    }

    public void toggle(Runnable onComplete) {
        if (isOpen) {
            collapse(onComplete);
        } else {
            expand(onComplete);
        }
    }

    private void expand(Runnable onComplete) {
        isOpen = true;
        setVisibility(View.VISIBLE);
        measure(
            MeasureSpec.makeMeasureSpec(((ViewGroup)getParent()).getWidth(), MeasureSpec.EXACTLY),
            MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED)
        );
        int targetHeight = getMeasuredHeight();
        if (heightAnimator != null) heightAnimator.cancel();
        final ViewGroup.LayoutParams params = getLayoutParams();
        params.height = 0;
        heightAnimator = ValueAnimator.ofInt(0, targetHeight);
        heightAnimator.setDuration(280);
        heightAnimator.setInterpolator(new android.view.animation.PathInterpolator(0.22f, 1f, 0.32f, 1f));
        heightAnimator.addUpdateListener(animation -> {
            
            
            params.height = (int) animation.getAnimatedValue();
            requestLayout();
        });
        heightAnimator.addListener(new AnimatorListenerAdapter() {
                        public void onAnimationEnd(Animator animation) {
                params.height = LayoutParams.WRAP_CONTENT;
                requestLayout();
                setLayerType(LAYER_TYPE_NONE, null);
                if (onComplete != null) onComplete.run();
                if (onStateChangedListener != null) onStateChangedListener.run();
            }
        });
        setAlpha(0f);
        
        setLayerType(LAYER_TYPE_HARDWARE, null);
        heightAnimator.start();
        animate().alpha(1f).setDuration(280).start();
    }

    public void collapse(Runnable onComplete) {
        if (!isOpen) {
            if (onComplete != null) onComplete.run();
            return;
        }
        isOpen = false;
        int currentHeight = getHeight();
        final ViewGroup.LayoutParams params = getLayoutParams();
        params.height = currentHeight;
        if (heightAnimator != null) heightAnimator.cancel();
        
        setLayerType(LAYER_TYPE_HARDWARE, null);
        animate().alpha(0f).setDuration(280).start();
        heightAnimator = ValueAnimator.ofInt(currentHeight, 0);
        heightAnimator.setDuration(280);
        heightAnimator.setInterpolator(new android.view.animation.PathInterpolator(0.22f, 1f, 0.32f, 1f));
        heightAnimator.addUpdateListener(animation -> {
            params.height = (int) animation.getAnimatedValue();
            requestLayout();
        });
        heightAnimator.addListener(new AnimatorListenerAdapter() {
                        public void onAnimationEnd(Animator animation) {
                setLayerType(LAYER_TYPE_NONE, null);
                setVisibility(View.GONE);
                if (onComplete != null) onComplete.run();
                if (onStateChangedListener != null) onStateChangedListener.run();
            }
        });
        heightAnimator.start();
    }

    public void forceCollapse() {
        if (heightAnimator != null) heightAnimator.cancel();
        isOpen = false;
        setVisibility(View.GONE);
        setAlpha(0f);
        getLayoutParams().height = 0;
    }

    public boolean isOpen() {
        return isOpen;
    }

    public void setOnStateChangedListener(Runnable listener) {
        onStateChangedListener = listener;
    }

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density);
    }
    
        public void onThemeColorChanged(int newColor) {
        updateThemeColors();
    }

    private void updateAllChildTextColors(ViewGroup viewGroup) {
        for (int i = 0; i < viewGroup.getChildCount(); i++) {
            View child = viewGroup.getChildAt(i);
            if (child instanceof TextView) {
                TextView tv = (TextView) child;
                if (tv.getParent() instanceof ModeChips) continue;
                
                if (themeButtons.contains(tv)) {
                    continue;
                }
                
                float textSize = tv.getTextSize() / getResources().getDisplayMetrics().scaledDensity;
                float baseSize = textSize / scaleFactor;
                
                if (baseSize <= 10f) {
                    tv.setTextColor(ThemeManager.getTextTertiary());
                } else {
                    tv.setTextColor(ThemeManager.getTextSecondary());
                }
            } else if (child instanceof ViewGroup) {
                updateAllChildTextColors((ViewGroup) child);
            }
        }
    }
    
        protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        ThemeManager.addListener(this);
        ThemeManager.addModeListener(this);
    }

        protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        ThemeManager.removeListener(this);
        ThemeManager.removeModeListener(this);
    }

        public void onThemeModeChanged(boolean isDark) {
        updateThemeColors();
    }

    private class ScalableWidget {
        View widget;
        TextView label;
        TextView valueText;
        TextView hintText;
        LayoutParams sliderParams;
        LayoutParams containerParams;
        LayoutParams switchParams;
        LayoutParams keybindParams;
        int baseSliderHeight;
        int baseContainerHeight;
        int baseSwitchWidth;
        int baseSwitchHeight;

        
        ScalableWidget(View widget, TextView label, TextView valueText, LayoutParams sliderParams, int baseSliderHeight) {
            this.widget = widget;
            this.label = label;
            this.valueText = valueText;
            this.sliderParams = sliderParams;
            this.baseSliderHeight = baseSliderHeight;
        }

        
        ScalableWidget(View widget, TextView label, LayoutParams containerParams, LayoutParams switchParams,
                      int baseContainerHeight, int baseSwitchWidth, int baseSwitchHeight) {
            this.widget = widget;
            this.label = label;
            this.containerParams = containerParams;
            this.switchParams = switchParams;
            this.baseContainerHeight = baseContainerHeight;
            this.baseSwitchWidth = baseSwitchWidth;
            this.baseSwitchHeight = baseSwitchHeight;
        }

        
        ScalableWidget(View widget, TextView label, TextView hintText, LayoutParams containerParams, LayoutParams keybindParams) {
            this.widget = widget;
            this.label = label;
            this.hintText = hintText;
            this.containerParams = containerParams;
            this.keybindParams = keybindParams;
            this.baseContainerHeight = 32;
        }

        void updateScale(float scale) {
            if (label != null) {
                label.setTextSize(11f * scale);
            }
            if (valueText != null) {
                valueText.setTextSize(11f * scale);
            }
            if (hintText != null) {
                hintText.setTextSize(9f * scale);
            }
            if (sliderParams != null) {
                sliderParams.height = scaled(baseSliderHeight);
                sliderParams.setMargins(0, scaled(2), 0, 0);
            }
            if (containerParams != null) {
                containerParams.height = scaled(baseContainerHeight);
                containerParams.setMargins(0, scaled(2), 0, scaled(2));
            }
            if (switchParams != null) {
                switchParams.width = scaled(baseSwitchWidth);
                switchParams.height = scaled(baseSwitchHeight);
            }
            if (keybindParams != null) {
                keybindParams.width = scaled(56);
                keybindParams.height = scaled(26);
            }
            if (widget instanceof CustomSlider) {
                ((CustomSlider) widget).updateScale(scale);
            } else if (widget instanceof CustomSwitch) {
                ((CustomSwitch) widget).updateScale(scale);
            } else if (widget instanceof ModeChips) {
                ((ModeChips) widget).updateScale(scale);
            } else if (widget instanceof KeybindButton) {
                ((KeybindButton) widget).updateScale(scale);
            }
        }
    }
}