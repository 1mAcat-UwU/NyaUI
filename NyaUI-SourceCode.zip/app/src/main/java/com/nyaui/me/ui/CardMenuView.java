package com.nyaui.me.ui;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.animation.PathInterpolator;
import android.os.Build;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import com.nyaui.me.ui.widgets.ContentScrollBar;
import android.widget.ImageView;
import android.widget.TextView;
import android.view.WindowManager;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.ModuleManager;
import com.nyaui.me.config.ConfigManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.nyaui.me.ui.SquircleDrawable;
import com.nyaui.me.ui.SquircleClipLayout;

public class CardMenuView extends FrameLayout implements ThemeManager.OnThemeColorChangeListener, ThemeManager.OnThemeModeChangeListener {

    private final Context context;
    private float scaleFactor = 0.95f;
    private FrameLayout categoryWrap;
    private View categoryIndicator;
    private LinearLayout categorySider;
    private static final PathInterpolator IND_EASE = new PathInterpolator(0.2f, 0f, 0f, 1f);
    private int panelW = 0;
    private int panelH = 0;
    private SquircleClipLayout panelCard;
    private ValueAnimator panelResizeAnim;
    private static final String KEY_PANEL_W = "panel_w";
    private static final String KEY_PANEL_H = "panel_h";
    private static final String KEY_SCALE = "ui_scale_factor";
    private LinearLayout topBar;
    private LinearLayout sidebar;
    private ScrollView contentScrollView;
    private LinearLayout contentArea;
    private ContentScrollBar contentScrollBar;
    private LinearLayout brandSection;
    private TextView brandText;
    private TextView categoryTitle;
    private View verticalDivider;
    private View horizontalDivider;
    private View bottomDivider;
    private LinearLayout mainContainer;
    private AnimatedBgDrawable panelBg;
    private LinearLayout contentContainer;
    private Runnable onHideCompleteListener;
    private static final String TAG = "CardMenuView";
    private static final String PREFS_NAME = "CardMenuPrefs";
    private static final String KEY_SELECTED_CATEGORY = "selected_category";
    private final Map<ModuleCategory, View> categoryItems = new HashMap<>();
    private final Map<Module, ModuleCardView> moduleCards = new HashMap<>();

    private final Map<ModuleCategory, List<ModuleCardView>> categoryCardCache = new HashMap<>();

    private ModuleCategory selectedCategory = ModuleCategory.COMBAT;
    private static final int ANIMATION_DURATION = 300;

    private ImageView profileAvatar;
    private TextView username;
    private TextView userId;

    public CardMenuView(Context context) {
        super(context);
        this.context = context;

        SharedPreferences sp = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        float configuredScale = ConfigManager.getUiScale();
        if (configuredScale == 0.95f && sp.contains(KEY_SCALE)) configuredScale = sp.getFloat(KEY_SCALE, 0.95f);
        scaleFactor = Math.max(0.5f, Math.min(1.2f, configuredScale));
        panelW = sp.getInt(KEY_PANEL_W, 0);
        panelH = sp.getInt(KEY_PANEL_H, 0);

        setLayoutParams(new LayoutParams(
            LayoutParams.MATCH_PARENT,
            LayoutParams.MATCH_PARENT
        ));

        setAlpha(0f);
        setScaleX(0.94f);
        setScaleY(0.94f);

        createLayout();
        ThemeManager.addListener(this);
        ThemeManager.addModeListener(this);
    }

    private void rebuildLayout() {

        if (panelResizeAnim != null && panelResizeAnim.isRunning()) {
            panelResizeAnim.cancel();
            panelResizeAnim = null;
        }
        removeAllViews();
        moduleCards.clear();
        categoryCardCache.clear();
        categoryItems.clear();
        createLayout();
        updateAllColors();
    }

    private int screenW() {
        DisplayMetrics m = new DisplayMetrics();
        ((WindowManager) context.getSystemService(Context.WINDOW_SERVICE))
                .getDefaultDisplay().getRealMetrics(m);
        return m.widthPixels;
    }

    private int screenH() {
        DisplayMetrics m = new DisplayMetrics();
        ((WindowManager) context.getSystemService(Context.WINDOW_SERVICE))
                .getDefaultDisplay().getRealMetrics(m);
        return m.heightPixels;
    }

    private int defaultPanelW() {
        return clampW((int) (screenW() * 0.7f * scaleFactor));
    }

    private int defaultPanelH() {
        return clampH((int) (screenH() * 0.75f * scaleFactor));
    }

    private int clampW(int w) { return Math.max(scaled(260), Math.min(screenW(), w)); }
    private int clampH(int h) { return Math.max(scaled(220), Math.min(screenH(), h)); }

    public void resetPanelSize(boolean animate) {

        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
                .remove(KEY_PANEL_W).remove(KEY_PANEL_H).apply();

        if (panelCard == null) return;

        final int toW = defaultPanelW();
        final int toH = defaultPanelH();
        final int fromW = panelCard.getWidth() > 0 ? panelCard.getWidth() : panelW;
        final int fromH = panelCard.getHeight() > 0 ? panelCard.getHeight() : panelH;

        if (panelResizeAnim != null && panelResizeAnim.isRunning()) panelResizeAnim.cancel();

        if (!animate || (fromW == toW && fromH == toH)) {
            applyPanelSize(toW, toH);
            return;
        }

        panelResizeAnim = ValueAnimator.ofFloat(0f, 1f);
        panelResizeAnim.setDuration(360);
        panelResizeAnim.setInterpolator(SPRING);
        panelResizeAnim.addUpdateListener(a -> {
            float t = (float) a.getAnimatedValue();
            applyPanelSize(
                (int) (fromW + (toW - fromW) * t),
                (int) (fromH + (toH - fromH) * t));
        });
        panelResizeAnim.start();
    }

    private void applyPanelSize(int w, int h) {
        if (panelCard == null) return;
        panelW = w;
        panelH = h;
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) panelCard.getLayoutParams();
        if (lp == null) return;
        lp.width = w;
        lp.height = h;
        panelCard.setLayoutParams(lp);
    }

    public void applyScale(float newScale) {
        newScale = Math.max(0.5f, Math.min(1.2f, newScale));
        if (Math.abs(newScale - scaleFactor) < 0.001f) return;

        final float target = newScale;
        final SquircleClipLayout oldPanel = panelCard;

        final Runnable rebuild = () -> {
            if (!isAttachedToWindow()) return;
            scaleFactor = target;
            ConfigManager.setUiScale(target);

            boolean hasSaved = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                    .contains(KEY_PANEL_W);
            if (!hasSaved) { panelW = 0; panelH = 0; }

            rebuildLayout();

            if (panelCard != null) {
                panelCard.setAlpha(0f);
                panelCard.setScaleX(0.97f);
                panelCard.setScaleY(0.97f);
                panelCard.animate().alpha(1f).scaleX(1f).scaleY(1f)
                        .setDuration(260).setInterpolator(SPRING).start();
            }
        };

        if (oldPanel != null && oldPanel.isAttachedToWindow()) {
            oldPanel.animate().alpha(0f).scaleX(0.97f).scaleY(0.97f)
                    .setDuration(140)
                    .setInterpolator(new PathInterpolator(0.4f, 0f, 1f, 1f))
                    .withEndAction(() -> post(rebuild)).start();
        } else {
            post(rebuild);
        }
    }

    public void resetAll() {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
                .remove(KEY_PANEL_W).remove(KEY_PANEL_H).apply();
        if (Math.abs(scaleFactor - 0.95f) < 0.001f) {
            resetPanelSize(true);
        } else {
            applyScale(0.95f);
        }
    }

    public float getScaleFactor() { return scaleFactor; }
    public int getPanelWidth() { return panelCard != null && panelCard.getWidth() > 0 ? panelCard.getWidth() : panelW; }
    public int getPanelHeight() { return panelCard != null && panelCard.getHeight() > 0 ? panelCard.getHeight() : panelH; }

    private void createLayout() {

        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics metrics = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(metrics);
        final int screenWidth = metrics.widthPixels;
        final int screenHeight = metrics.heightPixels;

        if (panelW <= 0) panelW = defaultPanelW();
        if (panelH <= 0) panelH = defaultPanelH();
        panelW = clampW(panelW);
        panelH = clampH(panelH);

        panelCard = new SquircleClipLayout(context);
        SquircleClipLayout clipContainer = panelCard;
        FrameLayout.LayoutParams clipParams = new FrameLayout.LayoutParams(panelW, panelH);
        clipParams.gravity = Gravity.CENTER;
        clipContainer.setLayoutParams(clipParams);
        clipContainer.setCornerRadius(scaled(22));
        clipContainer.setSmoothing(1.0f);
        clipContainer.setElevation(0);
        clipContainer.setClickable(true);

        mainContainer = new LinearLayout(context);
        mainContainer.setOrientation(LinearLayout.HORIZONTAL);
        mainContainer.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        AnimatedBgDrawable containerBg = UiBackground.create(scaled(28));
        containerBg.setCorner(scaled(22));
        panelBg = containerBg;
        mainContainer.setBackground(panelBg);

        sidebar = createSidebar();
        mainContainer.addView(sidebar);

        verticalDivider = new View(context);
        verticalDivider.setLayoutParams(new LinearLayout.LayoutParams(scaled(1), LayoutParams.MATCH_PARENT));
        updateVerticalDividerColor();
        mainContainer.addView(verticalDivider);

        contentContainer = createContentArea();
        mainContainer.addView(contentContainer);

        clipContainer.addView(mainContainer);

        View grip = new View(context) {
            private final android.graphics.Paint p =
                new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
            protected void onDraw(android.graphics.Canvas cv) {
                p.setColor(ThemeManager.getTextSecondary());
                float u = getWidth() / 5f;
                for (int i = 0; i < 3; i++)
                    for (int j = 0; j < 3 - i; j++)
                        cv.drawCircle(getWidth() - u*(j+1), getHeight() - u*(i+1), u*0.3f, p);
            }
        };
        FrameLayout.LayoutParams gripLp = new FrameLayout.LayoutParams(scaled(22), scaled(22));
        gripLp.gravity = Gravity.BOTTOM | Gravity.END;
        gripLp.bottomMargin = scaled(3);
        gripLp.rightMargin = scaled(3);
        grip.setLayoutParams(gripLp);
        final SquircleClipLayout fClip = clipContainer;
        grip.setOnTouchListener(new OnTouchListener() {
            float dx, dy; int sw0, sh0; boolean moved; long lastTap;
            public boolean onTouch(View v, android.view.MotionEvent e) {
                switch (e.getActionMasked()) {
                    case android.view.MotionEvent.ACTION_DOWN:
                        dx = e.getRawX(); dy = e.getRawY();
                        sw0 = fClip.getWidth(); sh0 = fClip.getHeight();
                        moved = false;
                        return true;
                    case android.view.MotionEvent.ACTION_MOVE:
                        if (Math.abs(e.getRawX()-dx) > scaled(4) || Math.abs(e.getRawY()-dy) > scaled(4)) moved = true;
                        int nw = (int)(sw0 + (e.getRawX()-dx)*2f);
                        int nh = (int)(sh0 + (e.getRawY()-dy));
                        nw = Math.max(scaled(260), Math.min(screenWidth, nw));
                        nh = Math.max(scaled(220), Math.min(screenHeight, nh));
                        panelW = nw; panelH = nh;
                        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) fClip.getLayoutParams();
                        lp.width = nw; lp.height = nh;
                        fClip.setLayoutParams(lp);
                        return true;
                    case android.view.MotionEvent.ACTION_UP:
                    case android.view.MotionEvent.ACTION_CANCEL:
                        if (moved) {
                            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
                                .putInt(KEY_PANEL_W, panelW).putInt(KEY_PANEL_H, panelH).apply();
                        } else {
                            long now = System.currentTimeMillis();
                            if (now - lastTap < 320) {
                                resetPanelSize(true);
                                lastTap = 0;
                            } else lastTap = now;
                        }
                        return true;
                }
                return false;
            }
        });
        clipContainer.addView(grip);

        addView(clipContainer);

        loadSelectedCategory();
    }

    private LinearLayout createTopBar() {
        LinearLayout bar = new LinearLayout(context);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dpToPx(56)
        ));
        bar.setBackgroundColor(ThemeManager.getThemeColor());
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dpToPx(16), 0, dpToPx(16), 0);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {

        }

        TextView brandName = new TextView(context);
        brandName.setText("NyaUI");
        brandName.setTextColor(ThemeManager.getTextOnTheme());
        brandName.setTextSize(20);
        brandName.setTypeface(Typeface.DEFAULT_BOLD);
        bar.addView(brandName);

        return bar;
    }

    private LinearLayout createSidebar() {
        LinearLayout sidebar = new LinearLayout(context);
        sidebar.setOrientation(LinearLayout.VERTICAL);
        sidebar.setLayoutParams(new LinearLayout.LayoutParams(
            scaled(220),
            LinearLayout.LayoutParams.MATCH_PARENT
        ));
        sidebar.setBackgroundColor(ThemeManager.getMenuBackground());

        brandSection = new LinearLayout(context);
        brandSection.setOrientation(LinearLayout.HORIZONTAL);
        brandSection.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        brandSection.setGravity(Gravity.CENTER_VERTICAL);
        brandSection.setPadding(scaled(12), scaled(12), scaled(12), scaled(12));

        brandText = new TextView(context);
        brandText.setText("NyaUI");
        brandText.setTextColor(ThemeManager.getTextPrimary());
        brandText.setTextSize(scaledFontSize(18));
        brandText.setTypeface(Typeface.DEFAULT_BOLD);

        brandSection.addView(brandText);
        sidebar.addView(brandSection);

        horizontalDivider = new View(context);
        horizontalDivider.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            scaled(1)
        ));
        updateHorizontalDividerColor();
        sidebar.addView(horizontalDivider);

        ScrollView categoryScrollView = new ScrollView(context);
        categoryScrollView.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            0,
            1f
        ));
        categoryScrollView.setVerticalScrollBarEnabled(false);
        categoryScrollView.setOverScrollMode(View.OVER_SCROLL_NEVER);

        categoryWrap = new FrameLayout(context);
        categoryWrap.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        ));

        categoryIndicator = new View(context);
        SquircleDrawable indBg = new SquircleDrawable();
        indBg.setColor(indicatorColor());
        indBg.setCornerRadius(scaled(13));
        categoryIndicator.setBackground(indBg);
        categoryIndicator.setVisibility(View.INVISIBLE);
        FrameLayout.LayoutParams indLp = new FrameLayout.LayoutParams(scaled(140), scaled(40));
        indLp.gravity = Gravity.TOP | Gravity.START;
        indLp.leftMargin = scaled(12);
        categoryIndicator.setLayoutParams(indLp);
        categoryWrap.addView(categoryIndicator);

        LinearLayout categoryContent = new LinearLayout(context);
        categorySider = categoryContent;
        categoryContent.setOrientation(LinearLayout.VERTICAL);
        categoryContent.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        ));
        categoryContent.setPadding(scaled(12), scaled(8), scaled(12), scaled(8));

        categoryTitle = new TextView(context);
        categoryTitle.setVisibility(View.GONE);
        categoryTitle.setLayoutParams(new LinearLayout.LayoutParams(0, 0));
        categoryContent.addView(categoryTitle);

        addCategoryItem(categoryContent, getCategoryDisplayName(ModuleCategory.COMBAT), ModuleCategory.COMBAT);
        addCategoryItem(categoryContent, getCategoryDisplayName(ModuleCategory.MISC), ModuleCategory.MISC);
        addCategoryItem(categoryContent, getCategoryDisplayName(ModuleCategory.RENDER), ModuleCategory.RENDER);
        addCategoryItem(categoryContent, getCategoryDisplayName(ModuleCategory.MOVEMENT), ModuleCategory.MOVEMENT);
        addCategoryItem(categoryContent, getCategoryDisplayName(ModuleCategory.PLAYER), ModuleCategory.PLAYER);
        addCategoryItem(categoryContent, getCategoryDisplayName(ModuleCategory.EXPLOIT), ModuleCategory.EXPLOIT);
        addCategoryItem(categoryContent, getCategoryDisplayName(ModuleCategory.CLIENT), ModuleCategory.CLIENT);

        categoryWrap.addView(categoryContent);
        categoryScrollView.addView(categoryWrap);
        sidebar.addView(categoryScrollView);

        bottomDivider = new View(context);
        bottomDivider.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            scaled(1)
        ));
        updateBottomDividerColor();
        sidebar.addView(bottomDivider);

        LinearLayout profileSection = createProfileSection();
        sidebar.addView(profileSection);

        return sidebar;
    }

    private void addCategoryItem(LinearLayout parent, String name, ModuleCategory category) {
        LinearLayout item = new LinearLayout(context);
        item.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            scaled(44)
        );
        params.setMargins(0, scaled(4), 0, scaled(4));
        item.setLayoutParams(params);
        item.setGravity(Gravity.CENTER_VERTICAL);
        item.setPadding(scaled(16), 0, scaled(16), 0);

        item.setBackground(null);

        TextView nameView = new TextView(context);
        nameView.setText(name);
        nameView.setTextColor(ThemeManager.getTextSecondary());
        nameView.setTextSize(scaledFontSize(14));

        item.addView(nameView);

        item.setOnClickListener(v -> { SoundPlayer.playClick(); selectCategory(category); });

        categoryItems.put(category, item);
        parent.addView(item);
    }

    private LinearLayout createProfileSection() {
        LinearLayout profile = new LinearLayout(context);
        profile.setOrientation(LinearLayout.HORIZONTAL);
        profile.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        profile.setGravity(Gravity.CENTER_VERTICAL);
        profile.setPadding(scaled(12), scaled(10), scaled(12), scaled(10));

        profileAvatar = new ImageView(context);
        profileAvatar.setLayoutParams(new LinearLayout.LayoutParams(scaled(36), scaled(36)));
        profileAvatar.setScaleType(ImageView.ScaleType.CENTER_CROP);
        profileAvatar.setClickable(true);
        profileAvatar.setFocusable(true);
        applyAvatarDrawable(profileAvatar);
        profileAvatar.setOnClickListener(v -> {
            try { SoundPlayer.playClick(); } catch (Throwable ignored) {}
            android.app.Activity act = PhoenixPopup.getCurrentActivity();
            if (act != null) AvatarPicker.pick(act);
        });

        LinearLayout userInfo = new LinearLayout(context);
        userInfo.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams userInfoParams = new LinearLayout.LayoutParams(
            0,
            LinearLayout.LayoutParams.WRAP_CONTENT,
            1f
        );
        userInfoParams.setMargins(scaled(10), 0, 0, 0);
        userInfo.setLayoutParams(userInfoParams);

        username = new TextView(context);
        username.setText(UserProfile.getUsername());
        username.setTextColor(ThemeManager.getTextPrimary());
        username.setTextSize(scaledFontSize(14));
        username.setTypeface(Typeface.DEFAULT_BOLD);
        username.setClickable(true);
        username.setFocusable(true);
        username.setPadding(0, scaled(2), 0, scaled(2));
        username.setOnClickListener(v -> {
            try { SoundPlayer.playClick(); } catch (Throwable ignored) {}
            android.app.Activity act = PhoenixPopup.getCurrentActivity();
            if (act == null) return;
            com.nyaui.me.ui.widgets.TextInputDialog.show(act, UserProfile.getUsername(), text -> {
                UserProfile.setUsername(text);
                refreshProfileUi();
            });
        });

        userId = new TextView(context);
        userId.setText(UserProfile.getBio());
        userId.setTextColor(ThemeManager.getTextSecondary());
        userId.setTextSize(scaledFontSize(11));
        userId.setClickable(true);
        userId.setFocusable(true);
        userId.setPadding(0, scaled(2), 0, scaled(2));
        userId.setOnClickListener(v -> {
            try { SoundPlayer.playClick(); } catch (Throwable ignored) {}
            android.app.Activity act = PhoenixPopup.getCurrentActivity();
            if (act == null) return;
            com.nyaui.me.ui.widgets.TextInputDialog.show(act, UserProfile.getBio(), text -> {
                UserProfile.setBio(text);
                refreshProfileUi();
            });
        });

        userInfo.addView(username);
        userInfo.addView(userId);

        profile.addView(profileAvatar);
        profile.addView(userInfo);

        UserProfile.addListener(this::refreshProfileUi);
        return profile;
    }

    private void applyAvatarDrawable(ImageView view) {
        if (view == null) return;
        android.graphics.Bitmap bmp = UserProfile.loadAvatarBitmap(context);
        if (bmp != null) {
            view.setImageBitmap(bmp);
            view.setBackground(null);
            view.setClipToOutline(true);
            view.setOutlineProvider(new android.view.ViewOutlineProvider() {
                public void getOutline(android.view.View v, android.graphics.Outline outline) {
                    outline.setOval(0, 0, v.getWidth(), v.getHeight());
                }
            });
        } else {
            view.setImageDrawable(null);
            GradientDrawable avatarBg = new GradientDrawable();
            avatarBg.setColor(ThemeManager.getThemeColor());
            avatarBg.setCornerRadius(scaled(18));
            view.setBackground(avatarBg);
        }
    }

    private void refreshProfileUi() {
        post(() -> {
            if (username != null) username.setText(UserProfile.getUsername());
            if (userId != null) userId.setText(UserProfile.getBio());
            if (profileAvatar != null) applyAvatarDrawable(profileAvatar);
        });
    }

    private LinearLayout createContentArea() {
        LinearLayout container = new LinearLayout(context);
        container.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams containerParams = new LinearLayout.LayoutParams(
            0,
            LinearLayout.LayoutParams.MATCH_PARENT,
            1f
        );
        container.setLayoutParams(containerParams);
        container.setBackgroundColor(android.graphics.Color.TRANSPARENT);
        container.setPadding(scaled(12), scaled(12), scaled(12), scaled(12));

        FrameLayout scrollWrap = new FrameLayout(context);
        scrollWrap.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.MATCH_PARENT
        ));

        contentScrollView = new ScrollView(context);
        contentScrollView.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ));
        contentScrollView.setFillViewport(false);
        contentScrollView.setVerticalScrollBarEnabled(false);
        contentScrollView.setHorizontalScrollBarEnabled(false);
        contentScrollView.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
        contentScrollView.setClipToPadding(true);
        contentScrollView.setClipChildren(true);
        contentScrollView.setPadding(0, 0, scaled(10), 0);

        contentArea = new LinearLayout(context);
        contentArea.setOrientation(LinearLayout.VERTICAL);
        contentArea.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        contentArea.setClickable(false);
        contentArea.setFocusable(false);

        contentScrollView.addView(contentArea);
        scrollWrap.addView(contentScrollView);

        contentScrollBar = new ContentScrollBar(context);
        FrameLayout.LayoutParams barLp = new FrameLayout.LayoutParams(
            scaled(12),
            FrameLayout.LayoutParams.MATCH_PARENT
        );
        barLp.gravity = Gravity.END | Gravity.TOP;
        contentScrollBar.setLayoutParams(barLp);
        scrollWrap.addView(contentScrollBar);
        contentScrollBar.attachTo(contentScrollView);

        container.addView(scrollWrap);
        return container;
    }

    private void selectCategory(ModuleCategory category) {
        boolean first = (selectedCategory == null);
        selectedCategory = category;
        saveSelectedCategory(category);

        for (Map.Entry<ModuleCategory, View> entry : categoryItems.entrySet()) {
            View item = entry.getValue();
            if (!(item instanceof LinearLayout)) continue;
            LinearLayout row = (LinearLayout) item;
            if (row.getChildCount() == 0) continue;
            TextView nameView = (TextView) row.getChildAt(0);
            if (entry.getKey() == category) {
                nameView.setTextColor(ThemeManager.getTextOnTheme());
                nameView.setTypeface(Typeface.DEFAULT_BOLD);
            } else {
                nameView.setTextColor(ThemeManager.getTextSecondary());
                nameView.setTypeface(Typeface.DEFAULT);
            }
        }

        moveCategoryIndicator(!first);
        updateContentArea(category);
    }

    private int indicatorColor() {
        int c = ThemeManager.getThemeColor();
        return 0xFF000000 | (c & 0x00FFFFFF);
    }

    private void moveCategoryIndicator(final boolean animate) {
        moveCategoryIndicator(animate, 0);
    }

    private void moveCategoryIndicator(final boolean animate, final int attempt) {
        if (categoryIndicator == null || categorySider == null) return;
        final View target = categoryItems.get(selectedCategory);
        if (target == null) {
            categoryIndicator.setVisibility(View.INVISIBLE);
            return;
        }
        categorySider.post(() -> {
            int h = target.getHeight();
            if (h <= 0) {
                if (attempt < 6) categorySider.post(() -> moveCategoryIndicator(animate, attempt + 1));
                return;
            }
            int y = 0;
            View v = target;
            while (v != null && v != categorySider) {
                y += v.getTop();
                Object p = v.getParent();
                v = (p instanceof View) ? (View) p : null;
            }
            y += categorySider.getTop();

            int wantW = Math.max(scaled(40), categorySider.getWidth() - scaled(24));
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) categoryIndicator.getLayoutParams();

            if (lp.width != wantW || lp.height != h) {
                lp.width = wantW;
                lp.height = h;
                categoryIndicator.setLayoutParams(lp);
            }

            if (categoryIndicator.getBackground() instanceof SquircleDrawable) {
                ((SquircleDrawable) categoryIndicator.getBackground()).setColor(indicatorColor());
            }

            if (categoryIndicator.getVisibility() != View.VISIBLE) {
                categoryIndicator.setTranslationY(y);
                categoryIndicator.setAlpha(0f);
                categoryIndicator.setVisibility(View.VISIBLE);
                categoryIndicator.animate().alpha(1f).setDuration(180).start();
            } else if (animate) {
                categoryIndicator.animate().cancel();
                categoryIndicator.setLayerType(LAYER_TYPE_HARDWARE, null);
                categoryIndicator.animate()
                    .translationY(y)
                    .setDuration(280)
                    .setInterpolator(IND_EASE)
                    .withEndAction(() -> categoryIndicator.setLayerType(LAYER_TYPE_NONE, null))
                    .start();
            } else {
                categoryIndicator.setTranslationY(y);
            }
        });
    }

    private int contentBatchToken = 0;
    private static final PathInterpolator SPRING = new PathInterpolator(0.22f, 1f, 0.32f, 1f);

    private void updateContentArea(ModuleCategory category) {

        if (contentArea.getChildCount() == 0) {
            contentArea.setAlpha(1f);
            contentArea.setTranslationX(0f);
            populateContent(category);
            return;
        }

        contentArea.setLayerType(LAYER_TYPE_HARDWARE, null);
        contentArea.animate()
            .alpha(0f)
            .translationX(scaled(-20))
            .setDuration(130)
            .setInterpolator(new PathInterpolator(0.4f, 0f, 1f, 1f))
            .withEndAction(() -> {

                contentArea.setLayerType(LAYER_TYPE_NONE, null);
                contentArea.setAlpha(1f);
                contentArea.setTranslationX(0f);
                populateContent(category);
            })
            .start();
    }

    private void populateContent(ModuleCategory category) {
        contentArea.removeAllViews();
        contentScrollView.scrollTo(0, 0);
        final int token = ++contentBatchToken;

        List<ModuleCardView> cached = categoryCardCache.get(category);
        if (cached != null) {

            for (int i = 0; i < cached.size(); i++) {
                ModuleCardView card = cached.get(i);
                if (card.getParent() instanceof ViewGroup) {
                    ((ViewGroup) card.getParent()).removeView(card);
                }
                contentArea.addView(card);
                card.setAlpha(0f);
                card.setTranslationY(scaled(12));
                card.animate()
                    .alpha(1f)
                    .translationY(0f)
                    .setStartDelay((long) (i * 14))
                    .setDuration(200)
                    .setInterpolator(SPRING)
                    .start();
            }
            markPopulated();
            return;
        }

        final List<Module> modules = ModuleManager.getModulesByCategory(category);
        final List<ModuleCardView> built = new ArrayList<>(modules.size());
        categoryCardCache.put(category, built);
        addCardsInBatches(modules, built, 0, token);
    }

    private static final int CARDS_PER_BATCH = 3;

    private void addCardsInBatches(List<Module> modules, List<ModuleCardView> built,
                                   int startIndex, int token) {
        if (token != contentBatchToken) return;
        int end = Math.min(startIndex + CARDS_PER_BATCH, modules.size());
        for (int i = startIndex; i < end; i++) {
            Module module = modules.get(i);
            ModuleCardView card = new ModuleCardView(context, module, this.scaleFactor);
            moduleCards.put(module, card);
            built.add(card);
            card.updateThemeColors();
            contentArea.addView(card);
            LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) card.getLayoutParams();
            params.setMargins(0, 0, 0, scaled(8));
            card.setLayoutParams(params);
            if (initialPopulated) {

                card.setAlpha(0f);
                card.setTranslationY(scaled(12));
                card.animate()
                    .alpha(1f)
                    .translationY(0f)
                    .setStartDelay((long) (i * 16))
                    .setDuration(240)
                    .setInterpolator(SPRING)
                    .start();
            } else {

                card.setAlpha(1f);
                card.setTranslationY(0f);
            }
        }
        if (end < modules.size()) {
            contentArea.postOnAnimation(() -> addCardsInBatches(modules, built, end, token));
        } else {
            markPopulated();
        }
    }

    private void markPopulated() {
        if (initialPopulated) return;
        initialPopulated = true;
        if (pendingShow != null) {
            Runnable r = pendingShow;
            pendingShow = null;
            r.run();
        }
    }

    private boolean initialPopulated = false;
    private Runnable pendingShow = null;

    public void show() {
        setVisibility(View.VISIBLE);

        if (!initialPopulated) {
            pendingShow = this::startShowAnim;
            return;
        }
        startShowAnim();
    }

    private void startShowAnim() {

        animate().cancel();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            setLayerType(LAYER_TYPE_HARDWARE, null);
        }
        animate()
            .alpha(1f)
            .scaleX(1f)
            .scaleY(1f)
            .setDuration(380)
            .setInterpolator(new android.view.animation.PathInterpolator(0.16f, 1f, 0.3f, 1f))
            .withEndAction(() -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
                    setLayerType(LAYER_TYPE_NONE, null);
                }
            })
            .start();
    }

    public void hide() {
        hide(null);
    }

    public void hide(Runnable onComplete) {
        this.onHideCompleteListener = onComplete;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            setLayerType(LAYER_TYPE_HARDWARE, null);
        }
        animate()
            .alpha(0f)
            .scaleX(0.92f)
            .scaleY(0.92f)
            .translationY(scaled(16))
            .setDuration(240)
            .setInterpolator(new android.view.animation.PathInterpolator(0.4f, 0f, 1f, 1f))
            .setListener(new AnimatorListenerAdapter() {
                                public void onAnimationEnd(Animator animation) {
                    super.onAnimationEnd(animation);
                    setLayerType(LAYER_TYPE_NONE, null);
                    setVisibility(View.GONE);
                    setAlpha(1f);
                    setScaleX(1f);
                    setScaleY(1f);
                    setTranslationY(0f);
                    if (onHideCompleteListener != null) {
                        onHideCompleteListener.run();
                        onHideCompleteListener = null;
                    }
                }
            })
            .start();
    }

    public void setOnHideCompleteListener(Runnable listener) {
        this.onHideCompleteListener = listener;
    }

        public void onThemeColorChanged(int newColor) {

        post(() -> updateAllColors());
    }

        public void onThemeModeChanged(boolean isDark) {

        post(() -> updateAllColors());
    }

    public void refreshLanguage() {
        if (categoryTitle != null) {
            categoryTitle.setText(ConfigManager.isChinese() ? "Category" : "Category");
        }

        for (Map.Entry<ModuleCategory, View> entry : categoryItems.entrySet()) {
            View view = entry.getValue();
            if (view instanceof LinearLayout && ((LinearLayout) view).getChildCount() > 0) {
                View child = ((LinearLayout) view).getChildAt(0);
                if (child instanceof TextView) {
                    ((TextView) child).setText(getCategoryDisplayName(entry.getKey()));
                }
            }
        }

        selectCategory(selectedCategory);
    }

    private String getCategoryDisplayName(ModuleCategory category) {
        if (!ConfigManager.isChinese()) {
            return category.getDisplayName();
        }
        switch (category) {
            case COMBAT: return "Combat";
            case MOVEMENT: return "Movement";
            case PLAYER: return "Player";
            case RENDER: return "Render";
            case MISC: return "Misc";
            case CLIENT: return "Client";
            default: return category.getDisplayName();
        }
    }

    private void updateAllColors() {
        if (getContext() == null) return;

        if (mainContainer != null) {
            if (panelBg != null) {
                panelBg.setStyle(UiBackground.style());
                panelBg.invalidateSelf();
            }
            mainContainer.invalidate();
        }

        if (sidebar != null) {
            sidebar.setBackgroundColor(ThemeManager.getMenuBackground());
            sidebar.invalidate();
        }

        if (brandText != null) {
            brandText.setTextColor(ThemeManager.getTextPrimary());
        }

        if (categoryTitle != null) {
            categoryTitle.setTextColor(ThemeManager.getTextSecondary());
        }

        if (contentContainer != null) {
            contentContainer.setBackgroundColor(android.graphics.Color.TRANSPARENT);
            contentContainer.invalidate();
        }
        if (contentScrollBar != null) contentScrollBar.refreshTheme();

        updateVerticalDividerColor();
        updateHorizontalDividerColor();
        updateBottomDividerColor();

        for (Map.Entry<ModuleCategory, View> entry : categoryItems.entrySet()) {
            View v = entry.getValue();
            if (!(v instanceof LinearLayout)) continue;
            LinearLayout item = (LinearLayout) v;
            if (item.getChildCount() == 0) continue;
            TextView nameView = (TextView) item.getChildAt(0);
            if (entry.getKey() == selectedCategory) {
                nameView.setTextColor(ThemeManager.getTextOnTheme());
                nameView.setTypeface(Typeface.DEFAULT_BOLD);
            } else {
                nameView.setTextColor(ThemeManager.getTextSecondary());
                nameView.setTypeface(Typeface.DEFAULT);
            }
        }

        if (categoryIndicator != null
                && categoryIndicator.getBackground() instanceof SquircleDrawable) {
            ((SquircleDrawable) categoryIndicator.getBackground()).setColor(indicatorColor());
            categoryIndicator.invalidate();
        }

        for (ModuleCardView card : moduleCards.values()) {
            if (card != null) {
                card.updateThemeColors();
            }
        }

        updateProfileColors();
    }

    private void saveSelectedCategory(ModuleCategory category) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(KEY_SELECTED_CATEGORY, category.name());
        editor.apply();
    }

    private void loadSelectedCategory() {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String categoryName = prefs.getString(KEY_SELECTED_CATEGORY, ModuleCategory.COMBAT.name());
        try {
            ModuleCategory category = ModuleCategory.valueOf(categoryName);
            selectCategory(category);
        } catch (IllegalArgumentException e) {
            selectCategory(ModuleCategory.COMBAT);
        }
    }

    private void updateVerticalDividerColor() {
        if (verticalDivider != null) {

            int dividerColor = ThemeManager.getTextSecondary();

            dividerColor = (dividerColor & 0x00FFFFFF) | 0x1A000000;
            verticalDivider.setBackgroundColor(dividerColor);
        }
    }

    private void updateHorizontalDividerColor() {
        if (horizontalDivider != null) {

            int dividerColor = ThemeManager.getTextSecondary();

            dividerColor = (dividerColor & 0x00FFFFFF) | 0x1A000000;
            horizontalDivider.setBackgroundColor(dividerColor);
        }
    }

    private void updateBottomDividerColor() {
        if (bottomDivider != null) {

            int dividerColor = ThemeManager.getTextSecondary();

            dividerColor = (dividerColor & 0x00FFFFFF) | 0x1A000000;
            bottomDivider.setBackgroundColor(dividerColor);
        }
    }

    private void updateProfileColors() {
        refreshProfileUi();
        if (username != null) username.setTextColor(ThemeManager.getTextPrimary());
        if (userId != null) userId.setTextColor(ThemeManager.getTextSecondary());
    }

    public void refreshBackgroundOnly() {
        if (panelBg != null) {
            panelBg.setStyle(UiBackground.style());
            panelBg.invalidateSelf();
        } else if (mainContainer != null) {
            panelBg = UiBackground.create(scaled(28));
            panelBg.setCorner(scaled(22));
            mainContainer.setBackground(panelBg);
        }
        if (mainContainer != null) mainContainer.invalidate();
    }

    public void destroy() {
        if (contentScrollBar != null) {
            contentScrollBar.detach();
            contentScrollBar = null;
        }
        if (panelBg != null) {
            panelBg.detach();
            panelBg = null;
        }
        UserProfile.removeListener(this::refreshProfileUi);
        pendingShow = null;
        if (panelResizeAnim != null) {
            panelResizeAnim.cancel();
            panelResizeAnim = null;
        }
        ThemeManager.removeListener(this);
        ThemeManager.removeModeListener(this);
    }

    private int scaled(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density * scaleFactor);
    }

    private float scaledFontSize(float sp) {

        return sp * scaleFactor;
    }

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density);
    }
}
