package com.nyaui.me.ui;

import android.app.Activity;
import android.view.WindowManager;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleManager;
import com.nyaui.me.config.ConfigManager;

import java.util.ArrayList;
import java.util.List;

public class NotificationManager {
    private static final List<NotificationView> activeNotifications = new ArrayList<>();
    private static Activity currentActivity;
    private static WindowManager windowManager;
    private static boolean enabled = true;
    private static final int ANIMATION_DURATION = 250;

    public static void init(Activity activity) {
        currentActivity = activity;
        if (activity != null) {
            windowManager = (WindowManager) activity.getSystemService(Activity.WINDOW_SERVICE);
        }
        Module notify = ModuleManager.getModuleByName("Notify");
        enabled = notify != null && notify.isEnabled();
    }

    public static void setEnabled(boolean e) {
        enabled = e;
        if (!e) clearAll();
    }

    private static boolean isNotifyModuleOn() {
        Module notify = ModuleManager.getModuleByName("Notify");
        return notify != null && notify.isEnabled();
    }

    public static void showNotification(Module module, boolean isEnabled) {
        if (!enabled || !isNotifyModuleOn()) return;
        if (currentActivity == null || windowManager == null) return;

        currentActivity.runOnUiThread(() -> {
            if (!isNotifyModuleOn()) return;
            NotificationView notification = new NotificationView(currentActivity, module, isEnabled);
            activeNotifications.add(notification);
            updateAllPositions();
            try { SoundPlayer.playClick(); } catch (Throwable ignored) {}
            notification.show(windowManager, activeNotifications.size() - 1);
            notification.postDelayed(() -> removeNotification(notification), getDisplayDuration() + ANIMATION_DURATION + 200);
        });
    }

    public static void onNotificationDismissed(NotificationView notification) {
        removeNotification(notification);
    }

    private static void removeNotification(NotificationView notification) {
        if (activeNotifications.remove(notification)) {
            updateAllPositions();
        }
    }

    public static void updateAllPositions() {
        for (int i = 0; i < activeNotifications.size(); i++) {
            NotificationView notification = activeNotifications.get(i);
            if (notification != null) {
                notification.updatePosition(i);
                notification.refreshHudPosition();
            }
        }
    }

    public static void updateColors() {
        for (NotificationView notification : new ArrayList<>(activeNotifications)) {
            if (notification != null) notification.updateColorsFromHud();
        }
    }

    public static void clearAll() {
        for (NotificationView notification : new ArrayList<>(activeNotifications)) {
            if (notification != null) notification.dismiss();
        }
        activeNotifications.clear();
    }

    public static void cleanup() {
        clearAll();
        currentActivity = null;
        windowManager = null;
    }

    public static int getDisplayDuration() {
        return Math.max(500, Math.min(10000, ConfigManager.getInt("HUD", "notification_duration", 2000)));
    }
}
