package com.nyaui.me.ui;

import android.graphics.*;
import android.graphics.drawable.Drawable;

public class SquircleDrawable extends Drawable {
    private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint strokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF bounds = new RectF();
    private float cornerRadius = 0f;
    private float strokeWidth = 0f;
    private float cornerSmoothing = 0.72f;
    private boolean pathDirty = true;

    public SquircleDrawable() {
        fillPaint.setStyle(Paint.Style.FILL);
        fillPaint.setColor(0xFFFFFFFF);
        strokePaint.setStyle(Paint.Style.STROKE);
    }

    public SquircleDrawable setColor(int color) {
        fillPaint.setColor(color);
        invalidateSelf();
        return this;
    }

    public int getColor() { return fillPaint.getColor(); }

    public SquircleDrawable setCornerRadius(float px) {
        if (cornerRadius == px) return this;
        cornerRadius = px;
        pathDirty = true;
        invalidateSelf();
        return this;
    }

    public SquircleDrawable setStroke(float width, int color) {
        strokeWidth = width;
        strokePaint.setStrokeWidth(width);
        strokePaint.setColor(color);
        invalidateSelf();
        return this;
    }

    protected void onBoundsChange(Rect b) {
        bounds.set(b);
        pathDirty = true;
    }

    public void draw(Canvas canvas) {
        if (pathDirty) {
            pathDirty = false;
            buildSquirclePath(path, bounds.left, bounds.top, bounds.right, bounds.bottom, cornerRadius, cornerSmoothing);
        }
        if (path.isEmpty()) return;
        canvas.drawPath(path, fillPaint);
        if (strokeWidth > 0f) canvas.drawPath(path, strokePaint);
    }

    public void getOutline(Outline outline) {
        float r = Math.min(cornerRadius, Math.min(bounds.width(), bounds.height()) / 2f);
        outline.setRoundRect((int) bounds.left, (int) bounds.top, (int) bounds.right, (int) bounds.bottom, Math.max(0f, r));
    }

    public void setAlpha(int a) { fillPaint.setAlpha(a); invalidateSelf(); }
    public void setColorFilter(ColorFilter cf) { fillPaint.setColorFilter(cf); }
    public int getOpacity() { return PixelFormat.TRANSLUCENT; }

    public static void buildSquirclePath(Path out, float l, float t, float rt, float bt, float cornerRadius, float cornerSmoothing) {
        out.reset();
        float w = rt - l, h = bt - t;
        if (w <= 0 || h <= 0) return;
        float budget = Math.min(w, h) / 2f;
        float r = Math.min(cornerRadius, budget);
        if (r <= 0.5f) { out.addRect(l, t, rt, bt, Path.Direction.CW); return; }
        float s = Math.max(0f, Math.min(1f, cornerSmoothing));
        float p = (1f + s) * r;
        if (p > budget) { s = Math.max(0f, budget / r - 1f); p = budget; }
        double arcM = Math.toRadians(90.0 * (1.0 - s));
        float arc = (float) (Math.sin(arcM / 2.0) * r * Math.sqrt(2.0));
        double aA = (Math.PI / 2.0 - arcM) / 2.0;
        float p34 = (float) (r * Math.tan(aA / 2.0));
        double aB = Math.toRadians(45.0 * s);
        float c = (float) (p34 * Math.cos(aB));
        float d = c * (float) Math.tan(aB);
        float b = (p - arc - c - d) / 3f;
        float a = 2f * b;
        float hl = (float) (4.0 / 3.0 * Math.tan(arcM / 4.0) * r);
        float ts = (float) Math.sqrt(c * c + d * d);
        float tAx, tAy, tBx, tBy;
        if (ts < 1e-4f) { tAx = 1f; tAy = 0f; tBx = 0f; tBy = 1f; }
        else { tAx = c / ts; tAy = d / ts; tBx = d / ts; tBy = c / ts; }
        float Ax = -p + a + b + c, Ay = d;
        float Bx = Ax + arc, By = Ay + arc;
        float[] L = { -p + a, 0f, -p + a + b, 0f, Ax, Ay,
                Ax + hl * tAx, Ay + hl * tAy, Bx - hl * tBx, By - hl * tBy, Bx, By,
                Bx + d, By + c, Bx + d, By + b + c, 0f, p };
        out.moveTo(rt - p, t);
        corner(out, rt, t, 1f, 0f, 0f, 1f, L); out.lineTo(rt, bt - p);
        corner(out, rt, bt, 0f, 1f, -1f, 0f, L); out.lineTo(l + p, bt);
        corner(out, l, bt, -1f, 0f, 0f, -1f, L); out.lineTo(l, t + p);
        corner(out, l, t, 0f, -1f, 1f, 0f, L);
        out.close();
    }

    private static void corner(Path p, float ax, float ay, float ux, float uy, float vx, float vy, float[] L) {
        p.cubicTo(ax+ux*L[0]+vx*L[1], ay+uy*L[0]+vy*L[1], ax+ux*L[2]+vx*L[3], ay+uy*L[2]+vy*L[3], ax+ux*L[4]+vx*L[5], ay+uy*L[4]+vy*L[5]);
        p.cubicTo(ax+ux*L[6]+vx*L[7], ay+uy*L[6]+vy*L[7], ax+ux*L[8]+vx*L[9], ay+uy*L[8]+vy*L[9], ax+ux*L[10]+vx*L[11], ay+uy*L[10]+vy*L[11]);
        p.cubicTo(ax+ux*L[12]+vx*L[13], ay+uy*L[12]+vy*L[13], ax+ux*L[14]+vx*L[15], ay+uy*L[14]+vy*L[15], ax+ux*L[16]+vx*L[17], ay+uy*L[16]+vy*L[17]);
    }
}
