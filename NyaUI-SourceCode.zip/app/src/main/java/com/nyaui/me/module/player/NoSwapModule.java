package com.nyaui.me.module.player;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class NoSwapModule extends Module {
    public NoSwapModule() {
        super("NoSwap", ModuleCategory.PLAYER);
    }
}
