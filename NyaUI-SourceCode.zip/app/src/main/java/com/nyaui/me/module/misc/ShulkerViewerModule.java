package com.nyaui.me.module.misc;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class ShulkerViewerModule extends Module {
    public ShulkerViewerModule() {
        super("ShulkerViewer", ModuleCategory.MISC);
    }
}
