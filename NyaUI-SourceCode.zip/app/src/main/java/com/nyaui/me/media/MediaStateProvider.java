package com.nyaui.me.media;

import android.content.ComponentName;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Bundle;
import android.os.SystemClock;

import java.io.ByteArrayOutputStream;
import java.util.List;

public class MediaStateProvider extends ContentProvider {

    public static final String AUTHORITY = "com.nyaui.me.mediastate";

    public boolean onCreate() { return true; }

        public Bundle call(String method, String arg, Bundle extras) {
        Bundle out = new Bundle();
        if (!"get".equals(method)) return out;
        try {
            MediaSessionManager mgr = (MediaSessionManager) getContext()
                    .getSystemService(android.content.Context.MEDIA_SESSION_SERVICE);
            ComponentName comp = new ComponentName(getContext(), MediaNotificationListener.class);
            List<MediaController> list = mgr.getActiveSessions(comp);
            MediaController best = null;
            if (list != null) {
                for (MediaController c : list) {
                    PlaybackState ps = c.getPlaybackState();
                    if (ps != null && ps.getState() == PlaybackState.STATE_PLAYING) { best = c; break; }
                }
                if (best == null && !list.isEmpty()) best = list.get(0);
            }
            if (best == null) { out.putBoolean("active", false); return out; }

            MediaMetadata md = best.getMetadata();
            PlaybackState ps = best.getPlaybackState();
            out.putBoolean("active", true);
            out.putBoolean("playing", ps != null && ps.getState() == PlaybackState.STATE_PLAYING);
            if (md != null) {
                out.putString("title", md.getString(MediaMetadata.METADATA_KEY_TITLE));
                String artist = md.getString(MediaMetadata.METADATA_KEY_ARTIST);
                if (artist == null || artist.isEmpty())
                    artist = md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST);
                out.putString("artist", artist);
                out.putString("album", md.getString(MediaMetadata.METADATA_KEY_ALBUM));
                String lyric = md.getString("android.media.metadata.LYRIC");
                if (lyric == null) lyric = md.getString(MediaMetadata.METADATA_KEY_DISPLAY_DESCRIPTION);
                out.putString("lyric", lyric);
                out.putLong("duration", md.getLong(MediaMetadata.METADATA_KEY_DURATION));
                Bitmap b = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
                if (b == null) b = md.getBitmap(MediaMetadata.METADATA_KEY_ART);
                if (b == null) b = md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON);
                byte[] art = encodeArt(b);
                if (art != null) out.putByteArray("art", art);
            }
            if (ps != null) {
                out.putLong("position", ps.getPosition());
                out.putLong("posTime", SystemClock.elapsedRealtime());
                out.putFloat("speed", ps.getPlaybackSpeed());
            }
        } catch (Throwable t) {
            out.putBoolean("active", false);
        }
        return out;
    }

    private byte[] encodeArt(Bitmap b) {
        if (b == null) return null;
        try {
            int max = 256;
            int w = b.getWidth(), h = b.getHeight();
            float scale = Math.min(1f, (float) max / Math.max(w, h));
            Bitmap s = scale < 1f
                    ? Bitmap.createScaledBitmap(b, Math.max(1, (int) (w * scale)),
                                                   Math.max(1, (int) (h * scale)), true)
                    : b;
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            s.compress(Bitmap.CompressFormat.JPEG, 80, bos);
            return bos.toByteArray();
        } catch (Throwable t) {
            return null;
        }
    }

    public Cursor query(Uri u, String[] p, String s, String[] a, String o) { return null; }
    public String getType(Uri u) { return null; }
    public Uri insert(Uri u, ContentValues v) { return null; }
    public int delete(Uri u, String s, String[] a) { return 0; }
    public int update(Uri u, ContentValues v, String s, String[] a) { return 0; }
}
