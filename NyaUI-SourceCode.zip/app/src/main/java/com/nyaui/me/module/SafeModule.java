package com.nyaui.me.module;

import com.nyaui.me.ui.widgets.SubMenuPanel;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import android.os.Handler;
import android.os.Looper;
import java.lang.ref.WeakReference;
import java.util.concurrent.Callable;

public abstract class SafeModule extends Module {
    
    protected volatile boolean jniLoaded = false;
    private static final ExecutorService SHARED_EXECUTOR = Executors.newFixedThreadPool(2, r -> {
        Thread t = new Thread(r, "NyaUI-ModuleWorker");
        t.setPriority(Thread.MIN_PRIORITY);
        return t;
    });
    protected final ExecutorService backgroundExecutor;
    protected final Handler mainHandler;
    protected volatile boolean isConfiguring = false;
    protected volatile boolean isDestroyed = false;
    private WeakReference<SubMenuPanel> subMenuRef;
    
    
    private Future<Boolean> jniCheckFuture;
    private static final long JNI_CHECK_TIMEOUT_MS = 500;

    public SafeModule(String name, ModuleCategory category, String description) {
        super(name, category, description);
        this.backgroundExecutor = SHARED_EXECUTOR;
        this.mainHandler = new Handler(Looper.getMainLooper());
        
        preloadJNI();
    }

    private void preloadJNI() {
        jniCheckFuture = backgroundExecutor.submit(() -> {
            try {
                SafeCall.getEnabled(getModuleName());
                return true;
            } catch (Throwable t) {
                return false;
            }
        });
    }

    protected boolean isBackgroundActive() {
        return !isDestroyed && backgroundExecutor != null && !backgroundExecutor.isShutdown();
    }

        public void configureSubMenu(SubMenuPanel subMenu) {
        super.configureSubMenu(subMenu);
        
        subMenuRef = new WeakReference<>(subMenu);
        
        if (isConfiguring || isDestroyed) {
            return;
        }
        isConfiguring = true;

        
        boolean useJNI = false;
        try {
            if (jniCheckFuture != null && jniCheckFuture.isDone()) {
                useJNI = jniCheckFuture.get(0, TimeUnit.MILLISECONDS);
            }
        } catch (Throwable t) {
            useJNI = false;
        }

        final boolean finalUseJNI = useJNI;

        mainHandler.post(() -> {
            try {
                if (!isDestroyed && subMenuRef.get() != null) {
                    if (finalUseJNI) {
                        configureWithJNI(subMenuRef.get());
                    } else {
                        configureWithDefaults(subMenuRef.get());
                    }
                }
            } catch (Throwable t) {
                System.err.println("配置UI异常: " + t.getMessage());
                
                try {
                    if (!isDestroyed && subMenuRef.get() != null) {
                        configureWithDefaults(subMenuRef.get());
                    }
                } catch (Throwable ex) {
                    System.err.println("默认配置也失败: " + ex.getMessage());
                }
            } finally {
                isConfiguring = false;
            }
        });
    }

    protected String getModuleName() {
        String className = getClass().getSimpleName();
        if (className.startsWith("Test")) {
            className = className.substring(4);
        }
        if (className.endsWith("Module")) {
            className = className.substring(0, className.length() - 6);
        }
        return className;
    }

    protected abstract void configureWithJNI(SubMenuPanel subMenu);
    protected abstract void configureWithDefaults(SubMenuPanel subMenu);

        public void onEnable() {
        super.onEnable();
        if (jniLoaded && isBackgroundActive()) {
            backgroundExecutor.execute(() -> {
                try {
                    SafeCall.setEnabled(getModuleName());
                } catch (Throwable t) {
                    System.err.println("Failed to enable module: " + t.getMessage());
                }
            });
        }
    }

        public void onDisable() {
        super.onDisable();
        if (jniLoaded && isBackgroundActive()) {
            backgroundExecutor.execute(() -> {
                try {
                    SafeCall.setEnabled(getModuleName());
                } catch (Throwable t) {
                    System.err.println("Failed to disable module: " + t.getMessage());
                }
            });
        }
    }

    public void cleanup() {
        isDestroyed = true;
        
        if (jniCheckFuture != null && !jniCheckFuture.isDone()) {
            jniCheckFuture.cancel(true);
        }
        
        if (mainHandler != null) {
            mainHandler.removeCallbacksAndMessages(null);
        }
    }

    public void reset() {
        isConfiguring = false;
    }
}