package com.nyaui.me.module.movement;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class PacketFlyModule extends Module {
    public PacketFlyModule() {
        super("PacketFly", ModuleCategory.MOVEMENT);
    }
}
