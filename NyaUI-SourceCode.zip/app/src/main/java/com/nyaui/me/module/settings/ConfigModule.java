package com.nyaui.me.module.settings;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.nyaui.me.config.ConfigExporter;
import com.nyaui.me.config.ConfigManager;
import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.ui.ThemeManager;
import com.nyaui.me.ui.widgets.SubMenuPanel;

import java.util.List;

public class ConfigModule extends Module {
    public ConfigModule() {
        super("Config", ModuleCategory.SETTINGS, "");
        setChineseName("Config Manager");
    }

    public boolean shouldShowInArraylist() { return false; }
    public boolean supportsShortcut() { return false; }

    public void configureSubMenu(SubMenuPanel subMenu) {
        super.configureSubMenu(subMenu);
        Context ctx = subMenu.getContext();
        float d = ctx.getResources().getDisplayMetrics().density;

        subMenu.addSectionTitle("Configuration File");

        LinearLayout fileRow = new LinearLayout(ctx);
        fileRow.setOrientation(LinearLayout.HORIZONTAL);
        fileRow.setGravity(Gravity.CENTER_VERTICAL);

        EditText fileName = new EditText(ctx);
        fileName.setSingleLine(true);
        fileName.setText(ConfigManager.getConfigFileName());
        fileName.setTextSize(12f);
        fileName.setTextColor(ThemeManager.getTextPrimary());
        fileName.setHintTextColor(ThemeManager.getTextSecondary());
        fileName.setHint("cfg.txt");
        fileName.setPadding((int) (8 * d), (int) (4 * d), (int) (8 * d), (int) (4 * d));
        fileName.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        fileRow.addView(fileName);

        TextView applyName = makeTextButton(ctx, "Apply", ThemeManager.getThemeColor(), d);
        applyName.setOnClickListener(v -> {
            String value = fileName.getText().toString().trim();
            if (value.isEmpty()) value = "cfg.txt";
            ConfigManager.setConfigFileName(value);
            fileName.setText(ConfigManager.getConfigFileName());
            Toast.makeText(ctx, "Config filename saved", Toast.LENGTH_SHORT).show();
        });
        fileRow.addView(applyName);
        subMenu.addCustomView(fileRow);

        subMenu.addText("Default: cfg.txt");
        subMenu.addDivider();
        subMenu.addSectionTitle("Import / Export");

        LinearLayout btnRow = new LinearLayout(ctx);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setGravity(Gravity.CENTER);

        TextView exportBtn = makeTextButton(ctx, "Export", ThemeManager.getThemeColor(), d);
        exportBtn.setOnClickListener(v -> {
            Activity act = findActivity(ctx);
            if (act != null) {
                ConfigExporter.doExport(act,
                        () -> Toast.makeText(ctx, "Export successful", Toast.LENGTH_SHORT).show(),
                        () -> Toast.makeText(ctx, "Export failed", Toast.LENGTH_SHORT).show());
            }
        });
        btnRow.addView(exportBtn);

        View gap = new View(ctx);
        gap.setLayoutParams(new LinearLayout.LayoutParams((int) (10 * d), 1));
        btnRow.addView(gap);

        TextView importBtn = makeTextButton(ctx, "Import", ThemeManager.getBgDisabled(), d);
        importBtn.setTextColor(ThemeManager.getTextPrimary());
        importBtn.setOnClickListener(v -> {
            Activity act = findActivity(ctx);
            if (act != null) {
                ConfigExporter.doImport(act,
                        () -> Toast.makeText(ctx, "Import successful", Toast.LENGTH_SHORT).show(),
                        () -> Toast.makeText(ctx, "Import failed", Toast.LENGTH_SHORT).show());
            }
        });
        btnRow.addView(importBtn);
        subMenu.addCustomView(btnRow);

        subMenu.addDivider();
        subMenu.addSectionTitle("Local Configs");
        subMenu.addText("These configs contain the same full client configuration as cfg.txt.");

        LinearLayout saveRow = new LinearLayout(ctx);
        saveRow.setOrientation(LinearLayout.HORIZONTAL);
        saveRow.setGravity(Gravity.CENTER_VERTICAL);

        EditText nameInput = new EditText(ctx);
        nameInput.setHint("Profile name");
        nameInput.setTextSize(12f);
        nameInput.setTextColor(ThemeManager.getTextPrimary());
        nameInput.setHintTextColor(ThemeManager.getTextSecondary());
        nameInput.setSingleLine(true);
        nameInput.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        saveRow.addView(nameInput);

        TextView saveBtn = makeTextButton(ctx, "Save", ThemeManager.getThemeColor(), d);
        saveBtn.setOnClickListener(v -> {
            String name = nameInput.getText().toString().trim();
            if (name.isEmpty()) name = "profile_" + System.currentTimeMillis() + ".txt";
            ConfigExporter.saveConfig(ctx, name);
            Toast.makeText(ctx, "Saved: " + name, Toast.LENGTH_SHORT).show();
        });
        saveRow.addView(saveBtn);
        subMenu.addCustomView(saveRow);

        List<String> configs = ConfigExporter.listConfigs(ctx);
        if (configs.isEmpty()) {
            subMenu.addText("No local configs");
        } else {
            for (String cfg : configs) {
                LinearLayout row = new LinearLayout(ctx);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding((int) (4 * d), (int) (5 * d), (int) (4 * d), (int) (5 * d));

                TextView label = new TextView(ctx);
                label.setText(cfg);
                label.setTextColor(ThemeManager.getTextPrimary());
                label.setTextSize(12f);
                label.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
                row.addView(label);

                TextView applyBtn = makeTextButton(ctx, "Apply", ThemeManager.getThemeColor(), d);
                applyBtn.setOnClickListener(v -> {
                    ConfigExporter.loadConfig(ctx, cfg);
                    Toast.makeText(ctx, "Applied: " + cfg, Toast.LENGTH_SHORT).show();
                });
                row.addView(applyBtn);

                View gap2 = new View(ctx);
                gap2.setLayoutParams(new LinearLayout.LayoutParams((int) (5 * d), 1));
                row.addView(gap2);

                TextView delBtn = makeTextButton(ctx, "Delete", 0xFFFF5F6D, d);
                delBtn.setOnClickListener(v -> {
                    ConfigExporter.deleteConfig(ctx, cfg);
                    Toast.makeText(ctx, "Deleted: " + cfg, Toast.LENGTH_SHORT).show();
                });
                row.addView(delBtn);
                subMenu.addCustomView(row);
            }
        }
    }

    private TextView makeTextButton(Context ctx, String text, int color, float d) {
        TextView button = new TextView(ctx);
        button.setText(text);
        button.setTextColor(0xFFFFFFFF);
        button.setTextSize(11f);
        button.setGravity(Gravity.CENTER);
        button.setPadding((int) (12 * d), (int) (7 * d), (int) (12 * d), (int) (7 * d));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(6 * d);
        button.setBackground(bg);
        button.setClickable(true);
        return button;
    }

    private Activity findActivity(Context ctx) {
        while (ctx instanceof android.content.ContextWrapper) {
            if (ctx instanceof Activity) return (Activity) ctx;
            ctx = ((android.content.ContextWrapper) ctx).getBaseContext();
        }
        return null;
    }
}
