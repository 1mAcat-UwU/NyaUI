package com.nyaui.me;

import android.app.Activity;

public class zombie_activity {
    public static Activity ocean_activity;

    public static void addActivity(Activity activity) {
        if (activity != null) {
            ocean_activity = activity;
        }
    }

    public static Activity getActivity() {
        Activity activity = ocean_activity;
        if (activity != null) {
            return activity;
        }
        return null;
    }
}

