package com.nyaui.me.ui;

import com.nyaui.me.config.ConfigManager;

public final class ColorStyle {
    public final String group;
    public final String key;
    public final int defaultSolid;

    public ColorStyle(String group, String key, int defaultSolid) {
        this.group = group;
        this.key = key;
        this.defaultSolid = defaultSolid;
    }

    public boolean isGradient() {
        return DynamicColorEngine.isGradientMode(ConfigManager.getColorMode(group, key));
    }

    public int solid() {
        return ConfigManager.getInt(group, key, defaultSolid);
    }

    public int start() {
        return ConfigManager.getGradientStart(group, key, solid());
    }

    public int end() {
        return ConfigManager.getGradientEnd(group, key, solid());
    }

    public int sample(float localOffset) {
        if (!isGradient()) return solid();
        return DynamicColorEngine.sampleFlow(start(), end(), localOffset);
    }
}
