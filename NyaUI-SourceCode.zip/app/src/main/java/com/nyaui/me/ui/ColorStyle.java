package com.nyaui.me.ui;

import com.nyaui.me.config.ConfigManager;

public final class ColorStyle {
    public final String group;
    public final String key;
    public final int defaultSolid;

    public ColorStyle(String group, String key, int defaultSolid) {
        this.group = group;
        this.key = key;
        this.defaultSolid = defaultSolid;
    }

    public boolean isGradient() {
        return DynamicColorEngine.isGradientMode(ConfigManager.getColorMode(group, key));
    }

    public int solid() {
        return applyTransparency(ConfigManager.getInt(group, key, defaultSolid));
    }

    public int start() {
        return applyTransparency(ConfigManager.getGradientStart(group, key, defaultSolid));
    }

    public int end() {
        return applyTransparency(ConfigManager.getGradientEnd(group, key, defaultSolid));
    }

    public int transparency() {
        return Math.max(0, Math.min(255, ConfigManager.getInt(group, key + "_alpha", android.graphics.Color.alpha(defaultSolid))));
    }

    public float speed() {
        return Math.max(0f, Math.min(5f, ConfigManager.getFloat(group, key + "_speed", 1f)));
    }

    public int direction() {
        return Math.max(0, Math.min(3, ConfigManager.getInt(group, key + "_dir", DynamicColorEngine.DIR_LEFT_RIGHT)));
    }

    public void applyEngineParams() {
        DynamicColorEngine.setSpeedMultiplier(speed());
        DynamicColorEngine.setDirection(direction());
    }

    private int applyTransparency(int color) {
        int a = transparency();
        return (color & 0x00FFFFFF) | (a << 24);
    }

    public int sample(float localOffset) {
        if (!isGradient()) return solid();
        return DynamicColorEngine.sampleFlow(start(), end(), localOffset);
    }
}
