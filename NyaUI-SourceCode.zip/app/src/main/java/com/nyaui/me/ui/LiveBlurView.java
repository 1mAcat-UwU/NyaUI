package com.nyaui.me.ui;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.os.Build;
import android.renderscript.Allocation;
import android.renderscript.Element;
import android.renderscript.RenderScript;
import android.renderscript.ScriptIntrinsicBlur;
import android.view.Choreographer;
import android.view.View;
import android.view.ViewTreeObserver;

public class LiveBlurView extends View {

    private final View sourceView;
    private Bitmap downscaledBitmap;
    private Bitmap blurredBitmap;
    private Canvas downscaleCanvas;
    private final Matrix drawMatrix = new Matrix();
    private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
    private final Paint scrimPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private RenderScript renderScript;
    private ScriptIntrinsicBlur blurScript;
    private Allocation inputAllocation;
    private Allocation outputAllocation;

    private float downscaleFactor = 6f;
    private float blurRadius = 20f;
    private int scrimColor = 0x33000000;

    private boolean rendering = false;
    private boolean attached = false;
    private float renderProgress = 0f;

    private final Choreographer.FrameCallback frameCallback = new Choreographer.FrameCallback() {
                public void doFrame(long frameTimeNanos) {
            if (!attached || !rendering) return;
            captureAndBlur();
            invalidate();
            Choreographer.getInstance().postFrameCallback(this);
        }
    };

    private final ViewTreeObserver.OnPreDrawListener preDrawListener = () -> {
        if (attached && rendering) invalidate();
        return true;
    };

    public LiveBlurView(Context context, View sourceView) {
        super(context);
        this.sourceView = sourceView;
        setLayerType(LAYER_TYPE_HARDWARE, null);
        scrimPaint.setColor(scrimColor);
    }

    public void setBlurConfig(float radius, float downscale, int scrim) {
        this.blurRadius = Math.max(1f, Math.min(25f, radius));
        this.downscaleFactor = Math.max(2f, downscale);
        this.scrimColor = scrim;
        scrimPaint.setColor(scrim);
        if (blurScript != null) {
            try { blurScript.setRadius(this.blurRadius); } catch (Throwable ignored) {}
        }
    }

    public void startBlur() {
        rendering = true;
        renderProgress = 0f;
        if (attached) {
            Choreographer.getInstance().postFrameCallback(frameCallback);
        }
        ValueAnimator fade = ValueAnimator.ofFloat(0f, 1f);
        fade.setDuration(280);
        fade.setInterpolator(new android.view.animation.DecelerateInterpolator(1.4f));
        fade.addUpdateListener(a -> {
            renderProgress = (float) a.getAnimatedValue();
            invalidate();
        });
        fade.start();
    }

    public void stopBlur(Runnable onEnd) {
        ValueAnimator fade = ValueAnimator.ofFloat(renderProgress, 0f);
        fade.setDuration(200);
        fade.setInterpolator(new android.view.animation.AccelerateInterpolator(1.4f));
        fade.addUpdateListener(a -> {
            renderProgress = (float) a.getAnimatedValue();
            invalidate();
        });
        fade.addListener(new android.animation.AnimatorListenerAdapter() {
            public void onAnimationEnd(android.animation.Animator animation) {
                rendering = false;
                if (onEnd != null) onEnd.run();
            }
        });
        fade.start();
    }

        protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        attached = true;
        getViewTreeObserver().addOnPreDrawListener(preDrawListener);
        if (rendering) Choreographer.getInstance().postFrameCallback(frameCallback);
    }

        protected void onDetachedFromWindow() {
        attached = false;
        rendering = false;
        Choreographer.getInstance().removeFrameCallback(frameCallback);
        getViewTreeObserver().removeOnPreDrawListener(preDrawListener);
        releaseResources();
        super.onDetachedFromWindow();
    }

    private void prepareBitmaps(int width, int height) {
        int scaledW = Math.max(1, (int) (width / downscaleFactor));
        int scaledH = Math.max(1, (int) (height / downscaleFactor));
        if (downscaledBitmap != null && downscaledBitmap.getWidth() == scaledW && downscaledBitmap.getHeight() == scaledH) {
            return;
        }
        releaseResources();
        try {
            downscaledBitmap = Bitmap.createBitmap(scaledW, scaledH, Bitmap.Config.ARGB_8888);
            blurredBitmap = Bitmap.createBitmap(scaledW, scaledH, Bitmap.Config.ARGB_8888);
            downscaleCanvas = new Canvas(downscaledBitmap);
            drawMatrix.reset();
            drawMatrix.postScale((float) width / scaledW, (float) height / scaledH);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                renderScript = RenderScript.create(getContext());
                blurScript = ScriptIntrinsicBlur.create(renderScript, Element.U8_4(renderScript));
                blurScript.setRadius(blurRadius);
                inputAllocation = Allocation.createFromBitmap(renderScript, downscaledBitmap);
                outputAllocation = Allocation.createFromBitmap(renderScript, blurredBitmap);
            }
        } catch (Throwable t) {
            releaseResources();
        }
    }

    private void captureAndBlur() {
        if (sourceView == null || sourceView.getWidth() == 0) return;
        prepareBitmaps(getWidth() > 0 ? getWidth() : sourceView.getWidth(),
                getHeight() > 0 ? getHeight() : sourceView.getHeight());
        if (downscaleCanvas == null || downscaledBitmap == null) return;

        try {
            downscaledBitmap.eraseColor(Color.TRANSPARENT);
            downscaleCanvas.save();
            float sx = (float) downscaledBitmap.getWidth() / sourceView.getWidth();
            float sy = (float) downscaledBitmap.getHeight() / sourceView.getHeight();
            downscaleCanvas.scale(sx, sy);
            sourceView.draw(downscaleCanvas);
            downscaleCanvas.restore();

            if (blurScript != null && inputAllocation != null) {
                inputAllocation.copyFrom(downscaledBitmap);
                blurScript.setInput(inputAllocation);
                blurScript.forEach(outputAllocation);
                outputAllocation.copyTo(blurredBitmap);
            } else {
                blurredBitmap = downscaledBitmap;
            }
        } catch (Throwable ignored) {
        }
    }

        protected void onDraw(Canvas canvas) {
        if (!rendering || blurredBitmap == null || renderProgress <= 0f) {
            return;
        }
        canvas.save();
        paint.setAlpha((int) (255 * renderProgress));
        drawMatrix.reset();
        drawMatrix.postScale(
                (float) getWidth() / blurredBitmap.getWidth(),
                (float) getHeight() / blurredBitmap.getHeight());
        canvas.drawBitmap(blurredBitmap, drawMatrix, paint);
        int a = Color.alpha(scrimColor);
        scrimPaint.setAlpha((int) (a * renderProgress));
        canvas.drawRect(0, 0, getWidth(), getHeight(), scrimPaint);
        canvas.restore();
    }

    private void releaseResources() {
        try {
            if (inputAllocation != null) { inputAllocation.destroy(); inputAllocation = null; }
            if (outputAllocation != null) { outputAllocation.destroy(); outputAllocation = null; }
            if (blurScript != null) { blurScript.destroy(); blurScript = null; }
            if (renderScript != null) { renderScript.destroy(); renderScript = null; }
        } catch (Throwable ignored) {}
        if (downscaledBitmap != null && !downscaledBitmap.isRecycled()) downscaledBitmap.recycle();
        if (blurredBitmap != null && blurredBitmap != downscaledBitmap && !blurredBitmap.isRecycled()) blurredBitmap.recycle();
        downscaledBitmap = null;
        blurredBitmap = null;
        downscaleCanvas = null;
    }
}
