package com.nyaui.me.module.player;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;

public class InvManagerModule extends Module {
    public InvManagerModule() { super("InvManager", ModuleCategory.PLAYER, ""); setChineseName("Inv Cleaner"); }
    public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("InvManager"); } catch (Throwable t) {} }
    public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("InvManager"); } catch (Throwable t) {} }
}
