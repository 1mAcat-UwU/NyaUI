package com.nyaui.me.ui;

import android.graphics.Color;

public final class ColorUtils {
    private ColorUtils() {}

    public static int clampChannel(int value) {
        return Math.max(0, Math.min(255, value));
    }

    public static int clampAlpha(int alpha) {
        return clampChannel(alpha);
    }

    public static float clampHue(float hue) {
        if (Float.isNaN(hue) || Float.isInfinite(hue)) return 0f;
        hue %= 360f;
        if (hue < 0f) hue += 360f;
        return hue;
    }

    public static float clampUnit(float value) {
        if (Float.isNaN(value) || Float.isInfinite(value)) return 0f;
        return Math.max(0f, Math.min(1f, value));
    }

    public static int opaque(int color) {
        return Color.rgb(Color.red(color), Color.green(color), Color.blue(color));
    }

    public static int withAlpha(int color, int alpha) {
        return Color.argb(clampAlpha(alpha), Color.red(color), Color.green(color), Color.blue(color));
    }

    public static int hsvToColor(float hue, float saturation, float value, int alpha) {
        return Color.HSVToColor(clampAlpha(alpha), new float[]{
                clampHue(hue), clampUnit(saturation), clampUnit(value)
        });
    }

    public static float[] toHsv(int color) {
        float[] hsv = new float[3];
        Color.colorToHSV(color, hsv);
        hsv[0] = clampHue(hsv[0]);
        hsv[1] = clampUnit(hsv[1]);
        hsv[2] = clampUnit(hsv[2]);
        return hsv;
    }

    public static int contrastingTextColor(int color) {
        double luminance = (0.299 * Color.red(color)
                + 0.587 * Color.green(color)
                + 0.114 * Color.blue(color)) / 255.0;
        return luminance >= 0.55 ? Color.BLACK : Color.WHITE;
    }

    public static int lighten(int color, float amount) {
        float[] hsv = toHsv(color);
        hsv[2] = hsv[2] + (1f - hsv[2]) * clampUnit(amount);
        return hsvToColor(hsv[0], hsv[1], hsv[2], Color.alpha(color));
    }
}
