package com.nyaui.me;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.widget.Toast;

public class DL {

    public static final String PREF_VIP_EXPIRY = "vip_expiry_time";
    public static final String PREF_KAMI = "saved_kami";
    public static final String PREF_IS_LOGGED_IN = "is_logged_in";

    private static final Handler mainHandler = new Handler(Looper.getMainLooper());
    static Context appContext;

    public interface LoginCallback {
        void onSuccess();
        void onSuccessWithTime(String vipTime);
        void onFailure(String error);
    }

    public static void Start(final Context context) {
        appContext = context;
        saveLoginState(context, true);
        jumpToHiroUI(context);
    }

    public static void logout(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("DL_Prefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean(PREF_IS_LOGGED_IN, false);
        editor.remove(PREF_KAMI);
        editor.remove(PREF_VIP_EXPIRY);
        editor.apply();
    }

    public static void verifyKami(final String kami, final Context context, final LoginCallback callback) {
        mainHandler.post(() -> {
            if (callback != null) {
                saveLoginState(context, true);
                callback.onSuccessWithTime("2099-12-31 23:59:59");
            }
        });
    }

    public static String getDeviceId(Context context) {
        try {
            return Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
        } catch (Throwable t) {
            return "unknown";
        }
    }

    private static void saveLoginState(Context context, boolean isLoggedIn) {
        SharedPreferences prefs = context.getSharedPreferences("DL_Prefs", Context.MODE_PRIVATE);
        prefs.edit().putBoolean(PREF_IS_LOGGED_IN, isLoggedIn).apply();
    }

    private static void jumpToHiroUI(final Context context) {
        try {
            final Activity activity;
            if (appContext instanceof Activity) {
                activity = (Activity) appContext;
            } else if (context instanceof Activity) {
                activity = (Activity) context;
            } else {
                return;
            }
            mainHandler.post(() -> {
                try {
                    if (activity.isFinishing() || activity.isDestroyed()) {
                        return;
                    }
                    new HiroUI(activity).show();
                } catch (Exception e) {
                    try {
                        Toast.makeText(context, "Failed to load UI", Toast.LENGTH_SHORT).show();
                    } catch (Throwable ignored) {}
                }
            });
        } catch (Exception ignored) {}
    }
}
