package com.nyaui.me.module.misc;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class PingModule extends Module {
    public PingModule() {
        super("Ping", ModuleCategory.MISC);
    }
}
