package com.nyaui.me.module.visual;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;

public class ItemESPModule extends Module {
    public ItemESPModule() { super("ItemESP", ModuleCategory.VISUAL, ""); setChineseName("Item ESP"); }
    public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("ItemESP"); } catch (Throwable t) {} }
    public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("ItemESP"); } catch (Throwable t) {} }
}
