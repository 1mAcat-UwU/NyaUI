package com.nyaui.me.module.player;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class NoRotateSetModule extends Module {
    public NoRotateSetModule() {
        super("NoRotateSet", ModuleCategory.PLAYER);
    }
}
