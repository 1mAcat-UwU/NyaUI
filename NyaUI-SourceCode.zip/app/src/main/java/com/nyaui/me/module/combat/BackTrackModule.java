package com.nyaui.me.module.combat;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class BackTrackModule extends Module {
    public BackTrackModule() { super("BackTrack", ModuleCategory.COMBAT, ""); setChineseName("Backtrack"); }
    public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("BackTrack"); } catch (Throwable t) {} }
    public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("BackTrack"); } catch (Throwable t) {} }
    public void configureSubMenu(SubMenuPanel s) {
        super.configureSubMenu(s);
        String n = getName();
        s.addSlider("Detect Range", 5, 50, (int)SafeCall.getFloat(n, 0), "%.1f", v -> SafeCall.setFloat(n, 0, v));
        s.addSlider("Follow Distance", 1, 10, (int)(SafeCall.getFloat(n, 1) * 2), "%.1f", v -> SafeCall.setFloat(n, 1, v));
    }
}
