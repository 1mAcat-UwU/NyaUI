package com.nyaui.me.module.combat;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class SilentDoubleModule extends Module {
    public SilentDoubleModule() {
        super("SilentDouble", ModuleCategory.COMBAT);
    }
}
