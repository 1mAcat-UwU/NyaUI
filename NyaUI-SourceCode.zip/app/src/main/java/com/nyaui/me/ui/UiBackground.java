package com.nyaui.me.ui;

public final class UiBackground {
    public static final int DEFAULT_COLOR = 0xCC211F26;

    private UiBackground() {}

    public static ColorStyle style() {
        return new ColorStyle("UI", "background", DEFAULT_COLOR);
    }

    public static AnimatedBgDrawable create(float cornerPx) {
        AnimatedBgDrawable d = new AnimatedBgDrawable(style(), cornerPx);
        d.attach();
        return d;
    }
}
