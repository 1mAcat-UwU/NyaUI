package com.nyaui.me.module.render;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class CustomFovModule extends Module {
    public CustomFovModule() {
        super("CustomFov", ModuleCategory.RENDER);
    }
}
