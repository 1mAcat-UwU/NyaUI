package com.nyaui.me.module.render;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;

public class DrawPathModule extends Module {
    public DrawPathModule() { super("DrawPath", ModuleCategory.RENDER, ""); setChineseName("Draw Path"); }
    public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("DrawPath"); } catch (Throwable t) {} }
    public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("DrawPath"); } catch (Throwable t) {} }
}
