package com.nyaui.me.ui;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import com.nyaui.me.ui.SquircleDrawable;
import android.os.Build;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.nyaui.me.module.Module;
import com.nyaui.me.ui.widgets.SubMenuPanel;
import com.nyaui.me.ui.widgets.CustomSwitch;

public class ModuleCardView extends LinearLayout {

    private final Module module;
    private final float scaleFactor;
    private final TextView titleText;
    private final TextView contentText;
    private final CustomSwitch switchButton;
    private final TextView arrowIcon;
    private boolean isEnabled = false;
    private SubMenuPanel subMenuPanel;
    private boolean isSubMenuOpen = false;

    public ModuleCardView(Context context, Module module, float scaleFactor) {
        super(context);
        this.module = module;
        this.isEnabled = module.isEnabled();
        this.scaleFactor = scaleFactor;

        setOrientation(VERTICAL);
        LinearLayout.LayoutParams rootParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        rootParams.setMargins(0, scaled(4), 0, scaled(4));
        setLayoutParams(rootParams);
        setVisibility(View.VISIBLE);

        LinearLayout mainCard = new LinearLayout(context);
        mainCard.setOrientation(HORIZONTAL);
        LinearLayout.LayoutParams mainCardParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        mainCard.setLayoutParams(mainCardParams);
        mainCard.setPadding(scaled(16), scaled(14), scaled(12), scaled(14));
        mainCard.setGravity(Gravity.CENTER_VERTICAL);
        mainCard.setVisibility(View.VISIBLE);

        SquircleDrawable cardBg = new SquircleDrawable();
        cardBg.setColor(ThemeManager.getBgPrimary());
        cardBg.setCornerRadius(scaled(14));
        mainCard.setBackground(cardBg);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            mainCard.setElevation(0);
        }

        LinearLayout textArea = new LinearLayout(context);
        textArea.setOrientation(VERTICAL);
        LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(
            0,
            LinearLayout.LayoutParams.WRAP_CONTENT,
            1f
        );
        textParams.setMargins(0, 0, scaled(8), 0);
        textArea.setLayoutParams(textParams);
        textArea.setGravity(Gravity.CENTER_VERTICAL);
        textArea.setVisibility(View.VISIBLE);

        titleText = new TextView(context);
        titleText.setText(module.getDisplayName());
        titleText.setTextColor(ThemeManager.getTextPrimary());
        titleText.setTextSize(scaledFontSize(15));
        titleText.setTypeface(Typeface.DEFAULT_BOLD);
        titleText.setSingleLine(true);
        titleText.setMaxLines(1);
        titleText.setEllipsize(TextUtils.TruncateAt.END);
        titleText.setVisibility(View.VISIBLE);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        titleText.setLayoutParams(titleParams);

        contentText = new TextView(context);
        String desc = module.getDescription();
        if (desc == null || desc.isEmpty()) {
            contentText.setVisibility(View.GONE);
        } else {
            contentText.setText(desc);
            contentText.setVisibility(View.VISIBLE);
        }
        contentText.setTextColor(ThemeManager.getTextSecondary());
        contentText.setTextSize(scaledFontSize(12));
        contentText.setSingleLine(true);
        contentText.setMaxLines(1);
        contentText.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams contentParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        contentParams.setMargins(0, scaled(2), 0, 0);
        contentText.setLayoutParams(contentParams);

        textArea.addView(titleText);
        textArea.addView(contentText);
        mainCard.addView(textArea);

        LinearLayout controlArea = new LinearLayout(context);
        controlArea.setOrientation(HORIZONTAL);
        LinearLayout.LayoutParams controlParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        controlArea.setLayoutParams(controlParams);
        controlArea.setGravity(Gravity.CENTER_VERTICAL);
        controlArea.setVisibility(View.VISIBLE);

        switchButton = new CustomSwitch(context, module.getName(), module.getName(), isEnabled,
            (enabled) -> {
                if (enabled) {
                    module.enable();
                } else {
                    module.disable();
                }
                isEnabled = module.isEnabled();
            });
        switchButton.updateScale(scaleFactor);
        LinearLayout.LayoutParams switchParams = new LinearLayout.LayoutParams(
            scaled(48),
            scaled(28)
        );
        switchParams.setMargins(0, 0, scaled(8), 0);
        switchButton.setLayoutParams(switchParams);
        switchButton.setClickable(true);
        switchButton.setVisibility(View.VISIBLE);
        controlArea.addView(switchButton);

        arrowIcon = new TextView(context);
        arrowIcon.setText("▶");
        arrowIcon.setTextColor(ThemeManager.getTextSecondary());
        arrowIcon.setTextSize(scaledFontSize(12));
        arrowIcon.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams arrowParams = new LinearLayout.LayoutParams(
            scaled(24),
            scaled(24)
        );
        arrowIcon.setLayoutParams(arrowParams);
        arrowIcon.setVisibility(View.GONE);
        controlArea.addView(arrowIcon);

        mainCard.addView(controlArea);
        addView(mainCard);

        subMenuPanel = new SubMenuPanel(context, module, scaleFactor);

        subMenuPanel.setOnStateChangedListener(() -> {
            isSubMenuOpen = subMenuPanel.isOpen();
            updateArrowIcon();
        });
        addView(subMenuPanel);

        mainCard.setOnClickListener(v -> { SoundPlayer.playClick(); toggleSubMenu(); });

        switchButton.setOnTouchListener((v, event) -> {
            v.onTouchEvent(event);
            return true;
        });
    }

    private boolean subMenuBuilt = false;

    private void buildSubMenuContent() {
        if (subMenuBuilt) return;
        subMenuBuilt = true;

        if (module.supportsShortcut()) {
            subMenuPanel.addShortcutSwitch(module.isShortcutEnabled());
        }
        subMenuPanel.addKeybindSetting();
        if (hasAdditionalConfiguration(module)) {
            subMenuPanel.addDivider();
            addModuleSpecificConfigurationSafely(subMenuPanel, module);
        }
    }

    private void toggleModule() {
        module.toggle();
        isEnabled = module.isEnabled();
        switchButton.setChecked(isEnabled, false);
    }

    private void toggleSubMenu() {
        if (subMenuPanel.isOpen()) {
            subMenuPanel.toggle();
            isSubMenuOpen = subMenuPanel.isOpen();
            updateArrowIcon();
            return;
        }

        boolean needBuild = !subMenuBuilt;
        buildSubMenuContent();
        isSubMenuOpen = true;
        updateArrowIcon();
        if (needBuild) {
            post(() -> subMenuPanel.toggle());
        } else {
            subMenuPanel.toggle();
        }
    }

    private void updateArrowIcon() {
        if (arrowIcon == null) {
            return;
        }
        arrowIcon.setText(isSubMenuOpen ? "▼" : "▶");
    }

    public void syncWithModuleState(boolean enabled) {
        if (this.isEnabled != enabled) {
            this.isEnabled = enabled;
            switchButton.setChecked(enabled, false);
        }
    }

    public void updateThemeColors() {

        View mainCard = getChildAt(0);
        if (mainCard != null && mainCard.getBackground() instanceof SquircleDrawable) {
            ((SquircleDrawable) mainCard.getBackground()).setColor(ThemeManager.getBgPrimary());
            mainCard.invalidate();
        }

        if (titleText != null) {
            titleText.setTextColor(ThemeManager.getTextPrimary());
        }
        if (contentText != null) {
            contentText.setTextColor(ThemeManager.getTextSecondary());
        }
        if (arrowIcon != null) {
            arrowIcon.setTextColor(ThemeManager.getTextSecondary());
        }

        if (switchButton != null) {
            switchButton.invalidate();
        }

        if (subMenuPanel != null) {
            subMenuPanel.updateThemeColors();
        }
    }

    public Module getModule() {
        return module;
    }

    public boolean isModuleEnabled() {
        return isEnabled;
    }

    private void addModuleSpecificConfiguration(SubMenuPanel subMenu, Module module) {

        String className = module.getClass().getSimpleName();
        if (className.contains("Theme") ||
            className.contains("Notification") ||
            className.contains("Watermark") ||
            className.contains("Sound")) {

            try {

                module.configureSubMenu(subMenu);
                subMenu.appendModuleReset(module);
            } catch (Exception e) {

            }
        }

    }

    private void addModuleSpecificConfigurationOnly(SubMenuPanel subMenu, Module module) {

        String className = module.getClass().getSimpleName();
        if (className.contains("Theme") ||
            className.contains("Notification") ||
            className.contains("Sound")) {

            addCustomModuleConfiguration(subMenu, module);
        }

    }

    private void addCustomModuleConfiguration(SubMenuPanel subMenu, Module module) {
        String className = module.getClass().getSimpleName();

        if (className.contains("Theme")) {

        } else if (className.contains("Sound")) {

        }

    }

    private boolean hasAdditionalConfiguration(Module module) {

        String className = module.getClass().getSimpleName();

        return !className.contains("Watermark") &&
               (className.contains("Theme") ||
                className.contains("Sound") ||
                className.contains("Notification") ||
                className.contains("ArraylistModule") ||
                className.contains("Arraylist") ||
                className.contains("HUD") ||
                className.contains("ESP") ||
                className.contains("Test") ||
                className.contains("Color") ||
                className.contains("Display") ||

                true);
    }

    private void addModuleSpecificConfigurationSafely(SubMenuPanel subMenu, Module module) {

        try {
            module.configureSubMenu(subMenu);
            subMenu.appendModuleReset(module);
        } catch (Exception e) {

            android.util.Log.w("ModuleCardView", "Failed to configure module: " + module.getClass().getSimpleName(), e);
        }
    }

    private int scaled(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density * scaleFactor);
    }

    private float scaledFontSize(float sp) {
        return sp * scaleFactor;
    }

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density);
    }

    private class MaterialSwitch extends View {
        private final Paint trackPaint;
        private final Paint thumbPaint;
        private final RectF trackRect;
        private boolean isChecked = false;
        private float thumbPosition = 0f;
        private ValueAnimator thumbAnimator;
        private final float scale;

        public MaterialSwitch(Context context, float scaleFactor) {
            super(context);
            this.scale = scaleFactor;

            trackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            thumbPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            trackRect = new RectF();

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                scaled(52),
                scaled(32)
            );
            setLayoutParams(params);
            setMinimumWidth(scaled(52));
            setMinimumHeight(scaled(32));

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                setElevation(0);
            }
        }

                protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            setMeasuredDimension(scaled(52), scaled(32));
        }

                protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);

            int width = getWidth();
            int height = getHeight();
            if (width == 0 || height == 0) return;

            float radius = height / 2f;

            trackRect.set(0, 0, width, height);
            int trackColor = isChecked ? ThemeManager.getThemeColor() : ThemeManager.getStateDisabled();
            trackPaint.setColor(trackColor);
            canvas.drawRoundRect(trackRect, radius, radius, trackPaint);

            float thumbRadius = height / 2f - scaled(4);
            float thumbCenterX = scaled(4) + thumbRadius + (width - height) * thumbPosition;
            float thumbCenterY = height / 2f;

            thumbPaint.setColor(ThemeManager.getBgPrimary());
            thumbPaint.clearShadowLayer();

            canvas.drawCircle(thumbCenterX, thumbCenterY, thumbRadius, thumbPaint);
        }

        public void setChecked(boolean checked) {
            if (this.isChecked == checked && thumbAnimator != null && thumbAnimator.isRunning()) {
                return;
            }

            this.isChecked = checked;
            animateToPosition(checked ? 1f : 0f);
        }

        private void animateToPosition(float targetPosition) {
            if (thumbAnimator != null) {
                thumbAnimator.cancel();
            }

            thumbAnimator = ValueAnimator.ofFloat(thumbPosition, targetPosition);
            thumbAnimator.setDuration(250);
            thumbAnimator.setInterpolator(new DecelerateInterpolator());
            thumbAnimator.addUpdateListener(animation -> {
                thumbPosition = (float) animation.getAnimatedValue();
                invalidate();
            });
            thumbAnimator.start();
        }

                protected void onDetachedFromWindow() {
            super.onDetachedFromWindow();
            if (thumbAnimator != null) {
                thumbAnimator.cancel();
            }
        }
    }
}
