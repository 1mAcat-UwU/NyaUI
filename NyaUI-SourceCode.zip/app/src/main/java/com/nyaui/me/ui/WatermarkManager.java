package com.nyaui.me.ui;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.nyaui.me.config.ConfigManager;

public class WatermarkManager {
    private static WatermarkView watermarkView;
    private static PopupWindow popupWindow;
    private static boolean isShown = false;
    private static Activity currentActivity;
    private static final int MARGIN_DP = 16;

    public static void init(Activity activity) {
        currentActivity = activity;
    }

    public static void show() {
        if (isShown || currentActivity == null) return;

        currentActivity.runOnUiThread(() -> {
            try {
                hideImmediate();
                watermarkView = new WatermarkView(currentActivity);
                applyColorStyle();

                watermarkView.measure(
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
                );

                int width = Math.max(watermarkView.getMeasuredWidth(), 1);
                int height = Math.max(watermarkView.getMeasuredHeight(), 80);

                popupWindow = new PopupWindow(watermarkView, width, height, false);
                popupWindow.setTouchable(false);
                popupWindow.setFocusable(false);
                popupWindow.setOutsideTouchable(false);
                popupWindow.setClippingEnabled(true);

                android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
                bg.setColor(android.graphics.Color.TRANSPARENT);
                popupWindow.setBackgroundDrawable(bg);

                DisplayMetrics metrics = new DisplayMetrics();
                currentActivity.getWindowManager().getDefaultDisplay().getRealMetrics(metrics);
                View decorView = currentActivity.getWindow().getDecorView();
                int x = getPositionX(width, metrics.widthPixels);
                int y = getPositionY(height, metrics.heightPixels);

                decorView.post(() -> {
                    try {
                        if (popupWindow != null && !popupWindow.isShowing()) {
                            popupWindow.showAtLocation(decorView, Gravity.NO_GRAVITY, x, y);
                            isShown = true;
                        }
                    } catch (Exception e) {
                        isShown = false;
                    }
                });

            } catch (Exception e) {

                isShown = false;
                if (popupWindow != null) {
                    try {
                        popupWindow.dismiss();
                    } catch (Exception ignored) {}
                    popupWindow = null;
                }
            }
        });
    }

    public static void hide() {
        if (currentActivity == null) return;
        currentActivity.runOnUiThread(WatermarkManager::hideImmediate);
    }

    private static void hideImmediate() {
        try {
            if (popupWindow != null && popupWindow.isShowing()) popupWindow.dismiss();
        } catch (Exception ignored) {
        }
        popupWindow = null;
        watermarkView = null;
        isShown = false;
        onHideColor();
    }

    public static void updatePosition() {
        if (!isShown || popupWindow == null || watermarkView == null || currentActivity == null) {
            return;
        }

        currentActivity.runOnUiThread(() -> {
            DisplayMetrics metrics = new DisplayMetrics();
            currentActivity.getWindowManager().getDefaultDisplay().getRealMetrics(metrics);
            watermarkView.measure(
                    android.view.View.MeasureSpec.makeMeasureSpec(metrics.widthPixels, android.view.View.MeasureSpec.AT_MOST),
                    android.view.View.MeasureSpec.makeMeasureSpec(metrics.heightPixels, android.view.View.MeasureSpec.AT_MOST));
            int width = Math.max(watermarkView.getWidth(), watermarkView.getMeasuredWidth());
            int height = Math.max(watermarkView.getHeight(), watermarkView.getMeasuredHeight());
            if (width <= 0) width = 1;
            if (height <= 0) height = 1;
            int x = getPositionX(width, metrics.widthPixels);
            int y = getPositionY(height, metrics.heightPixels);

            if (popupWindow == null || watermarkView == null) return;
            if (popupWindow.isShowing()) {
                popupWindow.update(x, y, -1, -1);
            }
        });
    }

    public static void setTextAlpha(float alpha) {
        if (watermarkView != null && currentActivity != null) {
            currentActivity.runOnUiThread(() -> {
                try {

                    int alphaValue = (int) (alpha * 255);
                    if (alphaValue < 0) alphaValue = 0;
                    if (alphaValue > 255) alphaValue = 255;

                    int originalColor = watermarkView.getCurrentTextColor();
                    int red = Color.red(originalColor);
                    int green = Color.green(originalColor);
                    int blue = Color.blue(originalColor);
                    int newColor = Color.argb(alphaValue, red, green, blue);
                    watermarkView.setTextColor(newColor);
                } catch (Exception e) {

                }
            });
        }
    }

    public static void setColor(int color) {
        if (watermarkView == null || currentActivity == null) return;
        currentActivity.runOnUiThread(() -> applyColorStyle());
    }

    private static final Runnable wmTick = () -> {
        if (watermarkView == null) return;
        applyColorStyle();
    };

    private static void applyColorStyle() {
        if (watermarkView == null) return;
        ColorStyle style = new ColorStyle("HUD", "watermark_color", 0x80FFFFFF);
        if (style.isGradient()) {
            DynamicColorEngine.addListener(wmTick);
            int w = Math.max(watermarkView.getWidth(), 1);
            watermarkView.getPaint().setShader(
                    DynamicColorEngine.createFlowShader(w, watermarkView.getTextSize(), style.start(), style.end()));
            watermarkView.setTextColor(0xFFFFFFFF);
        } else {
            DynamicColorEngine.removeListener(wmTick);
            watermarkView.getPaint().setShader(null);
            watermarkView.setTextColor(style.solid());
        }
        watermarkView.invalidate();
    }

    public static void onHideColor() {
        DynamicColorEngine.removeListener(wmTick);
    }

    private static int getPositionX(int width, int screenWidth) {
        float x = ConfigManager.getFloat("HUD", "watermark_x", 4f) / 100f;
        x = Math.max(0f, Math.min(1f, x));
        return Math.round(Math.max(0, screenWidth - width) * x);
    }

    private static int getPositionY(int height, int screenHeight) {
        float y = ConfigManager.getFloat("HUD", "watermark_y", 4f) / 100f;
        y = Math.max(0f, Math.min(1f, y));
        return Math.round(Math.max(0, screenHeight - height) * y);
    }

    private static int dpToPx(int dp) {
        if (currentActivity == null) return dp;
        return (int) (dp * currentActivity.getResources().getDisplayMetrics().density + 0.5f);
    }

    public static void cleanup() {
        if (currentActivity != null) {
            currentActivity.runOnUiThread(WatermarkManager::hideImmediate);
        } else {
            hideImmediate();
        }
        currentActivity = null;
    }

    public static void refreshText() {
        if (currentActivity == null) return;
        currentActivity.runOnUiThread(() -> {
            try {
                if (watermarkView == null) {
                    if (ConfigManager.getBoolean("HUD", "watermark", true)) show();
                    return;
                }
                watermarkView.refreshText();
                watermarkView.measure(
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
                );
                if (popupWindow != null) {
                    int w = Math.max(watermarkView.getMeasuredWidth(), 1);
                    int h = Math.max(watermarkView.getMeasuredHeight(), 1);
                    popupWindow.update(w, h);
                }
                updatePosition();
                applyColorStyle();
            } catch (Throwable ignored) {}
        });
    }

}
