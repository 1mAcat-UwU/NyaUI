package com.nyaui.me.module.combat;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class BurrowModule extends Module {
    public BurrowModule() {
        super("Burrow", ModuleCategory.COMBAT);
    }
}
