package com.nyaui.me.module.render;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class NoRenderModule extends Module {
    public NoRenderModule() {
        super("NoRender", ModuleCategory.RENDER);
    }
}
