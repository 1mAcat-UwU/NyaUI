package com.nyaui.me.module.player;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class ReachModule extends Module {
    public ReachModule() {
        super("Reach", ModuleCategory.PLAYER);
        setChineseName("Reach");
    }

    protected void onEnable() {
        try { SafeCall.setEnabled("BlockReach"); } catch (Throwable t) {}
    }

    protected void onDisable() {
        try { SafeCall.setEnabled("BlockReach"); } catch (Throwable t) {}
    }

    public void configureSubMenu(SubMenuPanel subMenu) {
        super.configureSubMenu(subMenu);
        new BlockReachModule().configureSubMenu(subMenu);
    }
}
