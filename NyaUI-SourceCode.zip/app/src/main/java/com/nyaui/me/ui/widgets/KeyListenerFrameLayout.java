

package com.nyaui.me.ui.widgets;

import android.content.Context;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.widget.FrameLayout;

public class KeyListenerFrameLayout extends FrameLayout {

    private OnKeyListener keyListener;

    public KeyListenerFrameLayout(Context context) {
        super(context);
        setFocusable(true);
        setFocusableInTouchMode(true);
    }

        public void setOnKeyListener(OnKeyListener l) {
        this.keyListener = l;
    }

        public boolean dispatchKeyEvent(KeyEvent event) {
        if (keyListener != null && keyListener.onKey(this, event.getKeyCode(), event)) {
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

        public boolean onTouchEvent(MotionEvent event) {
        return false;
    }
}
