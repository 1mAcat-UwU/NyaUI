package com.nyaui.me.module.render;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class ViewModelModule extends Module {
    public ViewModelModule() {
        super("ViewModel", ModuleCategory.RENDER);
    }
}
