package com.nyaui.me.module.movement;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;

public class NoSlowDownModule extends Module {
    public NoSlowDownModule() { super("NoSlowDown", ModuleCategory.MOVEMENT, ""); setChineseName("No Slow"); }
    public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("NoSlowDown"); } catch (Throwable t) {} }
    public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("NoSlowDown"); } catch (Throwable t) {} }
}
