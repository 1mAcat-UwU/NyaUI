package com.nyaui.me.module.combat;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class AntiWeaknessModule extends Module {
    public AntiWeaknessModule() {
        super("AntiWeakness", ModuleCategory.COMBAT);
    }
}
