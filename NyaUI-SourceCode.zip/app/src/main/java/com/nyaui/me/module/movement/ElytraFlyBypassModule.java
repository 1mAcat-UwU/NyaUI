package com.nyaui.me.module.movement;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class ElytraFlyBypassModule extends Module {
    public ElytraFlyBypassModule() {
        super("ElytraFlyBypass", ModuleCategory.MOVEMENT);
    }
}
