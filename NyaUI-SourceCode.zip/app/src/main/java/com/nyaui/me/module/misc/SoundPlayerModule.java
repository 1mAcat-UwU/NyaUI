package com.nyaui.me.module.misc;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class SoundPlayerModule extends Module {
    public SoundPlayerModule() { super("SoundPlayer", ModuleCategory.MISC, ""); setChineseName("Sound"); }
    public boolean shouldShowInArraylist() { return false; }
}
