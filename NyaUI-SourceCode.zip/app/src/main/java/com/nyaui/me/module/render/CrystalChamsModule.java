package com.nyaui.me.module.render;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class CrystalChamsModule extends Module {
    public CrystalChamsModule() {
        super("CrystalChams", ModuleCategory.RENDER);
    }
}
