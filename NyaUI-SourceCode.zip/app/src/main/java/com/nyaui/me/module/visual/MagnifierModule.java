package com.nyaui.me.module.visual;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class MagnifierModule extends Module {
    public MagnifierModule() { super("Magnifier", ModuleCategory.VISUAL, ""); setChineseName("Magnifier"); }
    public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("Magnifier"); } catch (Throwable t) {} }
    public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("Magnifier"); } catch (Throwable t) {} }
    public void configureSubMenu(SubMenuPanel s) {
        super.configureSubMenu(s);
        s.addSlider("FOV", 60, 170, (int)SafeCall.getFloat(getName(), 0), "%d", v -> SafeCall.setFloat(getName(), 0, v));
    }
}
