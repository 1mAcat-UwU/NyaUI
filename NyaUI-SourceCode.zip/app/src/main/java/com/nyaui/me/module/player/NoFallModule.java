package com.nyaui.me.module.player;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;

public class NoFallModule extends Module {
    public NoFallModule() { super("NoFall", ModuleCategory.PLAYER, ""); setChineseName("No Fall Damage"); }
    public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("NoFall"); } catch (Throwable t) {} }
    public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("NoFall"); } catch (Throwable t) {} }
}
