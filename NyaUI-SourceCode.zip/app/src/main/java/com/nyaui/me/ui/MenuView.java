package com.nyaui.me.ui;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import com.nyaui.me.ui.BackgroundBlurHelper;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewOutlineProvider;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.view.ViewGroup;
import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.ModuleManager;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MenuView extends LinearLayout implements ThemeManager.OnThemeColorChangeListener, ThemeManager.OnThemeModeChangeListener, ThemeManager.OnRainbowColorUpdateListener {

    private static final String PREF_NAME = "menu_view_client";
    private static final String KEY_SCALE_FACTOR = "scale_factor";

    private final Context context;
    private final ModuleCategory category;
    private final MenuPosition position;
    private final SharedPreferences preferences;

    private boolean isExpanded = false;

    private final LinearLayout titleBar;
    private final ScrollView scrollView;
    private final LinearLayout contentLayout;

    private final Map<Module, ModuleItemView> moduleItems = new HashMap<>();
    private ValueAnimator expandAnimator;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private float touchStartX = 0f;
    private float touchStartY = 0f;
    private boolean isDragging = false;
    private final int touchSlop;

    private float scaleFactor = 1.0f;

    private final float baseScaleFactor;

    private static final long ANIMATION_DURATION = 250L;
    private static final float CORNER_RADIUS_DP = 8f;

    private int menuMaxWidth = 0;

    private final Runnable statusChecker = new Runnable() {
                public void run() {
            if (getVisibility() == View.VISIBLE && isExpanded) {
                refreshAllModuleStates();
                handler.postDelayed(this, 500);
            }
        }
    };

    public enum MenuPosition {
        POSITION_1, POSITION_2, POSITION_3, POSITION_4, POSITION_5
    }

    public MenuView(Context context, ModuleCategory category, MenuPosition position) {
        super(context);
        this.context = context;
        this.category = category;
        this.position = position;
        this.preferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        this.touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();

        this.baseScaleFactor = calculateBaseScaleFactor() * 0.75f;

        this.scaleFactor = 1.0f;

        setOrientation(VERTICAL);

        List<Module> modules = ModuleManager.getModulesByCategory(category);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(ThemeManager.getMenuBackground());
        bg.setCornerRadius(scaled(CORNER_RADIUS_DP));
        setBackground(bg);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            setClipToOutline(true);
            setOutlineProvider(ViewOutlineProvider.BACKGROUND);
            setElevation(0);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                BackgroundBlurHelper.attachBackgroundBlur(this, 80, 8.0f);
            }
        } else {
            setClipChildren(true);
            setClipToPadding(true);
        }

        ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        );
        setLayoutParams(layoutParams);

        int titleHeight = scaled(36);
        int spacing = scaled(12);
        setTranslationY(position.ordinal() * (titleHeight + spacing));

        titleBar = createTitleBar();
        addView(titleBar);

        scrollView = new ScrollView(context);
        scrollView.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, 0));
        scrollView.setVerticalScrollBarEnabled(false);
        scrollView.setVisibility(View.GONE);
        scrollView.setClipChildren(false);
        scrollView.setClipToPadding(false);

        contentLayout = new LinearLayout(context);
        contentLayout.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        contentLayout.setOrientation(VERTICAL);
        contentLayout.setPadding(0, 0, 0, 0);
        contentLayout.setClipChildren(false);

        for (Module module : modules) {
            ModuleItemView item = new ModuleItemView(context, module, this, baseScaleFactor * scaleFactor);
            moduleItems.put(module, item);
            contentLayout.addView(item);
        }

        scrollView.addView(contentLayout);
        addView(scrollView);

        setupTouchListeners();

        ThemeManager.addListener(this);
        ThemeManager.addModeListener(this);
        ThemeManager.addRainbowColorUpdateListener(this);
    }

    private void refreshAllModuleStates() {
        for (Map.Entry<Module, ModuleItemView> entry : moduleItems.entrySet()) {
            Module module = entry.getKey();
            ModuleItemView item = entry.getValue();
            item.syncWithModuleState(module.isEnabled());
        }
    }

    private float calculateBaseScaleFactor() {
        WindowManager windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getRealMetrics(metrics);
        float dpi = metrics.densityDpi;

        if (dpi <= 240) {
            return 0.7f;
        } else if (dpi <= 320) {
            return 0.85f;
        } else if (dpi <= 480) {
            return 1.0f;
        } else if (dpi <= 640) {
            return 1.15f;
        } else {
            return 1.3f;
        }
    }

    private int scaled(int baseDp) {
        return (int) (dpToPx(baseDp) * baseScaleFactor * scaleFactor);
    }

    private float scaled(float baseDp) {
        return dpToPx((int) baseDp) * baseScaleFactor * scaleFactor;
    }

    public float getScaleFactor() {
        return scaleFactor;
    }

    public void setScaleFactor(float factor) {
        factor = Math.max(0.5f, Math.min(2.0f, factor));
        if (Math.abs(this.scaleFactor - factor) < 0.01f) {
            return;
        }

        this.scaleFactor = factor;

        preferences.edit()
            .putFloat(KEY_SCALE_FACTOR, factor)
            .apply();

        rebuildUI();
    }

    public void increaseScale() {
        setScaleFactor(scaleFactor * 1.1f);
    }

    public void decreaseScale() {
        setScaleFactor(scaleFactor * 0.9f);
    }

    public void resetScale() {
        setScaleFactor(1.0f);
    }

    private void rebuildUI() {
        boolean wasExpanded = isExpanded;

        if (isExpanded) {
            collapseContent();
        }

        GradientDrawable bg = (GradientDrawable) getBackground();
        bg.setCornerRadius(scaled(CORNER_RADIUS_DP));

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            setElevation(0);
        }

        updateTitleBar();

        for (ModuleItemView item : moduleItems.values()) {
            item.updateScale(baseScaleFactor * scaleFactor);
        }

        menuMaxWidth = 0;
        measureInitialSize();

        if (wasExpanded) {
            handler.postDelayed(this::expandContent, 100);
        }
    }

    private void updateTitleBar() {
        int height = scaled(36);
        titleBar.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, height));
        titleBar.setPadding(scaled(14), 0, scaled(14), 0);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(ThemeManager.getMenuTitleBarBackground());
        bg.setCornerRadius(scaled(CORNER_RADIUS_DP));
        titleBar.setBackground(bg);

        TextView textView = (TextView) titleBar.getChildAt(0);
        textView.setTextSize(11.5f * baseScaleFactor * scaleFactor);
        textView.setTextColor(ThemeManager.getMenuTitleTextColor());
    }

    private LinearLayout createTitleBar() {
        LinearLayout bar = new LinearLayout(context);
        int height = scaled(36);
        bar.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, height));
        bar.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        bar.setPadding(scaled(14), 0, scaled(14), 0);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(ThemeManager.getMenuTitleBarBackground());
        bg.setCornerRadius(scaled(CORNER_RADIUS_DP));
        bar.setBackground(bg);

        TextView textView = new TextView(context);
        textView.setText(category.getDisplayName());
        textView.setTextSize(11.5f * baseScaleFactor * scaleFactor);
        textView.setTextColor(ThemeManager.getMenuTitleTextColor());
        textView.setTypeface(Typeface.DEFAULT_BOLD);
        bar.addView(textView);

        return bar;
    }

    private void setupTouchListeners() {
        final float[] lastRaw = new float[2];

        titleBar.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    touchStartX = event.getX();
                    touchStartY = event.getY();
                    lastRaw[0] = event.getRawX();
                    lastRaw[1] = event.getRawY();
                    isDragging = false;
                    return true;

                case MotionEvent.ACTION_MOVE:
                    float deltaX = Math.abs(event.getX() - touchStartX);
                    float deltaY = Math.abs(event.getY() - touchStartY);

                    if (!isDragging && (deltaX > touchSlop || deltaY > touchSlop)) {
                        isDragging = true;
                    }

                    if (isDragging) {
                        float nowRawX = event.getRawX();
                        float nowRawY = event.getRawY();
                        float moveDeltaX = nowRawX - lastRaw[0];
                        float moveDeltaY = nowRawY - lastRaw[1];
                        MenuView.this.setTranslationX(MenuView.this.getTranslationX() + moveDeltaX);
                        MenuView.this.setTranslationY(MenuView.this.getTranslationY() + moveDeltaY);
                        lastRaw[0] = nowRawX;
                        lastRaw[1] = nowRawY;
                    }
                    return true;

                case MotionEvent.ACTION_UP:
                    if (!isDragging) {
                        toggleExpand();
                    }
                    isDragging = false;
                    return true;

                case MotionEvent.ACTION_CANCEL:
                    isDragging = false;
                    return true;
            }
            return false;
        });
    }

    private void toggleExpand() {
        if (expandAnimator != null) expandAnimator.cancel();

        if (isExpanded) {
            collapseContent();
        } else {
            expandContent();
        }
    }

    private void expandContent() {
        isExpanded = true;
        scrollView.setVisibility(View.VISIBLE);

        WindowManager windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics screenSize = new DisplayMetrics();
        windowManager.getDefaultDisplay().getRealMetrics(screenSize);

        contentLayout.measure(
            MeasureSpec.makeMeasureSpec(menuMaxWidth, MeasureSpec.AT_MOST),
            MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED)
        );
        int maxHeight = (int) (screenSize.heightPixels * 0.5);
        int targetHeight = Math.min(contentLayout.getMeasuredHeight(), maxHeight);

        scrollView.setAlpha(0f);
        LayoutParams lp = (LayoutParams) scrollView.getLayoutParams();
        lp.height = 0;
        scrollView.setLayoutParams(lp);

        expandAnimator = ValueAnimator.ofInt(0, targetHeight);
        expandAnimator.setDuration(ANIMATION_DURATION);
        expandAnimator.setInterpolator(new DecelerateInterpolator());
        expandAnimator.addUpdateListener(animator -> {
            int value = (int) animator.getAnimatedValue();
            LayoutParams params = (LayoutParams) scrollView.getLayoutParams();
            params.height = value;
            scrollView.setLayoutParams(params);
            scrollView.setAlpha((float) value / targetHeight);
        });
        expandAnimator.start();

        handler.post(statusChecker);
    }

    private void collapseContent() {
        isExpanded = false;
        int startHeight = scrollView.getHeight();

        closeAllSubMenus();

        handler.removeCallbacks(statusChecker);

        expandAnimator = ValueAnimator.ofInt(startHeight, 0);
        expandAnimator.setDuration(ANIMATION_DURATION);
        expandAnimator.setInterpolator(new DecelerateInterpolator());
        expandAnimator.addUpdateListener(animator -> {
            int value = (int) animator.getAnimatedValue();
            LayoutParams params = (LayoutParams) scrollView.getLayoutParams();
            params.height = value;
            scrollView.setLayoutParams(params);
            if (startHeight > 0) {
                scrollView.setAlpha((float) value / startHeight);
            }
        });
        expandAnimator.addListener(new android.animation.AnimatorListenerAdapter() {
                        public void onAnimationEnd(android.animation.Animator animation) {
                scrollView.setVisibility(View.GONE);
            }
        });
        expandAnimator.start();
    }

    public void show() {
        setVisibility(View.VISIBLE);
        measureInitialSize();

        setAlpha(0f);
        setScaleX(0.8f);
        setScaleY(0.8f);
        animate()
            .alpha(1f)
            .scaleX(1f)
            .scaleY(1f)
            .setDuration(ANIMATION_DURATION)
            .setInterpolator(new DecelerateInterpolator())
            .start();

        if (isExpanded) {
            handler.post(statusChecker);
        }
    }

    private void measureInitialSize() {
        int fixedWidth = scaled(180);

        ViewGroup.LayoutParams params = getLayoutParams();
        if (params != null) {
            params.width = fixedWidth;
            setLayoutParams(params);
        }

        menuMaxWidth = fixedWidth;
    }

    public void hide() {
        handler.removeCallbacks(statusChecker);

        if (expandAnimator != null) expandAnimator.cancel();
        animate().cancel();

        for (ModuleItemView item : moduleItems.values()) {
            item.cancelAllAnimations();
        }

        animate()
            .alpha(0f)
            .scaleX(0.8f)
            .scaleY(0.8f)
            .setDuration(ANIMATION_DURATION)
            .setInterpolator(new DecelerateInterpolator())
            .withEndAction(() -> setVisibility(View.GONE))
            .start();
    }

    public void closeAllSubMenus() {
        for (ModuleItemView item : moduleItems.values()) {
            item.closeSubMenuIfOpen();
        }
    }

    public void recalculateHeight() {
        if (!isExpanded) {
            return;
        }

        WindowManager windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics screenSize = new DisplayMetrics();
        windowManager.getDefaultDisplay().getRealMetrics(screenSize);

        contentLayout.measure(
            MeasureSpec.makeMeasureSpec(menuMaxWidth, MeasureSpec.AT_MOST),
            MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED)
        );
        int maxHeight = (int) (screenSize.heightPixels * 0.5);
        int targetHeight = Math.min(contentLayout.getMeasuredHeight(), maxHeight);

        int currentHeight = scrollView.getHeight();
        if (currentHeight != targetHeight && currentHeight > 0) {
            if (expandAnimator != null) expandAnimator.cancel();

            expandAnimator = ValueAnimator.ofInt(currentHeight, targetHeight);
            expandAnimator.setDuration(200);
            expandAnimator.setInterpolator(new DecelerateInterpolator());
            expandAnimator.addUpdateListener(animator -> {
                int value = (int) animator.getAnimatedValue();
                LayoutParams params = (LayoutParams) scrollView.getLayoutParams();
                params.height = value;
                scrollView.setLayoutParams(params);
            });
            expandAnimator.start();
        }
    }

    public String getScaleInfo() {
        return String.format("基础缩放: %.2f, 用户缩放: %.2f, 总缩放: %.2f",
            baseScaleFactor, scaleFactor, baseScaleFactor * scaleFactor);
    }

        public void onThemeColorChanged(int newColor) {
        GradientDrawable bg = (GradientDrawable) getBackground();
        bg.setColor(ThemeManager.getMenuBackground());

        GradientDrawable titleBg = (GradientDrawable) titleBar.getBackground();
        titleBg.setColor(ThemeManager.getMenuTitleBarBackground());

        TextView titleText = (TextView) titleBar.getChildAt(0);
        titleText.setTextColor(ThemeManager.getMenuTitleTextColor());

        for (ModuleItemView item : moduleItems.values()) {
            item.updateThemeColor();
        }
    }

        public void onThemeModeChanged(boolean isDark) {

        TextView titleText = (TextView) titleBar.getChildAt(0);
        titleText.setTextColor(ThemeManager.getMenuTitleTextColor());

        GradientDrawable bg = (GradientDrawable) getBackground();
        bg.setColor(ThemeManager.getMenuBackground());

        GradientDrawable titleBg = (GradientDrawable) titleBar.getBackground();
        titleBg.setColor(ThemeManager.getMenuTitleBarBackground());

        for (ModuleItemView item : moduleItems.values()) {
            item.onThemeModeChanged(isDark);
        }
    }

        public void onRainbowColorUpdate(int color) {

    }

    public void destroy() {
        ThemeManager.removeListener(this);
        ThemeManager.removeModeListener(this);
        ThemeManager.removeRainbowColorUpdateListener(this);
        if (expandAnimator != null) expandAnimator.cancel();
        handler.removeCallbacksAndMessages(null);
    }

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density);
    }
}
