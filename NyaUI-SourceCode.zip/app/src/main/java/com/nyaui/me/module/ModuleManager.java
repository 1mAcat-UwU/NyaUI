package com.nyaui.me.module;

import com.nyaui.me.module.client.*;
import com.nyaui.me.module.combat.*;
import com.nyaui.me.module.movement.*;
import com.nyaui.me.module.player.*;
import com.nyaui.me.module.render.*;
import com.nyaui.me.module.misc.*;
import com.nyaui.me.module.exploit.*;
import com.nyaui.me.ui.SoundPlayer;
import java.util.ArrayList;
import java.util.List;
import java.util.Collections;

public class ModuleManager {
    private static final List<Module> modules = new ArrayList<>();
    private static final List<ModuleToggleListener> listeners = new ArrayList<>();
    private static final List<ShortcutToggleListener> shortcutListeners = new ArrayList<>();

    static {
        registerModules();
    }

    private static void registerModules() {
        registerCombat();
        registerMisc();
        registerRender();
        registerMovement();
        registerPlayer();
        registerExploit();
        registerClient();
    }

    private static void registerCombat() {
        register(new AnchorAuraModule());
        register(new AnchorAssistModule());
        register(new AntiPistonModule());
        register(new AntiRegearModule());
        register(new AntiWeaknessModule());
        register(new AuraModule());
        register(new AutoAnchorModule());
        register(new AutoCityModule());
        register(new AutoCrystalModule());
        register(new AutoEXPModule());
        register(new AutoPotModule());
        register(new AutoRegearModule());
        register(new AutoTrapModule());
        register(new BedAuraModule());
        register(new BlockerModule());
        register(new BurrowModule());
        register(new BurrowAssistModule());
        register(new CriticalsModule());
        register(new FeetTrapModule());
        register(new HoleFillerModule());
        register(new HoleKickModule());
        register(new PistonCrystalModule());
        register(new QuiverModule());
        register(new com.nyaui.me.module.combat.SelfFillModule());
        register(new SilentDoubleModule());
        register(new SpeedMineModule());
        register(new TFAuraModule());
        register(new VAnchorAuraModule());
        register(new VAutoCityModule());
        register(new VSpeedMineModule());
        register(new WebAuraModule());
        register(new WebFillerModule());
        register(new WebCleanerModule());
    }

    private static void registerMisc() {
        register(new AntiSpamModule());
        register(new AutoEZModule());
        register(new AutoPearlModule());
        register(new AutoReconnectModule());
        register(new AutoSpawnModule());
        register(new BaseFinderModule());
        register(new BedCrafterModule());
        register(new ChatEncrypterModule());
        register(new ChatSuffixModule());
        register(new ExceptionCatcherModule());
        register(new FakePlayerModule());
        register(new HCFModule());
        register(new MCPModule());
        register(new NoServerRPModule());
        register(new NoSoundLagModule());
        register(new PingModule());
        register(new PopCounterModule());
        register(new PortalGuiModule());
        register(new ShulkerViewerModule());
        register(new SilentDisconnectModule());
        register(new TimerModule());
    }

    private static void registerRender() {
        register(new TwoDESPModule());
        register(new AmbienceModule());
        register(new AspectRatioModule());
        register(new BlockHighlightModule());
        register(new BlockerESPModule());
        register(new BreakESPModule());
        register(new CameraClipModule());
        register(new CrosshairModule());
        register(new CrystalChamsModule());
        register(new CrystalPlaceESPModule());
        register(new CustomFovModule());
        register(new DesyncESPModule());
        register(new ESPModule());
        register(new HitmarkerModule());
        register(new HoleESPModule());
        register(new HotbarRefillModule());
        register(new LogoutSpotsModule());
        register(new NameTagsModule());
        register(new NoInterpModule());
        register(new NoRenderModule());
        register(new PlaceRenderModule());
        register(new PopChamsModule());
        register(new ShaderModule());
        register(new SkyboxModule());
        register(new SwingModifierModule());
        register(new TotemAnimationModule());
        register(new TotemParticleModule());
        register(new TrajectoriesModule());
        register(new ViewModelModule());
        register(new ZoomModule());
    }

    private static void registerMovement() {
        register(new AntiVoidModule());
        register(new AutoWalkModule());
        register(new BlockStrafeModule());
        register(new ElytraFlyModule());
        register(new ElytraFlyBypassModule());
        register(new ElytraFlyPlusModule());
        register(new EntityControlModule());
        register(new FastFallModule());
        register(new FastWebModule());
        register(new FlightModule());
        register(new HoleSnapModule());
        register(new InventoryMoveModule());
        register(new NoSlowModule());
        register(new PacketElytraModule());
        register(new PacketFlyModule());
        register(new SafeWalkModule());
        register(new SpeedModule());
        register(new SprintModule());
        register(new StepModule());
        register(new StrafeModule());
        register(new TickShiftModule());
        register(new VelocityModule());
    }

    private static void registerPlayer() {
        register(new AutoArmorModule());
        register(new AutoRespawnModule());
        register(new BugClipModule());
        register(new FastUseModule());
        register(new FreeCamModule());
        register(new FreeLookModule());
        register(new NoFallModule());
        register(new NoRotateSetModule());
        register(new NoSwapModule());
        register(new PacketEatModule());
        register(new ReachModule());
        register(new ReplenishModule());
        register(new ScaffoldModule());
        register(new SpinBotModule());
    }

    private static void registerExploit() {
        register(new AntiHungerModule());
        register(new AutoDupeModule());
        register(new BlinkModule());
        register(new BowBombModule());
        register(new FakeLagModule());
        register(new ForceSyncModule());
        register(new HitboxDesyncModule());
        register(new MineTweakModule());
        register(new PacketControlModule());
        register(new RaytraceBypassModule());
        register(new com.nyaui.me.module.exploit.SelfFillModule());
        register(new ServerLaggerModule());
    }

    private static void registerClient() {
        register(new ConfigModule());
        register(new DynamicIslandModule());
        register(new HUDModule());
        register(new ModuleListModule());
        register(new NotifyModule());
        register(new UIModule());
    }

    private static void register(Module module) {
        modules.add(module);
    }

    public static List<Module> getAllModules() {
        return Collections.unmodifiableList(modules);
    }

    public static List<Module> getModulesByCategory(ModuleCategory category) {
        List<Module> result = new ArrayList<>();
        for (Module module : modules) {
            if (module.getCategory() == category) result.add(module);
        }
        return result;
    }

    public static Module getModuleByName(String name) {
        for (Module module : modules) {
            if (module.getName().equalsIgnoreCase(name)) return module;
        }
        return null;
    }

    public static void addToggleListener(ModuleToggleListener listener) {
        if (listener != null && !listeners.contains(listener)) listeners.add(listener);
    }

    public static void removeToggleListener(ModuleToggleListener listener) {
        listeners.remove(listener);
    }

    public static void addShortcutListener(ShortcutToggleListener listener) {
        if (listener != null && !shortcutListeners.contains(listener)) shortcutListeners.add(listener);
    }

    public static void removeShortcutListener(ShortcutToggleListener listener) {
        shortcutListeners.remove(listener);
    }

    public static void notifyModuleToggled(Module module) {
        try {
            if (module.isEnabled()) SoundPlayer.playOnSound();
            else SoundPlayer.playOffSound();
        } catch (Throwable ignored) {
        }
        for (ModuleToggleListener listener : new ArrayList<>(listeners)) {
            try {
                listener.onModuleToggled(module);
            } catch (Throwable ignored) {
            }
        }
    }

    public static void notifyShortcutToggled(Module module, boolean enabled) {
        for (ShortcutToggleListener listener : new ArrayList<>(shortcutListeners)) {
            try {
                listener.onShortcutToggled(module, enabled);
            } catch (Throwable ignored) {
            }
        }
    }

    public static void disableAll() {
        for (Module module : modules) if (module.isEnabled()) module.disable();
    }

    private ModuleManager() {}
}
