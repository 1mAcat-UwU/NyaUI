package com.nyaui.me.module.client;

import com.nyaui.me.config.ConfigManager;
import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.ui.HUDManager;
import com.nyaui.me.ui.NotificationManager;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public final class NotifyModule extends Module {
    public NotifyModule() {
        super("Notify", ModuleCategory.CLIENT, "");
        setChineseName("Notify");
    }

    public boolean shouldShowInArraylist() { return false; }
    public boolean supportsShortcut() { return false; }

    protected void onEnable() {
        NotificationManager.setEnabled(true);
    }

    protected void onDisable() {
        NotificationManager.setEnabled(false);
        NotificationManager.clearAll();
    }

    public void configureSubMenu(SubMenuPanel subMenu) {
        super.configureSubMenu(subMenu);
        subMenu.addSlider("Duration", 500, 10000, ConfigManager.getInt("HUD", "notification_duration", 2000), "%dms", v -> HUDManager.setNotificationDuration(Math.round(v)));
        subMenu.addSlider("X", 0, 100, Math.round(ConfigManager.getFloat("HUD", "notifications_x", 100f)), "%d%%", v -> HUDManager.setNotificationPosition(v / 100f, null));
        subMenu.addSlider("Y", 0, 100, Math.round(ConfigManager.getFloat("HUD", "notifications_y", 100f)), "%d%%", v -> HUDManager.setNotificationPosition(null, v / 100f));
        subMenu.addColorPicker("Color", ConfigManager.getInt("HUD", "notifications_color", 0xFFFFFFFF), HUDManager::setNotificationColor);
    }
}
