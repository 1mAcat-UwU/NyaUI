package com.nyaui.me.module.misc;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;

public class NoPacketModule extends Module {
    public NoPacketModule() { super("NoPacket", ModuleCategory.MISC, ""); setChineseName("No Packet"); }
    public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("NoPacket"); } catch (Throwable t) {} }
    public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("NoPacket"); } catch (Throwable t) {} }
}
