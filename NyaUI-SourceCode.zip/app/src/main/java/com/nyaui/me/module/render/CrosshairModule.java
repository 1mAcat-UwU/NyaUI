package com.nyaui.me.module.render;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class CrosshairModule extends Module {
    public CrosshairModule() {
        super("Crosshair", ModuleCategory.RENDER);
    }
}
