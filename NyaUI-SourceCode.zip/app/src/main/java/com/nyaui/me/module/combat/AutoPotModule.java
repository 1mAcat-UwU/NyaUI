package com.nyaui.me.module.combat;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class AutoPotModule extends Module {
    public AutoPotModule() {
        super("AutoPot", ModuleCategory.COMBAT);
    }
}
