package com.nyaui.me.module.movement;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class FastFallModule extends Module {
    public FastFallModule() {
        super("FastFall", ModuleCategory.MOVEMENT);
    }
}
