package com.nyaui.me.module.misc;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class NoSoundLagModule extends Module {
    public NoSoundLagModule() {
        super("NoSoundLag", ModuleCategory.MISC);
    }
}
