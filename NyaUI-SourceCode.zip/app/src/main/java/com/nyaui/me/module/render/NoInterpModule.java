package com.nyaui.me.module.render;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class NoInterpModule extends Module {
    public NoInterpModule() {
        super("NoInterp", ModuleCategory.RENDER);
    }
}
