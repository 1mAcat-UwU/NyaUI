package com.nyaui.me.module.movement;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;

public class FastStopModule extends Module {
    public FastStopModule() { super("FastStop", ModuleCategory.MOVEMENT, ""); setChineseName("Fast Stop"); }
    public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("FastStop"); } catch (Throwable t) {} }
    public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("FastStop"); } catch (Throwable t) {} }
}
