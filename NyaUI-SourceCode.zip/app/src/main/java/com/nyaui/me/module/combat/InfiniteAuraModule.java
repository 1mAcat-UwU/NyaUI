package com.nyaui.me.module.combat;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;
import java.util.ArrayList;
import java.util.List;

public class InfiniteAuraModule extends Module {
    public InfiniteAuraModule() { super("InfiniteAura", ModuleCategory.COMBAT, ""); setChineseName("Infinite Aura"); }
    public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("InfiniteAura"); } catch (Throwable t) {} }
    public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("InfiniteAura"); } catch (Throwable t) {} }
    public void configureSubMenu(SubMenuPanel s) {
        super.configureSubMenu(s);
        String n = getName();
        s.addSlider("CPS", 1, 20, SafeCall.getInt(n, 0), "%d", v -> SafeCall.setInt(n, 0, (int)v));
        s.addSlider("Range", 10, 200, (int)SafeCall.getFloat(n, 0), "%.1f", v -> SafeCall.setFloat(n, 0, v));
        s.addSlider("Target Count", 1, 15, SafeCall.getInt(n, 1), "%d", v -> SafeCall.setInt(n, 1, (int)v));
        int cnt0 = SafeCall.getModeSize(n, 0); List<String> m0 = new ArrayList<>(); for (int i = 0; i < cnt0; i++) m0.add(SafeCall.getModeString(n, 0, i));
        s.addMode("Attack Mode", m0, SafeCall.getModeValue(n, 0), (index, name) -> SafeCall.setModeValue(n, 0, index));
        int cnt1 = SafeCall.getModeSize(n, 1); List<String> m1 = new ArrayList<>(); for (int i = 0; i < cnt1; i++) m1.add(SafeCall.getModeString(n, 1, i));
        s.addMode("Attack Style", m1, SafeCall.getModeValue(n, 1), (index, name) -> SafeCall.setModeValue(n, 1, index));
    }
}
