package com.nyaui.me.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Outline;
import android.graphics.Path;
import android.os.Build;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;

public class SquircleClipLayout extends FrameLayout {
    private final Path clip = new Path();
    private float radius = 0f;
    private float smoothing = 1.0f;
    private boolean useOutline;

    public SquircleClipLayout(Context c) {
        super(c);
        useOutline = Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP;
        if (useOutline) {
            setOutlineProvider(new ViewOutlineProvider() {
                public void getOutline(View v, Outline o) {
                    int w = v.getWidth(), h = v.getHeight();
                    if (w <= 0 || h <= 0) return;
                    float r = Math.min(radius, Math.min(w, h) / 2f);
                    o.setRoundRect(0, 0, w, h, Math.max(0f, r));
                }
            });
            setClipToOutline(true);
        }
    }

    public void setCornerRadius(float r) {
        if (radius == r) return;
        radius = r;
        if (useOutline) invalidateOutline();
        else { rebuild(getWidth(), getHeight()); invalidate(); }
    }

    public void setSmoothing(float s) {
        s = Math.max(0f, Math.min(1f, s));
        if (smoothing == s) return;
        smoothing = s;
        if (!useOutline) { rebuild(getWidth(), getHeight()); invalidate(); }
    }

        protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (useOutline) invalidateOutline();
        else rebuild(w, h);
    }

    private void rebuild(int w, int h) {
        if (w <= 0 || h <= 0) { clip.reset(); return; }
        SquircleDrawable.buildSquirclePath(clip, 0f, 0f, w, h, radius, smoothing);
    }

        protected void dispatchDraw(Canvas canvas) {
        if (useOutline) { super.dispatchDraw(canvas); return; }   
        if (clip.isEmpty() || radius <= 0.5f) { super.dispatchDraw(canvas); return; }
        int save = canvas.save();
        canvas.clipPath(clip);
        super.dispatchDraw(canvas);
        canvas.restoreToCount(save);
    }
}
