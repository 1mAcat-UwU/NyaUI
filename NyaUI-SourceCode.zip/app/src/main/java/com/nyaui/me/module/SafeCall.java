package com.nyaui.me.module;

import net.peach.ocean.ui.module.ModulesCall;

public final class SafeCall {
    private static boolean available = false;
    static {
        try {
            ModulesCall.getModuleEnabled("_test_");
            available = true;
        } catch (Throwable t) {
            available = false;
        }
    }

    public static boolean isAvailable() { return available; }

    public static boolean getEnabled(String n) {
        try { return ModulesCall.getModuleEnabled(n); } catch (Throwable t) { return false; }
    }
    public static void setEnabled(String n) {
        try { ModulesCall.setModuleEnabled(n); } catch (Throwable t) {}
    }
    public static float getFloat(String n, int i) {
        try { return ModulesCall.getModuleFloatValue(n, i); } catch (Throwable t) { return 0f; }
    }
    public static void setFloat(String n, int i, float v) {
        try { ModulesCall.setModuleFloatValue(n, i, v); } catch (Throwable t) {}
    }
    public static int getInt(String n, int i) {
        try { return ModulesCall.getModuleIntValue(n, i); } catch (Throwable t) { return 0; }
    }
    public static void setInt(String n, int i, int v) {
        try { ModulesCall.setModuleIntValue(n, i, v); } catch (Throwable t) {}
    }
    public static boolean getBool(String n, int i) {
        try { return ModulesCall.getModuleBoolValue(n, i); } catch (Throwable t) { return false; }
    }
    public static void setBool(String n, int i, boolean v) {
        try { ModulesCall.setModuleBoolValue(n, i, v); } catch (Throwable t) {}
    }
    public static int getModeSize(String n, int i) {
        try { return ModulesCall.getModuleModeSize(n, i); } catch (Throwable t) { return 0; }
    }
    public static String getModeString(String n, int mi, int ii) {
        try { return ModulesCall.getModuleModeString(n, mi, ii); } catch (Throwable t) { return ""; }
    }
    public static int getModeValue(String n, int i) {
        try { return ModulesCall.getModuleModeValue(n, i); } catch (Throwable t) { return 0; }
    }
    public static void setModeValue(String n, int i, int v) {
        try { ModulesCall.setModuleModeValue(n, i, v); } catch (Throwable t) {}
    }
    private SafeCall() {}
}
