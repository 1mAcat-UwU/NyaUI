package com.nyaui.me.module.render;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class PopChamsModule extends Module {
    public PopChamsModule() {
        super("PopChams", ModuleCategory.RENDER);
    }
}
