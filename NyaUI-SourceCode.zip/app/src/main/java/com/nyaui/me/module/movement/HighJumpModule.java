package com.nyaui.me.module.movement;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class HighJumpModule extends Module {
    public HighJumpModule() { super("HighJump", ModuleCategory.MOVEMENT, ""); setChineseName("High Jump"); }
    public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("HighJump"); } catch (Throwable t) {} }
    public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("HighJump"); } catch (Throwable t) {} }
    public void configureSubMenu(SubMenuPanel s) {
        super.configureSubMenu(s);
        s.addSlider("Height", 1, 100, (int)(SafeCall.getFloat(getName(), 0) * 10), "%.1f", v -> SafeCall.setFloat(getName(), 0, v / 10f));
    }
}
