package com.nyaui.me.module.combat;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class AutoTrapModule extends Module {
    public AutoTrapModule() {
        super("AutoTrap", ModuleCategory.COMBAT);
    }
}
