package com.nyaui.me.module.misc;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class ChatEncrypterModule extends Module {
    public ChatEncrypterModule() {
        super("ChatEncrypter", ModuleCategory.MISC);
    }
}
