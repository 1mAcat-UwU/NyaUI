package com.nyaui.me.module.misc;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;

public class CrasherModule extends Module {
    public CrasherModule() { super("Crasher", ModuleCategory.MISC, ""); setChineseName("Crasher"); }
    public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("Crasher"); } catch (Throwable t) {} }
    public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("Crasher"); } catch (Throwable t) {} }
}
