package com.nyaui.me.ui.widgets;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputFilter;
import android.text.Spanned;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.nyaui.me.ui.ThemeManager;

public final class TextInputDialog {

    public interface Callback {
        void onConfirm(String text);
    }

    private TextInputDialog() {}

    public static final InputFilter EMOJI_FILTER = new InputFilter() {
        public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
            if (source == null) return null;
            StringBuilder out = new StringBuilder();
            boolean changed = false;
            int i = start;
            while (i < end) {
                int cp = Character.codePointAt(source, i);
                int len = Character.charCount(cp);
                if (isEmojiRelated(cp)) {
                    changed = true;
                } else {
                    out.appendCodePoint(cp);
                }
                i += len;
            }
            return changed ? out.toString() : null;
        }
    };

    private static boolean isEmojiRelated(int cp) {
        if (cp == 0x200D || cp == 0xFE0E || cp == 0xFE0F || cp == 0x20E3) return true;
        if (cp >= 0x1F1E6 && cp <= 0x1F1FF) return true;
        if (cp >= 0x1F300 && cp <= 0x1FAFF) return true;
        if (cp >= 0x1F000 && cp <= 0x1F02F) return true;
        if (cp >= 0x1F0A0 && cp <= 0x1F0FF) return true;
        if (cp >= 0x2600 && cp <= 0x27BF) return true;
        if (cp >= 0x2300 && cp <= 0x23FF) return true;
        if (cp >= 0x2B00 && cp <= 0x2BFF) return true;
        if (cp >= 0xFE00 && cp <= 0xFE0F) return true;
        if (cp >= 0xE0020 && cp <= 0xE007F) return true;
        if (cp >= 0x1F3FB && cp <= 0x1F3FF) return true;
        return false;
    }

    public static String stripEmoji(String input) {
        if (input == null) return "";
        StringBuilder out = new StringBuilder();
        int i = 0;
        while (i < input.length()) {
            int cp = Character.codePointAt(input, i);
            int len = Character.charCount(cp);
            if (!isEmojiRelated(cp)) out.appendCodePoint(cp);
            i += len;
        }
        return out.toString();
    }

    public static void show(Activity activity, String initial, Callback callback) {
        if (activity == null || activity.isFinishing()) return;
        float d = activity.getResources().getDisplayMetrics().density;

        Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);

        LinearLayout root = new LinearLayout(activity);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (18 * d);
        root.setPadding(pad, pad, pad, pad);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(ThemeManager.getBgPrimary());
        bg.setCornerRadius(14 * d);
        bg.setStroke(Math.max(1, (int) (1 * d)), ThemeManager.getThemeColor() & 0x55FFFFFF);
        root.setBackground(bg);

        EditText input = new EditText(activity);
        input.setHint("Please enter text......");
        input.setHintTextColor(ThemeManager.getTextTertiary());
        input.setTextColor(ThemeManager.getTextPrimary());
        input.setTextSize(14f);
        input.setSingleLine(true);
        input.setFilters(new InputFilter[]{EMOJI_FILTER, new InputFilter.LengthFilter(64)});
        String start = stripEmoji(initial == null ? "" : initial);
        input.setText(start);
        if (start.length() > 0) input.setSelection(start.length());
        input.setBackgroundColor(ThemeManager.getBgSecondary());
        input.setPadding((int) (12 * d), (int) (10 * d), (int) (12 * d), (int) (10 * d));
        LinearLayout.LayoutParams inputLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        inputLp.bottomMargin = (int) (14 * d);
        root.addView(input, inputLp);

        LinearLayout buttons = new LinearLayout(activity);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.setGravity(Gravity.END);

        TextView cancel = makeBtn(activity, "Cancel", false, d);
        TextView confirm = makeBtn(activity, "Confirm", true, d);
        LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        btnLp.leftMargin = (int) (10 * d);
        buttons.addView(cancel);
        buttons.addView(confirm, btnLp);
        root.addView(buttons);

        cancel.setOnClickListener(v -> dialog.dismiss());
        confirm.setOnClickListener(v -> {
            String text = stripEmoji(input.getText() == null ? "" : input.getText().toString());
            dialog.dismiss();
            if (callback != null) callback.onConfirm(text);
        });

        dialog.setContentView(root);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            int width = (int) (activity.getResources().getDisplayMetrics().widthPixels * 0.78f);
            dialog.getWindow().setLayout(width, ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        dialog.show();
    }

    private static TextView makeBtn(Activity activity, String label, boolean primary, float d) {
        TextView tv = new TextView(activity);
        tv.setText(label);
        tv.setTextSize(13f);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setPadding((int) (14 * d), (int) (8 * d), (int) (14 * d), (int) (8 * d));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(8 * d);
        if (primary) {
            bg.setColor(ThemeManager.getThemeColor());
            tv.setTextColor(ThemeManager.getTextOnTheme());
        } else {
            bg.setColor(ThemeManager.getBgSecondary());
            tv.setTextColor(ThemeManager.getTextSecondary());
        }
        tv.setBackground(bg);
        tv.setClickable(true);
        return tv;
    }
}
