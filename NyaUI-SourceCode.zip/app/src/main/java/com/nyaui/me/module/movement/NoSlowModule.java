package com.nyaui.me.module.movement;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class NoSlowModule extends Module {
    public NoSlowModule() {
        super("NoSlow", ModuleCategory.MOVEMENT);
        setChineseName("NoSlow");
    }

    protected void onEnable() {
        try { SafeCall.setEnabled("NoSlowDown"); } catch (Throwable t) {}
    }

    protected void onDisable() {
        try { SafeCall.setEnabled("NoSlowDown"); } catch (Throwable t) {}
    }

    public void configureSubMenu(SubMenuPanel subMenu) {
        super.configureSubMenu(subMenu);
        new NoSlowDownModule().configureSubMenu(subMenu);
    }
}
