package com.nyaui.me.module.combat;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class HoleKickModule extends Module {
    public HoleKickModule() {
        super("HoleKick", ModuleCategory.COMBAT);
    }
}
