package com.nyaui.me.ui;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.nyaui.me.config.ConfigManager;
import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.ModuleManager;
import com.nyaui.me.ui.widgets.SubMenuPanel;

import java.util.HashMap;
import java.util.Map;

public class ClassicMenuView extends FrameLayout implements ThemeManager.OnThemeModeChangeListener, ThemeManager.OnThemeColorChangeListener {
    private static final String PREFS = "NyaUIClassicFrames";
    private final float density;
    private final Map<ModuleCategory, FrameLayout> frames = new HashMap<>();
    private final SharedPreferences positions;
    private float scale;
    private int frameWidth;
    private int frameHeight;

    public ClassicMenuView(Context context) {
        super(context);
        density = context.getResources().getDisplayMetrics().density;
        scale = ConfigManager.getUiScale();
        positions = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        setWillNotDraw(false);
        setClipChildren(false);
        setBackgroundColor(Color.TRANSPARENT);
        build();
        ThemeManager.addModeListener(this);
        ThemeManager.addListener(this);
    }

    private int dp(float value) {
        return Math.max(1, (int) (value * density * scale + 0.5f));
    }

    private int baseDp(float value) {
        return Math.max(1, (int) (value * density + 0.5f));
    }

    private int screenW() {
        return getResources().getDisplayMetrics().widthPixels;
    }

    private int screenH() {
        return getResources().getDisplayMetrics().heightPixels;
    }

    private int frameWidth() {
        int gap = dp(7);
        int available = Math.max(baseDp(260), screenW() - dp(20));
        int columns = screenW() >= baseDp(900) ? 4 : screenW() >= baseDp(620) ? 3 : 2;
        int w = (available - gap * (columns + 1)) / columns;
        return Math.max(dp(118), Math.min(dp(210), w));
    }

    private int frameHeight() {
        return Math.max(dp(210), Math.min(screenH() - dp(24), (int) (screenH() * 0.62f)));
    }

    private int columns() {
        if (screenW() >= baseDp(900)) return 4;
        if (screenW() >= baseDp(620)) return 3;
        return 2;
    }

    private void build() {
        removeAllViews();
        frames.clear();
        frameWidth = frameWidth();
        frameHeight = frameHeight();

        ModuleCategory[] categories = {
                ModuleCategory.COMBAT,
                ModuleCategory.MOVEMENT,
                ModuleCategory.PLAYER,
                ModuleCategory.VISUAL,
                ModuleCategory.WORLD,
                ModuleCategory.MISC,
                ModuleCategory.SETTINGS
        };

        for (int i = 0; i < categories.length; i++) {
            addCategoryFrame(categories[i], i);
        }
    }

    private void addCategoryFrame(ModuleCategory category, int index) {
        FrameLayout frame = new FrameLayout(getContext());
        frame.setBackground(createPanelBackground());
        frame.setElevation(dp(3));
        frame.setClipChildren(true);

        LinearLayout root = new LinearLayout(getContext());
        root.setOrientation(LinearLayout.VERTICAL);
        frame.addView(root, new FrameLayout.LayoutParams(-1, -1));

        TextView header = new TextView(getContext());
        header.setText(category.getDisplayName());
        header.setTextColor(ThemeManager.getThemeColor());
        header.setTextSize(Math.max(9f, 11f * scale));
        header.setTypeface(Typeface.DEFAULT_BOLD);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(8), 0, dp(8), 0);
        header.setBackgroundColor(ThemeManager.getBgSecondary());
        root.addView(header, new LinearLayout.LayoutParams(-1, dp(27)));
        installDrag(frame, header, category);

        ScrollView scroll = new ScrollView(getContext());
        scroll.setFillViewport(false);
        scroll.setVerticalScrollBarEnabled(true);
        scroll.setHorizontalScrollBarEnabled(false);
        LinearLayout content = new LinearLayout(getContext());
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(2), dp(2), dp(2), dp(4));
        scroll.addView(content, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        for (Module module : ModuleManager.getModulesByCategory(category)) {
            addModule(content, module);
        }

        frames.put(category, frame);
        addView(frame, createFrameLayoutParams(index));
        frame.post(() -> restoreOrClampPosition(category, frame, index));
    }

    private FrameLayout.LayoutParams createFrameLayoutParams(int index) {
        int cols = columns();
        int col = index % cols;
        int row = index / cols;
        int gap = dp(7);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(frameWidth, frameHeight);
        lp.leftMargin = gap + col * (frameWidth + gap);
        lp.topMargin = gap + row * (frameHeight + gap);
        return lp;
    }

    private GradientDrawable createPanelBackground() {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(ThemeManager.getBgPrimary());
        drawable.setStroke(dp(1), ThemeManager.getStateDisabled());
        drawable.setCornerRadius(dp(2));
        return drawable;
    }

    private void applyRowStyle(View row, TextView name, TextView more, boolean enabled) {
        int normal = ThemeManager.getBgPrimary();
        int enabledBg = blend(ThemeManager.getBgPrimary(), ThemeManager.getThemeColor(), 0.18f);
        row.setBackgroundColor(enabled ? enabledBg : normal);
        name.setTextColor(enabled ? ThemeManager.getThemeColor() : ThemeManager.getTextPrimary());
        more.setTextColor(ThemeManager.getTextTertiary());
    }

    private int blend(int a, int b, float t) {
        float it = 1f - t;
        return Color.argb((int)(Color.alpha(a)*it + Color.alpha(b)*t),
                (int)(Color.red(a)*it + Color.red(b)*t),
                (int)(Color.green(a)*it + Color.green(b)*t),
                (int)(Color.blue(a)*it + Color.blue(b)*t));
    }

    private void addModule(LinearLayout content, Module module) {
        LinearLayout holder = new LinearLayout(getContext());
        holder.setOrientation(LinearLayout.VERTICAL);
        content.addView(holder, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout row = new LinearLayout(getContext());
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(6), 0, dp(2), 0);

        TextView name = new TextView(getContext());
        name.setText(module.getDisplayName());
        name.setTextSize(Math.max(8f, 10.5f * scale));
        name.setSingleLine(true);
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        row.addView(name, new LinearLayout.LayoutParams(0, dp(28), 1f));

        TextView more = new TextView(getContext());
        more.setText("...");
        more.setTextSize(Math.max(9f, 11f * scale));
        more.setGravity(Gravity.CENTER);
        more.setTextColor(ThemeManager.getTextTertiary());
        row.addView(more, new LinearLayout.LayoutParams(dp(27), dp(28)));
        holder.addView(row);
        applyRowStyle(row, name, more, module.isEnabled());

        SubMenuPanel sub = new SubMenuPanel(getContext(), module, Math.max(0.5f, scale), true);
        try {
            module.configureSubMenu(sub);
        } catch (Throwable ignored) {
        }
        holder.addView(sub, new LinearLayout.LayoutParams(-1, 0));

        row.setOnClickListener(v -> {
            SoundPlayer.playClick();
            module.toggle();
            applyRowStyle(row, name, more, module.isEnabled());
        });

        more.setOnClickListener(v -> {
            SoundPlayer.playClick();
            sub.toggle();
        });
    }

    private void installDrag(FrameLayout frame, View handle, ModuleCategory category) {
        handle.setOnTouchListener(new OnTouchListener() {
            float lastX;
            float lastY;
            boolean moved;

                        public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        lastX = event.getRawX();
                        lastY = event.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = event.getRawX() - lastX;
                        float dy = event.getRawY() - lastY;
                        if (Math.abs(dx) > 1 || Math.abs(dy) > 1) moved = true;
                        float nx = frame.getX() + dx;
                        float ny = frame.getY() + dy;
                        float maxX = Math.max(0, getWidth() - frame.getWidth());
                        float maxY = Math.max(0, getHeight() - frame.getHeight());
                        frame.setX(Math.max(0, Math.min(maxX, nx)));
                        frame.setY(Math.max(0, Math.min(maxY, ny)));
                        lastX = event.getRawX();
                        lastY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (moved) savePosition(category, frame);
                        return true;
                    case MotionEvent.ACTION_CANCEL:
                        if (moved) savePosition(category, frame);
                        return true;
                    default:
                        return false;
                }
            }
        });
    }

    private void savePosition(ModuleCategory category, View frame) {
        positions.edit()
                .putInt(category.name() + "_x", Math.round(frame.getX()))
                .putInt(category.name() + "_y", Math.round(frame.getY()))
                .apply();
    }

    private void restoreOrClampPosition(ModuleCategory category, View frame, int index) {
        int defaultCols = columns();
        int defaultGap = dp(7);
        int col = index % defaultCols;
        int row = index / defaultCols;
        int defaultX = defaultGap + col * (frameWidth + defaultGap);
        int defaultY = defaultGap + row * (frameHeight + defaultGap);
        int x = positions.getInt(category.name() + "_x", defaultX);
        int y = positions.getInt(category.name() + "_y", defaultY);
        int maxX = Math.max(0, getWidth() - frame.getWidth());
        int maxY = Math.max(0, getHeight() - frame.getHeight());
        frame.setX(Math.max(0, Math.min(maxX, x)));
        frame.setY(Math.max(0, Math.min(maxY, y)));
    }

    public void applyScale(float newScale) {
        scale = Math.max(0.5f, Math.min(1.2f, newScale));
        ConfigManager.setUiScale(scale);
        build();
        requestLayout();
    }

    public void show() {
        setAlpha(0f);
        setVisibility(VISIBLE);
        animate().alpha(1f).setDuration(120).start();
    }

    public void hide(Runnable after) {
        animate().alpha(0f).setDuration(100).withEndAction(() -> {
            setVisibility(GONE);
            if (after != null) after.run();
        }).start();
    }

    public void destroy() {
        ThemeManager.removeListener(this);
        ThemeManager.removeModeListener(this);
        removeAllViews();
        frames.clear();
    }

        public void onThemeModeChanged(boolean isDark) {
        build();
    }

        public void onThemeColorChanged(int newColor) {
        refreshThemeInPlace();
    }

    private void refreshThemeInPlace() {
        for (Map.Entry<ModuleCategory, FrameLayout> entry : frames.entrySet()) {
            FrameLayout frame = entry.getValue();
            frame.setBackground(createPanelBackground());
            refreshChildren(frame);
        }
        invalidate();
    }

    private void refreshChildren(View view) {
        if (view instanceof SubMenuPanel) {
            ((SubMenuPanel) view).updateThemeColors();
            return;
        }
        if (view instanceof TextView) {
            TextView tv = (TextView) view;
            if (tv.getText() != null && entryIsHeader(tv)) {
                tv.setTextColor(ThemeManager.getThemeColor());
                tv.setBackgroundColor(ThemeManager.getBgSecondary());
            }
        }
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) {
                View child = group.getChildAt(i);
                if (child instanceof LinearLayout) {
                    LinearLayout linearChild = (LinearLayout) child;
                    if (linearChild.getChildCount() >= 2
                            && linearChild.getChildAt(0) instanceof TextView
                            && linearChild.getChildAt(1) instanceof TextView) {
                        TextView name = (TextView) linearChild.getChildAt(0);
                        TextView more = (TextView) linearChild.getChildAt(1);
                        Module module = findModuleByDisplayName(name.getText().toString());
                        if (module != null) {
                            applyRowStyle(linearChild, name, more, module.isEnabled());
                        }
                    }
                }
                refreshChildren(child);
            }
        }
    }

    private boolean entryIsHeader(TextView tv) {
        return tv.getText() != null && ModuleCategoryNames.contains(tv.getText().toString());
    }

    private Module findModuleByDisplayName(String text) {
        for (Module m : ModuleManager.getAllModules()) {
            if (m.getDisplayName().equals(text)) return m;
        }
        return null;
    }

    private static final java.util.Set<String> ModuleCategoryNames = new java.util.HashSet<>();

    static {
        for (ModuleCategory c : ModuleCategory.values()) ModuleCategoryNames.add(c.getDisplayName());
    }
}
