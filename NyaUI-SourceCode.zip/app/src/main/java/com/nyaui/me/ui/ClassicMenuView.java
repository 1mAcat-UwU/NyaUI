package com.nyaui.me.ui;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.ImageView;
import android.widget.TextView;

import com.nyaui.me.config.ConfigManager;
import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.ModuleManager;
import com.nyaui.me.ui.widgets.SubMenuPanel;

import java.util.HashMap;
import java.util.Map;

public class ClassicMenuView extends FrameLayout implements ThemeManager.OnThemeModeChangeListener, ThemeManager.OnThemeColorChangeListener {
    private static final String PREFS = "NyaUIClassicFrames";
    private static final int LAYOUT_VERSION = 2;
    private final float density;
    private final Map<ModuleCategory, FrameLayout> frames = new HashMap<>();
    private final SharedPreferences positions;
    private FrameLayout canvas;
    private float scale;
    private int frameWidth;
    private int frameHeight;
    private ValueAnimator heightAnimator;
    private LinearLayout profileCapsule;
    private ImageView capsuleAvatar;
    private TextView capsuleUsername;
    private TextView capsuleBio;

    public ClassicMenuView(Context context) {
        super(context);
        density = context.getResources().getDisplayMetrics().density;
        scale = ConfigManager.getUiScale();
        positions = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        setWillNotDraw(false);
        setClipChildren(false);
        setBackgroundColor(Color.TRANSPARENT);
        build();
        ThemeManager.addModeListener(this);
        ThemeManager.addListener(this);
    }

    private int dp(float value) {
        return Math.max(1, (int) (value * density * scale + 0.5f));
    }

    private int baseDp(float value) {
        return Math.max(1, (int) (value * density + 0.5f));
    }

    private int screenW() {
        return getResources().getDisplayMetrics().widthPixels;
    }

    private int screenH() {
        return getResources().getDisplayMetrics().heightPixels;
    }

    private int frameWidth() {
        int count = categories().length;
        int gap = dp(7);
        int available = Math.max(dp(42), screenW() - gap * (count + 1));
        int preferred = dp(158);
        return Math.max(dp(42), Math.min(preferred, available / count));
    }

    private int frameHeight() {
        return Math.max(dp(250), Math.min(screenH() - dp(24), (int) (screenH() * 0.72f)));
    }

    private ModuleCategory[] categories() {
        return new ModuleCategory[] {
                ModuleCategory.COMBAT,
                ModuleCategory.MISC,
                ModuleCategory.RENDER,
                ModuleCategory.MOVEMENT,
                ModuleCategory.PLAYER,
                ModuleCategory.EXPLOIT,
                ModuleCategory.CLIENT
        };
    }

    private void detachPanelBackgrounds() {
        if (frames != null) {
            for (FrameLayout frame : frames.values()) {
                if (frame == null) continue;
                android.graphics.drawable.Drawable d = frame.getBackground();
                if (d instanceof AnimatedBgDrawable) {
                    ((AnimatedBgDrawable) d).detach();
                }
            }
        }
        if (profileCapsule != null) {
            android.graphics.drawable.Drawable d = profileCapsule.getBackground();
            if (d instanceof AnimatedBgDrawable) {
                ((AnimatedBgDrawable) d).detach();
            }
        }
    }

    private void build() {
        detachPanelBackgrounds();
        removeAllViews();
        frames.clear();
        frameWidth = frameWidth();
        frameHeight = frameHeight();

        canvas = new FrameLayout(getContext());
        canvas.setClipChildren(false);
        addView(canvas, new FrameLayout.LayoutParams(-1, -1));

        ModuleCategory[] categories = categories();
        for (int i = 0; i < categories.length; i++) {
            addCategoryFrame(categories[i], i);
        }
        addProfileCapsule();
        UserProfile.addListener(this::refreshCapsule);
    }

    private void addCategoryFrame(ModuleCategory category, int index) {
        FrameLayout frame = new FrameLayout(getContext());
        frame.setBackground(createPanelBackground());
        frame.setElevation(dp(2));
        frame.setClipChildren(true);

        LinearLayout root = new LinearLayout(getContext());
        root.setOrientation(LinearLayout.VERTICAL);
        frame.addView(root, new FrameLayout.LayoutParams(-1, -1));

        TextView header = new TextView(getContext());
        header.setText(category.getDisplayName());
        header.setTextColor(ThemeManager.getThemeColor());
        header.setTextSize(Math.max(9f, 11f * scale));
        header.setTypeface(Typeface.DEFAULT_BOLD);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(8), 0, dp(8), 0);
        header.setBackgroundColor(ThemeManager.getBgSecondary());
        root.addView(header, new LinearLayout.LayoutParams(-1, dp(29)));

        ScrollView scroll = new ScrollView(getContext());
        scroll.setFillViewport(false);
        scroll.setVerticalScrollBarEnabled(true);
        scroll.setHorizontalScrollBarEnabled(false);
        LinearLayout content = new LinearLayout(getContext());
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(3), dp(4), dp(3), dp(5));
        scroll.addView(content, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        for (Module module : ModuleManager.getModulesByCategory(category)) {
            addModule(content, module);
        }

        frames.put(category, frame);
        canvas.addView(frame, createFrameLayoutParams(index));
        installDrag(frame, header, category);
        frame.post(() -> restoreOrClampPosition(category, frame, index));

        boolean collapsed = positions.getBoolean(collapseKey(category), false);
        if (collapsed) {
            frame.setTag(Boolean.TRUE);
            applyCollapsedState(frame, true, false);
        } else {
            frame.setTag(Boolean.FALSE);
        }
    }

    private FrameLayout.LayoutParams createFrameLayoutParams(int index) {
        int gap = dp(7);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(frameWidth, frameHeight);
        lp.leftMargin = gap + index * (frameWidth + gap);
        lp.topMargin = dp(7);
        return lp;
    }

    private android.graphics.drawable.Drawable createPanelBackground() {
        AnimatedBgDrawable d = UiBackground.create(dp(6));
        return d;
    }

    private void applyRowStyle(View row, TextView name, TextView more, boolean enabled) {
        int normal = ThemeManager.getBgPrimary();
        int enabledBg = blend(ThemeManager.getBgPrimary(), ThemeManager.getThemeColor(), 0.18f);
        row.setBackgroundColor(enabled ? enabledBg : normal);
        name.setTextColor(enabled ? ThemeManager.getThemeColor() : ThemeManager.getTextPrimary());
        more.setTextColor(ThemeManager.getTextTertiary());
    }

    private int blend(int a, int b, float t) {
        float it = 1f - t;
        return Color.argb((int)(Color.alpha(a)*it + Color.alpha(b)*t),
                (int)(Color.red(a)*it + Color.red(b)*t),
                (int)(Color.green(a)*it + Color.green(b)*t),
                (int)(Color.blue(a)*it + Color.blue(b)*t));
    }

    private void addModule(LinearLayout content, Module module) {
        LinearLayout holder = new LinearLayout(getContext());
        holder.setOrientation(LinearLayout.VERTICAL);
        content.addView(holder, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout row = new LinearLayout(getContext());
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(6), 0, dp(2), 0);

        TextView name = new TextView(getContext());
        name.setText(module.getDisplayName());
        name.setTextSize(Math.max(8.5f, 10.5f * scale));
        name.setSingleLine(true);
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        row.addView(name, new LinearLayout.LayoutParams(0, dp(30), 1f));

        TextView more = new TextView(getContext());
        more.setText("⋯");
        more.setTextSize(Math.max(10f, 13f * scale));
        more.setGravity(Gravity.CENTER);
        more.setTextColor(ThemeManager.getTextTertiary());
        row.addView(more, new LinearLayout.LayoutParams(dp(24), dp(30)));
        holder.addView(row);
        applyRowStyle(row, name, more, module.isEnabled());

        SubMenuPanel sub = new SubMenuPanel(getContext(), module, Math.max(0.5f, scale), true);
        try {
            module.configureSubMenu(sub);
            sub.appendModuleReset(module);
        } catch (Throwable ignored) {
        }
        holder.addView(sub, new LinearLayout.LayoutParams(-1, 0));

        row.setOnClickListener(v -> {
            SoundPlayer.playClick();
            module.toggle();
            applyRowStyle(row, name, more, module.isEnabled());
        });

        more.setOnClickListener(v -> {
            SoundPlayer.playClick();
            sub.toggle();
        });
    }

    private void installDrag(FrameLayout frame, View handle, ModuleCategory category) {
        handle.setOnTouchListener(new OnTouchListener() {
            float lastX;
            float lastY;
            boolean moved;

            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        lastX = event.getRawX();
                        lastY = event.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = event.getRawX() - lastX;
                        float dy = event.getRawY() - lastY;
                        if (Math.abs(dx) > 2 || Math.abs(dy) > 2) moved = true;
                        float nx = frame.getX() + dx;
                        float ny = frame.getY() + dy;
                        float maxX = Math.max(0, canvas.getWidth() - frame.getWidth());
                        float maxY = Math.max(0, canvas.getHeight() - frame.getHeight());
                        frame.setX(Math.max(0, Math.min(maxX, nx)));
                        frame.setY(Math.max(0, Math.min(maxY, ny)));
                        lastX = event.getRawX();
                        lastY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (moved) {
                            savePosition(category, frame);
                        } else {
                            toggleCategoryFrame(category, frame);
                        }
                        return true;
                    case MotionEvent.ACTION_CANCEL:
                        if (moved) savePosition(category, frame);
                        return true;
                    default:
                        return false;
                }
            }
        });
    }

    private String collapseKey(ModuleCategory category) {
        return category.name() + "_collapsed";
    }

    private void toggleCategoryFrame(ModuleCategory category, FrameLayout frame) {
        boolean collapsed = Boolean.TRUE.equals(frame.getTag());
        boolean next = !collapsed;
        frame.setTag(next ? Boolean.TRUE : Boolean.FALSE);
        positions.edit().putBoolean(collapseKey(category), next).apply();
        applyCollapsedState(frame, next, true);
    }

    private void applyCollapsedState(FrameLayout frame, boolean collapsed, boolean animate) {
        ViewGroup root = (ViewGroup) frame.getChildAt(0);
        if (root == null || root.getChildCount() < 2) return;
        View content = root.getChildAt(1);
        int targetHeight = collapsed ? dp(29) : frameHeight;
        int startHeight = frame.getLayoutParams() != null && frame.getLayoutParams().height > 0
                ? frame.getLayoutParams().height : (collapsed ? frameHeight : dp(29));

        if (!animate) {
            content.setAlpha(collapsed ? 0f : 1f);
            content.setVisibility(collapsed ? GONE : VISIBLE);
            ViewGroup.LayoutParams lp = frame.getLayoutParams();
            lp.height = targetHeight;
            frame.setLayoutParams(lp);
            return;
        }

        if (heightAnimator != null) heightAnimator.cancel();
        content.setVisibility(VISIBLE);
        float startAlpha = collapsed ? 1f : 0f;
        float endAlpha = collapsed ? 0f : 1f;
        content.setAlpha(startAlpha);
        ValueAnimator animator = ValueAnimator.ofInt(startHeight, targetHeight);
        animator.setDuration(170);
        animator.addUpdateListener(a -> {
            ViewGroup.LayoutParams lp = frame.getLayoutParams();
            lp.height = (int) a.getAnimatedValue();
            frame.setLayoutParams(lp);
            float t = a.getAnimatedFraction();
            content.setAlpha(startAlpha + (endAlpha - startAlpha) * t);
        });
        animator.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(android.animation.Animator animation) {
                content.setVisibility(collapsed ? GONE : VISIBLE);
                content.setAlpha(collapsed ? 0f : 1f);
            }
        });
        animator.start();
    }

    private void savePosition(ModuleCategory category, View frame) {
        positions.edit()
                .putInt(category.name() + "_x", Math.round(frame.getX()))
                .putInt(category.name() + "_y", Math.round(frame.getY()))
                .apply();
    }

    private void restoreOrClampPosition(ModuleCategory category, FrameLayout frame, int index) {
        int defaultGap = dp(7);
        int defaultX = defaultGap + index * (frameWidth + defaultGap);
        int defaultY = defaultGap;
        int storedVersion = positions.getInt("layout_version", 0);
        int x = storedVersion == LAYOUT_VERSION ? positions.getInt(category.name() + "_x", defaultX) : defaultX;
        int y = storedVersion == LAYOUT_VERSION ? positions.getInt(category.name() + "_y", defaultY) : defaultY;
        int maxX = Math.max(0, canvas.getWidth() - frame.getWidth());
        int maxY = Math.max(0, canvas.getHeight() - frame.getHeight());
        frame.setX(Math.max(0, Math.min(maxX, x)));
        frame.setY(Math.max(0, Math.min(maxY, y)));
        if (storedVersion != LAYOUT_VERSION) {
            positions.edit().putInt("layout_version", LAYOUT_VERSION).apply();
        }
    }

    private final Runnable scaleRebuildRunnable = () -> {
        if (!isAttachedToWindow()) return;
        build();
        requestLayout();
    };

    public void applyScale(float newScale) {
        float s = Math.max(0.5f, Math.min(1.2f, newScale));
        if (Math.abs(s - scale) < 0.001f) return;
        scale = s;
        ConfigManager.setUiScale(scale);
        removeCallbacks(scaleRebuildRunnable);
        post(scaleRebuildRunnable);
    }

    public void show() {
        setAlpha(0f);
        setScaleX(0.97f);
        setScaleY(0.97f);
        setVisibility(VISIBLE);
        animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(150).start();
    }

    public void hide(Runnable after) {
        animate().alpha(0f).setDuration(100).withEndAction(() -> {
            setVisibility(GONE);
            if (after != null) after.run();
        }).start();
    }

    
    private void addProfileCapsule() {
        Context ctx = getContext();
        profileCapsule = new LinearLayout(ctx);
        profileCapsule.setOrientation(LinearLayout.HORIZONTAL);
        profileCapsule.setGravity(Gravity.CENTER_VERTICAL);
        int padH = dp(12);
        int padV = dp(8);
        profileCapsule.setPadding(padH, padV, padH, padV);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(ThemeManager.getBgPrimary());
        bg.setCornerRadius(dp(22));
        bg.setStroke(Math.max(1, dp(1)), ThemeManager.getThemeColor() & 0x66FFFFFF);
        profileCapsule.setBackground(bg);
        profileCapsule.setElevation(dp(3));

        capsuleAvatar = new ImageView(ctx);
        LinearLayout.LayoutParams avLp = new LinearLayout.LayoutParams(dp(32), dp(32));
        capsuleAvatar.setLayoutParams(avLp);
        capsuleAvatar.setScaleType(ImageView.ScaleType.CENTER_CROP);
        capsuleAvatar.setClickable(true);
        applyCapsuleAvatar();
        capsuleAvatar.setOnClickListener(v -> {
            try { SoundPlayer.playClick(); } catch (Throwable ignored) {}
            android.app.Activity act = PhoenixPopup.getCurrentActivity();
            if (act != null) AvatarPicker.pick(act);
        });

        LinearLayout texts = new LinearLayout(ctx);
        texts.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams tLp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        tLp.leftMargin = dp(10);
        texts.setLayoutParams(tLp);

        capsuleUsername = new TextView(ctx);
        capsuleUsername.setText(UserProfile.getUsername());
        capsuleUsername.setTextColor(ThemeManager.getTextPrimary());
        capsuleUsername.setTextSize(Math.max(10f, 12f * scale));
        capsuleUsername.setTypeface(Typeface.DEFAULT_BOLD);
        capsuleUsername.setClickable(true);
        capsuleUsername.setPadding(0, dp(1), 0, dp(1));
        capsuleUsername.setOnClickListener(v -> {
            try { SoundPlayer.playClick(); } catch (Throwable ignored) {}
            android.app.Activity act = PhoenixPopup.getCurrentActivity();
            if (act == null) return;
            com.nyaui.me.ui.widgets.TextInputDialog.show(act, UserProfile.getUsername(), text -> {
                UserProfile.setUsername(text);
                refreshCapsule();
            });
        });

        capsuleBio = new TextView(ctx);
        capsuleBio.setText(UserProfile.getBio());
        capsuleBio.setTextColor(ThemeManager.getTextSecondary());
        capsuleBio.setTextSize(Math.max(9f, 10f * scale));
        capsuleBio.setClickable(true);
        capsuleBio.setPadding(0, dp(1), 0, dp(1));
        capsuleBio.setOnClickListener(v -> {
            try { SoundPlayer.playClick(); } catch (Throwable ignored) {}
            android.app.Activity act = PhoenixPopup.getCurrentActivity();
            if (act == null) return;
            com.nyaui.me.ui.widgets.TextInputDialog.show(act, UserProfile.getBio(), text -> {
                UserProfile.setBio(text);
                refreshCapsule();
            });
        });

        texts.addView(capsuleUsername);
        texts.addView(capsuleBio);
        profileCapsule.addView(capsuleAvatar);
        profileCapsule.addView(texts);

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL
        );
        lp.bottomMargin = dp(14);
        addView(profileCapsule, lp);
    }

    private void applyCapsuleAvatar() {
        if (capsuleAvatar == null) return;
        android.graphics.Bitmap bmp = UserProfile.loadAvatarBitmap(getContext());
        if (bmp != null) {
            capsuleAvatar.setImageBitmap(bmp);
            capsuleAvatar.setBackground(null);
            capsuleAvatar.setClipToOutline(true);
            capsuleAvatar.setOutlineProvider(new android.view.ViewOutlineProvider() {
                public void getOutline(View v, android.graphics.Outline outline) {
                    outline.setOval(0, 0, v.getWidth(), v.getHeight());
                }
            });
        } else {
            capsuleAvatar.setImageDrawable(null);
            GradientDrawable g = new GradientDrawable();
            g.setColor(ThemeManager.getThemeColor());
            g.setCornerRadius(dp(16));
            capsuleAvatar.setBackground(g);
        }
    }

    private void refreshCapsule() {
        post(() -> {
            if (capsuleUsername != null) capsuleUsername.setText(UserProfile.getUsername());
            if (capsuleBio != null) capsuleBio.setText(UserProfile.getBio());
            applyCapsuleAvatar();
        });
    }

public void destroy() {
        UserProfile.removeListener(this::refreshCapsule);
        detachPanelBackgrounds();
        ThemeManager.removeListener(this);
        ThemeManager.removeModeListener(this);
        removeAllViews();
        frames.clear();
    }

    public void refreshBackgroundOnly() {
        for (FrameLayout frame : frames.values()) {
            if (frame == null) continue;
            android.graphics.drawable.Drawable d = frame.getBackground();
            if (d instanceof AnimatedBgDrawable) {
                AnimatedBgDrawable ab = (AnimatedBgDrawable) d;
                ab.setStyle(UiBackground.style());
                ab.invalidateSelf();
            } else {
                frame.setBackground(createPanelBackground());
            }
        }
        if (profileCapsule != null) {
            android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
            bg.setColor(ThemeManager.getBgPrimary());
            bg.setCornerRadius(dp(22));
            bg.setStroke(Math.max(1, dp(1)), ThemeManager.getThemeColor() & 0x66FFFFFF);
            profileCapsule.setBackground(bg);
        }
        invalidate();
    }

    public void onThemeModeChanged(boolean isDark) {
        refreshThemeInPlace();
    }

    public void onThemeColorChanged(int newColor) {
        refreshThemeInPlace();
    }

    private void refreshThemeInPlace() {
        for (Map.Entry<ModuleCategory, FrameLayout> entry : frames.entrySet()) {
            FrameLayout frame = entry.getValue();
            if (frame == null) continue;
            android.graphics.drawable.Drawable d = frame.getBackground();
            if (d instanceof AnimatedBgDrawable) {
                AnimatedBgDrawable ab = (AnimatedBgDrawable) d;
                ab.setStyle(UiBackground.style());
                ab.invalidateSelf();
            } else {
                frame.setBackground(createPanelBackground());
            }
            refreshChildren(frame);
        }
        if (profileCapsule != null) {
            android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
            bg.setColor(ThemeManager.getBgPrimary());
            bg.setCornerRadius(dp(22));
            bg.setStroke(Math.max(1, dp(1)), ThemeManager.getThemeColor() & 0x66FFFFFF);
            profileCapsule.setBackground(bg);
        }
        invalidate();
    }

    private void refreshChildren(View view) {
        if (view instanceof SubMenuPanel) {
            ((SubMenuPanel) view).updateThemeColors();
            return;
        }
        if (view instanceof TextView) {
            TextView tv = (TextView) view;
            if (tv.getText() != null && entryIsHeader(tv)) {
                tv.setTextColor(ThemeManager.getThemeColor());
                tv.setBackgroundColor(ThemeManager.getBgSecondary());
            }
        }
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) {
                View child = group.getChildAt(i);
                if (child instanceof LinearLayout) {
                    LinearLayout linearChild = (LinearLayout) child;
                    if (linearChild.getChildCount() >= 2
                            && linearChild.getChildAt(0) instanceof TextView
                            && linearChild.getChildAt(1) instanceof TextView) {
                        TextView name = (TextView) linearChild.getChildAt(0);
                        TextView more = (TextView) linearChild.getChildAt(1);
                        Module module = findModuleByDisplayName(name.getText().toString());
                        if (module != null) applyRowStyle(linearChild, name, more, module.isEnabled());
                    }
                }
                refreshChildren(child);
            }
        }
    }

    private boolean entryIsHeader(TextView tv) {
        return tv.getText() != null && ModuleCategoryNames.contains(tv.getText().toString());
    }

    private Module findModuleByDisplayName(String text) {
        for (Module m : ModuleManager.getAllModules()) {
            if (m.getDisplayName().equals(text)) return m;
        }
        return null;
    }

    private static final java.util.Set<String> ModuleCategoryNames = new java.util.HashSet<>();

    static {
        for (ModuleCategory c : ModuleCategory.values()) ModuleCategoryNames.add(c.getDisplayName());
    }
}
