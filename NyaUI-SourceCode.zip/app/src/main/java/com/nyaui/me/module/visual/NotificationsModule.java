package com.nyaui.me.module.visual;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.ui.NotificationManager;

public class NotificationsModule extends Module {
    private static NotificationsModule instance;
    public NotificationsModule() { super("Notifications", ModuleCategory.VISUAL, ""); setChineseName("Notifications"); instance = this; }
    public static NotificationsModule getInstance() { return instance; }
    public boolean shouldShowInArraylist() { return false; }
    protected void onEnable() { super.onEnable(); NotificationManager.setEnabled(true); }
    protected void onDisable() { super.onDisable(); NotificationManager.setEnabled(false); }
}
