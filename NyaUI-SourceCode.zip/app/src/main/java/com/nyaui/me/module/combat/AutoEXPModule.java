package com.nyaui.me.module.combat;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class AutoEXPModule extends Module {
    public AutoEXPModule() {
        super("AutoEXP", ModuleCategory.COMBAT);
    }
}
