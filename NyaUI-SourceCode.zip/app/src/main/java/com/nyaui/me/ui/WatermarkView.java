package com.nyaui.me.ui;

import android.content.Context;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import androidx.appcompat.widget.AppCompatTextView;

public class WatermarkView extends AppCompatTextView {

    public WatermarkView(Context context) {
        super(context);
        initialize();
    }

    private void initialize() {
        setText("  NyaUI  ");
        setTypeface(Typeface.DEFAULT_BOLD);
        setTextSize(22f);
        int watermarkColor = com.nyaui.me.config.ConfigManager.getInt("HUD", "watermark_color", 0x80FFFFFF);
        setTextColor(watermarkColor);
        setShadowLayer(0, 0, 0, 0);
        setGravity(Gravity.START | Gravity.TOP);
        
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        params.leftMargin = 0;
        params.topMargin = 0;
        setLayoutParams(params);
    }

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density);
    }
}