package com.nyaui.me.ui;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import androidx.appcompat.widget.AppCompatTextView;

import com.nyaui.me.config.ConfigManager;

public class WatermarkView extends AppCompatTextView {

    public WatermarkView(Context context) {
        super(context);
        initialize();
    }

    private void initialize() {
        setText(buildText(getContext()));
        setTypeface(Typeface.DEFAULT_BOLD);
        setTextSize(22f);
        int watermarkColor = ConfigManager.getInt("HUD", "watermark_color", 0x80FFFFFF);
        setTextColor(watermarkColor);
        setShadowLayer(0, 0, 0, 0);
        setGravity(Gravity.START | Gravity.TOP);
        setSingleLine(true);
        setMaxLines(1);
        setHorizontallyScrolling(true);

        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        params.leftMargin = 0;
        params.topMargin = 0;
        setLayoutParams(params);
    }

    public void refreshText() {
        setText(buildText(getContext()));
        requestLayout();
    }

    public static String buildText(Context context) {
        boolean showVersion = ConfigManager.getBoolean("HUD", "watermark_version", false);
        if (!showVersion) return "NyaUI";
        String ver = readVersionName(context);
        if (ver == null || ver.isEmpty()) return "NyaUI";
        return "NyaUI v" + ver;
    }

    public static String readVersionName(Context context) {
        try {
            String v = com.nyaui.me.BuildConfig.VERSION_NAME;
            if (v != null && !v.isEmpty()) return v;
        } catch (Throwable ignored) {}
        try {
            PackageInfo pi = context.getPackageManager().getPackageInfo("com.nyaui.me", 0);
            if (pi != null && pi.versionName != null && !pi.versionName.isEmpty()) return pi.versionName;
        } catch (Throwable ignored) {}
        if (context != null) {
            try {
                PackageInfo pi = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
                if (pi != null && pi.versionName != null && !pi.versionName.isEmpty()) return pi.versionName;
            } catch (Throwable ignored) {}
        }
        return "";
    }
}
