package com.nyaui.me.module.combat;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class WebFillerModule extends Module {
    public WebFillerModule() {
        super("WebFiller", ModuleCategory.COMBAT);
    }
}
