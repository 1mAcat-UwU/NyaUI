package com.nyaui.me.module.movement;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class PacketElytraModule extends Module {
    public PacketElytraModule() {
        super("PacketElytra", ModuleCategory.MOVEMENT);
    }
}
