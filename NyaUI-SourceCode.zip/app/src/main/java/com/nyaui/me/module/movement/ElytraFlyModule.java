package com.nyaui.me.module.movement;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class ElytraFlyModule extends Module {
    public ElytraFlyModule() {
        super("ElytraFly", ModuleCategory.MOVEMENT);
    }
}
