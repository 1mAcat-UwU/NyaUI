package com.nyaui.me.module.misc;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;

public class SummonVehicleModule extends Module {
    public SummonVehicleModule() { super("SummonVehicle", ModuleCategory.MISC, ""); setChineseName("Summon Mount"); }
    public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("SummonVehicle"); } catch (Throwable t) {} }
    public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("SummonVehicle"); } catch (Throwable t) {} }
}
