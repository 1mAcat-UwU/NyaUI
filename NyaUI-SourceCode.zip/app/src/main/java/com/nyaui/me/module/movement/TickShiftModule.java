package com.nyaui.me.module.movement;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class TickShiftModule extends Module {
    public TickShiftModule() {
        super("TickShift", ModuleCategory.MOVEMENT);
    }
}
