package com.nyaui.me.module.misc;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;

public class AutoSpawnModule extends Module {
    public AutoSpawnModule() {
        super("AutoSpawn", ModuleCategory.MISC);
    }
}
