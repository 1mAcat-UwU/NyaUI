package net.peach.ocean.ui.module;

public class ModulesCall {

    static {
        try {
            System.loadLibrary("minecraftpe");
        } catch (Throwable ignored) {}
    }

    public static native boolean getModuleEnabled(String name);
    public static native void setModuleEnabled(String name);

    public static native float getModuleFloatValue(String name, int index);
    public static native void setModuleFloatValue(String name, int index, float value);

    public static native int getModuleIntValue(String name, int index);
    public static native void setModuleIntValue(String name, int index, int value);

    public static native boolean getModuleBoolValue(String name, int index);
    public static native void setModuleBoolValue(String name, int index, boolean value);

    public static native int getModuleModeSize(String name, int index);
    public static native String getModuleModeString(String name, int modeIndex, int itemIndex);
    public static native int getModuleModeValue(String name, int index);
    public static native void setModuleModeValue(String name, int index, int value);
}
