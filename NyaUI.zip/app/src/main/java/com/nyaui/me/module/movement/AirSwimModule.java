package com.nyaui.me.module.movement;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;

public class AirSwimModule extends Module {
    public AirSwimModule() { super("AirSwim", ModuleCategory.MOVEMENT, ""); setChineseName("Air Swim"); }
    @Override public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("AirSwim"); } catch (Throwable t) {} }
    @Override public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("AirSwim"); } catch (Throwable t) {} }
}
