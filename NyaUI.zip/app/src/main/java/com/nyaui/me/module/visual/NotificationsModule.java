package com.nyaui.me.module.visual;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.ui.NotificationManager;

public class NotificationsModule extends Module {
    private static NotificationsModule instance;
    public NotificationsModule() { super("Notifications", ModuleCategory.VISUAL, ""); setChineseName("Notifications"); instance = this; }
    public static NotificationsModule getInstance() { return instance; }
    @Override public boolean shouldShowInArraylist() { return false; }
    @Override protected void onEnable() { super.onEnable(); NotificationManager.setEnabled(true); }
    @Override protected void onDisable() { super.onDisable(); NotificationManager.setEnabled(false); }
}
