package com.nyaui.me.module.visual;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;

public class ParticlesAuraModule extends Module {
    public ParticlesAuraModule() { super("ParticlesAura", ModuleCategory.VISUAL, ""); setChineseName("Particle Aura"); }
    @Override public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("ParticlesAura"); } catch (Throwable t) {} }
    @Override public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("ParticlesAura"); } catch (Throwable t) {} }
}
