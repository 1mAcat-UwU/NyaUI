package com.nyaui.me.media;

import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

public class MediaNotificationListener extends NotificationListenerService {
    @Override public void onNotificationPosted(StatusBarNotification sbn) {}
    @Override public void onNotificationRemoved(StatusBarNotification sbn) {}
}
