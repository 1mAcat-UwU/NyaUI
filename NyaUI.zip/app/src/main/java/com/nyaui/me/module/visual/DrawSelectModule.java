package com.nyaui.me.module.visual;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;

public class DrawSelectModule extends Module {
    public DrawSelectModule() { super("DrawSelect", ModuleCategory.VISUAL, ""); setChineseName("Draw Selection"); }
    @Override public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("DrawSelect"); } catch (Throwable t) {} }
    @Override public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("DrawSelect"); } catch (Throwable t) {} }
}
