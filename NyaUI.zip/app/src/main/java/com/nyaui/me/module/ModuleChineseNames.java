package com.nyaui.me.module;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ModuleChineseNames {
    
    private static final Map<String, String> chineseNames = new HashMap<>();
    
    static {
        
        chineseNames.put("KillAura", "KillAura");
        chineseNames.put("AimBot", "AimBot");
        chineseNames.put("HitBox", "Hitbox");
        chineseNames.put("InfiniteAura", "Infinite Aura");
        chineseNames.put("SpinAttack", "Spin Attack");
        chineseNames.put("AutoClick", "Auto Click");
        chineseNames.put("Velocity", "Velocity");
        chineseNames.put("HitSelect", "Attack Range");
        chineseNames.put("Criticals", "Criticals");
        chineseNames.put("BackTrack", "Backtrack");
        chineseNames.put("Surround", "Surround");
        chineseNames.put("Phantom", "Phantom");

        
        chineseNames.put("Fly", "Fly");
        chineseNames.put("Speed", "Speed");
        chineseNames.put("AirJump", "Air Jump");
        chineseNames.put("FastStop", "Fast Stop");
        chineseNames.put("InventoryMove", "Inventory Move");
        chineseNames.put("Sprint", "Sprint");
        chineseNames.put("AirSwim", "Air Swim");
        chineseNames.put("FarJump", "Long Jump");
        chineseNames.put("NoSlowDown", "No Slow");
        chineseNames.put("HighJump", "High Jump");

        
        chineseNames.put("Scaffold", "Scaffold");
        chineseNames.put("Break", "Break");
        chineseNames.put("AutoBreak", "Auto Break");
        chineseNames.put("BoxAura", "Chest Aura");
        chineseNames.put("ClickDestroy", "Click Destroy");
        chineseNames.put("Xray", "X-Ray");

        
        chineseNames.put("SummonVehicle", "Summon Mount");
        chineseNames.put("Spammer", "Spammer");
        chineseNames.put("Derp", "Derp");
        chineseNames.put("AntiKick", "Anti-Kick");
        chineseNames.put("RepeatPacket", "Repeat Packet");
        chineseNames.put("Blink", "Blink");
        chineseNames.put("NoPacket", "No Packet");
        chineseNames.put("Timer", "Timer");
        chineseNames.put("SoundPlayer", "Sound");
        chineseNames.put("ClickTp", "Click TP");
        chineseNames.put("ItemCopy", "Item Copy");
        chineseNames.put("Crasher", "Crasher");
        chineseNames.put("RemoteShop", "Remote Shop");

        
        chineseNames.put("ESP", "Player ESP");
        chineseNames.put("Tracer", "Player Rays");
        chineseNames.put("ItemESP", "Item ESP");
        chineseNames.put("ChestESP", "Chest ESP");
        chineseNames.put("FreeCam", "FreeCam");
        chineseNames.put("CameraMod", "Camera");
        chineseNames.put("ColorAdjustment", "Color Correct");
        chineseNames.put("ShowPosition", "Show Coordinates");
        chineseNames.put("NoHurtAnimate", "No Hurt Shake");
        chineseNames.put("NightVision", "Night Vision");
        chineseNames.put("FogCustom", "Custom Fog");
        chineseNames.put("SkyCustom", "Custom Sky");
        chineseNames.put("HitEffect", "Attack FX");
        chineseNames.put("Magnifier", "Magnifier");
        chineseNames.put("DepthOfField", "Depth of Field");
        chineseNames.put("DrawHalo", "Draw Halo");
        chineseNames.put("DrawPath", "Draw Path");
        chineseNames.put("DrawRange", "Draw Range");
        chineseNames.put("DrawSelect", "Draw Selection");
        chineseNames.put("SwingAnimation", "Swing Animation");
        chineseNames.put("FluxSwing", "Swing Animation");
        chineseNames.put("ShowSwing", "Slow Swing");
        chineseNames.put("FullBright", "World Brightness");
        chineseNames.put("Theme", "Theme");
        chineseNames.put("Notifications", "Notifications");
        chineseNames.put("Watermark", "Watermark");
        chineseNames.put("ArrayList", "Module List");
        chineseNames.put("ChineseMode", "Chinese Mode");
        chineseNames.put("ParticlesAura", "Particle Aura");

        
        chineseNames.put("ChestStealer", "Auto take chest items");
        chineseNames.put("BlockReach", "Block Distance");
        chineseNames.put("GodMode", "God Mode");
        chineseNames.put("InvManager", "Inv Cleaner");
        chineseNames.put("NoFall", "No Fall");
        chineseNames.put("AntiVoid", "Anti-Void");
        chineseNames.put("AntiWeb", "Anti-Web");
        chineseNames.put("AutoMine", "Auto Mine");
        chineseNames.put("BoatFly", "Boat Fly");
        chineseNames.put("AntiBot", "Anti-Bot");
        chineseNames.put("Crash", "Crash");

        
        chineseNames.put("Language", "Language");
    }
    
    public static String getChineseName(String moduleName) {
        return chineseNames.getOrDefault(moduleName, moduleName);
    }
    
    public static void initializeChineseNames() {
        List<Module> allModules = ModuleManager.getAllModules();
        if (allModules == null) return;
        for (Module module : allModules) {
            if (module == null) continue;
            String chineseName = getChineseName(module.getName());
            if (!chineseName.equals(module.getName())) {
                module.setChineseName(chineseName);
            }
        }
    }
}