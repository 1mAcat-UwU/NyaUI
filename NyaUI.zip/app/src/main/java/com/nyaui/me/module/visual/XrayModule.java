package com.nyaui.me.module.visual;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;

public class XrayModule extends Module {
    public XrayModule() { super("Xray", ModuleCategory.VISUAL, ""); setChineseName("ESP"); }
    @Override public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("Xray"); } catch (Throwable t) {} }
    @Override public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("Xray"); } catch (Throwable t) {} }
}
