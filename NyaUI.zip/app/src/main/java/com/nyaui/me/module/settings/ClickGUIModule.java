package com.nyaui.me.module.settings;

import com.nyaui.me.config.ConfigManager;
import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.ui.PhoenixPopup;
import com.nyaui.me.ui.SoundPlayer;
import com.nyaui.me.ui.ThemeManager;
import com.nyaui.me.ui.widgets.SubMenuPanel;
import com.nyaui.me.ui.widgets.ColorPickerView;

import java.util.ArrayList;
import java.util.List;

public class ClickGUIModule extends Module {
    public ClickGUIModule() {
        super("ClickGUI", ModuleCategory.SETTINGS, "");
        setChineseName("ClickGUI");
    }

    @Override public boolean shouldShowInArraylist() { return false; }
    @Override public boolean supportsShortcut() { return false; }
    @Override protected void onEnable() {}
    @Override protected void onDisable() {}

    @Override
    public void configureSubMenu(SubMenuPanel subMenu) {
        super.configureSubMenu(subMenu);
        subMenu.addSectionTitle("UI Style");
        List<String> styles = new ArrayList<>();
        styles.add("Default");
        styles.add("Classic");
        int cur = ConfigManager.isClassicUi() ? 1 : 0;
        subMenu.addMode("Style", styles, cur, (index, mode) -> {
            ConfigManager.setUiStyle(index == 1 ? ConfigManager.UI_STYLE_CLASSIC : ConfigManager.UI_STYLE_DEFAULT);
            ThemeManager.syncActiveStyleColor();
            PhoenixPopup.hideMenus();
        });

        subMenu.addDivider();
        subMenu.addSectionTitle("Theme");
        subMenu.addThemeModeSwitch();
        subMenu.addSwitch("Rainbow", ThemeManager.isRainbowModeEnabled(), ThemeManager::setRainbowModeEnabled);
        subMenu.addThemeButtons();
        subMenu.addSectionTitle("Custom Color");
        subMenu.addCustomView(new ColorPickerView(subMenu.getContext()));

        subMenu.addDivider();
        subMenu.addSectionTitle("Interface");
        float scale = ConfigManager.getFloat("ClickGUI", "ui_scale_factor", 0.95f);
        int scalePct = Math.round(scale * 100f);
        subMenu.addSlider("UI Size", 50, 120, scalePct, "%d%%", v -> {
            float s = Math.max(0.5f, Math.min(1.2f, v / 100f));
            ConfigManager.saveFloat("ClickGUI", "ui_scale_factor", s);
            PhoenixPopup.applyUiScale(s);
        });
        subMenu.addSwitch("UI Sound", ConfigManager.isSoundEnabled(), enabled -> {
            ConfigManager.setSoundEnabled(enabled);
            if (enabled) SoundPlayer.playClick();
        });
    }
}
