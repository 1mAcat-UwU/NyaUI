package com.nyaui.me.module.misc;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;

public class GodModeModule extends Module {
    public GodModeModule() { super("GodMode", ModuleCategory.MISC, ""); setChineseName("Invincible"); }
    @Override public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("GodMode"); } catch (Throwable t) {} }
    @Override public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("GodMode"); } catch (Throwable t) {} }
}
