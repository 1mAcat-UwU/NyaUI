package com.nyaui.me.module.visual;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;

public class HitEffectModule extends Module {
    public HitEffectModule() { super("HitEffect", ModuleCategory.VISUAL, ""); setChineseName("Hit Effect"); }
    @Override public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("HitEffect"); } catch (Throwable t) {} }
    @Override public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("HitEffect"); } catch (Throwable t) {} }
}
