package com.nyaui.me.module.player;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;

public class AntiBotModule extends Module {
    public AntiBotModule() { super("AntiBot", ModuleCategory.PLAYER, ""); setChineseName("Anti-Bot"); }
    @Override public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("AntiBot"); } catch (Throwable t) {} }
    @Override public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("AntiBot"); } catch (Throwable t) {} }
}
