package com.nyaui.me;

import android.app.Activity;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.ProviderInfo;
import android.text.TextUtils;
import dalvik.system.DexClassLoader;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import java.io.File;
import java.util.Iterator;
import java.util.List;

public class HookInit implements IXposedHookLoadPackage {
    boolean isLoaded = false;

    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam loadPackageParam) throws Throwable {
        XposedHelpers.findAndHookMethod("com.bytedance.pangle.FileProvider", loadPackageParam.classLoader, "attachInfo", new Object[]{Context.class, ProviderInfo.class, new XC_MethodReplacement() {
            protected Object replaceHookedMethod(XC_MethodHook.MethodHookParam methodHookParam) throws Throwable {
                return null;
            }
        }});
        XposedHelpers.findAndHookMethod("com.netease.android.protect.StubApp", loadPackageParam.classLoader, "attachBaseContext", new Object[]{Context.class, new XC_MethodHook() {
            public void afterHookedMethod(XC_MethodHook.MethodHookParam methodHookParam) {
                XposedHelpers.findAndHookMethod("com.mojang.minecraftpe.MainActivity", ((Context) methodHookParam.args[0]).getClassLoader(), "onResume", new Object[]{new XC_MethodHook() {
                    public void afterHookedMethod(XC_MethodHook.MethodHookParam methodHookParam2) throws Throwable {
                        if (HookInit.this.isLoaded) {
                            return;
                        }
                        Activity activity = (Activity) methodHookParam2.thisObject;
                        ViewLoader.Loading(activity);
                        HookInit.this.isLoaded = true;
                    }
                }});
            }
        }});
        if (loadPackageParam.appInfo != null && !TextUtils.isEmpty(loadPackageParam.appInfo.nativeLibraryDir) && TextUtils.equals(loadPackageParam.packageName, loadPackageParam.processName) && new File(loadPackageParam.appInfo.nativeLibraryDir, "libminecraftpe.so").exists()) {
            try {
                XposedBridge.hookMethod(loadPackageParam.classLoader.loadClass("com.netease.ntunisdk.unifix.UniFixBase").getDeclaredMethod("a", Context.class), new XC_MethodHook() {
                    protected void afterHookedMethod(XC_MethodHook.MethodHookParam methodHookParam) throws Throwable {
                        String str = (String) methodHookParam.getResult();
                        if (str != null) {
                            methodHookParam.setResult(str.replace(".com", ".dev"));
                        }
                    }
                });
            } catch (Exception unused) {
            }
        }
        if ("com.nyaui.me".equals(loadPackageParam.packageName)) {
            XposedHelpers.findAndHookMethod(MainActivity.class.getName(), loadPackageParam.classLoader, "isModuleActivated", new Object[]{XC_MethodReplacement.returnConstant(true)});
        }
        if ("com.netease.x19".equals(loadPackageParam.packageName) || "com.ycxbox.mc".equals(loadPackageParam.packageName)) {
            XposedHelpers.findAndHookMethod(Class.class, "forName", new Object[]{String.class, Boolean.TYPE, ClassLoader.class, new XC_MethodHook() {
                protected void beforeHookedMethod(XC_MethodHook.MethodHookParam methodHookParam) throws Throwable {
                    String str = (String) methodHookParam.args[0];
                    if (str.contains("com.nyaui.me") || str.contains("org.lsposed.lspatch") || str.contains("org.lsposed.npatch") || str.contains("org.lsposed.onpatch") || str.contains("org.lsposed.opatch")) {
                        methodHookParam.setThrowable(new ClassNotFoundException());
                    }
                }
            }});
            XposedHelpers.findAndHookMethod("android.app.ApplicationPackageManager", loadPackageParam.classLoader, "getInstalledApplications", new Object[]{Integer.TYPE, new XC_MethodHook() {
                protected void afterHookedMethod(XC_MethodHook.MethodHookParam methodHookParam) throws Throwable {
                    List list = (List) methodHookParam.getResult();
                    Iterator it = list.iterator();
                    while (it.hasNext()) {
                        ApplicationInfo applicationInfo = (ApplicationInfo) it.next();
                        if (applicationInfo.packageName.equals("org.lsposed.lspatch") || applicationInfo.packageName.equals("org.lsposed.npatch") || applicationInfo.packageName.equals("org.lsposed.onpatch") || applicationInfo.packageName.equals("org.lsposed.opatch") || applicationInfo.packageName.equals("com.nyaui.me")) {
                            it.remove();
                        }
                    }
                    methodHookParam.setResult(list);
                }
            }});
            XposedHelpers.findAndHookMethod("android.app.ApplicationPackageManager", loadPackageParam.classLoader, "getInstalledPackages", new Object[]{Integer.TYPE, new XC_MethodHook() {
                protected void afterHookedMethod(XC_MethodHook.MethodHookParam methodHookParam) throws Throwable {
                    List list = (List) methodHookParam.getResult();
                    Iterator it = list.iterator();
                    while (it.hasNext()) {
                        PackageInfo packageInfo = (PackageInfo) it.next();
                        if (packageInfo.packageName.equals("org.lsposed.lspatch") || packageInfo.packageName.equals("org.lsposed.npatch") || packageInfo.packageName.equals("org.lsposed.onpatch") || packageInfo.packageName.equals("org.lsposed.opatch") || packageInfo.packageName.equals("com.nyaui.me")) {
                            it.remove();
                        }
                    }
                    methodHookParam.setResult(list);
                }
            }});
        }
    }
}
