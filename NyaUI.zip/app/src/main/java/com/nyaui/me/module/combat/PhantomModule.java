package com.nyaui.me.module.combat;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class PhantomModule extends Module {
    public PhantomModule() { super("Phantom", ModuleCategory.COMBAT, ""); setChineseName("Phantom"); }
    @Override public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("Phantom"); } catch (Throwable t) {} }
    @Override public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("Phantom"); } catch (Throwable t) {} }
    @Override public void configureSubMenu(SubMenuPanel s) {
        super.configureSubMenu(s);
        String n = getName();
        s.addSlider("Width", 3, 10, (int)(SafeCall.getFloat(n, 0) * 2), "%.1f", v -> SafeCall.setFloat(n, 0, v));
        s.addSlider("Height", 5, 10, (int)SafeCall.getFloat(n, 1), "%.1f", v -> SafeCall.setFloat(n, 1, v));
        s.addSlider("Range", 5, 500, (int)SafeCall.getFloat(n, 2), "%d", v -> SafeCall.setFloat(n, 2, v));
    }
}
