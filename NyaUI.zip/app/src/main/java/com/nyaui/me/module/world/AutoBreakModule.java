package com.nyaui.me.module.world;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class AutoBreakModule extends Module {
    public AutoBreakModule() { super("AutoBreak", ModuleCategory.WORLD, ""); setChineseName("Auto Break"); }
    @Override public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("AutoBreak"); } catch (Throwable t) {} }
    @Override public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("AutoBreak"); } catch (Throwable t) {} }
    @Override public void configureSubMenu(SubMenuPanel s) {
        super.configureSubMenu(s);
        s.addSlider("Range", 3, 15, SafeCall.getInt(getName(), 0), "%d", v -> SafeCall.setInt(getName(), 0, (int)v));
    }
}
