package com.nyaui.me.module.combat;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;

public class HitSelectModule extends Module {
    public HitSelectModule() { super("HitSelect", ModuleCategory.COMBAT, ""); setChineseName("Attack Range"); }
    @Override public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("HitSelect"); } catch (Throwable t) {} }
    @Override public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("HitSelect"); } catch (Throwable t) {} }
}
