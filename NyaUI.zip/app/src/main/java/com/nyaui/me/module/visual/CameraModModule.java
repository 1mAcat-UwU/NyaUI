package com.nyaui.me.module.visual;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class CameraModModule extends Module {
    public CameraModModule() { super("CameraMod", ModuleCategory.VISUAL, ""); setChineseName("Camera"); }
    @Override public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("CameraMod"); } catch (Throwable t) {} }
    @Override public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("CameraMod"); } catch (Throwable t) {} }
    @Override public void configureSubMenu(SubMenuPanel s) {
        super.configureSubMenu(s);
        String n = getName();
        int cnt = SafeCall.getModeSize(n, 0); java.util.List<String> modes = new java.util.ArrayList<>(); for (int i = 0; i < cnt; i++) modes.add(SafeCall.getModeString(n, 0, i)); s.addMode("Mode", modes, SafeCall.getModeValue(n, 0), (index, name) -> SafeCall.setModeValue(n, 0, index));
        s.addSlider("Value", 0, 100, (int)SafeCall.getFloat(n, 0), "%.1f", v -> SafeCall.setFloat(n, 0, v));
    }
}
