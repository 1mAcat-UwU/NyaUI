package com.nyaui.me.ui.widgets;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.animation.LinearInterpolator;

import androidx.appcompat.widget.AppCompatTextView;

public class RainbowTextView extends AppCompatTextView {

    private LinearGradient linearGradient;
    private final Matrix matrix = new Matrix();
    private float translate;
    private final int[] rainbowColors;
    private ValueAnimator animator;

    public RainbowTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        rainbowColors = new int[]{
                Color.RED, Color.YELLOW, Color.GREEN, Color.CYAN, Color.BLUE, Color.MAGENTA, Color.RED
        };
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (w > 0) {
            if (linearGradient == null) {
                linearGradient = new LinearGradient(0, 0, w, 0,
                        rainbowColors, null, Shader.TileMode.CLAMP);
                getPaint().setShader(linearGradient);

                animator = ValueAnimator.ofFloat(0, w);
                animator.setDuration(2000);
                animator.setRepeatCount(ValueAnimator.INFINITE);
                animator.setInterpolator(new LinearInterpolator());
                animator.addUpdateListener(animation -> {
                    translate = (float) animation.getAnimatedValue();
                    matrix.setTranslate(translate, 0);
                    linearGradient.setLocalMatrix(matrix);
                    invalidate();
                });
                animator.start();
            }
        } else {
            if (animator != null) {
                animator.cancel();
            }
            getPaint().setShader(null);
            linearGradient = null;
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (animator != null) {
            animator.cancel();
        }
    }
}

