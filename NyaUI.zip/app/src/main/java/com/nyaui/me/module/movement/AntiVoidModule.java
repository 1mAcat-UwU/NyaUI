package com.nyaui.me.module.movement;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class AntiVoidModule extends Module {
    public AntiVoidModule() { super("AntiVoid", ModuleCategory.MOVEMENT, ""); setChineseName("Void Bounce"); }
    @Override public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("AntiVoid"); } catch (Throwable t) {} }
    @Override public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("AntiVoid"); } catch (Throwable t) {} }
    @Override public void configureSubMenu(SubMenuPanel s) {
        super.configureSubMenu(s);
        s.addSlider("Trigger Distance", 1, 10, SafeCall.getInt(getName(), 0), "%d", v -> SafeCall.setInt(getName(), 0, (int)v));
    }
}
