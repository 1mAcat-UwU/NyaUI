package com.nyaui.me.module.movement;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;

public class SprintModule extends Module {
    public SprintModule() { super("Sprint", ModuleCategory.MOVEMENT, ""); setChineseName("Sprint"); }
    @Override public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("Sprint"); } catch (Throwable t) {} }
    @Override public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("Sprint"); } catch (Throwable t) {} }
}
