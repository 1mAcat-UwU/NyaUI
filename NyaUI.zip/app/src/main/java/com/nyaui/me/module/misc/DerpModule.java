package com.nyaui.me.module.misc;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class DerpModule extends Module {
    public DerpModule() { super("Derp", ModuleCategory.MISC, ""); setChineseName("Derp"); }
    @Override public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("Derp"); } catch (Throwable t) {} }
    @Override public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("Derp"); } catch (Throwable t) {} }
    @Override public void configureSubMenu(SubMenuPanel s) {
        super.configureSubMenu(s);
        s.addSlider("Speed", 1, 30, (int)SafeCall.getFloat(getName(), 0), "%d", v -> SafeCall.setFloat(getName(), 0, v));
    }
}
