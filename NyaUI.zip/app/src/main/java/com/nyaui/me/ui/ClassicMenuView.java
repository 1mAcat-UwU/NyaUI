package com.nyaui.me.ui;

import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.nyaui.me.config.ConfigManager;
import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.ModuleManager;
import com.nyaui.me.ui.widgets.SubMenuPanel;

import java.util.List;

public class ClassicMenuView extends FrameLayout implements ThemeManager.OnThemeModeChangeListener, ThemeManager.OnThemeColorChangeListener {
    private static final int BG = 0xF0121216;
    private static final int HEADER = 0xF01B1B22;
    private static final int ROW = 0xF017171D;
    private static final int ROW_ON = 0xF0223025;
    private static final int LINE = 0xFF34343D;
    private static final int TEXT = 0xFFE6E6EA;
    private static final int OFF = 0xFF8D8D97;
    private final float d;
    private final LinearLayout panel;
    private final LinearLayout content;
    private final ScrollView scroll;
    private float scale;
    private float downX, downY;
    private int startX, startY;
    private boolean dragging;

    public ClassicMenuView(android.content.Context context) {
        super(context);
        d = context.getResources().getDisplayMetrics().density;
        scale = ConfigManager.getUiScale();
        setWillNotDraw(false);
        setClipChildren(false);

        panel = new LinearLayout(context);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(2), dp(2), dp(2), dp(2));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(BG);
        bg.setStroke(dp(1), LINE);
        bg.setCornerRadius(dp(3));
        panel.setBackground(bg);
        addView(panel, new FrameLayout.LayoutParams(width(), height(), Gravity.CENTER));

        TextView header = new TextView(context);
        header.setText("NyaUI Classic  •  "+"ClickGUI");
        header.setTextColor(TEXT);
        header.setTextSize(12f);
        header.setTypeface(Typeface.DEFAULT_BOLD);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(12), 0, dp(12), 0);
        header.setBackgroundColor(HEADER);
        panel.addView(header, new LinearLayout.LayoutParams(-1, dp(34)));
        setupDrag(header);

        scroll = new ScrollView(context);
        scroll.setFillViewport(false);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setHorizontalScrollBarEnabled(false);
        content = new LinearLayout(context);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(6), dp(6), dp(6), dp(8));
        scroll.addView(content, new ScrollView.LayoutParams(-1, -2));
        panel.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        build();
        ThemeManager.addModeListener(this);
        ThemeManager.addListener(this);
    }

    private int width() { return Math.max(dp(300), Math.min(getResources().getDisplayMetrics().widthPixels - dp(18), (int)(getResources().getDisplayMetrics().widthPixels * 0.84f * scale))); }
    private int height() { return Math.max(dp(260), Math.min(getResources().getDisplayMetrics().heightPixels - dp(18), (int)(getResources().getDisplayMetrics().heightPixels * 0.84f * scale))); }
    private int dp(int v) { return (int)(v*d + 0.5f); }

    private void build() {
        content.removeAllViews();
        ModuleCategory[] cats = {ModuleCategory.COMBAT, ModuleCategory.MOVEMENT, ModuleCategory.PLAYER, ModuleCategory.VISUAL, ModuleCategory.WORLD, ModuleCategory.MISC, ModuleCategory.SETTINGS};
        for (ModuleCategory cat : cats) {
            TextView title = new TextView(getContext());
            title.setText(cat.getDisplayName());
            title.setTextColor(ThemeManager.getThemeColor());
            title.setTextSize(10.5f);
            title.setTypeface(Typeface.DEFAULT_BOLD);
            title.setGravity(Gravity.CENTER_VERTICAL);
            title.setPadding(dp(8), dp(6), dp(8), dp(4));
            content.addView(title, new LinearLayout.LayoutParams(-1, dp(28)));
            for (Module module : ModuleManager.getModulesByCategory(cat)) addModule(module);
            View line = new View(getContext());
            line.setBackgroundColor(LINE);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(1));
            lp.setMargins(0, dp(5), 0, dp(5));
            content.addView(line, lp);
        }
    }

    private void addModule(Module module) {
        LinearLayout holder = new LinearLayout(getContext());
        holder.setOrientation(LinearLayout.VERTICAL);
        content.addView(holder, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout row = new LinearLayout(getContext());
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(9), 0, dp(5), 0);
        TextView name = new TextView(getContext());
        name.setText(module.getDisplayName());
        name.setTextSize(11f);
        name.setSingleLine(true);
        name.setTextColor(module.isEnabled() ? ThemeManager.getThemeColor() : TEXT);
        row.addView(name, new LinearLayout.LayoutParams(0, dp(34), 1f));
        TextView more = new TextView(getContext());
        more.setText("...");
        more.setTextSize(12f);
        more.setGravity(Gravity.CENTER);
        more.setTextColor(OFF);
        row.addView(more, new LinearLayout.LayoutParams(dp(38), dp(34)));
        updateRowBackground(row, module);
        holder.addView(row);

        SubMenuPanel sub = new SubMenuPanel(getContext(), module, Math.max(0.65f, scale));
        try { module.configureSubMenu(sub); } catch (Throwable ignored) {}
        holder.addView(sub, new LinearLayout.LayoutParams(-1, 0));

        row.setOnClickListener(v -> {
            SoundPlayer.playClick();
            module.toggle();
            name.setTextColor(module.isEnabled() ? ThemeManager.getThemeColor() : TEXT);
            updateRowBackground(row, module);
        });
        more.setOnClickListener(v -> {
            SoundPlayer.playClick();
            toggleInline(sub);
        });
    }

    private void toggleInline(SubMenuPanel sub) {
        if (sub.getVisibility() == View.VISIBLE) {
            sub.toggle();
        } else {
            sub.toggle();
        }
    }

    private void updateRowBackground(View row, Module module) {
        row.setBackgroundColor(module.isEnabled() ? ROW_ON : ROW);
    }

    private void setupDrag(View handle) {
        handle.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX=e.getRawX(); downY=e.getRawY();
                    startX=panel.getLeft(); startY=panel.getTop(); dragging=false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float dx=e.getRawX()-downX, dy=e.getRawY()-downY;
                    if (!dragging && Math.hypot(dx,dy)>dp(5)) dragging=true;
                    if (dragging) {
                        float nx=panel.getTranslationX()+dx; float ny=panel.getTranslationY()+dy;
                        float maxX=Math.max(0,(getWidth()-panel.getWidth())/2f);
                        float maxY=Math.max(0,(getHeight()-panel.getHeight())/2f);
                        panel.setTranslationX(Math.max(-maxX,Math.min(maxX,nx)));
                        panel.setTranslationY(Math.max(-maxY,Math.min(maxY,ny)));
                        downX=e.getRawX(); downY=e.getRawY();
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    return true;
            }
            return true;
        });
    }

    public void applyScale(float newScale) {
        scale=Math.max(0.5f,Math.min(1.2f,newScale));
        ConfigManager.setUiScale(scale);
        FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)panel.getLayoutParams();
        lp.width=width(); lp.height=height(); lp.gravity=Gravity.CENTER;
        panel.setLayoutParams(lp);
        build();
    }

    public void show() { setAlpha(0f); setVisibility(VISIBLE); animate().alpha(1f).setDuration(120).start(); }
    public void hide(Runnable after) { animate().alpha(0f).setDuration(100).withEndAction(() -> { setVisibility(GONE); if(after!=null) after.run(); }).start(); }
    public void destroy() { ThemeManager.removeListener(this); ThemeManager.removeModeListener(this); removeAllViews(); }
    @Override public void onThemeModeChanged(boolean isDark) { build(); }
    @Override public void onThemeColorChanged(int newColor) { build(); }
}
