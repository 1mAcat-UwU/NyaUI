package com.nyaui.me.module.combat;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class HitBoxModule extends Module {
    public HitBoxModule() { super("HitBox", ModuleCategory.COMBAT, ""); setChineseName("Hitbox"); }
    @Override public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("HitBox"); } catch (Throwable t) {} }
    @Override public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("HitBox"); } catch (Throwable t) {} }
    @Override public void configureSubMenu(SubMenuPanel s) {
        super.configureSubMenu(s);
        String n = getName();
        s.addSlider("Width", 0, 100, (int)(SafeCall.getFloat(n, 0) * 10), "%.1f", v -> SafeCall.setFloat(n, 0, v));
        s.addSlider("Height", 0, 100, (int)(SafeCall.getFloat(n, 1) * 10), "%.1f", v -> SafeCall.setFloat(n, 1, v));
        s.addSlider("Range", 5, 50, (int)SafeCall.getFloat(n, 2), "%.1f", v -> SafeCall.setFloat(n, 2, v));
    }
}
