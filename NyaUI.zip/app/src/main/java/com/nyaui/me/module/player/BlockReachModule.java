package com.nyaui.me.module.player;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class BlockReachModule extends Module {
    public BlockReachModule() { super("BlockReach", ModuleCategory.PLAYER, ""); setChineseName("Block Distance"); }
    @Override public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("BlockReach"); } catch (Throwable t) {} }
    @Override public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("BlockReach"); } catch (Throwable t) {} }
    @Override public void configureSubMenu(SubMenuPanel s) {
        super.configureSubMenu(s);
        s.addSlider("Distance", 3, 225, SafeCall.getInt(getName(), 0), "%d", v -> SafeCall.setInt(getName(), 0, (int)v));
    }
}
