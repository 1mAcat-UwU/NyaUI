package com.nyaui.me.media;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.SystemClock;
import android.provider.Settings;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MediaReader {

    private MediaReader() {}

    public static class NowPlaying {
        public boolean active = false;
        public boolean playing = false;
        public String title = "";
        public String artist = "";
        public String album = "";
        public String lyric = "";
        public Bitmap art = null;
        public long position = 0L;
        public long duration = 0L;
    }

     
    private static class Snap {
        boolean active, playing;
        String title = "", artist = "", album = "", lyric = "";
        Bitmap art;
        long position, duration;
        long posTime;
        float speed = 1f;
        long seq;
    }

    private static final ExecutorService IO = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "NyaUI-Media");
        t.setDaemon(true);
        t.setPriority(Thread.MIN_PRIORITY);
        return t;
    });

    private static final NowPlaying STATE = new NowPlaying();
    private static volatile Snap latest = null;
    private static long consumedSeq = -1;
    private static long seqGen = 0;

    private static volatile boolean fetching = false;
    private static long lastKick = 0L;
    private static final long POLL_MS = 1000L;

    private static long posAtRead = 0L;
    private static long posReadTime = 0L;
    private static float playSpeed = 1f;

    private static int lastArtHash = 0;

    private static volatile Boolean accessCache = null;
    private static long accessCheckedAt = 0L;

     
    public static boolean hasAccess(Context ctx) {
        long now = SystemClock.uptimeMillis();
        Boolean c = accessCache;
        if (c != null && now - accessCheckedAt < 3000L) return c;
        boolean r = false;
        try {
            String flat = Settings.Secure.getString(
                    ctx.getContentResolver(), "enabled_notification_listeners");
            if (flat != null) {
                r = flat.contains("com.nyaui.me/")
                        || flat.contains(MediaNotificationListener.class.getName());
            }
        } catch (Throwable ignored) {}
        accessCache = r;
        accessCheckedAt = now;
        return r;
    }

     
    public static NowPlaying poll(Context ctx) {
        if (ctx == null) return STATE;

        Snap s = latest;
        if (s != null && s.seq != consumedSeq) {
            consumedSeq = s.seq;
            STATE.active = s.active;
            STATE.playing = s.playing;
            STATE.title = s.title;
            STATE.artist = s.artist;
            STATE.album = s.album;
            STATE.lyric = s.lyric;
            STATE.art = s.art;
            STATE.duration = s.duration;
            posAtRead = s.position;
            posReadTime = s.posTime;
            playSpeed = s.speed <= 0 ? 1f : s.speed;
            STATE.position = posAtRead;
        }

        
        if (STATE.active && STATE.playing && posReadTime > 0) {
            long elapsed = SystemClock.elapsedRealtime() - posReadTime;
            long p = posAtRead + (long) (elapsed * playSpeed);
            if (STATE.duration > 0 && p > STATE.duration) p = STATE.duration;
            STATE.position = p;
        }

        long now = SystemClock.uptimeMillis();
        if (!fetching && now - lastKick >= POLL_MS) {
            lastKick = now;
            fetching = true;
            final Context app = ctx.getApplicationContext();
            try {
                IO.submit(() -> {
                    try { refresh(app); }
                    catch (Throwable ignored) {}
                    finally { fetching = false; }
                });
            } catch (Throwable t) {
                fetching = false;
            }
        }
        return STATE;
    }

     
    private static void refresh(Context app) {
        Snap s = new Snap();
        try {
            Uri uri = Uri.parse("content://" + MediaStateProvider.AUTHORITY);
            Bundle b = app.getContentResolver().call(uri, "get", null, null);
            if (b == null || !b.getBoolean("active", false)) {
                s.active = false;
                s.seq = ++seqGen;
                latest = s;
                return;
            }
            s.active = true;
            s.playing = b.getBoolean("playing", false);
            s.title = safe(b.getString("title"));
            s.artist = safe(b.getString("artist"));
            s.album = safe(b.getString("album"));
            s.lyric = safe(b.getString("lyric"));
            s.duration = b.getLong("duration", 0L);
            s.position = b.getLong("position", 0L);
            s.posTime = b.getLong("posTime", SystemClock.elapsedRealtime());
            s.speed = b.getFloat("speed", 1f);

            byte[] art = b.getByteArray("art");
            if (art != null) {
                int h = java.util.Arrays.hashCode(art);
                if (h != lastArtHash) {
                    lastArtHash = h;
                    s.art = BitmapFactory.decodeByteArray(art, 0, art.length);
                } else {
                    Snap old = latest;
                    s.art = old != null ? old.art : null;
                }
            } else {
                lastArtHash = 0;
                s.art = null;
            }
        } catch (Throwable t) {
            s.active = false;
        }
        s.seq = ++seqGen;
        latest = s;
    }

    private static String safe(String s) { return s == null ? "" : s; }

    public static void openAccessSettings(Context ctx) {
        try {
            android.content.Intent i =
                    new android.content.Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS");
            i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(i);
            accessCache = null;
        } catch (Throwable ignored) {}
    }
}
