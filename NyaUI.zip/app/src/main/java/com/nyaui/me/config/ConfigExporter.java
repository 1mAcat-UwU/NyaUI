package com.nyaui.me.config;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.Toast;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public final class ConfigExporter {
    public static final int REQ_EXPORT = 8001;
    public static final int REQ_IMPORT = 8002;
    private static final Charset UTF8 = Charset.forName("UTF-8");
    private static final String DIR = "zuoix_configs";
    private static Runnable pendingOk, pendingFail;

    public static String exportJson(Context ctx) {
        try {
            JSONObject root = new JSONObject();
            root.put("app", "NyaUI");
            root.put("version", 2);

            JSONArray mods = new JSONArray();
            for (Module m : ModuleManager.getAllModules()) {
                JSONObject o = new JSONObject();
                o.put("name", m.getName());
                o.put("enabled", m.isEnabled());
                o.put("shortcut", m.isShortcutEnabled());
                mods.put(o);
            }
            root.put("modules", mods);

            JSONObject keybinds = new JSONObject();
            try {
                SharedPreferences kbPrefs = ctx.getSharedPreferences("Remedy_Keybinds", Context.MODE_PRIVATE);
                Map<String, ?> all = kbPrefs.getAll();
                if (all != null) {
                    for (Map.Entry<String, ?> e : all.entrySet()) {
                        if (e.getValue() instanceof Integer) {
                            keybinds.put(e.getKey(), (Integer) e.getValue());
                        }
                    }
                }
            } catch (Throwable ignored) {}
            root.put("keybinds", keybinds);

            JSONObject shortcuts = new JSONObject();
            try {
                SharedPreferences scPrefs = ctx.getSharedPreferences("shortcut_button_positions", Context.MODE_PRIVATE);
                Map<String, ?> all = scPrefs.getAll();
                if (all != null) {
                    for (Map.Entry<String, ?> e : all.entrySet()) {
                        if (e.getValue() instanceof Integer) {
                            shortcuts.put(e.getKey(), (Integer) e.getValue());
                        }
                    }
                }
            } catch (Throwable ignored) {}
            root.put("shortcut_positions", shortcuts);

            JSONObject ui = new JSONObject();
            ui.put("darkMode", com.nyaui.me.ui.ThemeManager.isDarkMode());
            ui.put("themeColor", com.nyaui.me.ui.ThemeManager.getThemeColor());
            ui.put("rainbow", com.nyaui.me.ui.ThemeManager.isRainbowModeEnabled());
            ui.put("chinese", ConfigManager.isChinese());
            try {
                SharedPreferences cardPrefs = ctx.getSharedPreferences("CardMenuPrefs", Context.MODE_PRIVATE);
                ui.put("panel_w", cardPrefs.getInt("panel_w", 0));
                ui.put("panel_h", cardPrefs.getInt("panel_h", 0));
                ui.put("ui_scale", cardPrefs.getFloat("ui_scale_factor", 0.8f));
                ui.put("selected_category", cardPrefs.getString("selected_category", "MOVEMENT"));
            } catch (Throwable ignored) {}
            root.put("ui", ui);

            return root.toString(2);
        } catch (Throwable t) { return "{}"; }
    }

    public static void importJson(String json, Context ctx) {
        if (json == null) return;
        try {
            String text = json.trim();
            while (!text.isEmpty() && (text.charAt(0) == '\uFEFF' || text.charAt(0) == '\uFFFE'))
                text = text.substring(1);
            JSONObject root = new JSONObject(text);

            JSONArray mods = root.optJSONArray("modules");
            if (mods != null) {
                for (int i = 0; i < mods.length(); i++) {
                    JSONObject o = mods.optJSONObject(i);
                    if (o == null) continue;
                    Module m = ModuleManager.getModuleByName(o.optString("name"));
                    if (m == null) continue;
                    boolean en = o.optBoolean("enabled", false);
                    if (en && !m.isEnabled()) m.enable();
                    else if (!en && m.isEnabled()) m.disable();
                    boolean sc = o.optBoolean("shortcut", false);
                    if (sc != m.isShortcutEnabled()) m.toggleShortcut(sc);
                }
            }

            JSONObject keybinds = root.optJSONObject("keybinds");
            if (keybinds != null && ctx != null) {
                SharedPreferences.Editor ed = ctx.getSharedPreferences("Remedy_Keybinds", Context.MODE_PRIVATE).edit();
                ed.clear();
                Iterator<String> it = keybinds.keys();
                while (it.hasNext()) {
                    String k = it.next();
                    ed.putInt(k, keybinds.optInt(k, 0));
                }
                ed.apply();
                try {
                    com.nyaui.me.ui.KeybindManager.getInstance().initialize(ctx);
                } catch (Throwable ignored) {}
            }

            JSONObject scPos = root.optJSONObject("shortcut_positions");
            if (scPos != null && ctx != null) {
                SharedPreferences.Editor ed = ctx.getSharedPreferences("shortcut_button_positions", Context.MODE_PRIVATE).edit();
                ed.clear();
                Iterator<String> it = scPos.keys();
                while (it.hasNext()) {
                    String k = it.next();
                    ed.putInt(k, scPos.optInt(k, 0));
                }
                ed.apply();
            }

            JSONObject ui = root.optJSONObject("ui");
            if (ui != null) {
                com.nyaui.me.ui.ThemeManager.setDarkMode(ui.optBoolean("darkMode", false));
                if (ui.has("themeColor")) com.nyaui.me.ui.ThemeManager.setThemeColor(ui.optInt("themeColor"));
                com.nyaui.me.ui.ThemeManager.setRainbowModeEnabled(ui.optBoolean("rainbow", false));
                ConfigManager.setChinese(ui.optBoolean("chinese", false));
                if (ctx != null) {
                    SharedPreferences.Editor ed = ctx.getSharedPreferences("CardMenuPrefs", Context.MODE_PRIVATE).edit();
                    if (ui.has("panel_w")) ed.putInt("panel_w", ui.optInt("panel_w", 0));
                    if (ui.has("panel_h")) ed.putInt("panel_h", ui.optInt("panel_h", 0));
                    if (ui.has("ui_scale")) ed.putFloat("ui_scale_factor", (float) ui.optDouble("ui_scale", 0.8));
                    if (ui.has("selected_category")) ed.putString("selected_category", ui.optString("selected_category"));
                    ed.apply();
                }
            }
        } catch (Throwable ignored) {}
    }

    public static void doExport(Activity act, Runnable ok, Runnable fail) {
        pendingOk = ok; pendingFail = fail;
        try {
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("application/json");
            i.putExtra(Intent.EXTRA_TITLE, "zuoix_config.json");
            act.startActivityForResult(i, REQ_EXPORT);
        } catch (Throwable t) { if (fail != null) fail.run(); }
    }

    public static void doImport(Activity act, Runnable ok, Runnable fail) {
        pendingOk = ok; pendingFail = fail;
        try {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            act.startActivityForResult(Intent.createChooser(i, "Select config"), REQ_IMPORT);
        } catch (Throwable t) { if (fail != null) fail.run(); }
    }

    public static boolean handleResult(Activity act, int req, int res, Intent data) {
        if (req != REQ_EXPORT && req != REQ_IMPORT) return false;
        if (res != Activity.RESULT_OK || data == null || data.getData() == null) {
            if (pendingFail != null) pendingFail.run();
            pendingOk = null; pendingFail = null;
            return true;
        }
        try {
            if (req == REQ_EXPORT) {
                OutputStream os = act.getContentResolver().openOutputStream(data.getData(), "wt");
                if (os != null) { os.write(exportJson(act).getBytes(UTF8)); os.flush(); os.close(); }
                if (pendingOk != null) pendingOk.run();
            } else {
                InputStream is = act.getContentResolver().openInputStream(data.getData());
                ByteArrayOutputStream buf = new ByteArrayOutputStream();
                byte[] tmp = new byte[4096]; int r;
                while ((r = is.read(tmp)) > 0) buf.write(tmp, 0, r);
                is.close();
                importJson(new String(buf.toByteArray(), UTF8), act);
                if (pendingOk != null) pendingOk.run();
            }
        } catch (Throwable t) { if (pendingFail != null) pendingFail.run(); }
        pendingOk = null; pendingFail = null;
        return true;
    }

    public static void saveConfig(Context ctx, String name) {
        File d = new File(ctx.getFilesDir(), DIR);
        if (!d.exists()) d.mkdirs();
        try {
            FileOutputStream fo = new FileOutputStream(new File(d, name + ".json"));
            fo.write(exportJson(ctx).getBytes(UTF8)); fo.flush(); fo.close();
        } catch (Throwable ignored) {}
    }

    public static List<String> listConfigs(Context ctx) {
        List<String> out = new ArrayList<>();
        File d = new File(ctx.getFilesDir(), DIR);
        if (!d.isDirectory()) return out;
        File[] files = d.listFiles((dir, n) -> n.endsWith(".json"));
        if (files != null) {
            Arrays.sort(files, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));
            for (File f : files) { String n = f.getName(); out.add(n.substring(0, n.length()-5)); }
        }
        return out;
    }

    public static void loadConfig(Context ctx, String name) {
        File f = new File(new File(ctx.getFilesDir(), DIR), name + ".json");
        try {
            FileInputStream fi = new FileInputStream(f);
            ByteArrayOutputStream buf = new ByteArrayOutputStream();
            byte[] tmp = new byte[4096]; int r;
            while ((r = fi.read(tmp)) > 0) buf.write(tmp, 0, r);
            fi.close();
            importJson(new String(buf.toByteArray(), UTF8), ctx);
        } catch (Throwable ignored) {}
    }

    public static void deleteConfig(Context ctx, String name) {
        new File(new File(ctx.getFilesDir(), DIR), name + ".json").delete();
    }
}
