package com.nyaui.me.ui;

import android.content.Context;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import androidx.appcompat.widget.AppCompatTextView;

public class WatermarkView extends AppCompatTextView {

    public WatermarkView(Context context) {
        super(context);
        initialize();
    }

    private void initialize() {
        setText("  NyaUI  ");
        setTypeface(Typeface.DEFAULT_BOLD);
        setTextSize(22f);
        int themeColor = ThemeManager.getThemeColor();
        int watermarkColor = (themeColor & 0x00FFFFFF) | 0x33000000;
        setTextColor(watermarkColor);
        setShadowLayer(0, 0, 0, 0);
        setGravity(Gravity.START | Gravity.TOP);
        
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        params.leftMargin = dpToPx(20);
        params.topMargin = dpToPx(60);
        setLayoutParams(params);
    }

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density);
    }
}