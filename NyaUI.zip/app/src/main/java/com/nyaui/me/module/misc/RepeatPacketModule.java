package com.nyaui.me.module.misc;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class RepeatPacketModule extends Module {
    public RepeatPacketModule() { super("RepeatPacket", ModuleCategory.MISC, ""); setChineseName("Repeat Packet"); }
    @Override public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("RepeatPacket"); } catch (Throwable t) {} }
    @Override public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("RepeatPacket"); } catch (Throwable t) {} }
    @Override public void configureSubMenu(SubMenuPanel s) {
        super.configureSubMenu(s);
        s.addSlider("Repeat Count", 1, 10, SafeCall.getInt(getName(), 0), "%d", v -> SafeCall.setInt(getName(), 0, (int)v));
    }
}
