package com.nyaui.me.media;

import android.net.Uri;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LyricFetcher {

    public static class Line {
        public final long t;
        public final String text;
        Line(long t, String text) { this.t = t; this.text = text; }
    }

    private static final ExecutorService POOL = Executors.newSingleThreadExecutor();
    private static final Map<String, List<Line>> CACHE = new HashMap<>();
    private static final Object LOCK = new Object();
    private static String pendingKey = "";

    public static void request(String title, String artist) { request(title, artist, 0L); }

    public static void request(String title, String artist, long durationMs) {
        if (title == null || title.isEmpty()) return;
        final String key = title + "|" + (artist == null ? "" : artist);
        synchronized (LOCK) {
            if (CACHE.containsKey(key)) return;
            if (key.equals(pendingKey)) return;
            pendingKey = key;
        }
        final long dur = durationMs;
        POOL.submit(() -> {
            List<Line> result = null;
            try { result = fetch(title, artist, dur); } catch (Throwable ignored) {}
            synchronized (LOCK) {
                CACHE.put(key, result == null ? new ArrayList<>() : result);
                pendingKey = "";
            }
        });
    }

    public static class Cur {
        public final String text;
        public final long start, end;
        Cur(String t, long s, long e) { text = t; start = s; end = e; }
    }

    public static Cur current(String title, String artist, long positionMs) {
        if (title == null) return null;
        String key = title + "|" + (artist == null ? "" : artist);
        List<Line> lines;
        synchronized (LOCK) { lines = CACHE.get(key); }
        if (lines == null) { request(title, artist); return null; }
        if (lines.isEmpty()) return null;
        int idx = -1;
        for (int i = 0; i < lines.size(); i++) {
            if (lines.get(i).t <= positionMs + 120) idx = i;
            else break;
        }
        if (idx < 0) return null;
        long start = lines.get(idx).t;
        long end = (idx + 1 < lines.size()) ? lines.get(idx + 1).t : start + 4000;
        return new Cur(lines.get(idx).text, start, end);
    }

    public static String lineFor(String title, String artist, long positionMs) {
        if (title == null) return null;
        String key = title + "|" + (artist == null ? "" : artist);
        List<Line> lines;
        synchronized (LOCK) { lines = CACHE.get(key); }
        if (lines == null) { request(title, artist); return null; }
        if (lines.isEmpty()) return null;
        String cur = null;
        for (Line l : lines) {
            if (l.t <= positionMs + 120) cur = l.text;
            else break;
        }
        return cur;
    }

    public static boolean hasLyrics(String title, String artist) {
        if (title == null) return false;
        String key = title + "|" + (artist == null ? "" : artist);
        synchronized (LOCK) {
            List<Line> l = CACHE.get(key);
            return l != null && !l.isEmpty();
        }
    }

    private static List<Line> fetch(String title, String artist, long durationMs) throws Exception {
        String q = title + (artist != null && !artist.isEmpty() ? " " + artist : "");
        String searchUrl = "https://music.163.com/api/search/get?type=1&limit=8&s="
                + Uri.encode(q);
        String searchResp = http(searchUrl);
        if (searchResp == null) return null;
        JSONObject sj = new JSONObject(searchResp);
        JSONObject res = sj.optJSONObject("result");
        if (res == null) return null;
        JSONArray songs = res.optJSONArray("songs");
        if (songs == null || songs.length() == 0) return null;
        long id = pickSong(songs, title, artist, durationMs);
        if (id == 0) return null;

        String lyricUrl = "https://music.163.com/api/song/lyric?os=pc&lv=-1&kv=-1&tv=-1&id=" + id;
        String lyricResp = http(lyricUrl);
        if (lyricResp == null) return null;
        JSONObject lj = new JSONObject(lyricResp);
        JSONObject lrc = lj.optJSONObject("lrc");
        if (lrc == null) return null;
        String raw = lrc.optString("lyric", "");
        if (raw.isEmpty()) return null;
        return parseLrc(raw);
    }

    private static long pickSong(JSONArray songs, String title, String artist, long durationMs) {
        String wantT = norm(title);
        String wantA = norm(artist);
        long best = 0;
        int bestScore = -1;
        for (int i = 0; i < songs.length(); i++) {
            JSONObject s = songs.optJSONObject(i);
            if (s == null) continue;
            long id = s.optLong("id", 0);
            if (id == 0) continue;
            String nm = norm(s.optString("name", ""));
            String ar = "";
            JSONArray arts = s.optJSONArray("artists");
            if (arts != null) {
                StringBuilder sb = new StringBuilder();
                for (int j = 0; j < arts.length(); j++) {
                    JSONObject a = arts.optJSONObject(j);
                    if (a != null) sb.append(a.optString("name", "")).append(" ");
                }
                ar = norm(sb.toString());
            }
            int score = 0;
            if (nm.equals(wantT)) score += 4;
            else if (nm.contains(wantT) || wantT.contains(nm)) score += 2;
            if (!wantA.isEmpty()) {
                if (ar.contains(wantA) || wantA.contains(ar)) score += 3;
                else {
                    boolean any = false;
                    for (String part : wantA.split("[/、,&]+"))
                        if (!part.trim().isEmpty() && ar.contains(part.trim())) { any = true; break; }
                    if (any) score += 2;
                }
            }
            long dur = s.optLong("duration", 0L);
            if (durationMs > 0 && dur > 0) {
                long diff = Math.abs(dur - durationMs);
                if (diff <= 3000) score += 3;
                else if (diff <= 8000) score += 1;
            }
            if (score > bestScore) { bestScore = score; best = id; }
        }
        
        return bestScore >= 2 ? best : 0;
    }

    private static String norm(String s) {
        if (s == null) return "";
        return s.toLowerCase().replaceAll("[\\s\\(\\)\\[\\]（）【】\\-_~·]+", "").trim();
    }

    private static boolean isMetaLine(String s) {
        String t = s.trim();
        if (t.length() > 40 && (t.contains(":") || t.contains("："))) return true;
        String[] keys = {"Lyricist", "Composer", "Arranger", "Producer", "Mixing", "Mastering", "Recording", "Supervisor",
                "Released by", "Presented by", "Planner", "Vocals", "Harmony", "Guitar", "Bass", "Drums",
                "Producer", "Composer", "Lyricist", "Arranger", "Mixing", "Mastering"};
        for (String k : keys) {
            if (t.startsWith(k) || t.contains(k + " :") || t.contains(k + ":")
                    || t.contains(k + " ：") || t.contains(k + "：")) return true;
        }
        return false;
    }

    private static List<Line> parseLrc(String raw) {
        List<Line> out = new ArrayList<>();
        long offset = 0;
        java.util.regex.Matcher om = java.util.regex.Pattern
                .compile("\\[offset:(-?\\d+)\\]").matcher(raw);
        if (om.find()) {
            try { offset = Long.parseLong(om.group(1)); } catch (Throwable ignored) {}
        }
        for (String line : raw.split("\n")) {
            int close = line.lastIndexOf(']');
            if (close < 0) continue;
            String text = line.substring(close + 1).trim();
            int idx = 0;
            while (idx < line.length()) {
                int open = line.indexOf('[', idx);
                if (open < 0) break;
                int end = line.indexOf(']', open);
                if (end < 0) break;
                String tag = line.substring(open + 1, end);
                long t = parseTime(tag);
                if (t >= 0 && !text.isEmpty() && !isMetaLine(text)) {
                    long adj = t - offset;
                    out.add(new Line(adj < 0 ? 0 : adj, text));
                }
                idx = end + 1;
            }
        }
        Collections.sort(out, (a, b) -> Long.compare(a.t, b.t));
        return out;
    }

    private static long parseTime(String tag) {
        try {
            int colon = tag.indexOf(':');
            if (colon < 0) return -1;
            int mm = Integer.parseInt(tag.substring(0, colon).trim());
            String rest = tag.substring(colon + 1);
            float ss = Float.parseFloat(rest.trim());
            return (long) (mm * 60_000L + ss * 1000L);
        } catch (Throwable t) {
            return -1;
        }
    }

    private static String http(String urlStr) {
        HttpURLConnection c = null;
        try {
            URL url = new URL(urlStr);
            c = (HttpURLConnection) url.openConnection();
            c.setConnectTimeout(4000);
            c.setReadTimeout(4000);
            c.setRequestProperty("User-Agent",
                    "Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 Chrome/110 Mobile Safari/537.36");
            c.setRequestProperty("Referer", "https://music.163.com/");
            c.setRequestProperty("Accept", "application/json");
            int code = c.getResponseCode();
            if (code != 200) return null;
            BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String ln;
            while ((ln = br.readLine()) != null) sb.append(ln);
            br.close();
            return sb.toString();
        } catch (Throwable t) {
            return null;
        } finally {
            if (c != null) try { c.disconnect(); } catch (Throwable ignored) {}
        }
    }
}
