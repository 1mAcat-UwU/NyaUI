package com.nyaui.me.module.visual;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class FogCustomModule extends Module {
    public FogCustomModule() { super("FogCustom", ModuleCategory.VISUAL, ""); setChineseName("Custom Fog"); }
    @Override public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("FogCustom"); } catch (Throwable t) {} }
    @Override public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("FogCustom"); } catch (Throwable t) {} }
    @Override public void configureSubMenu(SubMenuPanel s) {
        super.configureSubMenu(s);
        String n = getName();
        s.addSlider("Red", 0, 100, (int)(SafeCall.getFloat(n, 0) * 100), "%d", v -> SafeCall.setFloat(n, 0, v / 100f));
        s.addSlider("Green", 0, 100, (int)(SafeCall.getFloat(n, 1) * 100), "%d", v -> SafeCall.setFloat(n, 1, v / 100f));
        s.addSlider("Blue", 0, 100, (int)(SafeCall.getFloat(n, 2) * 100), "%d", v -> SafeCall.setFloat(n, 2, v / 100f));
        s.addSlider("Opacity", 0, 100, (int)(SafeCall.getFloat(n, 3) * 100), "%d", v -> SafeCall.setFloat(n, 3, v / 100f));
        s.addSlider("Fog Start", 0, 20, (int)SafeCall.getFloat(n, 4), "%d", v -> SafeCall.setFloat(n, 4, v));
        s.addSlider("Fog End", 0, 20, (int)SafeCall.getFloat(n, 5), "%d", v -> SafeCall.setFloat(n, 5, v));
    }
}
