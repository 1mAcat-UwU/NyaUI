package com.nyaui.me.module.settings;

import com.nyaui.me.config.ConfigManager;
import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.ui.FrameRate;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class FakeFpsModule extends Module {
    private static final String CFG = "FakeFps";
    private static final String K_ENABLED = "enabled";
    private static final String K_VALUE = "value";

    public FakeFpsModule() {
        super("FakeFps", ModuleCategory.SETTINGS, "");
        setChineseName("FakeFps");
        boolean on = ConfigManager.getBoolean(CFG, K_ENABLED, false);
        int val = ConfigManager.getInt(CFG, K_VALUE, 120);
        FrameRate.setFakeFps(on, val);
        if (on) {
            try { enable(); } catch (Throwable ignored) {}
        }
    }

    @Override
    public boolean shouldShowInArraylist() {
        return false;
    }

    @Override
    public boolean supportsShortcut() {
        return false;
    }

    @Override
    protected void onEnable() {
        super.onEnable();
        int val = ConfigManager.getInt(CFG, K_VALUE, 120);
        ConfigManager.saveBoolean(CFG, K_ENABLED, true);
        FrameRate.setFakeFps(true, val);
    }

    @Override
    protected void onDisable() {
        super.onDisable();
        ConfigManager.saveBoolean(CFG, K_ENABLED, false);
        FrameRate.setFakeFps(false, ConfigManager.getInt(CFG, K_VALUE, 120));
    }

    @Override
    public void configureSubMenu(SubMenuPanel subMenu) {
        super.configureSubMenu(subMenu);
        subMenu.addSectionTitle("Fake FPS");
        int val = ConfigManager.getInt(CFG, K_VALUE, 120);
        subMenu.addSlider("FPS Value", 1, 999, val, "%d", v -> {
            ConfigManager.saveInt(CFG, K_VALUE, (int) v);
            FrameRate.setFakeFps(isEnabled(), (int) v);
        });
    }
}
