package com.nyaui.me.module;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleManager;

public class ModuleBridge {
    
    

    public static boolean getEnabledByName(String name) {
        Module module = ModuleManager.getModuleByName(name);
        return module != null && module.isEnabled();
    }
    
    

    public static void toggleModuleByName(String name) {
        Module module = ModuleManager.getModuleByName(name);
        if (module != null) {
            module.toggle();
        }
    }
    
    

    public static void enableModuleByName(String name) {
        Module module = ModuleManager.getModuleByName(name);
        if (module != null && !module.isEnabled()) {
            module.enable();
        }
    }
    
    

    public static void disableModuleByName(String name) {
        Module module = ModuleManager.getModuleByName(name);
        if (module != null && module.isEnabled()) {
            module.disable();
        }
    }
    
    

    public static String getChineseByName(String name) {
        Module module = ModuleManager.getModuleByName(name);
        if (module != null) {
            return module.getChineseName();
        }
        return name;
    }
    
    

    public static int getModuleCountByCategory(String category) {
        return ModuleManager.getModulesByCategory(
            getCategoryFromString(category)
        ).size();
    }
    
    

    public static String getModuleNameByCategoryAndCount(String category, int index) {
        try {
            return ModuleManager.getModulesByCategory(
                getCategoryFromString(category)
            ).get(index).getName();
        } catch (Exception e) {
            return "";
        }
    }
    
    

    public static String getModuleChineseByCategoryAndCount(String category, int index) {
        try {
            return ModuleManager.getModulesByCategory(
                getCategoryFromString(category)
            ).get(index).getChineseName();
        } catch (Exception e) {
            return "";
        }
    }
    
    

    private static ModuleCategory getCategoryFromString(String category) {
        switch (category.toUpperCase()) {
            case "COMBAT":
                return ModuleCategory.COMBAT;
            case "MOVEMENT":
                return ModuleCategory.MOVEMENT;
            case "PLAYER":
                return ModuleCategory.PLAYER;
            case "VISUAL":
                return ModuleCategory.VISUAL;
            case "WORLD":
                return ModuleCategory.WORLD;
            default:
                return ModuleCategory.VISUAL;
        }
    }
}

