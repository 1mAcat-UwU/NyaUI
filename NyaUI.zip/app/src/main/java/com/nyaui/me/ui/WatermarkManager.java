package com.nyaui.me.ui;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.PopupWindow;
import android.widget.TextView;

public class WatermarkManager {
    private static WatermarkView watermarkView;
    private static PopupWindow popupWindow;
    private static boolean isShown = false;
    private static Activity currentActivity;
    private static final int MARGIN_DP = 16; 

    public static void init(Activity activity) {
        currentActivity = activity;
    }

    public static void show() {
        if (isShown || currentActivity == null) return;

        currentActivity.runOnUiThread(() -> {
            try {
               
                hide();
                
                
                watermarkView = new WatermarkView(currentActivity);
                
                
                
                
                
                int textAlpha = 128; 
                
                
                int originalColor = watermarkView.getCurrentTextColor();
                int red = Color.red(originalColor);
                int green = Color.green(originalColor);
                int blue = Color.blue(originalColor);
                int newColor = Color.argb(textAlpha, red, green, blue);
                watermarkView.setTextColor(newColor);

                
                watermarkView.measure(
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
                );
                
                int width = Math.max(watermarkView.getMeasuredWidth(), 200); 
                int height = Math.max(watermarkView.getMeasuredHeight(), 80); 

                
                popupWindow = new PopupWindow(watermarkView, width, height, false);
                popupWindow.setTouchable(false);
                popupWindow.setFocusable(false);
                popupWindow.setOutsideTouchable(false);
                popupWindow.setClippingEnabled(true); 
                
                
                android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
                bg.setColor(android.graphics.Color.TRANSPARENT);
                popupWindow.setBackgroundDrawable(bg);
                
                

                
                DisplayMetrics metrics = new DisplayMetrics();
                currentActivity.getWindowManager().getDefaultDisplay().getRealMetrics(metrics);
                int marginPx = dpToPx(MARGIN_DP);
                int x = marginPx;  
                int y = marginPx;  

                
                View decorView = currentActivity.getWindow().getDecorView();
                decorView.post(() -> {
                    try {
                        if (popupWindow != null && !popupWindow.isShowing()) {
                            popupWindow.showAtLocation(decorView, Gravity.NO_GRAVITY, x, y);
                            isShown = true;
                        }
                    } catch (Exception e) {
                        isShown = false;
                    }
                });
                
            } catch (Exception e) {
                
                isShown = false;
                if (popupWindow != null) {
                    try {
                        popupWindow.dismiss();
                    } catch (Exception ignored) {}
                    popupWindow = null;
                }
            }
        });
    }

    public static void hide() {
        if (currentActivity == null) return;

        currentActivity.runOnUiThread(() -> {
            try {
                if (popupWindow != null && popupWindow.isShowing()) {
                    popupWindow.dismiss();
                }
            } catch (Exception ignored) {}
            popupWindow = null;
            watermarkView = null;
            isShown = false;
        });
    }

    
    public static void updatePosition() {
        if (!isShown || popupWindow == null || currentActivity == null) {
            return;
        }

        currentActivity.runOnUiThread(() -> {
            DisplayMetrics metrics = new DisplayMetrics();
            currentActivity.getWindowManager().getDefaultDisplay().getRealMetrics(metrics);
            int marginPx = dpToPx(MARGIN_DP);
            
            
            int widthMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
            int heightMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
            watermarkView.measure(widthMeasureSpec, heightMeasureSpec);
            
            
            int x = marginPx;
            int y = marginPx;

            View decorView = currentActivity.getWindow().getDecorView();
            if (popupWindow.isShowing()) {
                popupWindow.update(x, y, -1, -1);
            }
        });
    }

    
    public static void setTextAlpha(float alpha) {
        if (watermarkView != null && currentActivity != null) {
            currentActivity.runOnUiThread(() -> {
                try {
                    
                    int alphaValue = (int) (alpha * 255);
                    if (alphaValue < 0) alphaValue = 0;
                    if (alphaValue > 255) alphaValue = 255;
                    
                    
                    int originalColor = watermarkView.getCurrentTextColor();
                    int red = Color.red(originalColor);
                    int green = Color.green(originalColor);
                    int blue = Color.blue(originalColor);
                    int newColor = Color.argb(alphaValue, red, green, blue);
                    watermarkView.setTextColor(newColor);
                } catch (Exception e) {
                    
                }
            });
        }
    }

    private static int dpToPx(int dp) {
        if (currentActivity == null) return dp;
        return (int) (dp * currentActivity.getResources().getDisplayMetrics().density + 0.5f);
    }

    public static void cleanup() {
        hide();
        watermarkView = null;
        currentActivity = null;
    }
}