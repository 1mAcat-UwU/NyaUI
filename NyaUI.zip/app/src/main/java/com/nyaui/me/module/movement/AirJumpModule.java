package com.nyaui.me.module.movement;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;

public class AirJumpModule extends Module {
    public AirJumpModule() { super("AirJump", ModuleCategory.MOVEMENT, ""); setChineseName("Air Jump"); }
    @Override public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("AirJump"); } catch (Throwable t) {} }
    @Override public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("AirJump"); } catch (Throwable t) {} }
}
