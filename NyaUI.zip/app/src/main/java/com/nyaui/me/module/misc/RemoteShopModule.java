package com.nyaui.me.module.misc;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;

public class RemoteShopModule extends Module {
    public RemoteShopModule() { super("RemoteShop", ModuleCategory.MISC, ""); setChineseName("Remote Shop"); }
    @Override public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("RemoteShop"); } catch (Throwable t) {} }
    @Override public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("RemoteShop"); } catch (Throwable t) {} }
}
