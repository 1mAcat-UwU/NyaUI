package com.nyaui.me.module.settings;

import android.content.Context;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.nyaui.me.config.ConfigManager;
import com.nyaui.me.media.MediaReader;
import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.ui.FrameRate;
import com.nyaui.me.ui.IslandOverlay;
import com.nyaui.me.ui.ThemeManager;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class IslandModule extends Module {

    public IslandModule() {
        super("DynamicIsland", ModuleCategory.SETTINGS, "");
        setChineseName("Dynamic Island");
    }

    @Override public boolean shouldShowInArraylist() { return false; }
    @Override public boolean supportsShortcut() { return false; }

    @Override protected void onEnable() {
        ConfigManager.setDynamicIslandEnabled(true);
    }

    @Override protected void onDisable() {
        ConfigManager.setDynamicIslandEnabled(false);
    }

    public static void ensureDefaultEnabled() {
        com.nyaui.me.module.Module module = com.nyaui.me.module.ModuleManager.getModuleByName("DynamicIsland");
        if (module instanceof IslandModule && ConfigManager.getBoolean(IslandOverlay.CFG, IslandOverlay.K_ISLAND, true) && !module.isEnabled()) {
            module.enable();
        }
    }

    @Override
    public void configureSubMenu(SubMenuPanel subMenu) {
        super.configureSubMenu(subMenu);
        final Context ctx = subMenu.getContext();
        final float d = ctx.getResources().getDisplayMetrics().density;

        subMenu.addSectionTitle("Dynamic Island");

        subMenu.addSwitch("Enable Dynamic Island",
                ConfigManager.getBoolean(IslandOverlay.CFG, IslandOverlay.K_ISLAND, true),
                on -> { if (on) enable(); else disable(); });

        subMenu.addSwitch("Read & Show Music",
                ConfigManager.getBoolean(IslandOverlay.CFG, IslandOverlay.K_MUSIC, true),
                on -> ConfigManager.saveBoolean(IslandOverlay.CFG, IslandOverlay.K_MUSIC, on));

        subMenu.addDivider();
        subMenu.addSectionTitle("Music Access Permission");

        final TextView status = new TextView(ctx);
        status.setTextSize(11f);
        status.setPadding((int) (4 * d), 0, 0, (int) (6 * d));
        boolean granted = MediaReader.hasAccess(ctx);
        status.setText(granted ? "Status: Authorized" : "Status: Not authorized, no music");
        status.setTextColor(granted ? 0xFF88DD88 : 0xFFFF8888);
        subMenu.addCustomView(status);

        LinearLayout row = new LinearLayout(ctx);
        row.setGravity(Gravity.CENTER);
        row.setPadding(0, (int) (4 * d), 0, (int) (4 * d));

        TextView btn = new TextView(ctx);
        btn.setText(granted ? "Authorized" : "Revoke Access");
        btn.setTextColor(0xFFFFFFFF);
        btn.setTextSize(10.5f);
        btn.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        btn.setGravity(Gravity.CENTER);
        btn.setPadding((int) (16 * d), (int) (7 * d), (int) (16 * d), (int) (7 * d));
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(granted ? 0xFF666680 : ThemeManager.getThemeColor());
        bg.setCornerRadius(8 * d);
        btn.setBackground(bg);
        btn.setClickable(true);
        btn.setOnClickListener(v -> {
            MediaReader.openAccessSettings(ctx);
            Toast.makeText(ctx, "Find NyaUI in the list and enable it", Toast.LENGTH_LONG).show();
        });
        row.addView(btn);
        subMenu.addCustomView(row);

        subMenu.addText("After granting access, play any music to show cover, title and lyrics on the Dynamic Island");

        subMenu.addDivider();
        subMenu.addSectionTitle("Refresh Rate Info");

        final TextView modeInfo = new TextView(ctx);
        modeInfo.setTextSize(10f);
        modeInfo.setTextColor(ThemeManager.getTextSecondary());
        modeInfo.setPadding((int) (4 * d), 0, 0, (int) (6 * d));
        modeInfo.setText(readModes(ctx));
        subMenu.addCustomView(modeInfo);

        subMenu.addText("Shows the real display modes reported by the system. If max is only 120,"
                + "the system does not expose higher modes (display settings or battery saver may limit it).");
    }

     
    private String readModes(Context ctx) {
        android.app.Activity act = null;
        Context c = ctx;
        while (c instanceof android.content.ContextWrapper) {
            if (c instanceof android.app.Activity) { act = (android.app.Activity) c; break; }
            c = ((android.content.ContextWrapper) c).getBaseContext();
        }
        if (act != null) return FrameRate.describeModes(act);
        return "No Activity, cannot read display mode";
    }
}
