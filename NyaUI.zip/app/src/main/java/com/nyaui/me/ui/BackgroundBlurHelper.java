package com.nyaui.me.ui;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Build;
import android.view.View;
import android.view.ViewParent;
import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;

import java.lang.reflect.Method;

public final class BackgroundBlurHelper {

    private static final String CLASS_VIEW_ROOT_IMPL = "android.view.ViewRootImpl";
    private static final String CLASS_BACKGROUND_BLUR_DRAWABLE = "com.android.internal.graphics.drawable.BackgroundBlurDrawable";

    private BackgroundBlurHelper() {}

    public static void attachBackgroundBlur(@NonNull View target, int blurRadius, float cornerDp) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            return;
        }
        Context context = target.getContext().getApplicationContext();
        WindowManager wm = context.getSystemService(WindowManager.class);
        if (wm == null || !wm.isCrossWindowBlurEnabled()) {
            return;
        }
        if (target.isAttachedToWindow()) {
            applyBlurNow(target, blurRadius, cornerDp);
        } else {
            target.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
                @Override
                public void onViewAttachedToWindow(View v) {
                    target.removeOnAttachStateChangeListener(this);
                    applyBlurNow(target, blurRadius, cornerDp);
                }
                @Override
                public void onViewDetachedFromWindow(View v) {}
            });
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.S)
    private static void applyBlurNow(@NonNull View target, int blurRadius, float cornerDp) {
        try {
            target.setLayerType(View.LAYER_TYPE_HARDWARE, null);
            Object viewRootImpl = findViewRootImpl(target);
            if (viewRootImpl == null) {
                return;
            }
            Class<?> vriClass = Class.forName(CLASS_VIEW_ROOT_IMPL);
            Method createBgBlurMethod = vriClass.getMethod("createBackgroundBlurDrawable");
            Object blurDrawable = createBgBlurMethod.invoke(viewRootImpl);
            if (!(blurDrawable instanceof Drawable)) {
                return;
            }
            Class<?> blurClass = Class.forName(CLASS_BACKGROUND_BLUR_DRAWABLE);
            Method setBlurRadius = blurClass.getMethod("setBlurRadius", int.class);
            setBlurRadius.invoke(blurDrawable, Math.min(blurRadius, 150));
            float density = target.getResources().getDisplayMetrics().density;
            float rPx = cornerDp * density;
            Method setCornerRadius4 = blurClass.getMethod("setCornerRadius", float.class, float.class, float.class, float.class);
            setCornerRadius4.invoke(blurDrawable, rPx, rPx, rPx, rPx);
            Method setColor = blurClass.getMethod("setColor", int.class);
            setColor.invoke(blurDrawable, 0x00FFFFFF);
            Drawable blur = (Drawable) blurDrawable;
            Drawable original = target.getBackground();
            Drawable finalBg;
            if (original != null) {
                finalBg = new LayerDrawable(new Drawable[]{blur, original});
            } else {
                finalBg = blur;
            }
            target.setBackground(finalBg);
        } catch (Exception e) {
        }
    }

    private static Object findViewRootImpl(@NonNull View view) {
        ViewParent parent = view.getParent();
        while (parent != null) {
            String name = parent.getClass().getName();
            if (CLASS_VIEW_ROOT_IMPL.equals(name)) {
                return parent;
            }
            parent = parent.getParent();
        }
        return null;
    }
}
