package com.nyaui.me.module.visual;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;

public class DrawPathModule extends Module {
    public DrawPathModule() { super("DrawPath", ModuleCategory.VISUAL, ""); setChineseName("Draw Path"); }
    @Override public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("DrawPath"); } catch (Throwable t) {} }
    @Override public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("DrawPath"); } catch (Throwable t) {} }
}
