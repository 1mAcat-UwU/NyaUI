package com.nyaui.me.ui.widgets;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.AnimationUtils;

import com.nyaui.me.ui.ThemeManager;

public class CustomSlider extends View {
    private final Paint bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint thumbPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();

    private float min = 0f;
    private float max = 100f;
    private float value = 0f;
    private float prog = 0f;
    private float visualProg = 0f;
    private float thumbScale = 1f;
    private float targetScale = 1f;
    private long lastFrame = 0L;
    private int trackH;
    private float scaleFactor = 1f;

    private OnValueChangeListener listener;

    public interface OnValueChangeListener {
        void onValueChanged(float value);
    }

    public CustomSlider(Context ctx) {
        super(ctx);
        trackH = Math.max(2, (int) (ctx.getResources().getDisplayMetrics().density * 3));
        
        
        
    }

    public CustomSlider(Context ctx, String name, String label, int min, int max, int defaultValue, OnValueChangeListener l) {
        super(ctx);
        trackH = Math.max(2, (int) (ctx.getResources().getDisplayMetrics().density * 3));
        this.min = min;
        this.max = max;
        this.value = defaultValue - min;
        this.listener = l;
        recompute();
        visualProg = prog;
    }

    public void setRange(float min, float max) { this.min = min; this.max = max; recompute(); }
    public void setValue(float v) { this.value = v - min; recompute(); postInvalidateOnAnimation(); }
    public float getValue() { return value + min; }
    public void setOnValueChangeListener(OnValueChangeListener l) { this.listener = l; }
    public void setScaleFactor(float s) { this.scaleFactor = s; requestLayout(); }
    public void updateScale(float s) { setScaleFactor(s); }

    private void recompute() {
        prog = (max > min) ? Math.max(0f, Math.min(1f, value / (max - min))) : 0f;
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        float d = getResources().getDisplayMetrics().density * scaleFactor;
        setMeasuredDimension(MeasureSpec.getSize(wSpec), (int) (22 * d));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        long now = AnimationUtils.currentAnimationTimeMillis();
        float dt = lastFrame == 0 ? 16 : Math.max(1, Math.min(64, now - lastFrame));
        lastFrame = now;

        float lerp = 1f - (float) Math.exp(-dt / 80f);
        visualProg += (prog - visualProg) * lerp;
        thumbScale += (targetScale - thumbScale) * (1f - (float) Math.exp(-dt / 120f));

        float w = getWidth();
        float h = getHeight();
        float cy = h / 2f;
        float tt = cy - trackH / 2f;
        float tb = cy + trackH / 2f;
        float rd = trackH / 2f;

        bgPaint.setColor(ThemeManager.getStateDisabled());
        rect.set(0, tt, w, tb);
        canvas.drawRoundRect(rect, rd, rd, bgPaint);

        float fw = w * visualProg;
        fillPaint.setColor(ThemeManager.getThemeColor());
        rect.set(0, tt, fw, tb);
        canvas.drawRoundRect(rect, rd, rd, fillPaint);

        float tr = trackH * 1.7f * thumbScale;
        float tx = Math.max(tr, Math.min(fw, w - tr));
        thumbPaint.setColor(Color.WHITE);
        thumbPaint.clearShadowLayer();
        canvas.drawCircle(tx, cy, tr, thumbPaint);

        if (Math.abs(visualProg - prog) > 0.001f || Math.abs(thumbScale - targetScale) > 0.005f) {
            postInvalidateOnAnimation();
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getAction()) {
            case MotionEvent.ACTION_DOWN:
                targetScale = 1.18f;
                updateFromTouch(e.getX());
                getParent().requestDisallowInterceptTouchEvent(true);
                postInvalidateOnAnimation();
                return true;
            case MotionEvent.ACTION_MOVE:
                updateFromTouch(e.getX());
                postInvalidateOnAnimation();
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                targetScale = 1f;
                getParent().requestDisallowInterceptTouchEvent(false);
                postInvalidateOnAnimation();
                return true;
        }
        return super.onTouchEvent(e);
    }

    private void updateFromTouch(float x) {
        prog = Math.max(0f, Math.min(1f, x / getWidth()));
        value = prog * (max - min);
        if (listener != null) listener.onValueChanged(value + min);
    }
}
