package com.nyaui.me.module.visual;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;

public class NightVisionModule extends Module {
    public NightVisionModule() { super("NightVision", ModuleCategory.VISUAL, ""); setChineseName("Night Vision"); }
    @Override public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("NightVision"); } catch (Throwable t) {} }
    @Override public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("NightVision"); } catch (Throwable t) {} }
}
