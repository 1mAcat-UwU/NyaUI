package com.nyaui.me.ui;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.KeyEvent;
import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;

import com.nyaui.me.module.ModuleManager;
import com.nyaui.me.module.Module;

public class KeybindManager {
    private static KeybindManager instance;
    private static final String PREFS_NAME = "Remedy_Keybinds";
    private final Map<Integer, List<String>> keyToModulesMap = new HashMap<>();
    private final Map<String, Integer> moduleToKeyMap = new HashMap<>();
    private SharedPreferences sharedPreferences;

    private KeybindManager() {}

    public static synchronized KeybindManager getInstance() {
        if (instance == null) {
            instance = new KeybindManager();
        }
        return instance;
    }

    public void initialize(Context context) {
        sharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        loadKeybinds();
    }

    public void bindKey(String moduleName, int keyCode) {
        unbindKey(moduleName);
        
        
        List<String> modules = keyToModulesMap.get(keyCode);
        if (modules == null) {
            modules = new ArrayList<>();
            keyToModulesMap.put(keyCode, modules);
        }
        if (!modules.contains(moduleName)) {
            modules.add(moduleName);
        }
        
        moduleToKeyMap.put(moduleName, keyCode);
        saveKeybind(moduleName, keyCode);
    }

    public void unbindKey(String moduleName) {
        if (moduleToKeyMap.containsKey(moduleName)) {
            int oldKeyCode = moduleToKeyMap.get(moduleName);
            
            
            List<String> modules = keyToModulesMap.get(oldKeyCode);
            if (modules != null) {
                modules.remove(moduleName);
                if (modules.isEmpty()) {
                    keyToModulesMap.remove(oldKeyCode);
                }
            }
            
            moduleToKeyMap.remove(moduleName);
            removeKeybind(moduleName);
        }
    }

    public String getModuleForKey(int keyCode) {
        List<String> modules = keyToModulesMap.get(keyCode);
        return (modules != null && !modules.isEmpty()) ? modules.get(0) : null;
    }

    public List<String> getModulesForKey(int keyCode) {
        List<String> modules = keyToModulesMap.get(keyCode);
        return (modules != null) ? new ArrayList<>(modules) : new ArrayList<>();
    }

    public int getKeyForModule(String moduleName) {
        Integer keyCode = moduleToKeyMap.get(moduleName);
        return (keyCode == null) ? KeyEvent.KEYCODE_UNKNOWN : keyCode;
    }

    public static String getKeyName(int keyCode) {
        if (keyCode == KeyEvent.KEYCODE_UNKNOWN) return "NONE";
        String keyName = KeyEvent.keyCodeToString(keyCode).replace("KEYCODE_", "");
        if (keyName.equals("DEL")) return "DELETE";
        if (keyName.startsWith("NUMPAD_")) return keyName.replace("NUMPAD_", "NUM ");
        return keyName;
    }

    

    public boolean handleKeyEvent(int keyCode) {
        List<String> modules = getModulesForKey(keyCode);
        if (modules.isEmpty()) {
            return false;
        }

        boolean triggered = false;
        for (String moduleName : modules) {
            Module module = ModuleManager.getModuleByName(moduleName);
            if (module != null) {
                module.toggle();
                triggered = true;
            }
        }
        return triggered;
    }

    private void saveKeybind(String moduleName, int keyCode) {
        sharedPreferences.edit().putInt(moduleName, keyCode).apply();
    }

    private void removeKeybind(String moduleName) {
        sharedPreferences.edit().remove(moduleName).apply();
    }

    private void loadKeybinds() {
        Map<String, ?> allEntries = sharedPreferences.getAll();
        for (Map.Entry<String, ?> entry : allEntries.entrySet()) {
            if (entry.getValue() instanceof Integer) {
                String moduleName = entry.getKey();
                int keyCode = (Integer) entry.getValue();
                
                
                List<String> modules = keyToModulesMap.get(keyCode);
                if (modules == null) {
                    modules = new ArrayList<>();
                    keyToModulesMap.put(keyCode, modules);
                }
                if (!modules.contains(moduleName)) {
                    modules.add(moduleName);
                }
                
                moduleToKeyMap.put(moduleName, keyCode);
            }
        }
    }
}

