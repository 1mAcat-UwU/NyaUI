package com.nyaui.me.module.visual;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;

public class ShowPositionModule extends Module {
    public ShowPositionModule() { super("ShowPosition", ModuleCategory.VISUAL, ""); setChineseName("Show Coordinates"); }
    @Override public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("ShowPosition"); } catch (Throwable t) {} }
    @Override public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("ShowPosition"); } catch (Throwable t) {} }
}
