package com.nyaui.me.ui;

import android.app.Activity;
import android.view.WindowManager;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.visual.NotificationsModule;

import java.util.ArrayList;
import java.util.List;

public class NotificationManager {
    private static final List<NotificationView> activeNotifications = new ArrayList<>();
    private static Activity currentActivity;
    private static WindowManager windowManager;
    private static boolean enabled = true;
    private static final int DISPLAY_DURATION = 2000;
    private static final int ANIMATION_DURATION = 250;

    public static void init(Activity activity) {
        currentActivity = activity;
        if (activity != null) {
            windowManager = (WindowManager) activity.getSystemService(Activity.WINDOW_SERVICE);
        }
    }

    public static void setEnabled(boolean e) {
        enabled = e;
    }

    public static void showNotification(Module module, boolean isEnabled) {
        NotificationsModule mod = NotificationsModule.getInstance();
        if (mod == null || !mod.isEnabled()) {
            return;
        }

        if (currentActivity == null || windowManager == null) return;

        currentActivity.runOnUiThread(() -> {
            NotificationView notification = new NotificationView(currentActivity, module, isEnabled);
            activeNotifications.add(notification);
            updateAllPositions();
            try { SoundPlayer.playClick(); } catch (Throwable ignored) {}
            notification.show(windowManager, activeNotifications.size() - 1);
            notification.postDelayed(() -> {
                removeNotification(notification);
            }, DISPLAY_DURATION + ANIMATION_DURATION + 200);
        });
    }

    public static void onNotificationDismissed(NotificationView notification) {
        removeNotification(notification);
    }

    private static void removeNotification(NotificationView notification) {
        if (activeNotifications.remove(notification)) {
            updateAllPositions();
        }
    }

    private static void updateAllPositions() {
        for (int i = 0; i < activeNotifications.size(); i++) {
            NotificationView notification = activeNotifications.get(i);
            if (notification != null) {
                notification.updatePosition(i);
            }
        }
    }

    public static void clearAll() {
        for (NotificationView notification : new ArrayList<>(activeNotifications)) {
            notification.dismiss();
        }
        activeNotifications.clear();
    }

    public static void cleanup() {
        clearAll();
        currentActivity = null;
        windowManager = null;
    }
}
