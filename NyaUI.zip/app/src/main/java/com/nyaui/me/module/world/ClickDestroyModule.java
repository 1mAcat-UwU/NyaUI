package com.nyaui.me.module.world;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class ClickDestroyModule extends Module {
    public ClickDestroyModule() { super("ClickDestroy", ModuleCategory.WORLD, ""); setChineseName("Click Destroy"); }
    @Override public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("ClickDestroy"); } catch (Throwable t) {} }
    @Override public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("ClickDestroy"); } catch (Throwable t) {} }
    @Override public void configureSubMenu(SubMenuPanel s) {
        super.configureSubMenu(s);
        int cnt = SafeCall.getModeSize(getName(), 0); java.util.List<String> modes = new java.util.ArrayList<>(); for (int i = 0; i < cnt; i++) modes.add(SafeCall.getModeString(getName(), 0, i)); s.addMode("Mode", modes, SafeCall.getModeValue(getName(), 0), (index, name) -> SafeCall.setModeValue(getName(), 0, index));
    }
}
