package com.nyaui.me.ui;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.PathInterpolator;
import android.widget.FrameLayout;
import android.widget.PopupWindow;

import com.nyaui.me.config.ConfigManager;
import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleManager;
import com.nyaui.me.module.ModuleToggleListener;
import com.nyaui.me.module.ShortcutToggleListener;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.visual.NotificationsModule;
import com.nyaui.me.module.visual.WatermarkModule;
import com.nyaui.me.ui.widgets.KeyListenerFrameLayout;
import com.nyaui.me.ui.widgets.KeybindButton;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PhoenixPopup implements ShortcutToggleListener, ModuleToggleListener {

     
    private static final int BLUR_MAX = 56;
    private static boolean initialized = false;
    private static boolean isShowing = false;
    private static Activity currentActivity;
    private static PhoenixPopup instance;

    private static ArraylistView arraylistView;
    private static CardMenuView cardMenuView;
    private static ClassicMenuView classicMenuView;

     
    public static CardMenuView getCardMenuView() {
        return cardMenuView;
    }
    private static final Map<Module, PopupWindow> shortcutPopups = new HashMap<>();

    private static PopupWindow displayPopup;
    private static PopupWindow floatBallPopup;
    private static PopupWindow menuPopup;
    private static PopupWindow cardMenuPopup;

    public static void init(Context ctx) {
        if (initialized) return;
        ConfigManager.init(ctx);
        com.nyaui.me.module.settings.IslandModule.ensureDefaultEnabled();
        ThemeManager.loadFromConfig();
        SoundPlayer.init(ctx);
        com.nyaui.me.module.ModuleChineseNames.initializeChineseNames();
        initialized = true;
    }

    public static void show(Activity activity) {
        if (isShowing || activity == null) return;
        try {
            currentActivity = activity;
            if (instance == null) instance = new PhoenixPopup();
            View decorView = activity.getWindow().getDecorView();

            showDisplayLayer(activity, decorView);
            showFloatBall(activity, decorView);

            
            
            
            try {
                FrameRate.requestHighRefresh(activity);
                IslandOverlay.attach(activity);
            } catch (Throwable ignored) {}

            NotificationManager.init(activity);
            WatermarkManager.init(activity);
            SoundPlayer.init(activity);
            KeybindManager.getInstance().initialize(activity);
            setupGlobalKeyListener(activity);

            NotificationsModule notifMod = NotificationsModule.getInstance();
            if (notifMod != null && !notifMod.isEnabled()) {
                notifMod.enable();
            }

            WatermarkModule watermarkMod = WatermarkModule.getInstance();
            if (watermarkMod != null) {
                if (!watermarkMod.isEnabled()) {
                    watermarkMod.enable();
                }
                WatermarkManager.show();
            }

            for (Module module : ModuleManager.getAllModules()) {
                if (module.isShortcutEnabled()) {
                    showShortcut(module);
                }
            }

            ModuleManager.addShortcutListener(instance);
            ModuleManager.addToggleListener(instance);
            
            isShowing = true;
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }

    private static void showDisplayLayer(Activity activity, View decorView) {
        FrameLayout displayContainer = new FrameLayout(activity);
        arraylistView = new ArraylistView(activity);
        displayContainer.addView(arraylistView);

        displayPopup = new PopupWindow(displayContainer, WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, false);
        displayPopup.setTouchable(false);
        displayPopup.setClippingEnabled(false);
        displayPopup.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        displayPopup.showAtLocation(decorView, Gravity.NO_GRAVITY, 0, 0);
    }

    private static void showFloatBall(Activity activity, View decorView) {
        floatBallPopup = createInteractivePopup(activity);
        FloatBallView floatBall = new FloatBallView(activity, floatBallPopup);
        floatBallPopup.setContentView(floatBall);
        floatBallPopup.showAtLocation(decorView, Gravity.CENTER, 0, 0);
    }

    public static void showMenus() {
        if (currentActivity == null) return;
        if (cardMenuPopup == null) {
            showCardMenu();
        } else {
            hideCardMenu();
        }
    }

    private static void showCardMenu() {
        if (currentActivity == null || cardMenuPopup != null) return;
        if (ConfigManager.isClassicUi()) {
            showClassicMenu();
            return;
        }

        KeyListenerFrameLayout container = new KeyListenerFrameLayout(currentActivity);
        container.setLayoutParams(new ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ));
        container.setOnKeyListener((v, keyCode, event) -> {
            if (event == null || event.getAction() != KeyEvent.ACTION_DOWN) {
                return false;
            }
            if (keyCode == KeyEvent.KEYCODE_BACK) {
                hideCardMenu();
                return true;
            }
            KeybindButton listening = KeybindButton.listeningButton;
            if (listening != null) {
                listening.onKeyBound(keyCode);
                return true;
            }
            String moduleName = KeybindManager.getInstance().getModuleForKey(keyCode);
            if (moduleName != null) {
                Module module = ModuleManager.getModuleByName(moduleName);
                if (module != null) {
                    module.toggle();
                    return true;
                }
            }
            return false;
        });

        View overlay = new View(currentActivity);
        overlay.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ));
        overlay.setAlpha(0f);
        overlay.setOnClickListener(v -> hideCardMenu());
        overlay.setClickable(true);
        overlay.setFocusable(false);

        
        
        
        overlay.setBackgroundColor(0x0F0A0812);
        overlay.post(() -> {
            
            
            if (!WindowBlur.isSystemBlurAvailable(overlay.getContext())) {
                overlay.setBackgroundColor(0x3D0A0812);
            }
            
            FrameRate.requestHighRefresh(overlay);
        });

        container.addView(overlay);

        cardMenuView = new CardMenuView(currentActivity);
        FrameLayout.LayoutParams menuParams = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        );
        menuParams.gravity = Gravity.CENTER;
        cardMenuView.setLayoutParams(menuParams);
        container.addView(cardMenuView);

        cardMenuPopup = new PopupWindow(container,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            true);
        cardMenuPopup.setTouchable(true);
        cardMenuPopup.setFocusable(true);
        cardMenuPopup.setClippingEnabled(false);
        cardMenuPopup.setWindowLayoutMode(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT
        );
        cardMenuPopup.setOutsideTouchable(false);
        cardMenuPopup.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        cardMenuPopup.setOnDismissListener(() -> {
            WindowBlur.cancelPopupBlurAnim();
            if (cardMenuView != null) {
                cardMenuView.animate().cancel();
                cardMenuView.destroy();
                cardMenuView = null;
            }
            cardMenuPopup = null;
        });
        cardMenuPopup.showAtLocation(currentActivity.getWindow().getDecorView(), Gravity.NO_GRAVITY, 0, 0);

        container.post(() -> {
            container.requestFocus();
            overlay.animate()
                .alpha(1f)
                .setDuration(340)
                .setInterpolator(new PathInterpolator(0.16f, 1f, 0.3f, 1f))
                .start();
            
            WindowBlur.animatePopupBlur(overlay, 0, BLUR_MAX, 340, null);
            cardMenuView.show();
        });
    }

    private static void hideCardMenu() {
        if (classicMenuView != null && cardMenuPopup != null) {
            classicMenuView.hide(() -> {
                if (cardMenuPopup != null) {
                    cardMenuPopup.dismiss();
                    cardMenuPopup = null;
                }
                if (classicMenuView != null) {
                    classicMenuView.destroy();
                    classicMenuView = null;
                }
            });
            return;
        }
        if (cardMenuView != null && cardMenuPopup != null) {
            View container = (View) cardMenuView.getParent();
            View overlay = null;
            if (container instanceof FrameLayout) {
                FrameLayout frameLayout = (FrameLayout) container;
                if (frameLayout.getChildCount() > 0) {
                    overlay = frameLayout.getChildAt(0);
                }
            }

            if (overlay != null) {
                overlay.animate()
                    .alpha(0f)
                    .setDuration(240)
                    .setInterpolator(new PathInterpolator(0.4f, 0f, 0.2f, 1f))
                    .start();
                
                WindowBlur.animatePopupBlur(overlay, BLUR_MAX, 0, 240, null);
            }

            cardMenuView.hide(() -> {
                if (cardMenuPopup != null) {
                    cardMenuPopup.dismiss();
                    cardMenuPopup = null;
                }
                if (cardMenuView != null) {
                    cardMenuView.destroy();
                    cardMenuView = null;
                }
            });
        } else {
            if (cardMenuPopup != null) {
                cardMenuPopup.dismiss();
                cardMenuPopup = null;
            }
            if (cardMenuView != null) {
                cardMenuView.destroy();
                cardMenuView = null;
            }
        }
    }

    public static void hideMenus() {
        hideCardMenu();
    }

    public static boolean isMenuShowing() {
        return cardMenuPopup != null && cardMenuPopup.isShowing();
    }

    public static void applyUiScale(float scale) {
        float s = Math.max(0.5f, Math.min(1.2f, scale));
        ConfigManager.setUiScale(s);
        if (currentActivity == null) return;
        currentActivity.runOnUiThread(() -> {
            if (cardMenuView != null) cardMenuView.applyScale(s);
            if (classicMenuView != null) classicMenuView.applyScale(s);
        });
    }

    private static void setupGlobalKeyListener(Activity activity) {
        KeyListenerFrameLayout globalKeyListener = new KeyListenerFrameLayout(activity);
        globalKeyListener.setLayoutParams(new ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ));
        globalKeyListener.setOnKeyListener((v, keyCode, event) -> {
            if (event == null || event.getAction() != KeyEvent.ACTION_DOWN) {
                return false;
            }
            if (cardMenuPopup != null && cardMenuPopup.isShowing()) {
                return false;
            }
            if (KeybindButton.listeningButton != null) {
                return false;
            }
            return KeybindManager.getInstance().handleKeyEvent(keyCode);
        });

        PopupWindow globalKeyPopup = new PopupWindow(globalKeyListener,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            false);
        globalKeyPopup.setTouchable(false);
        globalKeyPopup.setFocusable(true);
        globalKeyPopup.setClippingEnabled(false);
        globalKeyPopup.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        globalKeyPopup.showAtLocation(activity.getWindow().getDecorView(), Gravity.NO_GRAVITY, 0, 0);
        globalKeyListener.post(() -> globalKeyListener.requestFocus());
    }

    private static void showShortcut(Module module) {
        if (currentActivity == null) return;
        hideShortcut(module);

        PopupWindow shortcutPopup = createInteractivePopup(currentActivity);
        ShortcutButton button = new ShortcutButton(currentActivity, module, shortcutPopup);
        shortcutPopup.setContentView(button);
        shortcutPopups.put(module, shortcutPopup);

        int[] pos = button.loadPosition();
        int x = pos[0];
        int y = pos[1];
        if (x == Integer.MAX_VALUE) {
            shortcutPopup.showAtLocation(currentActivity.getWindow().getDecorView(), Gravity.CENTER, 0, 100 + (shortcutPopups.size() * 100));
        } else {
            shortcutPopup.showAtLocation(currentActivity.getWindow().getDecorView(), Gravity.NO_GRAVITY, x, y);
        }
    }

    private static void hideShortcut(Module module) {
        if (shortcutPopups.containsKey(module)) {
            PopupWindow popup = shortcutPopups.get(module);
            if (popup != null) {
                ShortcutButton button = (ShortcutButton) popup.getContentView();
                if (button != null) button.destroy();
                popup.dismiss();
            }
            shortcutPopups.remove(module);
        }
    }

    private static PopupWindow createInteractivePopup(Context context) {
        PopupWindow popup = new PopupWindow(context);
        popup.setWidth(WindowManager.LayoutParams.WRAP_CONTENT);
        popup.setHeight(WindowManager.LayoutParams.WRAP_CONTENT);
        popup.setTouchable(true);
        popup.setClippingEnabled(false);
        popup.setOutsideTouchable(false);
        popup.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        return popup;
    }

    @Override
    public void onShortcutToggled(Module module, boolean enabled) {
        if (currentActivity == null) return;
        currentActivity.runOnUiThread(() -> {
            if (enabled) {
                showShortcut(module);
            } else {
                hideShortcut(module);
            }
        });
    }

    @Override
    public void onModuleToggled(Module module) {
        if (currentActivity == null) return;
        currentActivity.runOnUiThread(() -> {
            if (arraylistView != null && module.shouldShowInArraylist()) {
                if (module.isEnabled()) arraylistView.addModule(module.getDisplayName());
                else arraylistView.removeModule(module.getDisplayName());
            }
            if (shortcutPopups.containsKey(module)) {
                ShortcutButton button = (ShortcutButton) shortcutPopups.get(module).getContentView();
                if (button != null) button.updateStyle();
            }
            
            try { IslandOverlay.notifyToggle(module.getDisplayName(), module.isEnabled()); }
            catch (Throwable ignored) {}
            NotificationManager.showNotification(module, module.isEnabled());
        });
    }

    public static void hide() {
        if (!isShowing) return;
        try {
            if (instance != null) {
                ModuleManager.removeShortcutListener(instance);
                ModuleManager.removeToggleListener(instance);
                
            }
            if (displayPopup != null) displayPopup.dismiss();
            if (floatBallPopup != null) floatBallPopup.dismiss();
            if (menuPopup != null) menuPopup.dismiss();
            if (cardMenuPopup != null) cardMenuPopup.dismiss();
            for (PopupWindow popup : shortcutPopups.values()) {
                if (popup != null) {
                    ShortcutButton button = (ShortcutButton) popup.getContentView();
                    if (button != null) button.destroy();
                    popup.dismiss();
                }
            }
            shortcutPopups.clear();
            if (cardMenuView != null) {
                cardMenuView.destroy();
                cardMenuView = null;
            }
            if (classicMenuView != null) {
                classicMenuView.destroy();
                classicMenuView = null;
            }
            NotificationManager.cleanup();
            WatermarkManager.cleanup();
            displayPopup = null;
            floatBallPopup = null;
            menuPopup = null;
            cardMenuPopup = null;
            isShowing = false;
            currentActivity = null;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void cleanup() {
        hide();
        initialized = false;
    }

    public static ArraylistView getArraylistView() {
        return arraylistView;
    }

    public static boolean isShowing() {
        return isShowing;
    }

    
    private static void showClassicMenu() {
        if (currentActivity == null || cardMenuPopup != null) return;

        KeyListenerFrameLayout container = new KeyListenerFrameLayout(currentActivity);
        container.setLayoutParams(new ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ));
        container.setOnKeyListener((v, keyCode, event) -> {
            if (event != null && event.getAction() == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_BACK) {
                hideCardMenu();
                return true;
            }
            return false;
        });

        View overlay = new View(currentActivity);
        overlay.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ));
        overlay.setBackgroundColor(0x99000000);
        overlay.setOnClickListener(v -> hideCardMenu());
        container.addView(overlay);

        classicMenuView = new ClassicMenuView(currentActivity);
        FrameLayout.LayoutParams menuParams = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        );
        classicMenuView.setLayoutParams(menuParams);
        container.addView(classicMenuView);

        cardMenuPopup = new PopupWindow(container,
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            true);
        cardMenuPopup.setTouchable(true);
        cardMenuPopup.setFocusable(true);
        cardMenuPopup.setClippingEnabled(false);
        cardMenuPopup.setOutsideTouchable(false);
        cardMenuPopup.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        cardMenuPopup.setOnDismissListener(() -> {
            if (classicMenuView != null) {
                classicMenuView.destroy();
                classicMenuView = null;
            }
            cardMenuPopup = null;
        });
        cardMenuPopup.showAtLocation(currentActivity.getWindow().getDecorView(), Gravity.NO_GRAVITY, 0, 0);
        classicMenuView.show();
    }

    private PhoenixPopup() {}
}
