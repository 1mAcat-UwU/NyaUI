package com.nyaui.me.module.movement;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;

public class InventoryMoveModule extends Module {
    public InventoryMoveModule() { super("InventoryMove", ModuleCategory.MOVEMENT, ""); setChineseName("Inventory Move"); }
    @Override public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("InventoryMove"); } catch (Throwable t) {} }
    @Override public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("InventoryMove"); } catch (Throwable t) {} }
}
