package com.nyaui.me.module.settings;

import android.app.Activity;
import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.nyaui.me.config.ConfigExporter;
import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.ui.ThemeManager;
import com.nyaui.me.ui.widgets.SubMenuPanel;

import java.util.List;

public class ConfigModule extends Module {
    public ConfigModule() {
        super("Config", ModuleCategory.SETTINGS, "");
        setChineseName("Config Manager");
    }

    @Override public boolean shouldShowInArraylist() { return false; }
    @Override public boolean supportsShortcut() { return false; }

    @Override
    public void configureSubMenu(SubMenuPanel subMenu) {
        super.configureSubMenu(subMenu);
        Context ctx = subMenu.getContext();

        subMenu.addSectionTitle("Import / Export");

        LinearLayout btnRow = new LinearLayout(ctx);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setGravity(Gravity.CENTER);
        float d = ctx.getResources().getDisplayMetrics().density;

        TextView exportBtn = makeBtn(ctx, "Export", ThemeManager.getThemeColor(), d);
        exportBtn.setOnClickListener(v -> {
            Activity act = findActivity(ctx);
            if (act != null) ConfigExporter.doExport(act,
                () -> Toast.makeText(ctx, "Export successful", Toast.LENGTH_SHORT).show(),
                () -> Toast.makeText(ctx, "Export failed", Toast.LENGTH_SHORT).show());
        });
        btnRow.addView(exportBtn);

        View gap = new View(ctx);
        gap.setLayoutParams(new LinearLayout.LayoutParams((int)(8*d), 1));
        btnRow.addView(gap);

        TextView importBtn = makeBtn(ctx, "Import", ThemeManager.getBgDisabled(), d);
        importBtn.setTextColor(ThemeManager.getTextPrimary());
        importBtn.setOnClickListener(v -> {
            Activity act = findActivity(ctx);
            if (act != null) ConfigExporter.doImport(act,
                () -> Toast.makeText(ctx, "Import successful", Toast.LENGTH_SHORT).show(),
                () -> Toast.makeText(ctx, "Import failed", Toast.LENGTH_SHORT).show());
        });
        btnRow.addView(importBtn);

        subMenu.addCustomView(btnRow);

        subMenu.addDivider();
        subMenu.addSectionTitle("Save Current Config");

        LinearLayout saveRow = new LinearLayout(ctx);
        saveRow.setOrientation(LinearLayout.HORIZONTAL);
        saveRow.setGravity(Gravity.CENTER_VERTICAL);

        EditText nameInput = new EditText(ctx);
        nameInput.setHint("Config Name");
        nameInput.setTextSize(12f);
        nameInput.setTextColor(ThemeManager.getTextPrimary());
        nameInput.setHintTextColor(ThemeManager.getTextSecondary());
        nameInput.setSingleLine(true);
        nameInput.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        saveRow.addView(nameInput);

        TextView saveBtn = makeBtn(ctx, "Save", ThemeManager.getThemeColor(), d);
        saveBtn.setOnClickListener(v -> {
            String name = nameInput.getText().toString().trim();
            if (name.isEmpty()) name = "config_" + System.currentTimeMillis();
            ConfigExporter.saveConfig(ctx, name);
            Toast.makeText(ctx, "Saved: " + name, Toast.LENGTH_SHORT).show();
        });
        saveRow.addView(saveBtn);
        subMenu.addCustomView(saveRow);

        subMenu.addDivider();
        subMenu.addSectionTitle("Config saved");

        List<String> configs = ConfigExporter.listConfigs(ctx);
        if (configs.isEmpty()) {
            subMenu.addText("No saved configs");
        } else {
            for (String cfg : configs) {
                LinearLayout row = new LinearLayout(ctx);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding((int)(4*d), (int)(6*d), (int)(4*d), (int)(6*d));

                TextView label = new TextView(ctx);
                label.setText(cfg);
                label.setTextColor(ThemeManager.getTextPrimary());
                label.setTextSize(12f);
                label.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
                row.addView(label);

                TextView applyBtn = makeBtn(ctx, "Apply", ThemeManager.getThemeColor(), d);
                applyBtn.setOnClickListener(v -> {
                    ConfigExporter.loadConfig(ctx, cfg);
                    Toast.makeText(ctx, "Applied", Toast.LENGTH_SHORT).show();
                });
                row.addView(applyBtn);

                View g = new View(ctx);
                g.setLayoutParams(new LinearLayout.LayoutParams((int)(4*d), 1));
                row.addView(g);

                TextView delBtn = makeBtn(ctx, "Delete", 0xFFFF4D4F, d);
                delBtn.setOnClickListener(v -> {
                    ConfigExporter.deleteConfig(ctx, cfg);
                    Toast.makeText(ctx, "Deleted", Toast.LENGTH_SHORT).show();
                });
                row.addView(delBtn);

                subMenu.addCustomView(row);
            }
        }
    }

    private TextView makeBtn(Context ctx, String text, int color, float d) {
        TextView btn = new TextView(ctx);
        btn.setText(text);
        btn.setTextColor(0xFFFFFFFF);
        btn.setTextSize(11f);
        btn.setGravity(Gravity.CENTER);
        btn.setPadding((int)(14*d),(int)(8*d),(int)(14*d),(int)(8*d));
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(8*d);
        btn.setBackground(bg);
        btn.setClickable(true);
        return btn;
    }

    private Activity findActivity(Context ctx) {
        while (ctx instanceof android.content.ContextWrapper) {
            if (ctx instanceof Activity) return (Activity) ctx;
            ctx = ((android.content.ContextWrapper)ctx).getBaseContext();
        }
        return null;
    }
}
