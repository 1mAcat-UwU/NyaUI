package com.nyaui.me.ui;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Color;
import com.nyaui.me.config.ConfigManager; 
import android.animation.ValueAnimator;
import android.view.animation.LinearInterpolator;

import java.util.ArrayList;
import java.util.List;

public class ThemeManager {

    private static final String CONFIG_MODULE_NAME = "GlobalTheme";
    private static final String CONFIG_KEY_THEME_COLOR = "theme_color";
    private static final String CONFIG_KEY_DARK_MODE = "dark_mode";
    private static final int DEFAULT_THEME_COLOR = 0xFF96CCFF;

    private static int themeColor = DEFAULT_THEME_COLOR;
    private static boolean isDarkMode = false; 

    
    private static int bgPrimary_Light = 0xFFF3EDF7;    
    private static int bgSecondary_Light = 0xFFE8DEF8;  
    private static int bgDisabled_Light = 0xFFE0E0E0;
    private static int textPrimary_Light = 0xFF1C1B1F;
    private static int textSecondary_Light = 0xFF49454F;
    private static int textTertiary_Light = 0xFF79747E;
    private static int textOnTheme_Light = 0xFFFFFFFF;
    private static int accent_light = 0xFF6750A4; 

    
    private static int bgPrimary_Dark = 0xFF211F26;     
    private static int bgSecondary_Dark = 0xFF4A4458;   
    private static int bgDisabled_Dark = 0xFF333333;
    private static int textPrimary_Dark = 0xFFE6E1E5;
    private static int textSecondary_Dark = 0xFFCCC2DC;
    private static int textTertiary_Dark = 0xFF938F99;
    private static int textOnTheme_Dark = 0xFF381E72;
    private static int accent_dark = 0xFFD0BCFF; 

    
    private static int bgPrimary = bgPrimary_Light;
    private static int bgSecondary = bgSecondary_Light;
    private static int bgDisabled = bgDisabled_Light;
    private static int textPrimary = textPrimary_Light;
    private static int textSecondary = textSecondary_Light;
    private static int textTertiary = textTertiary_Light;
    private static int accentColor = accent_light;

    private static int stateDisabled = 0xFF555555;
    private static int glowColor = 0x66000000;
    private static int glassBackground = 0x4DFFFFFF;  
    private static int gradientStart = 0xFFa7ff8a;
    private static int gradientEnd = 0xFF82c1fb;

    private static boolean isRainbowModeEnabled = false;
    private static ValueAnimator rainbowAnimator;
    private static int currentRainbowColor = DEFAULT_THEME_COLOR;
    private static float[] baseHSVForRainbow = new float[3]; 

    private static final List<OnThemeColorChangeListener> listeners = new ArrayList<>();

    public interface OnThemeColorChangeListener {
        void onThemeColorChanged(int newColor);
    }

    public interface OnThemeModeChangeListener {
        void onThemeModeChanged(boolean isDark);
    }

    public interface OnRainbowModeChangeListener {
        void onRainbowModeChanged(boolean isEnabled);
    }

    public interface OnRainbowColorUpdateListener {
        void onRainbowColorUpdate(int color);
    }

    private static final List<OnThemeModeChangeListener> modeListeners = new ArrayList<>();
    private static final List<OnRainbowModeChangeListener> rainbowModeListeners = new ArrayList<>();
    private static final List<OnRainbowColorUpdateListener> rainbowColorUpdateListeners = new ArrayList<>();

    public static void initFromContext(Context context) {
        loadFromConfig();
    }

    

    public static void loadFromConfig() {
        int savedColor = ConfigManager.getInt(CONFIG_MODULE_NAME, CONFIG_KEY_THEME_COLOR, DEFAULT_THEME_COLOR);
        boolean savedDark = ConfigManager.getBoolean(CONFIG_MODULE_NAME, CONFIG_KEY_DARK_MODE, false);

        themeColor = savedColor;
        isDarkMode = savedDark;
        updateColorsForMode();

        isRainbowModeEnabled = ConfigManager.isRainbowModeEnabled();
        if (isRainbowModeEnabled) {
            Color.colorToHSV(themeColor, baseHSVForRainbow);
            startRainbowAnimation();
        }

        notifyModeListeners();
        notifyListeners();
    }

    public static boolean isDarkMode() {
        return isDarkMode;
    }

    public static void setDarkMode(boolean dark) {
        if (isDarkMode != dark) {
            isDarkMode = dark;
            ConfigManager.saveModuleConfig(CONFIG_MODULE_NAME, CONFIG_KEY_DARK_MODE, dark);
            updateColorsForMode();
            
            notifyModeListeners();
            notifyListeners(); 
        }
    }

    private static void updateColorsForMode() {
        if (isDarkMode) {
            bgPrimary = bgPrimary_Dark;
            bgSecondary = bgSecondary_Dark;
            bgDisabled = bgDisabled_Dark;
            textPrimary = textPrimary_Dark;
            textSecondary = textSecondary_Dark;
            textTertiary = textTertiary_Dark;
            
            accentColor = accent_dark;
            glassBackground = 0x4D000000;  
        } else {
            bgPrimary = bgPrimary_Light;
            bgSecondary = bgSecondary_Light;
            bgDisabled = bgDisabled_Light;
            textPrimary = textPrimary_Light;
            textSecondary = textSecondary_Light;
            textTertiary = textTertiary_Light;
            
            accentColor = accent_light;
            glassBackground = 0x4DFFFFFF;  
        }
        
    }

    private static void saveThemeColor() {
        
        ConfigManager.saveModuleConfig(CONFIG_MODULE_NAME, CONFIG_KEY_THEME_COLOR, themeColor);
    }

    public static int getThemeColor() {
        return themeColor;
    }

    public static void setThemeColor(int color) {
        if (themeColor != color) {
            themeColor = color;
            saveThemeColor(); 
            
            
            if (isRainbowModeEnabled) {
                Color.colorToHSV(color, baseHSVForRainbow);
            }
            
            notifyListeners();
        }
    }

    public static float[] getThemeColorHSV() {
        float[] hsv = new float[3];
        Color.colorToHSV(themeColor, hsv);
        return hsv;
    }

    public static int getMenuBackground() {
        return blendColors(getBgPrimary(), getThemeColor(), 0.1f);
    }

    public static int getMenuTitleBarBackground() {
        return blendColors(getBgSecondary(), getThemeColor(), 0.2f);
    }
    
    public static int getMenuTitleTextColor() {
        
        int titleBg = getMenuTitleBarBackground();
        
        return isColorDark(titleBg) ? Color.WHITE : Color.BLACK;
    }

    private static int blendColors(int color1, int color2, float ratio) {
        final float inverseRatio = 1f - ratio;
        float a = (Color.alpha(color1) * inverseRatio) + (Color.alpha(color2) * ratio);
        float r = (Color.red(color1) * inverseRatio) + (Color.red(color2) * ratio);
        float g = (Color.green(color1) * inverseRatio) + (Color.green(color2) * ratio);
        float b = (Color.blue(color1) * inverseRatio) + (Color.blue(color2) * ratio);
        return Color.argb((int) a, (int) r, (int) g, (int) b);
    }

    public static int getAccentColor() { return getThemeColor(); }
    
    
    
    public static int getBgPrimary() { return bgPrimary; }
    public static void setBgPrimary(int color) { bgPrimary = color; notifyListeners(); }
    public static int getBgSecondary() { return bgSecondary; }
    public static void setBgSecondary(int color) { bgSecondary = color; notifyListeners(); }
    public static int getBgDisabled() { return bgDisabled; }
    public static void setBgDisabled(int color) { bgDisabled = color; notifyListeners(); }
    public static int getTextPrimary() { return textPrimary; }
    public static void setTextPrimary(int color) { textPrimary = color; notifyListeners(); }
    public static int getTextSecondary() { return textSecondary; }
    public static void setTextSecondary(int color) { textSecondary = color; notifyListeners(); }
    public static int getTextTertiary() { return textTertiary; }
    public static void setTextTertiary(int color) { textTertiary = color; notifyListeners(); }
    
    public static int getTextOnTheme() {
        return isColorDark(getThemeColor()) ? Color.WHITE : Color.BLACK;
    }

    public static boolean isRainbowModeEnabled() {
        return isRainbowModeEnabled;
    }

    public static void setRainbowModeEnabled(boolean enabled) {
        if (isRainbowModeEnabled != enabled) {
            isRainbowModeEnabled = enabled;
            ConfigManager.setRainbowModeEnabled(enabled);
            if (enabled) {
                startRainbowAnimation();
            } else {
                stopRainbowAnimation();
            }
            notifyRainbowModeListeners();
        }
    }

    private static void startRainbowAnimation() {
        if (rainbowAnimator != null && rainbowAnimator.isRunning()) {
            return;
        }
        
        Color.colorToHSV(themeColor, baseHSVForRainbow);
        
        rainbowAnimator = ValueAnimator.ofFloat(0f, 360f);
        rainbowAnimator.setDuration(5000);
        rainbowAnimator.setRepeatCount(ValueAnimator.INFINITE);
        rainbowAnimator.setInterpolator(new LinearInterpolator());
        rainbowAnimator.addUpdateListener(animation -> {
            float hue = (float) animation.getAnimatedValue();
            
            int newColor = Color.HSVToColor(new float[]{hue, baseHSVForRainbow[1], baseHSVForRainbow[2]});
            setThemeColorInternal(newColor);
        });
        rainbowAnimator.start();
    }

    private static void stopRainbowAnimation() {
        if (rainbowAnimator != null) {
            rainbowAnimator.cancel();
            rainbowAnimator = null;
        }
    }

    private static void setThemeColorInternal(int color) {
        if (themeColor != color) {
            themeColor = color;
            notifyListeners();
        }
    }

    private static boolean isColorDark(int color) {
        double darkness = 1 - (0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color)) / 255;
        return darkness >= 0.5;
    }

    public static int getStateDisabled() { return stateDisabled; }
    public static void setStateDisabled(int color) { stateDisabled = color; notifyListeners(); }
    public static int getGlowColor() { return glowColor; }
    public static void setGlowColor(int color) { glowColor = color; notifyListeners(); }
    public static int getGlassBackground() { return glassBackground; }
    public static void setGlassBackground(int color) { glassBackground = color; notifyListeners(); }
    public static int getGradientStart() { return gradientStart; }
    public static void setGradientStart(int color) { gradientStart = color; notifyListeners(); }
    public static int getGradientEnd() { return gradientEnd; }
    public static void setGradientEnd(int color) { gradientEnd = color; notifyListeners(); }

    public static void applyDefaultTheme() {
        setThemeColor(DEFAULT_THEME_COLOR);
    }

    public static void applyGreenTheme() {
        setThemeColor(0xFF4CAF50);
    }

    public static void applyPurpleTheme() {
        setThemeColor(0xFFBB86FC);
    }

    public static void applyOrangeTheme() {
        setThemeColor(0xFFFF9800);
    }

    public static void applyPinkTheme() {
        setThemeColor(0xFFE91E63);
    }

    public static void setThemeColorRGB(int r, int g, int b) {
        setThemeColor(Color.rgb(r, g, b));
    }

    public static void setThemeColorHSV(float hue, float saturation, float value) {
        setThemeColor(Color.HSVToColor(new float[]{hue, saturation, value}));
    }

    public static void addListener(OnThemeColorChangeListener listener) {
        if (!listeners.contains(listener)) {
            listeners.add(listener);
        }
    }

    public static void removeListener(OnThemeColorChangeListener listener) {
        listeners.remove(listener);
    }

    public static void addModeListener(OnThemeModeChangeListener listener) {
        if (!modeListeners.contains(listener)) {
            modeListeners.add(listener);
        }
    }

    public static void removeModeListener(OnThemeModeChangeListener listener) {
        modeListeners.remove(listener);
    }

    public static void addRainbowModeListener(OnRainbowModeChangeListener listener) {
        if (!rainbowModeListeners.contains(listener)) {
            rainbowModeListeners.add(listener);
        }
    }

    public static void removeRainbowModeListener(OnRainbowModeChangeListener listener) {
        rainbowModeListeners.remove(listener);
    }

    public static void addRainbowColorUpdateListener(OnRainbowColorUpdateListener listener) {
        if (!rainbowColorUpdateListeners.contains(listener)) {
            rainbowColorUpdateListeners.add(listener);
        }
    }

    public static void removeRainbowColorUpdateListener(OnRainbowColorUpdateListener listener) {
        rainbowColorUpdateListeners.remove(listener);
    }

    private static void notifyListeners() {
        for (OnThemeColorChangeListener listener : new ArrayList<>(listeners)) {
            try {
                listener.onThemeColorChanged(themeColor);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private static void notifyModeListeners() {
        for (OnThemeModeChangeListener listener : new ArrayList<>(modeListeners)) {
            try {
                listener.onThemeModeChanged(isDarkMode);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private static void notifyRainbowModeListeners() {
        for (OnRainbowModeChangeListener listener : new ArrayList<>(rainbowModeListeners)) {
            try {
                listener.onRainbowModeChanged(isRainbowModeEnabled);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private static void notifyRainbowColorUpdateListeners() {
        for (OnRainbowColorUpdateListener listener : new ArrayList<>(rainbowColorUpdateListeners)) {
            try {
                listener.onRainbowColorUpdate(currentRainbowColor);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private ThemeManager() {

    }
}
