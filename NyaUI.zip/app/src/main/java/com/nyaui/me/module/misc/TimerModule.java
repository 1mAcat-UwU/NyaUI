package com.nyaui.me.module.misc;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class TimerModule extends Module {
    public TimerModule() { super("Timer", ModuleCategory.MISC, ""); setChineseName("World Speed"); }
    @Override public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("Timer"); } catch (Throwable t) {} }
    @Override public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("Timer"); } catch (Throwable t) {} }
    @Override public void configureSubMenu(SubMenuPanel s) {
        super.configureSubMenu(s);
        s.addSlider("Speed", 10, 50, (int)(SafeCall.getFloat(getName(), 0) * 10), "%.1f", v -> SafeCall.setFloat(getName(), 0, v / 10f));
    }
}
