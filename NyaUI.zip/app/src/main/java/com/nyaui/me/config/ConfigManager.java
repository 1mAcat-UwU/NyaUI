package com.nyaui.me.config;

import android.content.Context;
import android.content.SharedPreferences;

public class ConfigManager {

    private static final String PREF_NAME = "phoenix_gui_config";
    private static SharedPreferences sharedPreferences;

    private static final String KEY_DYNAMIC_ISLAND_ENABLED = "dynamic_island_enabled";
    private static final String KEY_UI_SCALE = "ClickGUI_ui_scale_factor";
    private static final String KEY_DYNAMIC_ISLAND_SCALE = "dynamic_island_scale";
    private static final String KEY_DYNAMIC_ISLAND_USERNAME = "dynamic_island_username";
    
    
    public static void init(Context context) {
        if (sharedPreferences == null) {
            sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        }
    }

    private static String getKey(String moduleName, String configKey) {
        return moduleName + "_" + configKey;
    }
        private static SharedPreferences getPrefs() {
        if (sharedPreferences == null) {
            throw new IllegalStateException("ConfigManager not initialized. Call init() first.");
        }
        return sharedPreferences;
    }
    public static float getFloat(String moduleName, String key, float defaultValue) {
        try {
            return getPrefs().getFloat(moduleName + "_" + key, defaultValue);
        } catch (ClassCastException e) {

            try {
                return (float) getPrefs().getInt(moduleName + "_" + key, (int) defaultValue);
            } catch (Exception e2) {
                return defaultValue;
            }
        }
    }

    public static void saveInt(String moduleName, String configKey, int value) {
        if (sharedPreferences == null) return;
        sharedPreferences.edit().putInt(getKey(moduleName, configKey), value).apply();
    }

    public static int getInt(String moduleName, String configKey, int defaultValue) {
        if (sharedPreferences == null) return defaultValue;
        return sharedPreferences.getInt(getKey(moduleName, configKey), defaultValue);
    }
    public static void saveBoolean(String moduleName, String configKey, boolean value) {
        if (sharedPreferences == null) return;
        sharedPreferences.edit().putBoolean(getKey(moduleName, configKey), value).apply();
    }

    public static boolean getBoolean(String moduleName, String configKey, boolean defaultValue) {
        if (sharedPreferences == null) return defaultValue;
        return sharedPreferences.getBoolean(getKey(moduleName, configKey), defaultValue);
    }

    public static void saveModuleConfig(String moduleName, String configKey, int value) {
        saveInt(moduleName, configKey, value);
    }

    public static void saveModuleConfig(String moduleName, String configKey, boolean value) {
        saveBoolean(moduleName, configKey, value);
    }

    public static boolean getDynamicIslandEnabled() {
        return getPrefs().getBoolean(KEY_DYNAMIC_ISLAND_ENABLED, true);
    }

    public static void setDynamicIslandEnabled(boolean enabled) {
        getPrefs().edit()
            .putBoolean(KEY_DYNAMIC_ISLAND_ENABLED, enabled)
            .apply();
    }

    public static float getDynamicIslandScale() {
        return getPrefs().getFloat(KEY_DYNAMIC_ISLAND_SCALE, 0.7f);
    }

    public static void setDynamicIslandScale(float scale) {
        getPrefs().edit().putFloat("dynamicIslandScale", scale).apply();
    }
    
    public static float getTargetHUDX() {
        return getPrefs().getFloat("targetHudX", 0.5f);
    }

    public static void setTargetHUDX(float x) {
        getPrefs().edit().putFloat("targetHudX", x).apply();
    }

    public static float getTargetHUDY() {
        return getPrefs().getFloat("targetHudY", 0.5f);
    }

    public static void setTargetHUDY(float y) {
        getPrefs().edit().putFloat("targetHudY", y).apply();
    }

    public static float getTargetHUDScale() {
        return getPrefs().getFloat("targetHudScale", 1.0f);
    }

    public static void setTargetHUDScale(float scale) {
        getPrefs().edit().putFloat("targetHudScale", scale).apply();
    }

    public static boolean isRainbowModeEnabled() {
        return getPrefs().getBoolean("rainbowModeEnabled", false);
    }

    public static void setRainbowModeEnabled(boolean enabled) {
        getPrefs().edit().putBoolean("rainbowModeEnabled", enabled).apply();
    }

    public static String getDynamicIslandUsername() {
        return getPrefs().getString(KEY_DYNAMIC_ISLAND_USERNAME, "User");
    }

    public static void setDynamicIslandUsername(String username) {
        getPrefs().edit()
            .putString(KEY_DYNAMIC_ISLAND_USERNAME, username)
            .apply();
    }

    public static void clearAll() {
        getPrefs().edit().clear().apply();
    }

    
    public static boolean isSoundEnabled() {
        return getPrefs().getBoolean("soundEnabled", true);
    }
    
    public static void setSoundEnabled(boolean enabled) {
        getPrefs().edit().putBoolean("soundEnabled", enabled).apply();
    }
    
    public static boolean isBlurEnabled() {
        return getPrefs().getBoolean("blurEnabled", true);
    }
    
    public static void setBlurEnabled(boolean enabled) {
        getPrefs().edit().putBoolean("blurEnabled", enabled).apply();
    }
    
    public static int getThemeColor() {
        return getPrefs().getInt("themeColor", 0xFF96CCFF);
    }
    
    public static void setThemeColor(int color) {
        getPrefs().edit().putInt("themeColor", color).apply();
    }
    
    public static boolean isWatermarkEnabled() {
        return getPrefs().getBoolean("watermarkEnabled", true);
    }
    
    public static void setWatermarkEnabled(boolean enabled) {
        getPrefs().edit().putBoolean("watermarkEnabled", enabled).apply();
    }
    
    public static boolean isChinese() {
        return false;
    }

    public static void setChinese(boolean isChinese) {
        getPrefs().edit().putBoolean("is_chinese", isChinese).apply();
    }
    
    public static float getBlurRadius() {
        return getPrefs().getFloat("blurRadius", 10.0f);
    }
    
    public static void setBlurRadius(float radius) {
        getPrefs().edit().putFloat("blurRadius", radius).apply();
    }

    private ConfigManager() {

    }

    public static final String UI_STYLE_DEFAULT = "default";
    public static final String UI_STYLE_CLASSIC = "classic";

    public static String getUiStyle() {
        return getPrefs().getString("ui_style", UI_STYLE_DEFAULT);
    }

    public static void setUiStyle(String style) {
        getPrefs().edit().putString("ui_style", style == null ? UI_STYLE_DEFAULT : style).apply();
    }

    public static boolean isClassicUi() {
        return UI_STYLE_CLASSIC.equalsIgnoreCase(getUiStyle());
    }

    public static float getUiScale() {
        return Math.max(0.5f, Math.min(1.2f, getPrefs().getFloat(KEY_UI_SCALE, 0.95f)));
    }

    public static void setUiScale(float scale) {
        getPrefs().edit().putFloat(KEY_UI_SCALE, Math.max(0.5f, Math.min(1.2f, scale))).apply();
    }

    public static void saveFloat(String moduleName, String key, float value) {
        getPrefs().edit().putFloat(moduleName + "_" + key, value).apply();
    }

}
