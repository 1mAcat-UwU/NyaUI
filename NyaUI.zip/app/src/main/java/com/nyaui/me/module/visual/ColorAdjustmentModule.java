package com.nyaui.me.module.visual;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class ColorAdjustmentModule extends Module {
    public ColorAdjustmentModule() { super("ColorAdjustment", ModuleCategory.VISUAL, ""); setChineseName("Color Correct"); }
    @Override public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("ColorAdjustment"); } catch (Throwable t) {} }
    @Override public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("ColorAdjustment"); } catch (Throwable t) {} }
    @Override public void configureSubMenu(SubMenuPanel s) {
        super.configureSubMenu(s);
        String n = getName();
        s.addSwitch("Enable Brightness", SafeCall.getBool(n, 0), e -> SafeCall.setBool(n, 0, e));
        s.addSlider("Brightness", 0, 50, (int)(SafeCall.getFloat(n, 0) * 10), "%.1f", v -> SafeCall.setFloat(n, 0, v));
        s.addSwitch("Enable Contrast", SafeCall.getBool(n, 1), e -> SafeCall.setBool(n, 1, e));
        s.addSlider("Contrast", 0, 50, (int)(SafeCall.getFloat(n, 1) * 10), "%.1f", v -> SafeCall.setFloat(n, 1, v));
        s.addSwitch("Enable Saturation", SafeCall.getBool(n, 2), e -> SafeCall.setBool(n, 2, e));
        s.addSlider("Saturation", 0, 50, (int)(SafeCall.getFloat(n, 2) * 10), "%.1f", v -> SafeCall.setFloat(n, 2, v));
        s.addSwitch("Enable Tint", SafeCall.getBool(n, 3), e -> SafeCall.setBool(n, 3, e));
        s.addSlider("Tint Strength", 0, 50, (int)(SafeCall.getFloat(n, 3) * 10), "%.1f", v -> SafeCall.setFloat(n, 3, v));
        s.addSlider("Red", 0, 255, (int)SafeCall.getFloat(n, 4), "%d", v -> SafeCall.setFloat(n, 4, v));
        s.addSlider("Green", 0, 255, (int)SafeCall.getFloat(n, 5), "%d", v -> SafeCall.setFloat(n, 5, v));
        s.addSlider("Blue", 0, 255, (int)SafeCall.getFloat(n, 6), "%d", v -> SafeCall.setFloat(n, 6, v));
    }
}
