package com.nyaui.me.module.combat;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;
import java.util.ArrayList;
import java.util.List;

public class AimBotModule extends Module {
    public AimBotModule() { super("AimBot", ModuleCategory.COMBAT, ""); setChineseName("AimBot"); }
    @Override public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("AimBot"); } catch (Throwable t) {} }
    @Override public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("AimBot"); } catch (Throwable t) {} }
    @Override public void configureSubMenu(SubMenuPanel s) {
        super.configureSubMenu(s);
        String n = getName();
        s.addSlider("Range", 5, 30, (int)SafeCall.getFloat(n, 0), "%.1f", v -> SafeCall.setFloat(n, 0, v));
        s.addSlider("Speed", 5, 20, (int)SafeCall.getFloat(n, 1), "%d", v -> SafeCall.setFloat(n, 1, v));
        int cnt = SafeCall.getModeSize(n, 0);
        List<String> modes = new ArrayList<>();
        for (int i = 0; i < cnt; i++) modes.add(SafeCall.getModeString(n, 0, i));
        s.addMode("Target Part", modes, SafeCall.getModeValue(n, 0), (index, name) -> SafeCall.setModeValue(n, 0, index));
    }
}
