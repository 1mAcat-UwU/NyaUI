package com.nyaui.me.module;

import com.nyaui.me.module.settings.*;
import com.nyaui.me.module.combat.*;
import com.nyaui.me.module.movement.*;
import com.nyaui.me.module.player.*;
import com.nyaui.me.module.visual.*;
import com.nyaui.me.module.world.*;
import com.nyaui.me.module.misc.*;
import com.nyaui.me.ui.SoundPlayer;
import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    private static final List<Module> modules = new ArrayList<>();
    private static final List<ModuleToggleListener> listeners = new ArrayList<>();
    private static final List<ShortcutToggleListener> shortcutListeners = new ArrayList<>();

    static {
        registerModules();
    }

    private static void registerModules() {
        register(new KillAuraModule());
        register(new AimBotModule());
        register(new HitBoxModule());
        register(new InfiniteAuraModule());
        register(new SpinAttackModule());
        register(new AutoClickModule());
        register(new VelocityModule());
        register(new TeamsModule());
        register(new HitSelectModule());
        register(new KnifeMaceModule());
        register(new CriticalsModule());
        register(new BackTrackModule());
        register(new SurroundModule());
        register(new KillOneselfModule());
        register(new PhantomModule());

        register(new FlyModule());
        register(new SpeedModule());
        register(new AirJumpModule());
        register(new FastStopModule());
        register(new InventoryMoveModule());
        register(new AutoSprintModule());
        register(new AirSwimModule());
        register(new FarJumpModule());
        register(new NoSlowDownModule());
        register(new HighJumpModule());
        register(new TWapModule());
        register(new NoFallModule());
        register(new AntiVoidModule());
        register(new AntiWebModule());
        register(new WaterClipModule());

        register(new ScaffoldModule());
        register(new BreakModule());
        register(new AutoBreakModule());
        register(new BoxAuraModule());
        register(new ClickDestroyModule());

        register(new SummonVehicleModule());
        register(new SpammerModule());
        register(new DerpModule());
        register(new AntiKickModule());
        register(new RepeatPacketModule());
        register(new BlinkModule());
        register(new NoPacketModule());
        register(new SoundPlayerModule());
        register(new ClickTpModule());
        register(new ItemCopyModule());
        register(new CrasherModule());
        register(new RemoteShopModule());
        register(new TimerModule());
        register(new FreeCamModule());
        register(new GodModeModule());

        register(new ESPModule());
        register(new TracerModule());
        register(new ItemESPModule());
        register(new ChestESPModule());
        register(new CameraModModule());
        register(new ColorAdjustmentModule());
        register(new ShowPositionModule());
        register(new NoHurtAnimateModule());
        register(new NightVisionModule());
        register(new FogCustomModule());
        register(new SkyCustomModule());
        register(new HitEffectModule());
        register(new MagnifierModule());
        register(new DepthOfFieldModule());
        register(new DrawHaloModule());
        register(new DrawPathModule());
        register(new DrawRangeModule());
        register(new DrawSelectModule());
        register(new SwingAnimationModule());
        register(new FluxSwingModule());
        register(new ShowSwingModule());
        register(new FullBrightModule());
        register(new ThemeModule());
        register(new NotificationsModule());
        register(new WatermarkModule());
        register(new ParticlesAuraModule());
        register(new XrayModule());

        register(new ChestStealerModule());
        register(new BlockReachModule());
        register(new InvManagerModule());
        register(new PseudoKillModule());
        register(new AutoMineModule());
        register(new BoatFlyModule());
        register(new AntiBotModule());
        register(new CrashModule());

        register(new UIDebugModule());
        register(new IslandModule());
        register(new FakeFpsModule());
        register(new ConfigModule());
    }

    private static void register(Module module) {
        modules.add(module);
    }

    public static List<Module> getAllModules() {
        return new ArrayList<>(modules);
    }

    public static List<Module> getModulesByCategory(ModuleCategory category) {
        List<Module> result = new ArrayList<>();
        for (Module module : modules) {
            if (module.getCategory() == category) {
                result.add(module);
            }
        }
        result.sort((a, b) -> a.getName().compareToIgnoreCase(b.getName()));
        return result;
    }

    public static Module getModuleByName(String name) {
        for (Module module : modules) {
            if (module.getName().equalsIgnoreCase(name)) {
                return module;
            }
        }
        return null;
    }

    public static void addToggleListener(ModuleToggleListener listener) {
        listeners.add(listener);
    }

    public static void removeToggleListener(ModuleToggleListener listener) {
        listeners.remove(listener);
    }

    public static void addShortcutListener(ShortcutToggleListener listener) {
        shortcutListeners.add(listener);
    }

    public static void removeShortcutListener(ShortcutToggleListener listener) {
        shortcutListeners.remove(listener);
    }

    public static void notifyModuleToggled(Module module) {
        try {
            if (module.isEnabled()) {
                SoundPlayer.playOnSound();
            } else {
                SoundPlayer.playOffSound();
            }
        } catch (Throwable t) {
        }
        for (ModuleToggleListener listener : listeners) {
            listener.onModuleToggled(module);
        }
    }

    public static void notifyShortcutToggled(Module module, boolean enabled) {
        for (ShortcutToggleListener listener : shortcutListeners) {
            listener.onShortcutToggled(module, enabled);
        }
    }

    public static void disableAll() {
        for (Module module : modules) {
            if (module.isEnabled()) {
                module.disable();
            }
        }
    }

    private ModuleManager() {}
}
