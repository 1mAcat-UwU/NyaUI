package com.nyaui.me.ui;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.util.Log;
import com.nyaui.me.config.ConfigManager;

import java.io.IOException;

public class SoundPlayer {

    private static final String TAG = "SoundPlayer";
    private static SoundPool soundPool;
    private static int onSoundId;
    private static int offSoundId;
    private static boolean isInitialized = false;

    public static void init(Context context) {
        if (isInitialized) return;
        try {
            AudioAttributes attributes = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            soundPool = new SoundPool.Builder()
                    .setMaxStreams(2)
                    .setAudioAttributes(attributes)
                    .build();
            
            
            isInitialized = true;
        } catch (Exception e) {
            Log.e(TAG, "Failed to initialize sound system.", e);
        }
    }

    public static void playOnSound() {
        if (isInitialized && ConfigManager.isSoundEnabled()) {
            
            Log.d(TAG, "Playing ON sound");
        }
    }

    public static void playOffSound() {
        if (isInitialized && ConfigManager.isSoundEnabled()) {
            
            Log.d(TAG, "Playing OFF sound");
        }
    }

    public static void release() {
        if (isInitialized && soundPool != null) {
            soundPool.release();
            soundPool = null;
            isInitialized = false;
        }
    }
}

