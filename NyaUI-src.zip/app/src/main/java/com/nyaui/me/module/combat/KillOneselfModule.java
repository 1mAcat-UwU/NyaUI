package com.nyaui.me.module.combat;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class KillOneselfModule extends Module {
    public KillOneselfModule() { super("KillOneself", ModuleCategory.COMBAT, ""); setChineseName("Kill Self"); }
    @Override public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("KillOneself"); } catch (Throwable t) {} }
    @Override public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("KillOneself"); } catch (Throwable t) {} }
    @Override public void configureSubMenu(SubMenuPanel s) {
        super.configureSubMenu(s);
        s.addSlider("CPS", 1, 8000, (int)SafeCall.getFloat(getName(), 0), "%d", v -> SafeCall.setFloat(getName(), 0, v));
    }
}
