package com.nyaui.me.module.combat;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class TeamsModule extends Module {
    public TeamsModule() { super("Teams", ModuleCategory.COMBAT, ""); setChineseName("Teams"); }
    @Override public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("Teams"); } catch (Throwable t) {} }
    @Override public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("Teams"); } catch (Throwable t) {} }
    @Override public void configureSubMenu(SubMenuPanel s) {
        super.configureSubMenu(s);
        String n = getName();
        int cnt = SafeCall.getModeSize(n, 0); java.util.List<String> modes = new java.util.ArrayList<>(); for (int i = 0; i < cnt; i++) modes.add(SafeCall.getModeString(n, 0, i));
        s.addMode("Detect Mode", modes, SafeCall.getModeValue(n, 0), (index, name) -> SafeCall.setModeValue(n, 0, index));
        s.addSwitch("Ignore Teammates", SafeCall.getBool(n, 0), e -> SafeCall.setBool(n, 0, e));
    }
}
