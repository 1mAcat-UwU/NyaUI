package com.nyaui.me.module.combat;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class KnifeMaceModule extends Module {
    public KnifeMaceModule() { super("KnifeMace", ModuleCategory.COMBAT, ""); setChineseName("Weapon Aura"); }
    @Override public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("KnifeMace"); } catch (Throwable t) {} }
    @Override public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("KnifeMace"); } catch (Throwable t) {} }
    @Override public void configureSubMenu(SubMenuPanel s) {
        super.configureSubMenu(s);
        s.addSlider("Height", 4, 140, (int)SafeCall.getFloat(getName(), 0), "%d", v -> SafeCall.setFloat(getName(), 0, v));
    }
}
