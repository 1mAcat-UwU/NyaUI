package com.nyaui.me.module.settings;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.visual.NotificationsModule;
import com.nyaui.me.module.visual.WatermarkModule;
import com.nyaui.me.ui.CardMenuView;
import com.nyaui.me.ui.PhoenixPopup;
import com.nyaui.me.ui.ThemeManager;
import com.nyaui.me.ui.WatermarkManager;
import com.nyaui.me.ui.widgets.SubMenuPanel;

public class UIDebugModule extends Module {
    public UIDebugModule() {
        super("UIDebug", ModuleCategory.SETTINGS, "");
        setChineseName("UI Debug");
    }

    @Override public boolean shouldShowInArraylist() { return false; }
    @Override public boolean supportsShortcut() { return false; }

    private TextView sizeLabel;

    @Override
    public void configureSubMenu(SubMenuPanel subMenu) {
        super.configureSubMenu(subMenu);
        final Context ctx = subMenu.getContext();
        final SharedPreferences sp = ctx.getSharedPreferences("CardMenuPrefs", Context.MODE_PRIVATE);
        final float d = ctx.getResources().getDisplayMetrics().density;

        subMenu.addSectionTitle("Panel Size");

        sizeLabel = new TextView(ctx);
        sizeLabel.setTextColor(ThemeManager.getTextSecondary());
        sizeLabel.setTextSize(11f);
        sizeLabel.setPadding((int)(4*d), 0, 0, (int)(4*d));
        refreshSizeLabel(sp);
        subMenu.addCustomView(sizeLabel);

        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        row.setPadding(0, (int)(6*d), 0, (int)(6*d));

        TextView resetSize = makeBtn(ctx, "Reset Panel Size", 0xFFFF6B6B, d);
        resetSize.setOnClickListener(v -> {
            CardMenuView menu = PhoenixPopup.getCardMenuView();
            if (menu != null) {
                menu.resetPanelSize(true);
                menu.postDelayed(() -> refreshSizeLabel(sp), 400);
            } else {
                sp.edit().remove("panel_w").remove("panel_h").apply();
                refreshSizeLabel(sp);
            }
            Toast.makeText(ctx, "Panel size reset", Toast.LENGTH_SHORT).show();
        });
        row.addView(resetSize);

        row.addView(gap(ctx, d));

        TextView resetAll = makeBtn(ctx, "Reset All", 0xFFCC3333, d);
        resetAll.setOnClickListener(v -> {
            CardMenuView menu = PhoenixPopup.getCardMenuView();
            if (menu != null) {
                menu.resetAll();
            } else {
                sp.edit().remove("panel_w").remove("panel_h")
                         .putFloat("ui_scale_factor", 0.8f).apply();
            }
            Toast.makeText(ctx, "All reset", Toast.LENGTH_SHORT).show();
        });
        row.addView(resetAll);

        subMenu.addCustomView(row);

        subMenu.addDivider();
        subMenu.addSectionTitle("Scale Adjust");
        subMenu.addText("Applies after drag to avoid rebuilds");

        float curScale = sp.getFloat("ui_scale_factor", 0.8f);
        subMenu.addSlider("UI Scale", 50, 120, (int)(curScale * 100), "%.0f%%", v -> {
            pendingScale = v / 100f;
            sp.edit().putFloat("ui_scale_factor", pendingScale).apply();
        });

        TextView applyScaleBtn = makeBtn(ctx, "Apply Scale", ThemeManager.getThemeColor(), d);
        applyScaleBtn.setOnClickListener(v -> {
            CardMenuView menu = PhoenixPopup.getCardMenuView();
            float target = pendingScale > 0 ? pendingScale : sp.getFloat("ui_scale_factor", 0.8f);
            if (menu != null) menu.applyScale(target);
        });
        LinearLayout applyRow = new LinearLayout(ctx);
        applyRow.setGravity(Gravity.CENTER);
        applyRow.setPadding(0, (int)(6*d), 0, (int)(2*d));
        applyRow.addView(applyScaleBtn);
        subMenu.addCustomView(applyRow);

        subMenu.addDivider();
        subMenu.addSectionTitle("Theme");
        subMenu.addThemeModeSwitch();
        subMenu.addSwitch("Rainbow", ThemeManager.isRainbowModeEnabled(),
            e -> ThemeManager.setRainbowModeEnabled(e));
        subMenu.addDivider();
        subMenu.addThemeButtons();
        subMenu.addDivider();
        subMenu.addCustomView(new com.nyaui.me.ui.widgets.ColorPickerView(ctx));

        subMenu.addDivider();
        subMenu.addSectionTitle("HUD");
        subMenu.addSwitch("Toggle Tips", true, e -> {
            NotificationsModule mod = NotificationsModule.getInstance();
            if (mod != null) { if (e) mod.enable(); else mod.disable(); }
        });
        subMenu.addSwitch("Watermark", true, e -> {
            WatermarkModule mod = WatermarkModule.getInstance();
            if (mod != null) {
                if (e) { mod.enable(); WatermarkManager.show(); }
                else { mod.disable(); WatermarkManager.hide(); }
            }
        });
    }

    private float pendingScale = -1f;

    private void refreshSizeLabel(SharedPreferences sp) {
        if (sizeLabel == null) return;
        CardMenuView menu = PhoenixPopup.getCardMenuView();
        float scale = menu != null ? menu.getScaleFactor() : sp.getFloat("ui_scale_factor", 0.8f);
        int w = menu != null ? menu.getPanelWidth() : sp.getInt("panel_w", 0);
        int h = menu != null ? menu.getPanelHeight() : sp.getInt("panel_h", 0);
        String s = (w > 0 && h > 0)
                ? "Current: " + w + " x " + h + "  ·  Scale " + String.format("%.0f%%", scale * 100)
                : "Current: Default size  ·  Scale " + String.format("%.0f%%", scale * 100);
        sizeLabel.setText(s);
    }

    private View gap(Context ctx, float d) {
        View v = new View(ctx);
        v.setLayoutParams(new LinearLayout.LayoutParams((int)(8*d), 1));
        return v;
    }

    private TextView makeBtn(Context ctx, String text, int color, float d) {
        TextView btn = new TextView(ctx);
        btn.setText(text);
        btn.setTextColor(0xFFFFFFFF);
        btn.setTextSize(10.5f);
        btn.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        btn.setGravity(Gravity.CENTER);
        btn.setPadding((int)(12*d),(int)(7*d),(int)(12*d),(int)(7*d));
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(8*d);
        btn.setBackground(bg);
        btn.setClickable(true);
        return btn;
    }
}
