package com.nyaui.me.module.visual;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.ui.ThemeManager;
import com.nyaui.me.ui.widgets.SubMenuPanel;
import com.nyaui.me.ui.widgets.ColorPickerView;

public class ThemeModule extends Module {
    private static ThemeModule instance;
    public ThemeModule() { super("Theme", ModuleCategory.VISUAL, ""); setChineseName("Theme"); instance = this; }
    public static ThemeModule getInstance() { return instance; }
    @Override public boolean shouldShowInArraylist() { return false; }
    @Override public void configureSubMenu(SubMenuPanel s) {
        super.configureSubMenu(s);
        s.addThemeModeSwitch();
        s.addSwitch("Rainbow", ThemeManager.isRainbowModeEnabled(), e -> ThemeManager.setRainbowModeEnabled(e));
        s.addDivider();
        s.addThemeButtons();
        s.addDivider();
        s.addCustomView(new ColorPickerView(s.getContext()));
    }
}
