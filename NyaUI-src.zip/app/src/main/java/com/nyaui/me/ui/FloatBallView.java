package com.nyaui.me.ui;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.WindowManager;
import android.view.animation.OvershootInterpolator;
import android.widget.LinearLayout;
import android.widget.PopupWindow;

public class FloatBallView extends LinearLayout {

    private final LinearLayout outerBall;
    private final PopupWindow popupWindow;

    public FloatBallView(Context context, PopupWindow popupWindow) {
        super(context);
        this.popupWindow = popupWindow;

        outerBall = new LinearLayout(context);
        int size = (int) (getScreenHeight(context) * 0.05);
        outerBall.setLayoutParams(new LayoutParams(size, size));

        GradientDrawable gradient = new GradientDrawable();
        gradient.setColors(new int[]{ThemeManager.getGradientStart(), ThemeManager.getGradientEnd()});
        gradient.setGradientType(GradientDrawable.LINEAR_GRADIENT);
        gradient.setShape(GradientDrawable.OVAL);
        outerBall.setBackground(gradient);
        outerBall.setGravity(Gravity.CENTER);

        LinearLayout innerBall = new LinearLayout(context);
        int innerSize = (int) (getScreenHeight(context) * 0.03);
        innerBall.setLayoutParams(new LayoutParams(innerSize, innerSize));
        GradientDrawable innerDrawable = new GradientDrawable();
        innerDrawable.setColor(ThemeManager.getTextPrimary());
        innerDrawable.setShape(GradientDrawable.OVAL);
        innerBall.setBackground(innerDrawable);

        outerBall.addView(innerBall);
        addView(outerBall);

        setupTouchListeners();
    }

    private void setupTouchListeners() {
        final float[] downRaw = new float[2];
        final int[] initialPos = new int[2];
        final boolean[] hasMoved = {false};
        final long[] downTime = {0};

        outerBall.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    downRaw[0] = event.getRawX();
                    downRaw[1] = event.getRawY();
                    WindowManager.LayoutParams params = (WindowManager.LayoutParams) getRootView().getLayoutParams();
                    initialPos[0] = params.x;
                    initialPos[1] = params.y;
                    hasMoved[0] = false;
                    downTime[0] = System.currentTimeMillis();
                    v.animate().scaleX(0.85f).scaleY(0.85f).setDuration(80)
                        .setInterpolator(new android.view.animation.PathInterpolator(0.16f, 1f, 0.3f, 1f)).start();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float deltaX = event.getRawX() - downRaw[0];
                    float deltaY = event.getRawY() - downRaw[1];
                    if (!hasMoved[0] && (Math.abs(deltaX) > 10 || Math.abs(deltaY) > 10)) {
                        hasMoved[0] = true;
                    }
                    if (hasMoved[0]) {
                        int newX = initialPos[0] + (int) deltaX;
                        int newY = initialPos[1] + (int) deltaY;
                        popupWindow.update(newX, newY, -1, -1);
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    v.animate().scaleX(1f).scaleY(1f).setDuration(200)
                        .setInterpolator(new android.view.animation.PathInterpolator(0.34f, 1.4f, 0.64f, 1f)).start();
                    if (!hasMoved[0] && System.currentTimeMillis() - downTime[0] < 300) {
                        toggleMenus();
                    }
                    return true;
            }
            return false;
        });
    }

    private void toggleMenus() {
        PhoenixPopup.showMenus();
    }

    public void hide() {
        PhoenixPopup.hideMenus();
        animate().alpha(0f).scaleX(0.8f).scaleY(0.8f).setDuration(200)
            .setInterpolator(new android.view.animation.PathInterpolator(0.4f, 0f, 1f, 1f))
            .withEndAction(() -> setVisibility(GONE)).start();
    }

    public void destroy() {}

    private int getScreenHeight(Context context) {
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics metrics = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(metrics);
        return metrics.heightPixels;
    }
}
