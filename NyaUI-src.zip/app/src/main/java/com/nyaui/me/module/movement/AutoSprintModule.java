package com.nyaui.me.module.movement;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;

public class AutoSprintModule extends Module {
    public AutoSprintModule() { super("AutoSprint", ModuleCategory.MOVEMENT, ""); setChineseName("Auto Sprint"); }
    @Override public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("AutoSprint"); } catch (Throwable t) {} }
    @Override public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("AutoSprint"); } catch (Throwable t) {} }
}
