package com.nyaui.me.module.player;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;

public class PseudoKillModule extends Module {
    public PseudoKillModule() { super("PseudoKill", ModuleCategory.PLAYER, ""); setChineseName("Fake Death"); }
    @Override public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("PseudoKill"); } catch (Throwable t) {} }
    @Override public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("PseudoKill"); } catch (Throwable t) {} }
}
