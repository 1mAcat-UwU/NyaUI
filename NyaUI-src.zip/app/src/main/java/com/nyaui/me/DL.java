package com.nyaui.me;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.widget.*;
import android.view.*;
import android.graphics.drawable.*;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.text.method.PasswordTransformationMethod;
import android.view.inputmethod.InputMethodManager;
import android.provider.Settings;
import android.animation.ValueAnimator;
import android.graphics.*;
import android.util.TypedValue;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.NetworkInterface;
import java.util.Collections;
import java.util.List;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;
import java.util.UUID;
import java.util.Date;
import org.json.JSONObject;
import org.json.JSONException;
import android.content.SharedPreferences;
import android.content.Intent;

public class DL {
    static String wy_url = "https://wy.llua.cn";
    static String WY_APPID = "17042";
    static String WY_APPKEY = "y4s3j686s38Y8Rp4";
    static String WY_RC4KEY = "4uN3r4evawUBHgX";

    static String STORAGE_PATH = "/storage/emulated/0/.km_data";
    static String CONFIG_PATH = "/storage/emulated/0/.config";

    private static Handler mainHandler = new Handler(Looper.getMainLooper());
    static AlertDialog alertDialogss;
    static Context appContext;
    static boolean isAutoLoginChecked = true;
    
    
    public static final String PREF_VIP_EXPIRY = "vip_expiry_time";
    public static final String PREF_KAMI = "saved_kami";
    public static final String PREF_IS_LOGGED_IN = "is_logged_in";

    
    private static final int COLOR_PRIMARY = 0xFF6750A4;
    private static final int COLOR_PRIMARY_CONTAINER = 0xFFEADDFF;
    private static final int COLOR_SECONDARY = 0xFF625B71;
    private static final int COLOR_SECONDARY_CONTAINER = 0xFFE8DEF8;
    private static final int COLOR_SURFACE = 0xFFFFFBFE;
    private static final int COLOR_SURFACE_VARIANT = 0xFFE7E0EC;
    private static final int COLOR_ON_SURFACE = 0xFF1C1B1F;
    private static final int COLOR_OUTLINE = 0xFF79747E;
    private static final int COLOR_ERROR = 0xFFB3261E;

    public static void Start(final Context context) {
        appContext = context;
        
        
        createConfigDirectory();
        
        
        if (isVpnUsed()) {
            showVpnWarning(context);
            return;
        }
        
        
        SharedPreferences prefs = context.getSharedPreferences("DL_Prefs", Context.MODE_PRIVATE);
        boolean isLoggedIn = prefs.getBoolean(PREF_IS_LOGGED_IN, false);
        
        if (isLoggedIn) {
            
            jumpToHiroUI(context);
        } else {
            
            if (tryAutoLogin(context)) {
                return;
            }
            
            
            showMD3LoginDialog(context);
        }
    }
    
    public static void logout(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("DL_Prefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean(PREF_IS_LOGGED_IN, false);
        editor.remove(PREF_KAMI);
        editor.remove(PREF_VIP_EXPIRY);
        editor.apply();
        
        
        writeFile(CONFIG_PATH + "/auto_login", "false");
        new File(STORAGE_PATH).delete();
        
        
        showMD3LoginDialog(context);
    }

    private static void createConfigDirectory() {
        File configDir = new File(CONFIG_PATH);
        if (!configDir.exists()) {
            configDir.mkdirs();
        }
    }

    private static boolean tryAutoLogin(final Context context) {
        
        String autoLoginConfig = readFile(CONFIG_PATH + "/auto_login");
        if (autoLoginConfig == null || !"true".equals(autoLoginConfig.trim())) {
            return false;
        }
        
        
        SharedPreferences prefs = context.getSharedPreferences("DL_Prefs", Context.MODE_PRIVATE);
        String savedKami = prefs.getString(PREF_KAMI, null);
        
        if (savedKami == null || savedKami.trim().isEmpty()) {
            
            savedKami = readFile(STORAGE_PATH);
            if (savedKami != null && !savedKami.trim().isEmpty()) {
                
                SharedPreferences.Editor editor = prefs.edit();
                editor.putString(PREF_KAMI, savedKami);
                editor.apply();
            } else {
                return false;
            }
        }
        
        if (savedKami != null && !savedKami.trim().isEmpty()) {
            
            mainHandler.post(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(context, "Auto logging in...", Toast.LENGTH_SHORT).show();
                }
            });
            
            verifyKami(savedKami, context, new LoginCallback() {
                @Override
                public void onSuccess() {
                    saveLoginState(context, true);
                    saveVipExpiry(context, getLongTermExpiry()); 
                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(context, "Auto login successful", Toast.LENGTH_SHORT).show();
                            jumpToHiroUI(context);
                        }
                    });
                }
                
                @Override
                public void onSuccessWithTime(String vipTime) {
                    saveLoginState(context, true);
                    saveVipExpiry(context, vipTime);
                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(context, "Auto login successful\nExpires: " + vipTime, Toast.LENGTH_LONG).show();
                            jumpToHiroUI(context);
                        }
                    });
                }
                
                @Override
                public void onFailure(String error) {
                    
                    saveLoginState(context, false);
                    writeFile(CONFIG_PATH + "/auto_login", "false");
                    SharedPreferences prefs = context.getSharedPreferences("DL_Prefs", Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = prefs.edit();
                    editor.remove(PREF_KAMI);
                    editor.remove(PREF_VIP_EXPIRY);
                    editor.apply();
                    new File(STORAGE_PATH).delete();
                    
                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            showMD3LoginDialog(context);
                        }
                    });
                }
            });
            return true;
        }
        return false;
    }

    private static void saveLoginState(Context context, boolean isLoggedIn) {
        SharedPreferences prefs = context.getSharedPreferences("DL_Prefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean(PREF_IS_LOGGED_IN, isLoggedIn);
        editor.apply();
    }

    private static void saveVipExpiry(Context context, String expiryTime) {
        SharedPreferences prefs = context.getSharedPreferences("DL_Prefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(PREF_VIP_EXPIRY, expiryTime);
        editor.apply();
    }
    
    public static String getVipExpiry(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("DL_Prefs", Context.MODE_PRIVATE);
        return prefs.getString(PREF_VIP_EXPIRY, null);
    }
    
    
    private static String getLongTermExpiry() {
        try {
            GregorianCalendar gc = new GregorianCalendar();
            gc.setTimeInMillis(System.currentTimeMillis());
            gc.add(GregorianCalendar.YEAR, 100); 
            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            return df.format(gc.getTime());
        } catch (Exception e) {
            return "2099-12-31 23:59:59"; 
        }
    }

    private static void showVpnWarning(final Context context) {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                
                GradientDrawable background = createMD3CardBackground();
                GradientDrawable buttonBackground = createMD3ButtonBackground();
                
                LinearLayout layout = new LinearLayout(context);
                layout.setOrientation(LinearLayout.VERTICAL);
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                );
                layout.setLayoutParams(layoutParams);
                layout.setBackground(background);
                int padding = dpToPx(context, 20);
                layout.setPadding(padding, padding, padding, padding);
                
                
                ImageView icon = new ImageView(context);
                icon.setImageResource(android.R.drawable.ic_dialog_alert);
                icon.setColorFilter(COLOR_ERROR);
                LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(
                    dpToPx(context, 40), dpToPx(context, 40)
                );
                iconParams.gravity = Gravity.CENTER;
                iconParams.bottomMargin = dpToPx(context, 12);
                icon.setLayoutParams(iconParams);
                layout.addView(icon);
                
                
                TextView title = new TextView(context);
                title.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ));
                title.setGravity(Gravity.CENTER);
                title.setText("VPN Detected");
                title.setTextColor(COLOR_ON_SURFACE);
                title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
                title.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
                title.setPadding(0, 0, 0, dpToPx(context, 6));
                layout.addView(title);
                
                
                TextView message = new TextView(context);
                message.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ));
                message.setGravity(Gravity.CENTER);
                message.setText("VPN connection detected. Please disable VPN and try again.");
                message.setTextColor(COLOR_ERROR);
                message.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
                message.setPadding(0, 0, 0, dpToPx(context, 16));
                layout.addView(message);
                
                
                Button button = new Button(context);
                LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    dpToPx(context, 40)
                );
                button.setLayoutParams(btnParams);
                button.setText("Exit");
                button.setTextColor(Color.WHITE);
                button.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
                button.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
                button.setAllCaps(false);
                button.setBackground(buttonBackground);
                
                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        System.exit(0);
                    }
                });
                
                layout.addView(button);
                
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setCancelable(false);
                builder.setView(layout);
                AlertDialog dialog = builder.show();
                
                
                if (dialog.getWindow() != null) {
                    dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
                    dialog.getWindow().setLayout(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    );
                }
            }
        });
    }

    public static void verifyKami(final String kami, final Context context, final LoginCallback callback) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String uuid = getDeviceId(context);
                    Long time = System.currentTimeMillis() / 1000;
                    
                    
                    String signs = encodeMD5("kami=" + kami + "&markcode=" + uuid + "&t=" + time + "&" + WY_APPKEY);
                    String body = "&app=" + WY_APPID + "&kami=" + kami + "&markcode=" + uuid + "&t=" + time + "&sign=" + signs;
                    String submitUrl = wy_url + "/api/?id=kmlogin" + body;
                    
                    String random = UUID.randomUUID().toString().replace("-", "") + WY_APPKEY + uuid;
                    String data = "data=" + RC4Util.encryRC4String(body, WY_RC4KEY, "UTF-8");
                    
                    
                    String response = urlPost(submitUrl + "&app=" + WY_APPID, data + "&value=" + random);
                    
                    if (response == null || response.trim().isEmpty()) {
                        throw new Exception("Server connection failed");
                    }
                    
                    
                    String decrypted = RC4Util.decryRC4(response, WY_RC4KEY, "UTF-8");
                    
                    if (decrypted == null || decrypted.trim().isEmpty()) {
                        throw new Exception("Decrypt failed");
                    }
                    
                    JSONObject jsonObject = new JSONObject(decrypted);
                    
                    
                    String code = jsonObject.optString("v98eb15d45c8bf3f5a8dba93a92ef2fef");
                    String message = jsonObject.optString("w41661199c0dbc259391dd092632e8c39");
                    String check = jsonObject.optString("p64a5d967fdb0b5c472bc89cbc5a4ed34");
                    Long timee = jsonObject.optLong("k9c75ab8d001bb0b12b7a17dd729c2824", 0);
                    
                    
                    if ("42966".equals(code)) {
                        
                        if (!check.equals(encodeMD5(timee.toString() + WY_APPKEY + random))) {
                            callback.onFailure("Invalid operation");
                            return;
                        }
                        
                        
                        if (Math.abs(timee - time) > 30) {
                            callback.onFailure("Data expired");
                            return;
                        }
                        
                        
                        JSONObject dataJson = new JSONObject(message);
                        Long vip = dataJson.optLong("i12e1399046978c7fde12bb36ffa6dc40", 0);
                        
                        if (vip > 0) {
                            GregorianCalendar gc = new GregorianCalendar();
                            gc.setTimeInMillis(vip * 1000);
                            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                            final String vipTime = df.format(gc.getTime());
                            
                            callback.onSuccessWithTime(vipTime);
                        } else {
                            callback.onSuccess();
                        }
                    } else {
                        
                        String errorMsg = jsonObject.optString("msg", message);
                        callback.onFailure(errorMsg.isEmpty() ? "Login failed" : errorMsg);
                    }
                    
                } catch (JSONException e) {
                    callback.onFailure("Invalid server response");
                } catch (Exception e) {
                    callback.onFailure("Network error: " + e.getMessage());
                }
            }
        }).start();
    }

    private static void showMD3LoginDialog(final Context context) {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                
                LinearLayout mainLayout = new LinearLayout(context);
                mainLayout.setOrientation(LinearLayout.VERTICAL);
                LinearLayout.LayoutParams mainParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                );
                mainLayout.setLayoutParams(mainParams);
                int padding = dpToPx(context, 24);
                mainLayout.setPadding(padding, padding, padding, padding);
                mainLayout.setBackground(createMD3SurfaceBackground());
                
                
                TextView title = new TextView(context);
                LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                );
                titleParams.bottomMargin = dpToPx(context, 20);
                title.setLayoutParams(titleParams);
                title.setGravity(Gravity.CENTER);
                title.setText("Welcome");
                title.setTextColor(COLOR_ON_SURFACE);
                title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
                title.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
                mainLayout.addView(title);
                
                
                TextView subtitle = new TextView(context);
                LinearLayout.LayoutParams subtitleParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                );
                subtitleParams.bottomMargin = dpToPx(context, 24);
                subtitle.setLayoutParams(subtitleParams);
                subtitle.setGravity(Gravity.CENTER);
                subtitle.setText("Please log in to continue");
                subtitle.setTextColor(COLOR_ON_SURFACE);
                subtitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
                subtitle.setAlpha(0.6f);
                mainLayout.addView(subtitle);
                
                
                LinearLayout inputContainer = new LinearLayout(context);
                inputContainer.setOrientation(LinearLayout.VERTICAL);
                inputContainer.setLayoutParams(new LinearLayout.LayoutParams(
                    dpToPx(context, 465),
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ));
                
                
                final EditText kamiEdit = createMD3EditText(context, "Enter license key");
                LinearLayout.LayoutParams editParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    dpToPx(context, 60)
                );
                editParams.bottomMargin = dpToPx(context, 12);
                kamiEdit.setLayoutParams(editParams);
                
                kamiEdit.setPadding(dpToPx(context, 16), dpToPx(context, 16),
                                   dpToPx(context, 52), dpToPx(context, 16));
                
                
                SharedPreferences prefs = context.getSharedPreferences("DL_Prefs", Context.MODE_PRIVATE);
                String savedKami = prefs.getString(PREF_KAMI, null);
                if (savedKami == null) {
                    savedKami = readFile(STORAGE_PATH);
                }
                if (savedKami != null && !savedKami.trim().isEmpty()) {
                    kamiEdit.setText(savedKami);
                }
                
                
                ImageButton togglePassword = new ImageButton(context);
                togglePassword.setLayoutParams(new LinearLayout.LayoutParams(
                    dpToPx(context, 40), dpToPx(context, 40)
                ));
                togglePassword.setBackgroundResource(android.R.color.transparent);
                togglePassword.setImageResource(android.R.drawable.ic_menu_view);
                togglePassword.setColorFilter(COLOR_OUTLINE);
                togglePadding(togglePassword, dpToPx(context, 8));
                
                togglePassword.setOnClickListener(new View.OnClickListener() {
                    boolean isPasswordVisible = false;
                    
                    @Override
                    public void onClick(View v) {
                        isPasswordVisible = !isPasswordVisible;
                        if (isPasswordVisible) {
                            kamiEdit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                            togglePassword.setImageResource(android.R.drawable.ic_menu_recent_history);
                        } else {
                            kamiEdit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                            togglePassword.setImageResource(android.R.drawable.ic_menu_view);
                        }
                        
                        kamiEdit.setSelection(kamiEdit.getText().length());
                    }
                });
                
                
                RelativeLayout editLayout = new RelativeLayout(context);
                editLayout.setLayoutParams(editParams);
                editLayout.addView(kamiEdit);
                
                RelativeLayout.LayoutParams toggleParams = new RelativeLayout.LayoutParams(
                    RelativeLayout.LayoutParams.WRAP_CONTENT,
                    RelativeLayout.LayoutParams.WRAP_CONTENT
                );
                toggleParams.addRule(RelativeLayout.ALIGN_PARENT_END);
                toggleParams.addRule(RelativeLayout.CENTER_VERTICAL);
                toggleParams.rightMargin = dpToPx(context, 12);
                togglePassword.setLayoutParams(toggleParams);
                editLayout.addView(togglePassword);
                inputContainer.addView(editLayout);
                
                
                final CheckBox autoLoginSwitch = new CheckBox(context);
                autoLoginSwitch.setText("Auto Login");
                autoLoginSwitch.setTextColor(COLOR_ON_SURFACE);
                autoLoginSwitch.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
                
                String autoLoginConfig = readFile(CONFIG_PATH + "/auto_login");
                isAutoLoginChecked = autoLoginConfig != null && "true".equals(autoLoginConfig.trim());
                autoLoginSwitch.setChecked(isAutoLoginChecked);
                autoLoginSwitch.setPadding(0, dpToPx(context, 8), 0, dpToPx(context, 8));
                inputContainer.addView(autoLoginSwitch);
                
                mainLayout.addView(inputContainer);
                
                
                LinearLayout buttonContainer = new LinearLayout(context);
                buttonContainer.setOrientation(LinearLayout.HORIZONTAL);
                buttonContainer.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ));
                buttonContainer.setPadding(0, dpToPx(context, 16), 0, 0);
                
                
                final Button loginButton = new Button(context);
                LinearLayout.LayoutParams loginBtnParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(context, 44)
                );
                loginButton.setLayoutParams(loginBtnParams);
                loginButton.setText("Login");
                loginButton.setTextColor(Color.WHITE);
                loginButton.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
                loginButton.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
                loginButton.setAllCaps(false);
                GradientDrawable loginBg = new GradientDrawable();
                loginBg.setCornerRadius(dpToPx(context, 22));
                loginBg.setColor(COLOR_PRIMARY);
                loginButton.setBackground(loginBg);
                
                buttonContainer.addView(loginButton);
                mainLayout.addView(buttonContainer);
                
                
                TextView bottomText = new TextView(context);
                LinearLayout.LayoutParams bottomParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                );
                bottomParams.topMargin = dpToPx(context, 16);
                bottomText.setLayoutParams(bottomParams);
                bottomText.setGravity(Gravity.CENTER);
                bottomText.setText("Need help? Contact support");
                bottomText.setTextColor(COLOR_OUTLINE);
                bottomText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
                bottomText.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast.makeText(context, "Support feature coming soon", Toast.LENGTH_SHORT).show();
                    }
                });
                mainLayout.addView(bottomText);
                
                
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setCancelable(false);
                builder.setView(mainLayout);
                alertDialogss = builder.create();
                
                
                if (alertDialogss.getWindow() != null) {
                    alertDialogss.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
                    alertDialogss.getWindow().setDimAmount(0.3f);
                    alertDialogss.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
                    alertDialogss.getWindow().setLayout(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    );
                    alertDialogss.getWindow().setGravity(Gravity.CENTER);
                }
                
                
                loginButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        
                        InputMethodManager imm = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
                        if (imm != null && v.getWindowToken() != null) {
                            imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
                        }
                        
                        final String inputKami = kamiEdit.getText().toString().trim();
                        if (inputKami.isEmpty()) {
                            showMD3Error(context, "License key cannot be empty");
                            return;
                        }
                        
                        
                        isAutoLoginChecked = autoLoginSwitch.isChecked();
                        writeFile(CONFIG_PATH + "/auto_login", String.valueOf(isAutoLoginChecked));
                        
                        
                        ValueAnimator animator = ValueAnimator.ofFloat(1f, 0.7f, 1f);
                        animator.setDuration(200);
                        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                            @Override
                            public void onAnimationUpdate(ValueAnimator animation) {
                                float value = (float) animation.getAnimatedValue();
                                loginButton.setScaleX(value);
                                loginButton.setScaleY(value);
                            }
                        });
                        animator.start();
                        
                        loginButton.setText("Verifying...");
                        loginButton.setEnabled(false);
                        
                        verifyKami(inputKami, context, new LoginCallback() {
                            @Override
                            public void onSuccess() {
                                
                                SharedPreferences prefs = context.getSharedPreferences("DL_Prefs", Context.MODE_PRIVATE);
                                SharedPreferences.Editor editor = prefs.edit();
                                
                                
                                editor.putString(PREF_KAMI, inputKami);
                                
                                editor.putBoolean(PREF_IS_LOGGED_IN, true);
                                editor.apply();
                                
                                
                                saveVipExpiry(context, getLongTermExpiry());
                                
                                mainHandler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        loginButton.setText("Login successful");
                                        loginButton.setEnabled(true);
                                        
                                        
                                        if (isAutoLoginChecked) {
                                            writeFile(STORAGE_PATH, inputKami);
                                        } else {
                                            new File(STORAGE_PATH).delete();
                                        }
                                        
                                        
                                        if (alertDialogss != null && alertDialogss.isShowing()) {
                                            alertDialogss.dismiss();
                                        }
                                        
                                        
                                        jumpToHiroUI(context);
                                    }
                                });
                            }
                            
                            @Override
                            public void onSuccessWithTime(String vipTime) {
                                
                                SharedPreferences prefs = context.getSharedPreferences("DL_Prefs", Context.MODE_PRIVATE);
                                SharedPreferences.Editor editor = prefs.edit();
                                
                                
                                editor.putString(PREF_KAMI, inputKami);
                                
                                editor.putBoolean(PREF_IS_LOGGED_IN, true);
                                editor.apply();
                                
                                
                                saveVipExpiry(context, vipTime);
                                
                                mainHandler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        loginButton.setText("Login successful");
                                        loginButton.setEnabled(true);
                                        
                                        
                                        Toast.makeText(context, "Expires: " + vipTime, Toast.LENGTH_LONG).show();
                                        
                                        if (isAutoLoginChecked) {
                                            writeFile(STORAGE_PATH, inputKami);
                                        } else {
                                            new File(STORAGE_PATH).delete();
                                        }
                                        
                                        if (alertDialogss != null && alertDialogss.isShowing()) {
                                            alertDialogss.dismiss();
                                        }
                                        
                                        
                                        jumpToHiroUI(context);
                                    }
                                });
                            }
                            
                            @Override
                            public void onFailure(final String error) {
                                mainHandler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        loginButton.setText("Login");
                                        loginButton.setEnabled(true);
                                        showMD3Error(context, error);
                                    }
                                });
                            }
                        });
                    }
                });
                
                
                alertDialogss.show();
                
                
                mainHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (kamiEdit != null) {
                            kamiEdit.requestFocus();
                            InputMethodManager imm = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
                            if (imm != null) {
                                imm.showSoftInput(kamiEdit, InputMethodManager.SHOW_IMPLICIT);
                            }
                        }
                    }
                }, 300);
            }
        });
    }
    
    private static void showMD3Error(Context context, String message) {
        
        GradientDrawable background = createMD3ErrorBackground();
        
        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dpToPx(context, 40)
        ));
        layout.setBackground(background);
        layout.setPadding(dpToPx(context, 12), 0, dpToPx(context, 12), 0);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        
        ImageView icon = new ImageView(context);
        icon.setImageResource(android.R.drawable.ic_dialog_alert);
        icon.setColorFilter(Color.WHITE);
        icon.setLayoutParams(new LinearLayout.LayoutParams(
            dpToPx(context, 20), dpToPx(context, 20)
        ));
        layout.addView(icon);
        
        TextView text = new TextView(context);
        LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT
        );
        textParams.weight = 1;
        textParams.leftMargin = dpToPx(context, 8);
        text.setLayoutParams(textParams);
        text.setText(message);
        text.setTextColor(Color.WHITE);
        text.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        layout.addView(text);
        
        Toast toast = new Toast(context);
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setView(layout);
        toast.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL, 0, dpToPx(context, 60));
        toast.show();
    }
    
    
    private static void jumpToHiroUI(final Context context) {
        try {
            final Activity activity;
            
            
            if (appContext instanceof Activity) {
                activity = (Activity) appContext;
            } else if (context instanceof Activity) {
                activity = (Activity) context;
            } else {
                
                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(context, "Login successful. Please restart the app", Toast.LENGTH_SHORT).show();
                    }
                });
                return;
            }
            
            
            mainHandler.post(new Runnable() {
                @Override
                public void run() {
                    try {
                        
                        if (activity.isFinishing() || activity.isDestroyed()) {
                            return;
                        }
                        
                        
                        HiroUI hiroUI = new HiroUI(activity);
                        hiroUI.show();
                        
                        
                        Toast.makeText(activity, "Welcome", Toast.LENGTH_SHORT).show();
                        
                    } catch (Exception e) {
                        e.printStackTrace();
                        
                        Toast.makeText(context, "Failed to load UI: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        
                        showMD3LoginDialog(context);
                    }
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
            
            mainHandler.post(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(context, "Unknown error，Please log in again", Toast.LENGTH_SHORT).show();
                    showMD3LoginDialog(context);
                }
            });
        }
    }
    
    
    private static EditText createMD3EditText(Context context, String hint) {
        EditText editText = new EditText(context);
        editText.setHint(hint);
        editText.setTextColor(COLOR_ON_SURFACE);
        editText.setHintTextColor(COLOR_OUTLINE);
        editText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        editText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        editText.setTransformationMethod(PasswordTransformationMethod.getInstance());
        editText.setBackground(createMD3EditTextBackground());
        editText.setPadding(dpToPx(context, 16), dpToPx(context, 16),
                           dpToPx(context, 52), dpToPx(context, 16));
        editText.setMinHeight(dpToPx(context, 56));
        return editText;
    }
    
    private static GradientDrawable createMD3SurfaceBackground() {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(COLOR_SURFACE);
        gd.setCornerRadius(dpToPx(appContext, 16));
        gd.setStroke(dpToPx(appContext, 1), COLOR_SURFACE_VARIANT);
        return gd;
    }
    
    private static GradientDrawable createMD3CardBackground() {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(COLOR_SURFACE);
        gd.setCornerRadius(dpToPx(appContext, 12));
        gd.setStroke(dpToPx(appContext, 1), COLOR_SURFACE_VARIANT);
        return gd;
    }
    
    private static GradientDrawable createMD3EditTextBackground() {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.TRANSPARENT);
        gd.setCornerRadius(dpToPx(appContext, 12));
        gd.setStroke(dpToPx(appContext, 1), COLOR_OUTLINE);
        return gd;
    }
    
    private static GradientDrawable createMD3ButtonBackground() {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(COLOR_PRIMARY);
        gd.setCornerRadius(dpToPx(appContext, 20));
        return gd;
    }
    
    private static GradientDrawable createMD3ErrorBackground() {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(COLOR_ERROR);
        gd.setCornerRadius(dpToPx(appContext, 20));
        return gd;
    }
    
    private static void togglePadding(View view, int padding) {
        view.setPadding(padding, padding, padding, padding);
    }
    
    private static int dpToPx(Context context, int dp) {
        return (int) (dp * context.getResources().getDisplayMetrics().density);
    }

    public static String getDeviceId(Context context) {
        return Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
    }

    public static boolean isVpnUsed() {
        try {
            List<NetworkInterface> nis = Collections.list(NetworkInterface.getNetworkInterfaces());
            if (nis != null) {
                for (NetworkInterface intf : nis) {
                    if (!intf.isUp() || intf.getInterfaceAddresses().size() == 0) {
                        continue;
                    }
                    if ("tun0".equals(intf.getName()) || "ppp0".equals(intf.getName())) {
                        return true;
                    }
                }
            }
        } catch (Throwable e) {
            e.printStackTrace();
        }
        return false;
    }

    public static String urlPost(String ur, String byteString) {
        StringBuilder result = new StringBuilder();
        try {
            URL url = new URL(ur);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setReadTimeout(9000);
            conn.setConnectTimeout(9000);
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

            OutputStream os = conn.getOutputStream();
            os.write(byteString.getBytes("UTF-8"));
            os.flush();
            os.close();

            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
            String line;
            while ((line = br.readLine()) != null) {
                result.append(line);
            }
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result.toString();
    }

    public static String encodeMD5(String str) {
        try {
            MessageDigest md5 = MessageDigest.getInstance("MD5");
            md5.update(str.getBytes("UTF-8"));
            byte[] digest = md5.digest();
            StringBuilder sb = new StringBuilder();
            for (byte b : digest) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    public static void writeFile(String path, String content) {
        try {
            File file = new File(path);
            File parent = file.getParentFile();
            if (parent != null && !parent.exists()) {
                parent.mkdirs();
            }
            FileWriter writer = new FileWriter(file, false);
            writer.write(content);
            writer.flush();
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static String readFile(String path) {
        StringBuilder content = new StringBuilder();
        try {
            File file = new File(path);
            if (!file.exists()) {
                return null;
            }
            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"));
            String line;
            while ((line = br.readLine()) != null) {
                content.append(line);
            }
            br.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return content.toString();
    }

    
    public interface LoginCallback {
        void onSuccess();
        void onSuccessWithTime(String vipTime);
        void onFailure(String error);
    }
    
    
    public static class RC4Util {
        public static String encryRC4String(String data, String key, String charset) {
            if (data == null || key == null) {
                return null;
            }
            try {
                return toHexString(asString(encryRC4Byte(data, key, charset)));
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }
        
        public static String decryRC4(String data, String key, String charset) {
            if (data == null || key == null) {
                return null;
            }
            try {
                byte[] bytes = decryRC4Byte(hexString2Bytes(data), key);
                if (bytes == null) return null;
                return new String(bytes, charset);
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }
        
        private static String toHexString(String s) {
            String str = "";
            for (int i = 0; i < s.length(); i++) {
                int ch = (int) s.charAt(i);
                String s4 = Integer.toHexString(ch & 0xFF);
                if (s4.length() == 1) {
                    s4 = '0' + s4;
                }
                str = str + s4;
            }
            return str;
        }
        
        private static byte[] hexString2Bytes(String src) {
            if (src == null || src.length() == 0) {
                return null;
            }
            int size = src.length();
            if (size % 2 != 0) {
                return null;
            }
            byte[] ret = new byte[size / 2];
            for (int i = 0; i < size; i = i + 2) {
                ret[i / 2] = (byte) Integer.parseInt(src.substring(i, i + 2), 16);
            }
            return ret;
        }
        
        private static String asString(byte[] buf) {
            if (buf == null) return null;
            StringBuffer strbuf = new StringBuffer(buf.length);
            for (int i = 0; i < buf.length; i++) {
                strbuf.append((char) buf[i]);
            }
            return strbuf.toString();
        }
        
        private static byte[] encryRC4Byte(String data, String key, String charset) {
            if (data == null || key == null) {
                return null;
            }
            byte[] b_data = null;
            try {
                b_data = data.getBytes(charset);
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
            return RC4Base(b_data, key);
        }
        
        private static byte[] decryRC4Byte(byte[] data, String key) {
            if (data == null || key == null) {
                return null;
            }
            return RC4Base(data, key);
        }
        
        private static byte[] initKey(String aKey) {
            if (aKey == null) return null;
            byte[] b_key = aKey.getBytes();
            byte[] state = new byte[256];
            for (int i = 0; i < 256; i++) {
                state[i] = (byte) i;
            }
            int index1 = 0;
            int index2 = 0;
            if (b_key.length == 0) {
                return null;
            }
            for (int i = 0; i < 256; i++) {
                index2 = ((b_key[index1] & 0xff) + (state[i] & 0xff) + index2) & 0xff;
                byte tmp = state[i];
                state[i] = state[index2];
                state[index2] = tmp;
                index1 = (index1 + 1) % b_key.length;
            }
            return state;
        }
        
        private static byte[] RC4Base(byte[] input, String mKkey) {
            if (input == null || mKkey == null) return null;
            
            int x = 0;
            int y = 0;
            byte[] key = initKey(mKkey);
            if (key == null) return null;
            
            byte[] result = new byte[input.length];
            for (int i = 0; i < input.length; i++) {
                x = (x + 1) & 0xff;
                y = ((key[x] & 0xff) + y) & 0xff;
                byte tmp = key[x];
                key[x] = key[y];
                key[y] = tmp;
                int xorIndex = ((key[x] & 0xff) + (key[y] & 0xff)) & 0xff;
                result[i] = (byte) (input[i] ^ key[xorIndex]);
            }
            return result;
        }
    }
}