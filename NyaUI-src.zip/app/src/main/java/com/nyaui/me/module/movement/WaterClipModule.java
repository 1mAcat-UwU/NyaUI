package com.nyaui.me.module.movement;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;

public class WaterClipModule extends Module {
    public WaterClipModule() { super("WaterClip", ModuleCategory.MOVEMENT, ""); setChineseName("Jesus"); }
    @Override public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("WaterClip"); } catch (Throwable t) {} }
    @Override public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("WaterClip"); } catch (Throwable t) {} }
}
