package com.nyaui.me.module.movement;

import com.nyaui.me.module.Module;
import com.nyaui.me.module.ModuleCategory;
import com.nyaui.me.module.SafeCall;

public class TWapModule extends Module {
    public TWapModule() { super("TWap", ModuleCategory.MOVEMENT, ""); setChineseName("TWap"); }
    @Override public void onEnable() { super.onEnable(); try { SafeCall.setEnabled("TWap"); } catch (Throwable t) {} }
    @Override public void onDisable() { super.onDisable(); try { SafeCall.setEnabled("TWap"); } catch (Throwable t) {} }
}
